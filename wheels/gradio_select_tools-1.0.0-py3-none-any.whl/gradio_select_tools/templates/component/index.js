import { i as Me, g as ue, o as ke, a as lt, b as Ie, T as Pe, c as Re, d as Le, e as _t, f as Ot, r as Ae, h as ut, p as Ne, j as Ct, m as Oe, s as Ce, k as It, E as Pt, L as Te, N as Be, l as $e, n as je, q as ze, u as J, t as De, S as Ke, v as Fe, w as Ge, x as it, y as He, z as Y, A as de, B as xt, C as L, D as st, F as Tt, G as bt, H as Ye, I as qe, J as Ue, K as We, M as W, O as Bt, P as X, Q as Xe, R as Ve } from "./render-BKVekDVV.js";
function pe(n) {
  throw new Error("https://svelte.dev/e/lifecycle_outside_component");
}
const Qe = [];
function Je(n, t = !1, e = !1) {
  return nt(n, /* @__PURE__ */ new Map(), "", Qe, null, e);
}
function nt(n, t, e, i, s = null, r = !1) {
  if (typeof n == "object" && n !== null) {
    var o = t.get(n);
    if (o !== void 0) return o;
    if (n instanceof Map) return (
      /** @type {Snapshot<T>} */
      new Map(n)
    );
    if (n instanceof Set) return (
      /** @type {Snapshot<T>} */
      new Set(n)
    );
    if (Me(n)) {
      var l = (
        /** @type {Snapshot<any>} */
        Array(n.length)
      );
      t.set(n, l), s !== null && t.set(s, l);
      for (var a = 0; a < n.length; a += 1) {
        var c = n[a];
        a in n && (l[a] = nt(c, t, e, i, null, r));
      }
      return l;
    }
    if (ue(n) === ke) {
      l = {}, t.set(n, l), s !== null && t.set(s, l);
      for (var d in n)
        l[d] = nt(
          // @ts-expect-error
          n[d],
          t,
          e,
          i,
          null,
          r
        );
      return l;
    }
    if (n instanceof Date)
      return (
        /** @type {Snapshot<T>} */
        structuredClone(n)
      );
    if (typeof /** @type {T & { toJSON?: any } } */
    n.toJSON == "function" && !r)
      return nt(
        /** @type {T & { toJSON(): any } } */
        n.toJSON(),
        t,
        e,
        i,
        // Associate the instance with the toJSON clone
        n
      );
  }
  if (n instanceof EventTarget)
    return (
      /** @type {Snapshot<T>} */
      n
    );
  try {
    return (
      /** @type {Snapshot<T>} */
      structuredClone(n)
    );
  } catch {
    return (
      /** @type {Snapshot<T>} */
      n
    );
  }
}
function ge(n) {
  var t = document.createElement("template");
  return t.innerHTML = n.replaceAll("<!>", "<!---->"), t.content;
}
function ht(n, t) {
  var e = (
    /** @type {Effect} */
    Le
  );
  e.nodes === null && (e.nodes = { start: n, end: t, a: null, t: null });
}
// @__NO_SIDE_EFFECTS__
function Rt(n, t) {
  var e = (t & Pe) !== 0, i = (t & Re) !== 0, s, r = !n.startsWith("<!>");
  return () => {
    s === void 0 && (s = ge(r ? n : "<!>" + n), e || (s = /** @type {TemplateNode} */
    lt(s)));
    var o = (
      /** @type {TemplateNode} */
      i || Ie ? document.importNode(s, !0) : s.cloneNode(!0)
    );
    if (e) {
      var l = (
        /** @type {TemplateNode} */
        lt(o)
      ), a = (
        /** @type {TemplateNode} */
        o.lastChild
      );
      ht(l, a);
    } else
      ht(o, o);
    return o;
  };
}
// @__NO_SIDE_EFFECTS__
function Ze(n, t, e = "svg") {
  var i = !n.startsWith("<!>"), s = `<${e}>${i ? n : "<!>" + n}</${e}>`, r;
  return () => {
    if (!r) {
      var o = (
        /** @type {DocumentFragment} */
        ge(s)
      ), l = (
        /** @type {Element} */
        lt(o)
      );
      r = /** @type {Element} */
      lt(l);
    }
    var a = (
      /** @type {TemplateNode} */
      r.cloneNode(!0)
    );
    return ht(a, a), a;
  };
}
// @__NO_SIDE_EFFECTS__
function ft(n, t) {
  return /* @__PURE__ */ Ze(n, t, "svg");
}
function ti() {
  var n = document.createDocumentFragment(), t = document.createComment(""), e = _t();
  return n.append(t, e), ht(t, e), n;
}
function D(n, t) {
  n !== null && n.before(
    /** @type {Node} */
    t
  );
}
class Lt {
  /** @type {TemplateNode} */
  anchor;
  /** @type {Map<Batch, Key>} */
  #t = /* @__PURE__ */ new Map();
  /**
   * Map of keys to effects that are currently rendered in the DOM.
   * These effects are visible and actively part of the document tree.
   * Example:
   * ```
   * {#if condition}
   * 	foo
   * {:else}
   * 	bar
   * {/if}
   * ```
   * Can result in the entries `true->Effect` and `false->Effect`
   * @type {Map<Key, Effect>}
   */
  #e = /* @__PURE__ */ new Map();
  /**
   * Similar to #onscreen with respect to the keys, but contains branches that are not yet
   * in the DOM, because their insertion is deferred.
   * @type {Map<Key, Branch>}
   */
  #i = /* @__PURE__ */ new Map();
  /**
   * Keys of effects that are currently outroing
   * @type {Set<Key>}
   */
  #h = /* @__PURE__ */ new Set();
  /**
   * Whether to pause (i.e. outro) on change, or destroy immediately.
   * This is necessary for `<svelte:element>`
   */
  #c = !0;
  /**
   * @param {TemplateNode} anchor
   * @param {boolean} transition
   */
  constructor(t, e = !0) {
    this.anchor = t, this.#c = e;
  }
  #p = () => {
    var t = (
      /** @type {Batch} */
      Ot
    );
    if (this.#t.has(t)) {
      var e = (
        /** @type {Key} */
        this.#t.get(t)
      ), i = this.#e.get(e);
      if (i)
        Ae(i), this.#h.delete(e);
      else {
        var s = this.#i.get(e);
        s && (this.#e.set(e, s.effect), this.#i.delete(e), s.fragment.lastChild.remove(), this.anchor.before(s.fragment), i = s.effect);
      }
      for (const [r, o] of this.#t) {
        if (this.#t.delete(r), r === t)
          break;
        const l = this.#i.get(o);
        l && (ut(l.effect), this.#i.delete(o));
      }
      for (const [r, o] of this.#e) {
        if (r === e || this.#h.has(r)) continue;
        const l = () => {
          if (Array.from(this.#t.values()).includes(r)) {
            var c = document.createDocumentFragment();
            Oe(o, c), c.append(_t()), this.#i.set(r, { effect: o, fragment: c });
          } else
            ut(o);
          this.#h.delete(r), this.#e.delete(r);
        };
        this.#c || !i ? (this.#h.add(r), Ne(o, l, !1)) : l();
      }
    }
  };
  /**
   * @param {Batch} batch
   */
  #g = (t) => {
    this.#t.delete(t);
    const e = Array.from(this.#t.values());
    for (const [i, s] of this.#i)
      e.includes(i) || (ut(s.effect), this.#i.delete(i));
  };
  /**
   *
   * @param {any} key
   * @param {null | ((target: TemplateNode) => void)} fn
   */
  ensure(t, e) {
    var i = (
      /** @type {Batch} */
      Ot
    ), s = Ce();
    if (e && !this.#e.has(t) && !this.#i.has(t))
      if (s) {
        var r = document.createDocumentFragment(), o = _t();
        r.append(o), this.#i.set(t, {
          effect: Ct(() => e(o)),
          fragment: r
        });
      } else
        this.#e.set(
          t,
          Ct(() => e(this.anchor))
        );
    if (this.#t.set(i, t), s) {
      for (const [l, a] of this.#e)
        l === t ? i.skipped_effects.delete(a) : i.skipped_effects.add(a);
      for (const [l, a] of this.#i)
        l === t ? i.skipped_effects.delete(a.effect) : i.skipped_effects.add(a.effect);
      i.oncommit(this.#p), i.ondiscard(this.#g);
    } else
      this.#p();
  }
}
function $t(n, t, e = !1) {
  var i = new Lt(n), s = e ? Pt : 0;
  function r(o, l) {
    i.ensure(o, l);
  }
  It(() => {
    var o = !1;
    t((l, a = !0) => {
      o = !0, r(a, l);
    }), o || r(!1, null);
  }, s);
}
function ei(n, t, ...e) {
  var i = new Lt(n);
  It(() => {
    const s = t() ?? null;
    i.ensure(s, s && ((r) => s(r, ...e)));
  }, Pt);
}
function ii(n, t, e) {
  var i = new Lt(n);
  It(() => {
    var s = t() ?? null;
    i.ensure(s, s && ((r) => e(r, s)));
  }, Pt);
}
const jt = [...` 	
\r\f \v\uFEFF`];
function si(n, t, e) {
  var i = n == null ? "" : "" + n;
  if (e) {
    for (var s in e)
      if (e[s])
        i = i ? i + " " + s : s;
      else if (i.length)
        for (var r = s.length, o = 0; (o = i.indexOf(s, o)) >= 0; ) {
          var l = o + r;
          (o === 0 || jt.includes(i[o - 1])) && (l === i.length || jt.includes(i[l])) ? i = (o === 0 ? "" : i.substring(0, o)) + i.substring(l + 1) : o = l;
        }
  }
  return i === "" ? null : i;
}
function zt(n, t = !1) {
  var e = t ? " !important;" : ";", i = "";
  for (var s in n) {
    var r = n[s];
    r != null && r !== "" && (i += " " + s + ": " + r + e);
  }
  return i;
}
function ni(n, t) {
  if (t) {
    var e = "", i, s;
    return Array.isArray(t) ? (i = t[0], s = t[1]) : i = t, i && (e += zt(i)), s && (e += zt(s, !0)), e = e.trim(), e === "" ? null : e;
  }
  return String(n);
}
function Dt(n, t, e, i, s, r) {
  var o = n.__className;
  if (o !== e || o === void 0) {
    var l = si(e, i, r);
    l == null ? n.removeAttribute("class") : n.className = l, n.__className = e;
  } else if (r && s !== r)
    for (var a in r) {
      var c = !!r[a];
      (s == null || c !== !!s[a]) && n.classList.toggle(a, c);
    }
  return r;
}
function dt(n, t = {}, e, i) {
  for (var s in e) {
    var r = e[s];
    t[s] !== r && (e[s] == null ? n.style.removeProperty(s) : n.style.setProperty(s, r, i));
  }
}
function ri(n, t, e, i) {
  var s = n.__style;
  if (s !== t) {
    var r = ni(t, i);
    r == null ? n.removeAttribute("style") : n.style.cssText = r, n.__style = t;
  } else i && (Array.isArray(i) ? (dt(n, e?.[0], i[0]), dt(n, e?.[1], i[1], "important")) : dt(n, e, i));
  return i;
}
const oi = /* @__PURE__ */ Symbol("is custom element"), li = /* @__PURE__ */ Symbol("is html");
function rt(n, t, e, i) {
  var s = hi(n);
  s[t] !== (s[t] = e) && (t === "loading" && (n[Te] = e), e == null ? n.removeAttribute(t) : typeof e != "string" && ai(n).includes(t) ? n[t] = e : n.setAttribute(t, e));
}
function hi(n) {
  return (
    /** @type {Record<string | symbol, unknown>} **/
    // @ts-expect-error
    n.__attributes ??= {
      [oi]: n.nodeName.includes("-"),
      [li]: n.namespaceURI === Be
    }
  );
}
var Kt = /* @__PURE__ */ new Map();
function ai(n) {
  var t = n.getAttribute("is") || n.nodeName, e = Kt.get(t);
  if (e) return e;
  Kt.set(t, e = []);
  for (var i, s = n, r = Element.prototype; r !== s; ) {
    i = $e(s);
    for (var o in i)
      i[o].set && e.push(o);
    s = ue(s);
  }
  return e;
}
function Ft(n, t) {
  return n === t || n?.[Ke] === t;
}
function ci(n = {}, t, e, i) {
  return je(() => {
    var s, r;
    return ze(() => {
      s = r, r = [], J(() => {
        n !== e(...r) && (t(n, ...r), s && Ft(e(...s), n) && t(null, ...s));
      });
    }), () => {
      De(() => {
        r && Ft(e(...r), n) && t(null, ...r);
      });
    };
  }), n;
}
function fi(n, t, e) {
  if (n == null)
    return t(void 0), Fe;
  const i = J(
    () => n.subscribe(
      t,
      // @ts-expect-error
      e
    )
  );
  return i.unsubscribe ? () => i.unsubscribe() : i;
}
function ui(n) {
  let t;
  return fi(n, (e) => t = e)(), t;
}
const di = {
  get(n, t) {
    if (!n.exclude.includes(t))
      return n.props[t];
  },
  set(n, t) {
    return !1;
  },
  getOwnPropertyDescriptor(n, t) {
    if (!n.exclude.includes(t) && t in n.props)
      return {
        enumerable: !0,
        configurable: !0,
        value: n.props[t]
      };
  },
  has(n, t) {
    return n.exclude.includes(t) ? !1 : t in n.props;
  },
  ownKeys(n) {
    return Reflect.ownKeys(n.props).filter((t) => !n.exclude.includes(t));
  }
};
// @__NO_SIDE_EFFECTS__
function pi(n, t, e) {
  return new Proxy(
    { props: n, exclude: t },
    di
  );
}
function A(n, t, e, i) {
  var s = (
    /** @type {V} */
    i
  ), r = !0, o = () => (r && (r = !1, s = /** @type {V} */
  i), s), l;
  l = /** @type {V} */
  n[t], l === void 0 && i !== void 0 && (l = o());
  var a;
  return a = () => {
    var c = (
      /** @type {V} */
      n[t]
    );
    return c === void 0 ? o() : (r = !0, c);
  }, a;
}
Ge();
function ye(n) {
  it === null && pe(), He && it.l !== null ? yi(it).m.push(n) : Y(() => {
    const t = J(n);
    if (typeof t == "function") return (
      /** @type {() => void} */
      t
    );
  });
}
function gi(n) {
  it === null && pe(), ye(() => () => J(n));
}
function yi(n) {
  var t = (
    /** @type {ComponentContextLegacy} */
    n.l
  );
  return t.u ??= { a: [], b: [], m: [] };
}
var mi = /* @__PURE__ */ Rt('<span class="svelte-1oxpd6a"> </span>'), _i = /* @__PURE__ */ Rt("<button><!> <div><!> <!></div></button>");
function xi(n, t) {
  let e = A(t, "label", 3, ""), i = A(t, "show_label", 3, !1), s = A(t, "pending", 3, !1), r = A(t, "size", 3, "small"), o = A(t, "padded", 3, !0), l = A(t, "highlight", 3, !1), a = A(t, "disabled", 3, !1), c = A(t, "hasPopup", 3, !1), d = A(t, "color", 3, "var(--block-label-text-color)"), h = A(t, "transparent", 3, !1), f = A(t, "background", 3, "var(--block-background-fill)"), u = A(t, "border", 3, "transparent"), y = bt(() => l() ? "var(--color-accent)" : d());
  var p = _i();
  let _;
  p.__click = function(...v) {
    t.onclick?.apply(this, v);
  };
  let m;
  var g = st(p);
  {
    var x = (v) => {
      var S = mi(), I = st(S);
      xt(() => Ye(I, e())), D(v, S);
    };
    $t(g, (v) => {
      i() && v(x);
    });
  }
  var b = Tt(g, 2);
  let w;
  var E = st(b);
  ii(E, () => t.Icon, (v, S) => {
    S(v, {});
  });
  var R = Tt(E, 2);
  {
    var M = (v) => {
      var S = ti(), I = qe(S);
      ei(I, () => t.children), D(v, S);
    };
    $t(R, (v) => {
      t.children && v(M);
    });
  }
  xt(() => {
    _ = Dt(p, 1, "icon-button svelte-1oxpd6a", null, _, {
      pending: s(),
      padded: o(),
      highlight: l(),
      transparent: h()
    }), p.disabled = a(), rt(p, "aria-label", e()), rt(p, "aria-haspopup", c()), rt(p, "title", e()), m = ri(p, "", m, {
      "--border-color": u(),
      color: !a() && L(y) ? L(y) : "var(--block-label-text-color)",
      "--bg-color": a() ? "auto" : f()
    }), w = Dt(b, 1, "svelte-1oxpd6a", null, w, {
      "x-small": r() === "x-small",
      small: r() === "small",
      large: r() === "large",
      medium: r() === "medium"
    });
  }), D(n, p);
}
de(["click"]);
const bi = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], Gt = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
bi.reduce((n, { color: t, primary: e, secondary: i }) => ({
  ...n,
  [t]: {
    primary: Gt[t][e],
    secondary: Gt[t][i]
  }
}), {});
function vi(n) {
  let t;
  const e = We((s) => {
    let r = !1;
    const o = n.subscribe((l) => {
      t = l, r && s();
    });
    return r = !0, o;
  });
  function i() {
    return Ue() ? (e(), t) : ui(n);
  }
  return "set" in n ? {
    get current() {
      return i();
    },
    set current(s) {
      n.set(s);
    }
  } : {
    get current() {
      return i();
    }
  };
}
const wi = "__i18n__", Ei = [
  "label",
  "info",
  "placeholder",
  "description",
  "title",
  "value"
], Si = [
  "elem_id",
  "elem_classes",
  "visible",
  "interactive",
  "server_fns",
  "server",
  "id",
  "target",
  "theme_mode",
  "version",
  "root",
  "autoscroll",
  "max_file_size",
  "formatter",
  "client",
  "load_component",
  "scale",
  "min_width",
  "theme",
  "padding",
  "loading_status",
  "label",
  "show_label",
  "validation_error",
  "show_progress",
  "api_prefix",
  "container",
  "attached_events",
  "register_component",
  "dispatcher"
];
function Mi(n) {
  return typeof n == "string" && n.includes(wi);
}
class ki {
  load_component;
  #t = W(Bt({}));
  get shared() {
    return L(this.#t);
  }
  set shared(t) {
    X(this.#t, t, !0);
  }
  #e = W(Bt({}));
  get props() {
    return L(this.#e);
  }
  set props(t) {
    X(this.#e, t, !0);
  }
  #i = W((t) => t);
  get i18n() {
    return L(this.#i);
  }
  set i18n(t) {
    X(this.#i, t, !0);
  }
  i18n_store;
  _i18n_from_store;
  translatable_props = {};
  dispatcher;
  last_update = null;
  shared_props = Si;
  mounted = !1;
  old_value;
  register_component;
  constructor(t, e) {
    for (const i in t.shared_props)
      this.shared[i] = t.shared_props[i];
    for (const i in t.props)
      i !== "i18n_store" && (this.props[i] = t.props[i]);
    if (e)
      for (const i in e)
        this.props[i] === void 0 && (this.props[i] = e[i]);
    this.i18n = this.props.i18n ?? ((i) => i), this.i18n_store = t.props.i18n_store, this._i18n_from_store = this.i18n_store ? vi(this.i18n_store) : void 0;
    for (const i of Ei)
      this.shared[i] = this._translate_and_store(
        "shared",
        i,
        // @ts-ignore
        t.shared_props[i]
      ), this.props[i] = this._translate_and_store(
        "props",
        i,
        // @ts-ignore
        t.props[i]
      );
    this.load_component = this.shared.load_component, this.register_component = this.shared.register_component || (() => {
    }), this.dispatcher = this.shared.dispatcher || (() => {
    }), this.register_component(
      t.shared_props.id,
      // @ts-ignore
      this.set_data.bind(this),
      this.get_data.bind(this)
    ), Y(() => {
      for (const i in t.shared_props)
        this._is_i18n_managed(`shared.${i}`, t.shared_props[i]) || (this.shared[i] = t.shared_props[i]);
      for (const i in t.props)
        i !== "i18n_store" && (this._is_i18n_managed(`props.${i}`, t.props[i]) || (this.props[i] = t.props[i]));
      this.register_component(
        t.shared_props.id,
        // @ts-ignore
        this.set_data.bind(this),
        this.get_data.bind(this)
      ), J(() => {
        this.shared.id = t.shared_props.id;
      });
    }), Y(() => this.i18n_store ? this.i18n_store.subscribe(() => {
      for (const [s, r] of Object.entries(this.translatable_props)) {
        const [o, l] = s.split("."), a = this.i18n(r);
        o === "shared" ? this.shared[l] = a : this.props[l] = a;
      }
    }) : void 0);
  }
  // check if props are translatable
  _is_i18n_managed(t, e) {
    const i = this.translatable_props[t];
    return i ? e === i ? !0 : (delete this.translatable_props[t], !1) : !1;
  }
  _translate_and_store(t, e, i) {
    if (typeof i != "string") return i;
    const s = this.i18n(i);
    return s !== i && (this.translatable_props[`${t}.${e}`] = i), s;
  }
  // Reactive variant of `i18n`. Reading it inside a derived or template
  // subscribes to the live locale store (via Svelte's createSubscriber), so
  // the caller re-runs when the locale changes at runtime. The store is only
  // the reactivity trigger; translation always goes through `this.i18n` so a
  // custom formatter passed via props keeps taking effect.
  live_i18n = (t) => (this._i18n_from_store?.current, this.i18n(t));
  dispatch(t, e) {
    this.dispatcher(this.shared.id, t, e);
  }
  async get_data() {
    return Je(this.props);
  }
  update(t) {
    this.set_data(t);
  }
  set_data(t) {
    for (const e in t) {
      const i = t[e], s = Mi(i) ? this._translate_and_store(this.shared_props.includes(e) ? "shared" : "props", e, i) : i;
      if (this.shared_props.includes(e)) {
        const r = e;
        this.shared[r] = s;
        continue;
      }
      this.props[e] = s;
    }
  }
  watch_for_change() {
    Y(() => {
      this.mounted || (this.old_value = this.props.value, this.mounted = !0), this.old_value != this.props.value && (this.old_value = this.props.value, this.dispatch("change"));
    });
  }
}
de(["click"]);
const Ht = "canvas-host", Ii = "canvas-host-request";
function Pi(n, t) {
  const e = (i) => {
    const s = i.detail;
    s.id === n && t(s);
  };
  return window.addEventListener(Ht, e), window.dispatchEvent(
    new CustomEvent(Ii, { detail: { canvas_id: n, resolve: t } })
  ), () => window.removeEventListener(Ht, e);
}
var Ri = /* @__PURE__ */ ft('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.1 2.182a10 10 0 0 1 3.8 0"></path><path d="M13.9 21.818a10 10 0 0 1-3.8 0"></path><path d="M17.609 3.721a10 10 0 0 1 2.69 2.7"></path><path d="M2.182 13.9a10 10 0 0 1 0-3.8"></path><path d="M20.279 17.609a10 10 0 0 1-2.7 2.69"></path><path d="M21.818 10.1a10 10 0 0 1 0 3.8"></path><path d="M3.721 6.391a10 10 0 0 1 2.7-2.69"></path><path d="M6.391 20.279a10 10 0 0 1-2.69-2.7"></path></svg>');
function Li(n) {
  var t = Ri();
  D(n, t);
}
class F {
  constructor(t, e) {
    this.next = null, this.key = t, this.data = e, this.left = null, this.right = null;
  }
}
function Ai(n, t) {
  return n > t ? 1 : n < t ? -1 : 0;
}
function j(n, t, e) {
  const i = new F(null, null);
  let s = i, r = i;
  for (; ; ) {
    const o = e(n, t.key);
    if (o < 0) {
      if (t.left === null) break;
      if (e(n, t.left.key) < 0) {
        const l = t.left;
        if (t.left = l.right, l.right = t, t = l, t.left === null) break;
      }
      r.left = t, r = t, t = t.left;
    } else if (o > 0) {
      if (t.right === null) break;
      if (e(n, t.right.key) > 0) {
        const l = t.right;
        if (t.right = l.left, l.left = t, t = l, t.right === null) break;
      }
      s.right = t, s = t, t = t.right;
    } else break;
  }
  return s.right = t.left, r.left = t.right, t.left = i.right, t.right = i.left, t;
}
function pt(n, t, e, i) {
  const s = new F(n, t);
  if (e === null)
    return s.left = s.right = null, s;
  e = j(n, e, i);
  const r = i(n, e.key);
  return r < 0 ? (s.left = e.left, s.right = e, e.left = null) : r >= 0 && (s.right = e.right, s.left = e, e.right = null), s;
}
function Yt(n, t, e) {
  let i = null, s = null;
  if (t) {
    t = j(n, t, e);
    const r = e(t.key, n);
    r === 0 ? (i = t.left, s = t.right) : r < 0 ? (s = t.right, t.right = null, i = t) : (i = t.left, t.left = null, s = t);
  }
  return { left: i, right: s };
}
function Ni(n, t, e) {
  return t === null ? n : (n === null || (t = j(n.key, t, e), t.left = n), t);
}
function vt(n, t, e, i, s) {
  if (n) {
    i(`${t}${e ? "└── " : "├── "}${s(n)}
`);
    const r = t + (e ? "    " : "│   ");
    n.left && vt(n.left, r, !1, i, s), n.right && vt(n.right, r, !0, i, s);
  }
}
class At {
  constructor(t = Ai) {
    this._root = null, this._size = 0, this._comparator = t;
  }
  /**
   * Inserts a key, allows duplicates
   */
  insert(t, e) {
    return this._size++, this._root = pt(t, e, this._root, this._comparator);
  }
  /**
   * Adds a key, if it is not present in the tree
   */
  add(t, e) {
    const i = new F(t, e);
    this._root === null && (i.left = i.right = null, this._size++, this._root = i);
    const s = this._comparator, r = j(t, this._root, s), o = s(t, r.key);
    return o === 0 ? this._root = r : (o < 0 ? (i.left = r.left, i.right = r, r.left = null) : o > 0 && (i.right = r.right, i.left = r, r.right = null), this._size++, this._root = i), this._root;
  }
  /**
   * @param  {Key} key
   * @return {Node|null}
   */
  remove(t) {
    this._root = this._remove(t, this._root, this._comparator);
  }
  /**
   * Deletes i from the tree if it's there
   */
  _remove(t, e, i) {
    let s;
    return e === null ? null : (e = j(t, e, i), i(t, e.key) === 0 ? (e.left === null ? s = e.right : (s = j(t, e.left, i), s.right = e.right), this._size--, s) : e);
  }
  /**
   * Removes and returns the node with smallest key
   */
  pop() {
    let t = this._root;
    if (t) {
      for (; t.left; ) t = t.left;
      return this._root = j(t.key, this._root, this._comparator), this._root = this._remove(t.key, this._root, this._comparator), { key: t.key, data: t.data };
    }
    return null;
  }
  /**
   * Find without splaying
   */
  findStatic(t) {
    let e = this._root;
    const i = this._comparator;
    for (; e; ) {
      const s = i(t, e.key);
      if (s === 0) return e;
      s < 0 ? e = e.left : e = e.right;
    }
    return null;
  }
  find(t) {
    return this._root && (this._root = j(t, this._root, this._comparator), this._comparator(t, this._root.key) !== 0) ? null : this._root;
  }
  contains(t) {
    let e = this._root;
    const i = this._comparator;
    for (; e; ) {
      const s = i(t, e.key);
      if (s === 0) return !0;
      s < 0 ? e = e.left : e = e.right;
    }
    return !1;
  }
  forEach(t, e) {
    let i = this._root;
    const s = [];
    let r = !1;
    for (; !r; )
      i !== null ? (s.push(i), i = i.left) : s.length !== 0 ? (i = s.pop(), t.call(e, i), i = i.right) : r = !0;
    return this;
  }
  /**
   * Walk key range from `low` to `high`. Stops if `fn` returns a value.
   */
  range(t, e, i, s) {
    const r = [], o = this._comparator;
    let l = this._root, a;
    for (; r.length !== 0 || l; )
      if (l)
        r.push(l), l = l.left;
      else {
        if (l = r.pop(), a = o(l.key, e), a > 0)
          break;
        if (o(l.key, t) >= 0 && i.call(s, l))
          return this;
        l = l.right;
      }
    return this;
  }
  /**
   * Returns array of keys
   */
  keys() {
    const t = [];
    return this.forEach(({ key: e }) => {
      t.push(e);
    }), t;
  }
  /**
   * Returns array of all the data in the nodes
   */
  values() {
    const t = [];
    return this.forEach(({ data: e }) => {
      t.push(e);
    }), t;
  }
  min() {
    return this._root ? this.minNode(this._root).key : null;
  }
  max() {
    return this._root ? this.maxNode(this._root).key : null;
  }
  minNode(t = this._root) {
    if (t) for (; t.left; ) t = t.left;
    return t;
  }
  maxNode(t = this._root) {
    if (t) for (; t.right; ) t = t.right;
    return t;
  }
  /**
   * Returns node at given index
   */
  at(t) {
    let e = this._root, i = !1, s = 0;
    const r = [];
    for (; !i; )
      if (e)
        r.push(e), e = e.left;
      else if (r.length > 0) {
        if (e = r.pop(), s === t) return e;
        s++, e = e.right;
      } else i = !0;
    return null;
  }
  next(t) {
    let e = this._root, i = null;
    if (t.right) {
      for (i = t.right; i.left; ) i = i.left;
      return i;
    }
    const s = this._comparator;
    for (; e; ) {
      const r = s(t.key, e.key);
      if (r === 0) break;
      r < 0 ? (i = e, e = e.left) : e = e.right;
    }
    return i;
  }
  prev(t) {
    let e = this._root, i = null;
    if (t.left !== null) {
      for (i = t.left; i.right; ) i = i.right;
      return i;
    }
    const s = this._comparator;
    for (; e; ) {
      const r = s(t.key, e.key);
      if (r === 0) break;
      r < 0 ? e = e.left : (i = e, e = e.right);
    }
    return i;
  }
  clear() {
    return this._root = null, this._size = 0, this;
  }
  toList() {
    return Ci(this._root);
  }
  /**
   * Bulk-load items. Both array have to be same size
   */
  load(t, e = [], i = !1) {
    let s = t.length;
    const r = this._comparator;
    if (i && St(t, e, 0, s - 1, r), this._root === null)
      this._root = wt(t, e, 0, s), this._size = s;
    else {
      const o = Ti(
        this.toList(),
        Oi(t, e),
        r
      );
      s = this._size + s, this._root = Et({ head: o }, 0, s);
    }
    return this;
  }
  isEmpty() {
    return this._root === null;
  }
  get size() {
    return this._size;
  }
  get root() {
    return this._root;
  }
  toString(t = (e) => String(e.key)) {
    const e = [];
    return vt(this._root, "", !0, (i) => e.push(i), t), e.join("");
  }
  update(t, e, i) {
    const s = this._comparator;
    let { left: r, right: o } = Yt(t, this._root, s);
    s(t, e) < 0 ? o = pt(e, i, o, s) : r = pt(e, i, r, s), this._root = Ni(r, o, s);
  }
  split(t) {
    return Yt(t, this._root, this._comparator);
  }
  *[Symbol.iterator]() {
    let t = this._root;
    const e = [];
    let i = !1;
    for (; !i; )
      t !== null ? (e.push(t), t = t.left) : e.length !== 0 ? (t = e.pop(), yield t, t = t.right) : i = !0;
  }
}
function wt(n, t, e, i) {
  const s = i - e;
  if (s > 0) {
    const r = e + Math.floor(s / 2), o = n[r], l = t[r], a = new F(o, l);
    return a.left = wt(n, t, e, r), a.right = wt(n, t, r + 1, i), a;
  }
  return null;
}
function Oi(n, t) {
  const e = new F(null, null);
  let i = e;
  for (let s = 0; s < n.length; s++)
    i = i.next = new F(n[s], t[s]);
  return i.next = null, e.next;
}
function Ci(n) {
  let t = n;
  const e = [];
  let i = !1;
  const s = new F(null, null);
  let r = s;
  for (; !i; )
    t ? (e.push(t), t = t.left) : e.length > 0 ? (t = r = r.next = e.pop(), t = t.right) : i = !0;
  return r.next = null, s.next;
}
function Et(n, t, e) {
  const i = e - t;
  if (i > 0) {
    const s = t + Math.floor(i / 2), r = Et(n, t, s), o = n.head;
    return o.left = r, n.head = n.head.next, o.right = Et(n, s + 1, e), o;
  }
  return null;
}
function Ti(n, t, e) {
  const i = new F(null, null);
  let s = i, r = n, o = t;
  for (; r !== null && o !== null; )
    e(r.key, o.key) < 0 ? (s.next = r, r = r.next) : (s.next = o, o = o.next), s = s.next;
  return r !== null ? s.next = r : o !== null && (s.next = o), i.next;
}
function St(n, t, e, i, s) {
  if (e >= i) return;
  const r = n[e + i >> 1];
  let o = e - 1, l = i + 1;
  for (; ; ) {
    do
      o++;
    while (s(n[o], r) < 0);
    do
      l--;
    while (s(n[l], r) > 0);
    if (o >= l) break;
    let a = n[o];
    n[o] = n[l], n[l] = a, a = t[o], t[o] = t[l], t[l] = a;
  }
  St(n, t, e, l, s), St(n, t, l + 1, i, s);
}
const B = 11102230246251565e-32, k = 134217729, Bi = (3 + 8 * B) * B;
function gt(n, t, e, i, s) {
  let r, o, l, a, c = t[0], d = i[0], h = 0, f = 0;
  d > c == d > -c ? (r = c, c = t[++h]) : (r = d, d = i[++f]);
  let u = 0;
  if (h < n && f < e)
    for (d > c == d > -c ? (o = c + r, l = r - (o - c), c = t[++h]) : (o = d + r, l = r - (o - d), d = i[++f]), r = o, l !== 0 && (s[u++] = l); h < n && f < e; )
      d > c == d > -c ? (o = r + c, a = o - r, l = r - (o - a) + (c - a), c = t[++h]) : (o = r + d, a = o - r, l = r - (o - a) + (d - a), d = i[++f]), r = o, l !== 0 && (s[u++] = l);
  for (; h < n; )
    o = r + c, a = o - r, l = r - (o - a) + (c - a), c = t[++h], r = o, l !== 0 && (s[u++] = l);
  for (; f < e; )
    o = r + d, a = o - r, l = r - (o - a) + (d - a), d = i[++f], r = o, l !== 0 && (s[u++] = l);
  return (r !== 0 || u === 0) && (s[u++] = r), u;
}
function $i(n, t) {
  let e = t[0];
  for (let i = 1; i < n; i++) e += t[i];
  return e;
}
function Z(n) {
  return new Float64Array(n);
}
const ji = (3 + 16 * B) * B, zi = (2 + 12 * B) * B, Di = (9 + 64 * B) * B * B, H = Z(4), qt = Z(8), Ut = Z(12), Wt = Z(16), P = Z(4);
function Ki(n, t, e, i, s, r, o) {
  let l, a, c, d, h, f, u, y, p, _, m, g, x, b, w, E, R, M;
  const v = n - s, S = e - s, I = t - r, O = i - r;
  b = v * O, f = k * v, u = f - (f - v), y = v - u, f = k * O, p = f - (f - O), _ = O - p, w = y * _ - (b - u * p - y * p - u * _), E = I * S, f = k * I, u = f - (f - I), y = I - u, f = k * S, p = f - (f - S), _ = S - p, R = y * _ - (E - u * p - y * p - u * _), m = w - R, h = w - m, H[0] = w - (m + h) + (h - R), g = b + m, h = g - b, x = b - (g - h) + (m - h), m = x - E, h = x - m, H[1] = x - (m + h) + (h - E), M = g + m, h = M - g, H[2] = g - (M - h) + (m - h), H[3] = M;
  let T = $i(4, H), q = zi * o;
  if (T >= q || -T >= q || (h = n - v, l = n - (v + h) + (h - s), h = e - S, c = e - (S + h) + (h - s), h = t - I, a = t - (I + h) + (h - r), h = i - O, d = i - (O + h) + (h - r), l === 0 && a === 0 && c === 0 && d === 0) || (q = Di * o + Bi * Math.abs(T), T += v * d + O * l - (I * c + S * a), T >= q || -T >= q)) return T;
  b = l * O, f = k * l, u = f - (f - l), y = l - u, f = k * O, p = f - (f - O), _ = O - p, w = y * _ - (b - u * p - y * p - u * _), E = a * S, f = k * a, u = f - (f - a), y = a - u, f = k * S, p = f - (f - S), _ = S - p, R = y * _ - (E - u * p - y * p - u * _), m = w - R, h = w - m, P[0] = w - (m + h) + (h - R), g = b + m, h = g - b, x = b - (g - h) + (m - h), m = x - E, h = x - m, P[1] = x - (m + h) + (h - E), M = g + m, h = M - g, P[2] = g - (M - h) + (m - h), P[3] = M;
  const we = gt(4, H, 4, P, qt);
  b = v * d, f = k * v, u = f - (f - v), y = v - u, f = k * d, p = f - (f - d), _ = d - p, w = y * _ - (b - u * p - y * p - u * _), E = I * c, f = k * I, u = f - (f - I), y = I - u, f = k * c, p = f - (f - c), _ = c - p, R = y * _ - (E - u * p - y * p - u * _), m = w - R, h = w - m, P[0] = w - (m + h) + (h - R), g = b + m, h = g - b, x = b - (g - h) + (m - h), m = x - E, h = x - m, P[1] = x - (m + h) + (h - E), M = g + m, h = M - g, P[2] = g - (M - h) + (m - h), P[3] = M;
  const Ee = gt(we, qt, 4, P, Ut);
  b = l * d, f = k * l, u = f - (f - l), y = l - u, f = k * d, p = f - (f - d), _ = d - p, w = y * _ - (b - u * p - y * p - u * _), E = a * c, f = k * a, u = f - (f - a), y = a - u, f = k * c, p = f - (f - c), _ = c - p, R = y * _ - (E - u * p - y * p - u * _), m = w - R, h = w - m, P[0] = w - (m + h) + (h - R), g = b + m, h = g - b, x = b - (g - h) + (m - h), m = x - E, h = x - m, P[1] = x - (m + h) + (h - E), M = g + m, h = M - g, P[2] = g - (M - h) + (m - h), P[3] = M;
  const Se = gt(Ee, Ut, 4, P, Wt);
  return Wt[Se - 1];
}
function Fi(n, t, e, i, s, r) {
  const o = (t - r) * (e - s), l = (n - s) * (i - r), a = o - l, c = Math.abs(o + l);
  return Math.abs(a) >= ji * c ? a : -Ki(n, t, e, i, s, r, c);
}
const U = (n, t) => n.ll.x <= t.x && t.x <= n.ur.x && n.ll.y <= t.y && t.y <= n.ur.y, Mt = (n, t) => {
  if (t.ur.x < n.ll.x || n.ur.x < t.ll.x || t.ur.y < n.ll.y || n.ur.y < t.ll.y) return null;
  const e = n.ll.x < t.ll.x ? t.ll.x : n.ll.x, i = n.ur.x < t.ur.x ? n.ur.x : t.ur.x, s = n.ll.y < t.ll.y ? t.ll.y : n.ll.y, r = n.ur.y < t.ur.y ? n.ur.y : t.ur.y;
  return {
    ll: {
      x: e,
      y: s
    },
    ur: {
      x: i,
      y: r
    }
  };
};
let z = Number.EPSILON;
z === void 0 && (z = Math.pow(2, -52));
const Gi = z * z, Xt = (n, t) => {
  if (-z < n && n < z && -z < t && t < z)
    return 0;
  const e = n - t;
  return e * e < Gi * n * t ? 0 : n < t ? -1 : 1;
};
class Hi {
  constructor() {
    this.reset();
  }
  reset() {
    this.xRounder = new Vt(), this.yRounder = new Vt();
  }
  round(t, e) {
    return {
      x: this.xRounder.round(t),
      y: this.yRounder.round(e)
    };
  }
}
class Vt {
  constructor() {
    this.tree = new At(), this.round(0);
  }
  // Note: this can rounds input values backwards or forwards.
  //       You might ask, why not restrict this to just rounding
  //       forwards? Wouldn't that allow left endpoints to always
  //       remain left endpoints during splitting (never change to
  //       right). No - it wouldn't, because we snap intersections
  //       to endpoints (to establish independence from the segment
  //       angle for t-intersections).
  round(t) {
    const e = this.tree.add(t), i = this.tree.prev(e);
    if (i !== null && Xt(e.key, i.key) === 0)
      return this.tree.remove(t), i.key;
    const s = this.tree.next(e);
    return s !== null && Xt(e.key, s.key) === 0 ? (this.tree.remove(t), s.key) : t;
  }
}
const Q = new Hi(), ot = (n, t) => n.x * t.y - n.y * t.x, me = (n, t) => n.x * t.x + n.y * t.y, Qt = (n, t, e) => {
  const i = Fi(n.x, n.y, t.x, t.y, e.x, e.y);
  return i > 0 ? -1 : i < 0 ? 1 : 0;
}, at = (n) => Math.sqrt(me(n, n)), Yi = (n, t, e) => {
  const i = {
    x: t.x - n.x,
    y: t.y - n.y
  }, s = {
    x: e.x - n.x,
    y: e.y - n.y
  };
  return ot(s, i) / at(s) / at(i);
}, qi = (n, t, e) => {
  const i = {
    x: t.x - n.x,
    y: t.y - n.y
  }, s = {
    x: e.x - n.x,
    y: e.y - n.y
  };
  return me(s, i) / at(s) / at(i);
}, Jt = (n, t, e) => t.y === 0 ? null : {
  x: n.x + t.x / t.y * (e - n.y),
  y: e
}, Zt = (n, t, e) => t.x === 0 ? null : {
  x: e,
  y: n.y + t.y / t.x * (e - n.x)
}, Ui = (n, t, e, i) => {
  if (t.x === 0) return Zt(e, i, n.x);
  if (i.x === 0) return Zt(n, t, e.x);
  if (t.y === 0) return Jt(e, i, n.y);
  if (i.y === 0) return Jt(n, t, e.y);
  const s = ot(t, i);
  if (s == 0) return null;
  const r = {
    x: e.x - n.x,
    y: e.y - n.y
  }, o = ot(r, t) / s, l = ot(r, i) / s, a = n.x + l * t.x, c = e.x + o * i.x, d = n.y + l * t.y, h = e.y + o * i.y, f = (a + c) / 2, u = (d + h) / 2;
  return {
    x: f,
    y: u
  };
};
class N {
  // for ordering sweep events in the sweep event queue
  static compare(t, e) {
    const i = N.comparePoints(t.point, e.point);
    return i !== 0 ? i : (t.point !== e.point && t.link(e), t.isLeft !== e.isLeft ? t.isLeft ? 1 : -1 : K.compare(t.segment, e.segment));
  }
  // for ordering points in sweep line order
  static comparePoints(t, e) {
    return t.x < e.x ? -1 : t.x > e.x ? 1 : t.y < e.y ? -1 : t.y > e.y ? 1 : 0;
  }
  // Warning: 'point' input will be modified and re-used (for performance)
  constructor(t, e) {
    t.events === void 0 ? t.events = [this] : t.events.push(this), this.point = t, this.isLeft = e;
  }
  link(t) {
    if (t.point === this.point)
      throw new Error("Tried to link already linked events");
    const e = t.point.events;
    for (let i = 0, s = e.length; i < s; i++) {
      const r = e[i];
      this.point.events.push(r), r.point = this.point;
    }
    this.checkForConsuming();
  }
  /* Do a pass over our linked events and check to see if any pair
   * of segments match, and should be consumed. */
  checkForConsuming() {
    const t = this.point.events.length;
    for (let e = 0; e < t; e++) {
      const i = this.point.events[e];
      if (i.segment.consumedBy === void 0)
        for (let s = e + 1; s < t; s++) {
          const r = this.point.events[s];
          r.consumedBy === void 0 && i.otherSE.point.events === r.otherSE.point.events && i.segment.consume(r.segment);
        }
    }
  }
  getAvailableLinkedEvents() {
    const t = [];
    for (let e = 0, i = this.point.events.length; e < i; e++) {
      const s = this.point.events[e];
      s !== this && !s.segment.ringOut && s.segment.isInResult() && t.push(s);
    }
    return t;
  }
  /**
   * Returns a comparator function for sorting linked events that will
   * favor the event that will give us the smallest left-side angle.
   * All ring construction starts as low as possible heading to the right,
   * so by always turning left as sharp as possible we'll get polygons
   * without uncessary loops & holes.
   *
   * The comparator function has a compute cache such that it avoids
   * re-computing already-computed values.
   */
  getLeftmostComparator(t) {
    const e = /* @__PURE__ */ new Map(), i = (s) => {
      const r = s.otherSE;
      e.set(s, {
        sine: Yi(this.point, t.point, r.point),
        cosine: qi(this.point, t.point, r.point)
      });
    };
    return (s, r) => {
      e.has(s) || i(s), e.has(r) || i(r);
      const {
        sine: o,
        cosine: l
      } = e.get(s), {
        sine: a,
        cosine: c
      } = e.get(r);
      return o >= 0 && a >= 0 ? l < c ? 1 : l > c ? -1 : 0 : o < 0 && a < 0 ? l < c ? -1 : l > c ? 1 : 0 : a < o ? -1 : a > o ? 1 : 0;
    };
  }
}
let Wi = 0;
class K {
  /* This compare() function is for ordering segments in the sweep
   * line tree, and does so according to the following criteria:
   *
   * Consider the vertical line that lies an infinestimal step to the
   * right of the right-more of the two left endpoints of the input
   * segments. Imagine slowly moving a point up from negative infinity
   * in the increasing y direction. Which of the two segments will that
   * point intersect first? That segment comes 'before' the other one.
   *
   * If neither segment would be intersected by such a line, (if one
   * or more of the segments are vertical) then the line to be considered
   * is directly on the right-more of the two left inputs.
   */
  static compare(t, e) {
    const i = t.leftSE.point.x, s = e.leftSE.point.x, r = t.rightSE.point.x, o = e.rightSE.point.x;
    if (o < i) return 1;
    if (r < s) return -1;
    const l = t.leftSE.point.y, a = e.leftSE.point.y, c = t.rightSE.point.y, d = e.rightSE.point.y;
    if (i < s) {
      if (a < l && a < c) return 1;
      if (a > l && a > c) return -1;
      const h = t.comparePoint(e.leftSE.point);
      if (h < 0) return 1;
      if (h > 0) return -1;
      const f = e.comparePoint(t.rightSE.point);
      return f !== 0 ? f : -1;
    }
    if (i > s) {
      if (l < a && l < d) return -1;
      if (l > a && l > d) return 1;
      const h = e.comparePoint(t.leftSE.point);
      if (h !== 0) return h;
      const f = t.comparePoint(e.rightSE.point);
      return f < 0 ? 1 : f > 0 ? -1 : 1;
    }
    if (l < a) return -1;
    if (l > a) return 1;
    if (r < o) {
      const h = e.comparePoint(t.rightSE.point);
      if (h !== 0) return h;
    }
    if (r > o) {
      const h = t.comparePoint(e.rightSE.point);
      if (h < 0) return 1;
      if (h > 0) return -1;
    }
    if (r !== o) {
      const h = c - l, f = r - i, u = d - a, y = o - s;
      if (h > f && u < y) return 1;
      if (h < f && u > y) return -1;
    }
    return r > o ? 1 : r < o || c < d ? -1 : c > d ? 1 : t.id < e.id ? -1 : t.id > e.id ? 1 : 0;
  }
  /* Warning: a reference to ringWindings input will be stored,
   *  and possibly will be later modified */
  constructor(t, e, i, s) {
    this.id = ++Wi, this.leftSE = t, t.segment = this, t.otherSE = e, this.rightSE = e, e.segment = this, e.otherSE = t, this.rings = i, this.windings = s;
  }
  static fromRing(t, e, i) {
    let s, r, o;
    const l = N.comparePoints(t, e);
    if (l < 0)
      s = t, r = e, o = 1;
    else if (l > 0)
      s = e, r = t, o = -1;
    else throw new Error(`Tried to create degenerate segment at [${t.x}, ${t.y}]`);
    const a = new N(s, !0), c = new N(r, !1);
    return new K(a, c, [i], [o]);
  }
  /* When a segment is split, the rightSE is replaced with a new sweep event */
  replaceRightSE(t) {
    this.rightSE = t, this.rightSE.segment = this, this.rightSE.otherSE = this.leftSE, this.leftSE.otherSE = this.rightSE;
  }
  bbox() {
    const t = this.leftSE.point.y, e = this.rightSE.point.y;
    return {
      ll: {
        x: this.leftSE.point.x,
        y: t < e ? t : e
      },
      ur: {
        x: this.rightSE.point.x,
        y: t > e ? t : e
      }
    };
  }
  /* A vector from the left point to the right */
  vector() {
    return {
      x: this.rightSE.point.x - this.leftSE.point.x,
      y: this.rightSE.point.y - this.leftSE.point.y
    };
  }
  isAnEndpoint(t) {
    return t.x === this.leftSE.point.x && t.y === this.leftSE.point.y || t.x === this.rightSE.point.x && t.y === this.rightSE.point.y;
  }
  /* Compare this segment with a point.
   *
   * A point P is considered to be colinear to a segment if there
   * exists a distance D such that if we travel along the segment
   * from one * endpoint towards the other a distance D, we find
   * ourselves at point P.
   *
   * Return value indicates:
   *
   *   1: point lies above the segment (to the left of vertical)
   *   0: point is colinear to segment
   *  -1: point lies below the segment (to the right of vertical)
   */
  comparePoint(t) {
    if (this.isAnEndpoint(t)) return 0;
    const e = this.leftSE.point, i = this.rightSE.point, s = this.vector();
    if (e.x === i.x)
      return t.x === e.x ? 0 : t.x < e.x ? 1 : -1;
    const r = (t.y - e.y) / s.y, o = e.x + r * s.x;
    if (t.x === o) return 0;
    const l = (t.x - e.x) / s.x, a = e.y + l * s.y;
    return t.y === a ? 0 : t.y < a ? -1 : 1;
  }
  /**
   * Given another segment, returns the first non-trivial intersection
   * between the two segments (in terms of sweep line ordering), if it exists.
   *
   * A 'non-trivial' intersection is one that will cause one or both of the
   * segments to be split(). As such, 'trivial' vs. 'non-trivial' intersection:
   *
   *   * endpoint of segA with endpoint of segB --> trivial
   *   * endpoint of segA with point along segB --> non-trivial
   *   * endpoint of segB with point along segA --> non-trivial
   *   * point along segA with point along segB --> non-trivial
   *
   * If no non-trivial intersection exists, return null
   * Else, return null.
   */
  getIntersection(t) {
    const e = this.bbox(), i = t.bbox(), s = Mt(e, i);
    if (s === null) return null;
    const r = this.leftSE.point, o = this.rightSE.point, l = t.leftSE.point, a = t.rightSE.point, c = U(e, l) && this.comparePoint(l) === 0, d = U(i, r) && t.comparePoint(r) === 0, h = U(e, a) && this.comparePoint(a) === 0, f = U(i, o) && t.comparePoint(o) === 0;
    if (d && c)
      return f && !h ? o : !f && h ? a : null;
    if (d)
      return h && r.x === a.x && r.y === a.y ? null : r;
    if (c)
      return f && o.x === l.x && o.y === l.y ? null : l;
    if (f && h) return null;
    if (f) return o;
    if (h) return a;
    const u = Ui(r, this.vector(), l, t.vector());
    return u === null || !U(s, u) ? null : Q.round(u.x, u.y);
  }
  /**
   * Split the given segment into multiple segments on the given points.
   *  * Each existing segment will retain its leftSE and a new rightSE will be
   *    generated for it.
   *  * A new segment will be generated which will adopt the original segment's
   *    rightSE, and a new leftSE will be generated for it.
   *  * If there are more than two points given to split on, new segments
   *    in the middle will be generated with new leftSE and rightSE's.
   *  * An array of the newly generated SweepEvents will be returned.
   *
   * Warning: input array of points is modified
   */
  split(t) {
    const e = [], i = t.events !== void 0, s = new N(t, !0), r = new N(t, !1), o = this.rightSE;
    this.replaceRightSE(r), e.push(r), e.push(s);
    const l = new K(s, o, this.rings.slice(), this.windings.slice());
    return N.comparePoints(l.leftSE.point, l.rightSE.point) > 0 && l.swapEvents(), N.comparePoints(this.leftSE.point, this.rightSE.point) > 0 && this.swapEvents(), i && (s.checkForConsuming(), r.checkForConsuming()), e;
  }
  /* Swap which event is left and right */
  swapEvents() {
    const t = this.rightSE;
    this.rightSE = this.leftSE, this.leftSE = t, this.leftSE.isLeft = !0, this.rightSE.isLeft = !1;
    for (let e = 0, i = this.windings.length; e < i; e++)
      this.windings[e] *= -1;
  }
  /* Consume another segment. We take their rings under our wing
   * and mark them as consumed. Use for perfectly overlapping segments */
  consume(t) {
    let e = this, i = t;
    for (; e.consumedBy; ) e = e.consumedBy;
    for (; i.consumedBy; ) i = i.consumedBy;
    const s = K.compare(e, i);
    if (s !== 0) {
      if (s > 0) {
        const r = e;
        e = i, i = r;
      }
      if (e.prev === i) {
        const r = e;
        e = i, i = r;
      }
      for (let r = 0, o = i.rings.length; r < o; r++) {
        const l = i.rings[r], a = i.windings[r], c = e.rings.indexOf(l);
        c === -1 ? (e.rings.push(l), e.windings.push(a)) : e.windings[c] += a;
      }
      i.rings = null, i.windings = null, i.consumedBy = e, i.leftSE.consumedBy = e.leftSE, i.rightSE.consumedBy = e.rightSE;
    }
  }
  /* The first segment previous segment chain that is in the result */
  prevInResult() {
    return this._prevInResult !== void 0 ? this._prevInResult : (this.prev ? this.prev.isInResult() ? this._prevInResult = this.prev : this._prevInResult = this.prev.prevInResult() : this._prevInResult = null, this._prevInResult);
  }
  beforeState() {
    if (this._beforeState !== void 0) return this._beforeState;
    if (!this.prev) this._beforeState = {
      rings: [],
      windings: [],
      multiPolys: []
    };
    else {
      const t = this.prev.consumedBy || this.prev;
      this._beforeState = t.afterState();
    }
    return this._beforeState;
  }
  afterState() {
    if (this._afterState !== void 0) return this._afterState;
    const t = this.beforeState();
    this._afterState = {
      rings: t.rings.slice(0),
      windings: t.windings.slice(0),
      multiPolys: []
    };
    const e = this._afterState.rings, i = this._afterState.windings, s = this._afterState.multiPolys;
    for (let l = 0, a = this.rings.length; l < a; l++) {
      const c = this.rings[l], d = this.windings[l], h = e.indexOf(c);
      h === -1 ? (e.push(c), i.push(d)) : i[h] += d;
    }
    const r = [], o = [];
    for (let l = 0, a = e.length; l < a; l++) {
      if (i[l] === 0) continue;
      const c = e[l], d = c.poly;
      if (o.indexOf(d) === -1)
        if (c.isExterior) r.push(d);
        else {
          o.indexOf(d) === -1 && o.push(d);
          const h = r.indexOf(c.poly);
          h !== -1 && r.splice(h, 1);
        }
    }
    for (let l = 0, a = r.length; l < a; l++) {
      const c = r[l].multiPoly;
      s.indexOf(c) === -1 && s.push(c);
    }
    return this._afterState;
  }
  /* Is this segment part of the final result? */
  isInResult() {
    if (this.consumedBy) return !1;
    if (this._isInResult !== void 0) return this._isInResult;
    const t = this.beforeState().multiPolys, e = this.afterState().multiPolys;
    switch (C.type) {
      case "union": {
        const i = t.length === 0, s = e.length === 0;
        this._isInResult = i !== s;
        break;
      }
      case "intersection": {
        let i, s;
        t.length < e.length ? (i = t.length, s = e.length) : (i = e.length, s = t.length), this._isInResult = s === C.numMultiPolys && i < s;
        break;
      }
      case "xor": {
        const i = Math.abs(t.length - e.length);
        this._isInResult = i % 2 === 1;
        break;
      }
      case "difference": {
        const i = (s) => s.length === 1 && s[0].isSubject;
        this._isInResult = i(t) !== i(e);
        break;
      }
      default:
        throw new Error(`Unrecognized operation type found ${C.type}`);
    }
    return this._isInResult;
  }
}
class te {
  constructor(t, e, i) {
    if (!Array.isArray(t) || t.length === 0)
      throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
    if (this.poly = e, this.isExterior = i, this.segments = [], typeof t[0][0] != "number" || typeof t[0][1] != "number")
      throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
    const s = Q.round(t[0][0], t[0][1]);
    this.bbox = {
      ll: {
        x: s.x,
        y: s.y
      },
      ur: {
        x: s.x,
        y: s.y
      }
    };
    let r = s;
    for (let o = 1, l = t.length; o < l; o++) {
      if (typeof t[o][0] != "number" || typeof t[o][1] != "number")
        throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
      let a = Q.round(t[o][0], t[o][1]);
      a.x === r.x && a.y === r.y || (this.segments.push(K.fromRing(r, a, this)), a.x < this.bbox.ll.x && (this.bbox.ll.x = a.x), a.y < this.bbox.ll.y && (this.bbox.ll.y = a.y), a.x > this.bbox.ur.x && (this.bbox.ur.x = a.x), a.y > this.bbox.ur.y && (this.bbox.ur.y = a.y), r = a);
    }
    (s.x !== r.x || s.y !== r.y) && this.segments.push(K.fromRing(r, s, this));
  }
  getSweepEvents() {
    const t = [];
    for (let e = 0, i = this.segments.length; e < i; e++) {
      const s = this.segments[e];
      t.push(s.leftSE), t.push(s.rightSE);
    }
    return t;
  }
}
class Xi {
  constructor(t, e) {
    if (!Array.isArray(t))
      throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
    this.exteriorRing = new te(t[0], this, !0), this.bbox = {
      ll: {
        x: this.exteriorRing.bbox.ll.x,
        y: this.exteriorRing.bbox.ll.y
      },
      ur: {
        x: this.exteriorRing.bbox.ur.x,
        y: this.exteriorRing.bbox.ur.y
      }
    }, this.interiorRings = [];
    for (let i = 1, s = t.length; i < s; i++) {
      const r = new te(t[i], this, !1);
      r.bbox.ll.x < this.bbox.ll.x && (this.bbox.ll.x = r.bbox.ll.x), r.bbox.ll.y < this.bbox.ll.y && (this.bbox.ll.y = r.bbox.ll.y), r.bbox.ur.x > this.bbox.ur.x && (this.bbox.ur.x = r.bbox.ur.x), r.bbox.ur.y > this.bbox.ur.y && (this.bbox.ur.y = r.bbox.ur.y), this.interiorRings.push(r);
    }
    this.multiPoly = e;
  }
  getSweepEvents() {
    const t = this.exteriorRing.getSweepEvents();
    for (let e = 0, i = this.interiorRings.length; e < i; e++) {
      const s = this.interiorRings[e].getSweepEvents();
      for (let r = 0, o = s.length; r < o; r++)
        t.push(s[r]);
    }
    return t;
  }
}
class ee {
  constructor(t, e) {
    if (!Array.isArray(t))
      throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
    try {
      typeof t[0][0][0] == "number" && (t = [t]);
    } catch {
    }
    this.polys = [], this.bbox = {
      ll: {
        x: Number.POSITIVE_INFINITY,
        y: Number.POSITIVE_INFINITY
      },
      ur: {
        x: Number.NEGATIVE_INFINITY,
        y: Number.NEGATIVE_INFINITY
      }
    };
    for (let i = 0, s = t.length; i < s; i++) {
      const r = new Xi(t[i], this);
      r.bbox.ll.x < this.bbox.ll.x && (this.bbox.ll.x = r.bbox.ll.x), r.bbox.ll.y < this.bbox.ll.y && (this.bbox.ll.y = r.bbox.ll.y), r.bbox.ur.x > this.bbox.ur.x && (this.bbox.ur.x = r.bbox.ur.x), r.bbox.ur.y > this.bbox.ur.y && (this.bbox.ur.y = r.bbox.ur.y), this.polys.push(r);
    }
    this.isSubject = e;
  }
  getSweepEvents() {
    const t = [];
    for (let e = 0, i = this.polys.length; e < i; e++) {
      const s = this.polys[e].getSweepEvents();
      for (let r = 0, o = s.length; r < o; r++)
        t.push(s[r]);
    }
    return t;
  }
}
class ct {
  /* Given the segments from the sweep line pass, compute & return a series
   * of closed rings from all the segments marked to be part of the result */
  static factory(t) {
    const e = [];
    for (let i = 0, s = t.length; i < s; i++) {
      const r = t[i];
      if (!r.isInResult() || r.ringOut) continue;
      let o = null, l = r.leftSE, a = r.rightSE;
      const c = [l], d = l.point, h = [];
      for (; o = l, l = a, c.push(l), l.point !== d; )
        for (; ; ) {
          const f = l.getAvailableLinkedEvents();
          if (f.length === 0) {
            const p = c[0].point, _ = c[c.length - 1].point;
            throw new Error(`Unable to complete output ring starting at [${p.x}, ${p.y}]. Last matching segment found ends at [${_.x}, ${_.y}].`);
          }
          if (f.length === 1) {
            a = f[0].otherSE;
            break;
          }
          let u = null;
          for (let p = 0, _ = h.length; p < _; p++)
            if (h[p].point === l.point) {
              u = p;
              break;
            }
          if (u !== null) {
            const p = h.splice(u)[0], _ = c.splice(p.index);
            _.unshift(_[0].otherSE), e.push(new ct(_.reverse()));
            continue;
          }
          h.push({
            index: c.length,
            point: l.point
          });
          const y = l.getLeftmostComparator(o);
          a = f.sort(y)[0].otherSE;
          break;
        }
      e.push(new ct(c));
    }
    return e;
  }
  constructor(t) {
    this.events = t;
    for (let e = 0, i = t.length; e < i; e++)
      t[e].segment.ringOut = this;
    this.poly = null;
  }
  getGeom() {
    let t = this.events[0].point;
    const e = [t];
    for (let c = 1, d = this.events.length - 1; c < d; c++) {
      const h = this.events[c].point, f = this.events[c + 1].point;
      Qt(h, t, f) !== 0 && (e.push(h), t = h);
    }
    if (e.length === 1) return null;
    const i = e[0], s = e[1];
    Qt(i, t, s) === 0 && e.shift(), e.push(e[0]);
    const r = this.isExteriorRing() ? 1 : -1, o = this.isExteriorRing() ? 0 : e.length - 1, l = this.isExteriorRing() ? e.length : -1, a = [];
    for (let c = o; c != l; c += r) a.push([e[c].x, e[c].y]);
    return a;
  }
  isExteriorRing() {
    if (this._isExteriorRing === void 0) {
      const t = this.enclosingRing();
      this._isExteriorRing = t ? !t.isExteriorRing() : !0;
    }
    return this._isExteriorRing;
  }
  enclosingRing() {
    return this._enclosingRing === void 0 && (this._enclosingRing = this._calcEnclosingRing()), this._enclosingRing;
  }
  /* Returns the ring that encloses this one, if any */
  _calcEnclosingRing() {
    let t = this.events[0];
    for (let s = 1, r = this.events.length; s < r; s++) {
      const o = this.events[s];
      N.compare(t, o) > 0 && (t = o);
    }
    let e = t.segment.prevInResult(), i = e ? e.prevInResult() : null;
    for (; ; ) {
      if (!e) return null;
      if (!i) return e.ringOut;
      if (i.ringOut !== e.ringOut)
        return i.ringOut.enclosingRing() !== e.ringOut ? e.ringOut : e.ringOut.enclosingRing();
      e = i.prevInResult(), i = e ? e.prevInResult() : null;
    }
  }
}
class ie {
  constructor(t) {
    this.exteriorRing = t, t.poly = this, this.interiorRings = [];
  }
  addInterior(t) {
    this.interiorRings.push(t), t.poly = this;
  }
  getGeom() {
    const t = [this.exteriorRing.getGeom()];
    if (t[0] === null) return null;
    for (let e = 0, i = this.interiorRings.length; e < i; e++) {
      const s = this.interiorRings[e].getGeom();
      s !== null && t.push(s);
    }
    return t;
  }
}
class Vi {
  constructor(t) {
    this.rings = t, this.polys = this._composePolys(t);
  }
  getGeom() {
    const t = [];
    for (let e = 0, i = this.polys.length; e < i; e++) {
      const s = this.polys[e].getGeom();
      s !== null && t.push(s);
    }
    return t;
  }
  _composePolys(t) {
    const e = [];
    for (let i = 0, s = t.length; i < s; i++) {
      const r = t[i];
      if (!r.poly)
        if (r.isExteriorRing()) e.push(new ie(r));
        else {
          const o = r.enclosingRing();
          o.poly || e.push(new ie(o)), o.poly.addInterior(r);
        }
    }
    return e;
  }
}
class Qi {
  constructor(t) {
    let e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : K.compare;
    this.queue = t, this.tree = new At(e), this.segments = [];
  }
  process(t) {
    const e = t.segment, i = [];
    if (t.consumedBy)
      return t.isLeft ? this.queue.remove(t.otherSE) : this.tree.remove(e), i;
    const s = t.isLeft ? this.tree.add(e) : this.tree.find(e);
    if (!s) throw new Error(`Unable to find segment #${e.id} [${e.leftSE.point.x}, ${e.leftSE.point.y}] -> [${e.rightSE.point.x}, ${e.rightSE.point.y}] in SweepLine tree.`);
    let r = s, o = s, l, a;
    for (; l === void 0; )
      r = this.tree.prev(r), r === null ? l = null : r.key.consumedBy === void 0 && (l = r.key);
    for (; a === void 0; )
      o = this.tree.next(o), o === null ? a = null : o.key.consumedBy === void 0 && (a = o.key);
    if (t.isLeft) {
      let c = null;
      if (l) {
        const h = l.getIntersection(e);
        if (h !== null && (e.isAnEndpoint(h) || (c = h), !l.isAnEndpoint(h))) {
          const f = this._splitSafely(l, h);
          for (let u = 0, y = f.length; u < y; u++)
            i.push(f[u]);
        }
      }
      let d = null;
      if (a) {
        const h = a.getIntersection(e);
        if (h !== null && (e.isAnEndpoint(h) || (d = h), !a.isAnEndpoint(h))) {
          const f = this._splitSafely(a, h);
          for (let u = 0, y = f.length; u < y; u++)
            i.push(f[u]);
        }
      }
      if (c !== null || d !== null) {
        let h = null;
        c === null ? h = d : d === null ? h = c : h = N.comparePoints(c, d) <= 0 ? c : d, this.queue.remove(e.rightSE), i.push(e.rightSE);
        const f = e.split(h);
        for (let u = 0, y = f.length; u < y; u++)
          i.push(f[u]);
      }
      i.length > 0 ? (this.tree.remove(e), i.push(t)) : (this.segments.push(e), e.prev = l);
    } else {
      if (l && a) {
        const c = l.getIntersection(a);
        if (c !== null) {
          if (!l.isAnEndpoint(c)) {
            const d = this._splitSafely(l, c);
            for (let h = 0, f = d.length; h < f; h++)
              i.push(d[h]);
          }
          if (!a.isAnEndpoint(c)) {
            const d = this._splitSafely(a, c);
            for (let h = 0, f = d.length; h < f; h++)
              i.push(d[h]);
          }
        }
      }
      this.tree.remove(e);
    }
    return i;
  }
  /* Safely split a segment that is currently in the datastructures
   * IE - a segment other than the one that is currently being processed. */
  _splitSafely(t, e) {
    this.tree.remove(t);
    const i = t.rightSE;
    this.queue.remove(i);
    const s = t.split(e);
    return s.push(i), t.consumedBy === void 0 && this.tree.add(t), s;
  }
}
const se = typeof process < "u" && process.env.POLYGON_CLIPPING_MAX_QUEUE_SIZE || 1e6, Ji = typeof process < "u" && process.env.POLYGON_CLIPPING_MAX_SWEEPLINE_SEGMENTS || 1e6;
class Zi {
  run(t, e, i) {
    C.type = t, Q.reset();
    const s = [new ee(e, !0)];
    for (let h = 0, f = i.length; h < f; h++)
      s.push(new ee(i[h], !1));
    if (C.numMultiPolys = s.length, C.type === "difference") {
      const h = s[0];
      let f = 1;
      for (; f < s.length; )
        Mt(s[f].bbox, h.bbox) !== null ? f++ : s.splice(f, 1);
    }
    if (C.type === "intersection")
      for (let h = 0, f = s.length; h < f; h++) {
        const u = s[h];
        for (let y = h + 1, p = s.length; y < p; y++)
          if (Mt(u.bbox, s[y].bbox) === null) return [];
      }
    const r = new At(N.compare);
    for (let h = 0, f = s.length; h < f; h++) {
      const u = s[h].getSweepEvents();
      for (let y = 0, p = u.length; y < p; y++)
        if (r.insert(u[y]), r.size > se)
          throw new Error("Infinite loop when putting segment endpoints in a priority queue (queue size too big).");
    }
    const o = new Qi(r);
    let l = r.size, a = r.pop();
    for (; a; ) {
      const h = a.key;
      if (r.size === l) {
        const u = h.segment;
        throw new Error(`Unable to pop() ${h.isLeft ? "left" : "right"} SweepEvent [${h.point.x}, ${h.point.y}] from segment #${u.id} [${u.leftSE.point.x}, ${u.leftSE.point.y}] -> [${u.rightSE.point.x}, ${u.rightSE.point.y}] from queue.`);
      }
      if (r.size > se)
        throw new Error("Infinite loop when passing sweep line over endpoints (queue size too big).");
      if (o.segments.length > Ji)
        throw new Error("Infinite loop when passing sweep line over endpoints (too many sweep line segments).");
      const f = o.process(h);
      for (let u = 0, y = f.length; u < y; u++) {
        const p = f[u];
        p.consumedBy === void 0 && r.insert(p);
      }
      l = r.size, a = r.pop();
    }
    Q.reset();
    const c = ct.factory(o.segments);
    return new Vi(c).getGeom();
  }
}
const C = new Zi(), ts = function(n) {
  for (var t = arguments.length, e = new Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++)
    e[i - 1] = arguments[i];
  return C.run("union", n, e);
}, es = function(n) {
  for (var t = arguments.length, e = new Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++)
    e[i - 1] = arguments[i];
  return C.run("intersection", n, e);
}, is = function(n) {
  for (var t = arguments.length, e = new Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++)
    e[i - 1] = arguments[i];
  return C.run("xor", n, e);
}, ss = function(n) {
  for (var t = arguments.length, e = new Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++)
    e[i - 1] = arguments[i];
  return C.run("difference", n, e);
};
var V = {
  union: ts,
  intersection: es,
  xor: is,
  difference: ss
};
const ns = 0.25;
function ne(n, t) {
  const e = n.length;
  return t === 0 ? n : n.map((i, s) => {
    const r = Math.min(t, s, e - 1 - s);
    let [o, l] = [0, 0];
    for (let c = s - r; c <= s + r; c++)
      o += n[c][0], l += n[c][1];
    const a = 2 * r + 1;
    return [o / a, l / a];
  });
}
function rs(n, t, e) {
  const [i, s] = n, [r, o] = [t[0] - i, t[1] - s], l = Math.PI / 4, a = Math.round(Math.atan2(o, r) / l) * l, c = Math.round(Math.cos(a) * 1e9) / 1e9, d = Math.round(Math.sin(a) * 1e9) / 1e9;
  let h = r * c + o * d;
  return c > 0 && (h = Math.min(h, (e.width - i) / c)), c < 0 && (h = Math.min(h, -i / c)), d > 0 && (h = Math.min(h, (e.height - s) / d)), d < 0 && (h = Math.min(h, -s / d)), h = Math.max(0, h), [i + c * h, s + d * h];
}
function os([[n, t], [e, i]]) {
  return [
    [n, t],
    [e, t],
    [e, i],
    [n, i]
  ];
}
function ls([[n, t], [e, i]]) {
  const [s, r] = [(n + e) / 2, (t + i) / 2], [o, l] = [Math.abs(e - n) / 2, Math.abs(i - t) / 2], a = 2 * Math.acos(1 - Math.min(1, ns / Math.max(o, l))), c = Math.max(8, Math.ceil(2 * Math.PI / a));
  return Array.from({ length: c }, (d, h) => {
    const f = 2 * Math.PI * h / c;
    return [s + o * Math.cos(f), r + l * Math.sin(f)];
  });
}
function _e(n) {
  const [t, ...e] = n.map((i) => [i]);
  return V.xor(t, ...e);
}
function xe(n) {
  const t = n.flatMap(
    (e) => e.map((i) => i.slice(0, -1).map(([s, r]) => [s, r]))
  );
  return t.length ? t : null;
}
const hs = {
  add: V.union,
  subtract: V.difference,
  intersect: V.intersection
};
function as(n, t, e) {
  try {
    return xe(hs[e](_e(n), [t]));
  } catch (i) {
    return console.warn("Select tool couldn't combine selections:", i), null;
  }
}
function cs(n, t) {
  const e = [
    [0, 0],
    [t.width, 0],
    [t.width, t.height],
    [0, t.height]
  ];
  return n ? xe(V.difference([e], _e(n))) : [e];
}
function fs(n, [t, e]) {
  let i = !1;
  for (const s of n)
    for (let r = 0, o = s.length - 1; r < s.length; o = r++) {
      const [l, a] = s[r], [c, d] = s[o];
      a > e != d > e && t < l + (e - a) * (c - l) / (d - a) && (i = !i);
    }
  return i;
}
function us(n, [t, e]) {
  return n.map((i) => i.map(([s, r]) => [s + t, r + e]));
}
function re(n) {
  return n && n.map((t) => t.map(([e, i]) => [Math.round(e), Math.round(i)]));
}
function tt(n, t, e) {
  return Math.max(t, Math.min(e, n));
}
function G(n) {
  return n === "rectangle" || n === "ellipse";
}
const yt = 3, oe = 10, et = 1, ds = 8, ps = 500, be = /Mac|iPhone|iPad/.test(navigator.userAgent);
function ve(n) {
  return be ? n.metaKey : n.ctrlKey;
}
const le = '<path d="M7 22a5 5 0 0 1-2-3.994"/><circle cx="5" cy="16" r="2"/>', he = '<path d="M12 4v16M4 12h16"/>', gs = {
  freehand: '<path d="M3.704 14.467a10 8 0 1 1 3.115 2.375"/>' + le,
  // Hexagon inscribed in the freehand loop, a corner on the knot.
  polygonal: '<path d="M4.35 14.11 2.3 8.2 9.1 2.3l9.7 1.9 2.9 7.6-6.8 5.9-7.93-1.36"/>' + le,
  rectangle: he,
  ellipse: he,
  move: '<path d="M12 2v20"/><path d="m15 19-3 3-3-3"/><path d="m19 9 3 3-3 3"/><path d="M2 12h20"/><path d="m5 9-3 3 3 3"/><path d="m9 5 3-3 3 3"/>'
}, ys = {
  add: '<path d="M22 26h8M26 22v8"/>',
  subtract: '<path d="M22 26h8"/>',
  intersect: '<path d="M23 23l6 6M29 23l-6 6"/>',
  close: '<circle cx="26" cy="26" r="3"/>'
}, ae = /* @__PURE__ */ new Map();
function ce(n, t) {
  const e = `${n} ${t}`, i = ae.get(e);
  if (i) return i;
  const s = gs[n] + (t ? ys[t] : ""), r = n === "rectangle" || n === "ellipse" ? 20 / 24 : 16 / 24, o = t ? 36 : 24, l = o * r, [a, c] = n === "freehand" || n === "polygonal" ? [7.5, 22.5] : [12, 12], d = `${Math.round(a * r)} ${Math.round(c * r)}`, h = `<svg xmlns="http://www.w3.org/2000/svg" width="${l}" height="${l}" viewBox="0 0 ${o} ${o}" fill="none" stroke-linecap="round" stroke-linejoin="round"><g stroke="white" stroke-width="4">${s}</g><g stroke="black" stroke-width="2">${s}</g></svg>`, f = n === "move" ? "move" : "crosshair", u = `url("data:image/svg+xml,${encodeURIComponent(h)}") ${d}, ${f}`;
  return ae.set(e, u), u;
}
const ms = `
	:host {
		position: absolute;
		display: none;
		z-index: 1;
		touch-action: none;
		user-select: none;
	}

	:host([hidden]) {
		display: none !important;
	}

	/* Cursor changes as overlay gets enabled, for browser to show it at once. */
	:host([disabled]) {
		pointer-events: none;
		cursor: auto;
	}

	svg {
		position: absolute;
		inset: 0;
		width: 100%;
		height: 100%;
		overflow: visible;
		pointer-events: none;
	}

	polyline,
	path {
		display: none;
		fill: none;
		stroke-width: 1px;
	}

	#draft {
		stroke: var(--select-tool-color, var(--color-accent, #f97316));
	}

	/* Marching ants: black dashes over a white line. */
	#selection {
		stroke: white;
	}

	#ants {
		stroke: black;
		stroke-dasharray: 4 4;
		animation: march 0.6s linear infinite;
	}

	:host([static]) #ants {
		animation: none;
	}

	@keyframes march {
		to {
			stroke-dashoffset: -8;
		}
	}
`;
class _s extends HTMLElement {
  #t = null;
  /** As drawn, kept intact while browsing images. */
  #e = null;
  /** Resolution of the image selection was drawn over. */
  #i = null;
  /** Last selection user cleared, which they may select back, and its resolution. */
  #h = null;
  #c;
  #p;
  #g;
  /** Last emitted value, as JSON, to emit only changes. */
  #L = "null";
  /**
   * Element selection is drawn within, e.g. the canvas: a drawing leaving it
   * is in fact a drag of image to another element.
   */
  area = null;
  /** Element image shows in, letterbox bands included, which take clicks while drawing. Null for the parent. */
  bands = null;
  /** Neighbors each vertex of freehand segments is averaged with on each side, to smooth the hand's jitter. */
  smoothing = 1;
  #s = "freehand";
  #A = !1;
  #H = ["", ""];
  /** Pointer pressed: not moved yet, dragged, or dragging the image away. */
  #n = null;
  /** Whether an outline is being drawn, pointer pressed or not. */
  #r = !1;
  /** Whether this drag started the outline, which leaving the area drops then. */
  #j = !1;
  /** What outline being drawn does to the current selection, if not replace it. */
  #x = null;
  /** Operation of the shortcut held while pointer is over overlay, if any. */
  #N = null;
  /** Whether pointer hovers the selection, which a shape tool moves then. */
  #E = !1;
  /** Whether user moves the selection, rather than draws. */
  #S = !1;
  /** Modifiers held since the press which set the operation, so don't constrain a shape. */
  #M = { shift: !1, alt: !1 };
  /** Where user pressed, in client pixels, to tell a click from a move. */
  #z = null;
  /** Where user pressed, in image pixels. */
  #O = null;
  /** Selection as it was when user started drawing or moving it, back if user cancels. */
  #k = null;
  /** Vertices of the outline being drawn, applied to the current selection once closed. */
  #a = null;
  /** Draft length at the end of each segment, back to which Delete goes. */
  #I = [];
  /** Whether pointer draws a freehand segment, else a straight one. */
  #o = !1;
  /** Index of the first vertex of the freehand segment being drawn. */
  #C = 0;
  /** End of the straight segment being drawn, where pointer is. */
  #y = null;
  /** Where pointer is, in client and in image pixels, and keys held then. */
  #P = null;
  #D = null;
  #K = null;
  /** Last click while drawing, to tell a double-click. */
  #T = null;
  /** Element outside overlay that pointer is over, while user drags image. */
  #u = null;
  /** Whether drop target accepts displayed image. */
  #F = !1;
  #B = null;
  #X = new ResizeObserver(() => this.#Y());
  #V = () => this.#Y();
  /** Tell what a drag would do, as user presses or releases a shortcut. */
  #G = (t) => {
    if (!this.matches(":hover")) {
      this.#Z();
      return;
    }
    t.key === "Alt" && t.preventDefault(), this.#U(t);
  };
  /**
   * While user presses or draws: Escape cancels, Delete removes the last
   * segment, and modifiers change the segment or shape being drawn. Captured
   * before others, e.g. the canvas, which leaves fullscreen on Escape.
   */
  #Q = (t) => {
    const e = t.type === "keydown";
    if (e && t.key === "Escape") {
      t.preventDefault(), t.stopPropagation(), this.#m();
      return;
    }
    if (e && (t.key === "Delete" || t.key === "Backspace")) {
      this.#xt() && (t.preventDefault(), t.stopPropagation());
      return;
    }
    if (["Shift", "Alt", "Control", "Meta"].includes(t.key)) {
      if (t.key === "Alt" && t.preventDefault(), !e && t.key === "Alt" && this.#s === "freehand" && this.#r && !this.#n && !this.#o) {
        this.#w();
        return;
      }
      this.#P && this.#v(this.#P, t);
    }
  };
  /** Pointer moves anywhere while user presses or draws. */
  #ct = (t) => {
    this.#v([t.clientX, t.clientY], t);
  };
  /** Clicks on letterbox bands add vertices too while drawing, clamped to image. */
  #ft = (t) => {
    const e = t.target, i = this.bands ?? this.parentElement;
    this.#r && e !== this && i?.contains(e) && this.#it(t);
  };
  constructor() {
    super();
    const t = this.attachShadow({ mode: "open" }), e = document.createElement("style");
    e.textContent = ms;
    const i = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    i.innerHTML = '<path id="selection"></path><path id="ants"></path><polyline id="draft"></polyline>', this.#c = i.querySelector("#draft"), this.#p = i.querySelector("#selection"), this.#g = i.querySelector("#ants"), t.append(e, i), this.addEventListener("pointerenter", (s) => this.#pt(s)), this.addEventListener("pointerleave", () => this.#Z()), this.addEventListener("pointerdown", (s) => this.#it(s)), this.addEventListener("pointermove", (s) => this.#d || this.#U(s)), this.addEventListener("pointerup", (s) => this.#yt(s)), this.addEventListener("pointercancel", () => this.#d && this.#m());
  }
  /**
   * Image to draw the selection over. Selection persists when another image
   * is displayed, scaled to its resolution, so user finds it back while
   * browsing images.
   */
  get target() {
    return this.#t;
  }
  set target(t) {
    this.#t !== t && (this.#t && (this.#X.unobserve(this.#t), this.#t.removeEventListener("load", this.#V)), this.#d && this.#m(), this.#t = t, t && (this.#X.observe(t), t.addEventListener("load", this.#V))), this.#Y();
  }
  /** How user draws. Changing it closes the outline being drawn, if any. */
  get mode() {
    return this.#s;
  }
  set mode(t) {
    t !== this.#s && (this.#ot(), this.#s = t, this.#E = !1, this.#f());
  }
  /** Whether user can't draw. Disabling closes the outline being drawn, if any. */
  get disabled() {
    return this.#A;
  }
  set disabled(t) {
    t !== this.#A && (this.#ot(), this.#A = t, this.toggleAttribute("disabled", t), this.#f());
  }
  /**
   * Tooltips shown over the image: while nothing is selected, e.g. to tell
   * how to select, then once selected, e.g. to tell how to clear it.
   */
  get tooltips() {
    return this.#H;
  }
  set tooltips(t) {
    this.#H = t, this.#l();
  }
  /**
   * Selection in pixels of the displayed image, scaled to it.
   * Setting it emits no event.
   */
  get value() {
    return this.#b();
  }
  set value(t) {
    this.#e = t && t.map((e) => e.map(([i, s]) => [i, s])), this.#i = $(this.#t) ?? this.#i, this.#L = JSON.stringify(re(this.#b())), this.#_(), this.#l();
  }
  /** Clear the selection, which `reselect` brings back. */
  clear() {
    this.#d && this.#m(), this.#e && (this.#h = { selection: this.#e, size: this.#i }), this.#e = null, this.#_(), this.#l(), this.#R();
  }
  /** Bring back the last selection cleared, if any, in place of the current one. */
  reselect() {
    this.#d && this.#m(), this.#h && (this.#e = this.#h.selection, this.#i = this.#h.size, this.#l(), this.#R());
  }
  /** Select what isn't, and only that: the whole image if nothing is. */
  invert() {
    this.#d && this.#m();
    const t = $(this.#t);
    if (!t) return;
    let e;
    try {
      e = cs(this.#b(), t);
    } catch (i) {
      console.warn("Select tool couldn't invert selection:", i);
      return;
    }
    if (!e) {
      this.clear();
      return;
    }
    this.#e = e, this.#i = t, this.#l(), this.#R();
  }
  /** Cover image content, letterbox bands excluded. */
  sync() {
    const t = this.#t, e = this.parentElement;
    if (!t?.isConnected || !e || !t.naturalWidth || !t.naturalHeight) {
      this.style.display = "none";
      return;
    }
    const i = t.getBoundingClientRect(), s = e.getBoundingClientRect(), r = Math.min(
      i.width / t.naturalWidth,
      i.height / t.naturalHeight
    ), o = t.naturalWidth * r, l = t.naturalHeight * r;
    if (o <= 0 || l <= 0) {
      this.style.display = "none";
      return;
    }
    const a = i.left - s.left - e.clientLeft + (i.width - o) / 2, c = i.top - s.top - e.clientTop + (i.height - l) / 2;
    this.style.display = "block", this.style.left = `${a}px`, this.style.top = `${c}px`, this.style.width = `${o}px`, this.style.height = `${l}px`;
  }
  /** Whether user presses or draws. */
  get #d() {
    return this.#n !== null || this.#r;
  }
  /** Follow displayed image, which may be another one or resized. */
  #Y() {
    this.#i ??= $(this.#t), this.sync(), this.#l(), this.#R();
  }
  /**
   * Selection scaled to displayed image, whose resolution may differ from
   * the drawn one, so it surrounds the same region.
   */
  #b() {
    const t = this.#e, e = $(this.#t);
    if (!t || !e || !this.#i) return t;
    const i = e.width / this.#i.width, s = e.height / this.#i.height;
    return t.map(
      (r) => r.map(([o, l]) => [o * i, l * s])
    );
  }
  /** Image point at client coordinates, clamped to image. */
  #q([t, e]) {
    const i = this.#t, s = this.getBoundingClientRect(), r = tt(t - s.left, 0, s.width), o = tt(e - s.top, 0, s.height);
    return [
      r / s.width * i.naturalWidth,
      o / s.height * i.naturalHeight
    ];
  }
  /** Distance between image points, in CSS pixels. */
  #ut([t, e], [i, s]) {
    const r = this.#t;
    return Math.hypot(
      (t - i) * this.clientWidth / r.naturalWidth,
      (e - s) * this.clientHeight / r.naturalHeight
    );
  }
  #l() {
    const t = this.#t, e = !!$(t), i = e ? this.#b() : null, s = e ? this.#dt() : null;
    this.title = this.#r ? "" : this.#H[i ? 1 : 0], this.#c.style.display = s ? "inline" : "none", s && this.#c.setAttribute("points", this.#J(s, t));
    for (const r of [this.#p, this.#g])
      r.style.display = i ? "inline" : "none", i && r.setAttribute(
        "d",
        i.map((o) => `M${this.#J(o, t)}Z`).join("")
      );
  }
  /**
   * Outline being drawn, as shown: shape closed, freehand segment smoothed
   * as on its end, since last vertices settle as next ones come, or straight
   * segment to pointer.
   */
  #dt() {
    const t = this.#a;
    if (!this.#r || !t?.length) return null;
    if (G(this.#s)) return [...t, t[0]];
    if (this.#o) {
      const e = this.#C;
      return [...t.slice(0, e), ...ne(t.slice(e), this.#lt())];
    }
    return this.#y ? [...t, this.#y] : t;
  }
  /** SVG points of vertices, in overlay pixels. */
  #J(t, e) {
    const i = this.clientWidth / e.naturalWidth, s = this.clientHeight / e.naturalHeight;
    return t.map(([r, o]) => `${r * i},${o * s}`).join(" ");
  }
  /** Emit value, if changed. */
  #R() {
    const t = re(this.#b()), e = JSON.stringify(t);
    e !== this.#L && (this.#L = e, this.dispatchEvent(new CustomEvent("selection-change", { detail: t })));
  }
  #pt(t) {
    window.addEventListener("keydown", this.#G, !0), window.addEventListener("keyup", this.#G, !0), this.#U(t);
  }
  #Z() {
    window.removeEventListener("keydown", this.#G, !0), window.removeEventListener("keyup", this.#G, !0), this.#N = null, this.#E = !1, this.#f();
  }
  /**
   * Operation of the shortcut held, if any. None for a shape while nothing is
   * selected: its modifiers rather constrain it.
   */
  #tt(t) {
    return G(this.#s) && !this.#e ? null : xs(t);
  }
  /** Whether pointer, at `client`, is over the selection, which a shape tool moves. */
  #et(t) {
    if (!G(this.#s) || !this.#t) return !1;
    const e = this.#b();
    return !!e && fs(e, this.#q(t));
  }
  /** Tell what a click or drag would do, as pointer hovers or user presses or releases a shortcut. */
  #U(t) {
    const e = this.#tt(t), i = t instanceof PointerEvent ? this.#et([t.clientX, t.clientY]) : this.#E;
    e === this.#N && i === this.#E || (this.#N = e, this.#E = i, this.#f());
  }
  /**
   * A press, unless an outline is being drawn, prepares one, which starts
   * as the pointer moves, or on release for a polygonal lasso. Shift held
   * then adds the outline drawn to the current selection, Alt subtracts it,
   * and both intersect it: for a shape, only if something is selected, else
   * they constrain it. Else the outline replaces the current selection as it
   * starts, or, for a shape pressed inside the selection, moves it.
   */
  #it(t) {
    if (!this.#t || t.button !== 0 || this.#n) return;
    t.preventDefault(), t.stopPropagation();
    const e = [t.clientX, t.clientY], i = this.#q(e);
    if (!this.#r) {
      this.#_(), this.#e = this.#b(), this.#i = $(this.#t), this.#k = this.#e, this.#x = this.#tt(t);
      const s = this.#x !== null;
      this.#M = { shift: s && t.shiftKey, alt: s && t.altKey }, this.#S = !s && this.#et(e), this.#a = [i], this.#I = [1], this.#ht(!0);
    }
    this.#n = "press", this.#z = e, this.#O = i, this.setPointerCapture(t.pointerId), this.#v(e, t);
  }
  /**
   * Follow pointer, at `client`, or modifiers, as user presses or draws.
   *
   * A freehand lasso draws freehand while dragged, and straight segments
   * once released with Alt held: from then on, clicks with Alt held add
   * vertices, and releasing Alt while dragging goes freehand again.
   * A polygonal lasso draws straight segments to the pointer, and freehand
   * while dragged with Alt held. Shift snaps a straight segment to 45°.
   * A shape is dragged from the press to the pointer, as is the selection
   * moved.
   */
  #v(t, e) {
    if (this.#P = t, this.#K = e, this.#n === "drop") {
      this.#at(t);
      return;
    }
    const i = this.#a;
    if (!this.#t || !i) return;
    const s = this.#q(t), r = G(this.#s);
    this.#D = s;
    let o = !1;
    if (this.#n === "press") {
      const [l, a] = this.#z;
      Math.hypot(t[0] - l, t[1] - a) > oe && (this.#n = "drag", o = !0, !this.#r && !this.#S && this.#nt(!0));
    }
    if (this.#S) {
      if (this.#n === "drag") {
        const [l, a] = this.#O;
        this.#e = us(this.#k, [s[0] - l, s[1] - a]), this.#l();
      }
      this.#f();
      return;
    }
    if (this.#n === "drag" && this.#j && this.#vt(t)) {
      this.#bt(), this.#at(t);
      return;
    }
    if (this.#n === "drag" && !r) {
      const l = this.#s === "freehand" ? this.#o || !e.altKey : e.altKey;
      l && !this.#o ? this.#_t(o ? this.#O : this.#y ?? s) : !l && this.#o && this.#W();
    }
    if (r)
      this.#r && (this.#a = this.#gt(s, e));
    else if (this.#o) {
      const [l, a] = i[i.length - 1];
      Math.hypot(s[0] - l, s[1] - a) >= et && i.push(s);
    } else {
      const l = i[i.length - 1];
      this.#y = e.shiftKey ? rs(l, s, $(this.#t)) : s;
    }
    this.#l(), this.#f();
  }
  /**
   * Rectangle or ellipse from the press to `point`, clamped to image, or no
   * vertex if it encloses nothing. Shift makes it a square or a circle, and
   * Alt draws it from its center, unless they set the operation at the
   * press: then, once released and pressed again.
   */
  #gt(t, e) {
    this.#M.shift &&= e.shiftKey, this.#M.alt &&= e.altKey;
    const [i, s] = this.#O;
    let [r, o] = [t[0] - i, t[1] - s];
    if (e.shiftKey && !this.#M.shift) {
      const h = Math.max(Math.abs(r), Math.abs(o));
      r = r < 0 ? -h : h, o = o < 0 ? -h : h;
    }
    if (Math.abs(r) < et || Math.abs(o) < et) return [];
    const a = [e.altKey && !this.#M.alt ? [i - r, s - o] : [i, s], [i + r, s + o]], { width: c, height: d } = $(this.#t);
    return (this.#s === "rectangle" ? os(a) : ls(a)).map(
      ([h, f]) => [tt(h, 0, c), tt(f, 0, d)]
    );
  }
  /**
   * Release ends a click, which ends a straight segment, or a drag, which
   * ends a freehand one, closes a shape or moves the selection. A click on
   * the first vertex closes the outline, as do a double-click, a click with
   * Ctrl (Cmd on macOS) held, which adds a vertex first, and releasing a
   * freehand lasso without Alt held.
   */
  #yt(t) {
    const e = this.#n;
    if (!e) return;
    if (this.#n = null, this.#j = !1, e === "drop") {
      this.#F && (this.#$(this.#u, "drop"), this.#u = null), this.#_();
      return;
    }
    if (this.#S && e === "drag") {
      this.#_(), this.#l(), this.#R();
      return;
    }
    if (!this.#r) {
      this.#s === "polygonal" ? (this.#nt(!1), this.#T = { time: t.timeStamp, at: this.#z }, this.#l(), this.#f()) : this.#x ? this.#_() : this.clear();
      return;
    }
    const i = [t.clientX, t.clientY];
    if (G(this.#s)) {
      this.#v(i, t), this.#w();
      return;
    }
    if (this.#o) {
      if (this.#s === "freehand" && !t.altKey) {
        this.#w();
        return;
      }
      this.#W(), this.#v(i, t);
      return;
    }
    if (this.#v(i, t), e === "press" && this.#mt(t.timeStamp, i)) {
      this.#w();
      return;
    }
    if (this.#st()) {
      this.#w();
      return;
    }
    if (this.#rt(this.#y), ve(t) || this.#s === "freehand" && !t.altKey) {
      this.#w();
      return;
    }
    this.#T = e === "press" ? { time: t.timeStamp, at: i } : null, this.#l(), this.#f();
  }
  #mt(t, [e, i]) {
    const s = this.#T;
    return !!s && t - s.time <= ps && Math.hypot(e - s.at[0], i - s.at[1]) <= oe;
  }
  /** Whether pointer is on the first vertex of a lasso outline it can close. */
  #st() {
    const t = this.#a;
    return this.#r && !G(this.#s) && !this.#o && !!t && !!this.#D && t.length >= yt && this.#ut(t[0], this.#D) <= ds;
  }
  /** Start drawing an outline, which replaces the current selection at once if no shortcut was held. */
  #nt(t) {
    this.#r = !0, this.#j = t, this.#x || (this.#e = null), this.#s === "freehand" && (this.#C = 0, this.#o = !0);
  }
  /** Start a freehand segment, from `point`, after a straight one to it. */
  #_t(t) {
    this.#rt(t), this.#C = this.#a.length - 1, this.#o = !0, this.#y = null;
  }
  /** End the freehand segment, smoothed. */
  #W() {
    const t = this.#a, e = this.#C;
    t.splice(e, 1 / 0, ...ne(t.slice(e), this.#lt())), this.#I.push(t.length), this.#o = !1;
  }
  /** End a straight segment at a vertex. */
  #rt(t) {
    const e = this.#a, [i, s] = e[e.length - 1];
    Math.hypot(t[0] - i, t[1] - s) < et || (e.push(t), this.#I.push(e.length));
  }
  /** Remove the last segment of a lasso, or cancel it if none is left. */
  #xt() {
    if (!this.#r || this.#o || G(this.#s)) return !1;
    this.#I.pop();
    const t = this.#I.at(-1);
    return t === void 0 ? this.#m() : (this.#a.length = t, this.#T = null, this.#P && this.#K && this.#v(this.#P, this.#K)), !0;
  }
  /** Close the outline being drawn, if any, else forget the press. */
  #ot() {
    this.#r ? this.#w() : this.#n && this.#m();
  }
  /** Close the outline from its last vertex to its first, unless it encloses nothing, and apply it. */
  #w() {
    this.#o && this.#W();
    const t = this.#a, e = this.#x, i = this.#e, s = this.#k;
    if (this.#_(), e)
      t && t.length >= yt && (i ? this.#e = as(i, t, e) ?? i : this.#e = e === "add" ? [t] : null);
    else {
      if (!t || t.length < yt) {
        this.#e = s, this.clear();
        return;
      }
      this.#e = [t];
    }
    this.#l(), this.#R();
  }
  #lt() {
    return Math.max(0, Math.floor(this.smoothing)) || 0;
  }
  /** Back to selection as it was before user started drawing or moving it. */
  #m() {
    this.#d && this.#n !== "drop" && (this.#e = this.#k), this.#_(), this.#l();
  }
  /** Turn the drawing into a drag of the image. */
  #bt() {
    this.#n = "drop", this.#e = this.#k, this.#r = !1, this.#o = !1, this.#a = null, this.#y = null, this.#l();
  }
  /** Forget ongoing gesture and outline, if any. */
  #_() {
    this.#u && this.#$(this.#u, "dragleave"), this.#ht(!1), this.#n = null, this.#r = !1, this.#j = !1, this.#x = null, this.#S = !1, this.#M = { shift: !1, alt: !1 }, this.#z = null, this.#O = null, this.#k = null, this.#a = null, this.#I = [], this.#o = !1, this.#C = 0, this.#y = null, this.#P = null, this.#D = null, this.#K = null, this.#T = null, this.#u = null, this.#F = !1, this.#B = null, this.#f();
  }
  /** Follow keys and pointer anywhere, while user presses or draws. */
  #ht(t) {
    const e = (t ? window.addEventListener : window.removeEventListener).bind(window);
    e("keydown", this.#Q, !0), e("keyup", this.#Q, !0), e("pointermove", this.#ct, !0), e("pointerdown", this.#ft, !0);
  }
  /** Cursor of ongoing drop, if any, else of what a click or drag would do. */
  #f() {
    let t = "";
    if (this.#n === "drop")
      t = this.#F ? "copy" : "grabbing";
    else if (this.#S || this.#E && !this.#d && !this.#N && !this.#A)
      t = ce("move", null);
    else if (!this.#A) {
      const i = this.#d ? this.#x : this.#N;
      t = ce(this.#s, this.#st() ? "close" : i);
    }
    this.style.cursor = t;
    const e = this.bands ?? this.parentElement;
    e && (e.style.cursor = this.#r ? t : "");
  }
  /** Whether pointer left the area selection is drawn within. */
  #vt([t, e]) {
    const i = (this.area ?? this).getBoundingClientRect();
    return t < i.left || t > i.right || e < i.top || e > i.bottom;
  }
  /**
   * Drag displayed image over the element pointer is over, outside overlay,
   * as browser would do. Overlay can't let browser drag the image itself:
   * it would take any drag over it, those drawing the selection included.
   */
  #at([t, e]) {
    const i = document.elementFromPoint(t, e), s = i === this ? null : i;
    s !== this.#u && (s && this.#$(s, "dragenter"), this.#u && this.#$(this.#u, "dragleave"), this.#u = s), this.#F = !!s && !this.#$(s, "dragover"), this.#f();
  }
  /** Returns false if canceled. */
  #$(t, e) {
    return this.#B || (this.#B = new DataTransfer(), this.#B.setData("text/uri-list", this.#t.currentSrc)), t.dispatchEvent(
      new DragEvent(e, {
        bubbles: !0,
        cancelable: !0,
        composed: !0,
        dataTransfer: this.#B
      })
    );
  }
}
function xs(n) {
  return n.shiftKey && n.altKey ? "intersect" : n.shiftKey ? "add" : n.altKey ? "subtract" : null;
}
function $(n) {
  return n?.naturalWidth && n.naturalHeight ? { width: n.naturalWidth, height: n.naturalHeight } : null;
}
const kt = "select-tool-overlay";
customElements.get(kt) || customElements.define(kt, _s);
const fe = /* @__PURE__ */ Symbol.for("gradio_select_tools.group"), mt = {
  freehand: "l",
  polygonal: "l",
  rectangle: "m",
  ellipse: "m"
};
function bs(n) {
  return n instanceof HTMLElement && (n.isContentEditable || ["INPUT", "TEXTAREA", "SELECT"].includes(n.tagName));
}
class Nt {
  constructor(t) {
    this.host = t, this.overlay = document.createElement(kt), t.doc_el.append(this.overlay), this.overlay.area = t.area, this.overlay.bands = t.frame, this.overlay.target = t.image, this.overlay.addEventListener("selection-change", (e) => {
      const i = e.detail;
      for (const s of this.#t.values()) s.on_change(i, !0);
    }), t.addEventListener("tool-change", this.#i), window.addEventListener("keydown", this.#h);
  }
  host;
  overlay;
  #t = /* @__PURE__ */ new Map();
  /** Tool user selected last, by key, which this key selects back. */
  #e = /* @__PURE__ */ new Map();
  #i = () => this.refresh();
  /**
   * L (M) selects the lasso (shape) tool user selected last, or the next
   * one if such a tool is selected, unless user types text with pointer away
   * from the canvas area.
   * While a select tool is selected, Ctrl+D (Cmd+D on macOS) clears the
   * selection, Ctrl+Shift+D selects it back, and Ctrl+Shift+I inverts it.
   */
  #h = (t) => {
    if (t.defaultPrevented || t.repeat || t.altKey || bs(t.target) && !this.host.area.matches(":hover"))
      return;
    const e = t.key.toLowerCase(), i = ve(t);
    (be ? t.ctrlKey : t.metaKey) || (!i && Object.values(mt).includes(e) ? this.#L(e, t) : i && (e === "d" || e === "i" && t.shiftKey) && this.#s(e, t));
  };
  /** Group of the select tools of a canvas. */
  static of(t) {
    const e = t;
    return e[fe] ??= new Nt(t);
  }
  /** Add a tool, with its value, which is the selection unless null. */
  join(t, e) {
    this.#t.set(t.id, t), e ? this.set_value(t.id, e) : this.overlay.value && t.on_change(this.overlay.value, !1), this.refresh();
  }
  leave(t) {
    if (this.#t.delete(t), this.#t.size) {
      this.refresh();
      return;
    }
    this.host.removeEventListener("tool-change", this.#i), window.removeEventListener("keydown", this.#h), this.overlay.target = null, this.overlay.remove(), delete this.host[fe];
  }
  /** Selection set by an event to a tool's value: the other tools follow. */
  set_value(t, e) {
    this.overlay.value = e;
    for (const i of this.#t.values())
      i.id !== t && i.on_change(e, !1);
  }
  /** Apply tool states, e.g. after one changed. */
  refresh() {
    const t = this.#c();
    t && this.#e.set(mt[t.state.mode], t.id);
    const e = t ?? this.#p()[0], i = this.overlay;
    i.mode = t?.state.mode ?? i.mode, i.disabled = !t || !this.#g(t), i.hidden = ![...this.#t.values()].some((s) => s.state.visible), i.toggleAttribute("static", e?.state.marching_ants === !1), i.smoothing = e?.state.smoothing ?? 1, i.tooltips = e?.state.tooltips ?? ["", ""];
  }
  #c() {
    return this.host.tool === null ? void 0 : this.#t.get(this.host.tool);
  }
  /** Tools in the order they were given to canvas. */
  #p() {
    return this.host.tool_groups.flat().flatMap((t) => this.#t.get(t) ?? []);
  }
  #g(t) {
    return t.state.visible && t.state.interactive;
  }
  #L(t, e) {
    const i = this.#p().filter(
      (o) => mt[o.state.mode] === t && this.#g(o)
    );
    if (!i.length) return;
    const s = this.#c(), r = s && i.includes(s) ? i[(i.indexOf(s) + 1) % i.length] : i.find((o) => o.id === this.#e.get(t)) ?? i[0];
    e.preventDefault(), this.host.tool = r.id;
  }
  #s(t, e) {
    const i = this.#c();
    !i || !this.#g(i) || (e.preventDefault(), t === "i" ? this.overlay.invert() : e.shiftKey ? this.overlay.reselect() : this.overlay.clear());
  }
}
var vs = /* @__PURE__ */ ft('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3.704 14.467a10 8 0 1 1 3.115 2.375"></path><path d="M7 22a5 5 0 0 1-2-3.994"></path><circle cx="5" cy="16" r="2"></circle></svg>');
function ws(n) {
  var t = vs();
  D(n, t);
}
var Es = /* @__PURE__ */ ft('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4.35 14.11 2.3 8.2 9.1 2.3l9.7 1.9 2.9 7.6-6.8 5.9-7.93-1.36"></path><path d="M7 22a5 5 0 0 1-2-3.994"></path><circle cx="5" cy="16" r="2"></circle></svg>');
function Ss(n) {
  var t = Es();
  D(n, t);
}
var Ms = /* @__PURE__ */ ft('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="square" stroke-linejoin="round"><path d="M3 5V4a1 1 0 0 1 1-1h1"></path><path d="M19 3h1a1 1 0 0 1 1 1v1"></path><path d="M21 19v1a1 1 0 0 1-1 1h-1"></path><path d="M5 21H4a1 1 0 0 1-1-1v-1"></path><path d="M9 3h1"></path><path d="M9 21h1"></path><path d="M14 3h1"></path><path d="M14 21h1"></path><path d="M3 9v1"></path><path d="M21 9v1"></path><path d="M3 14v1"></path><path d="M21 14v1"></path></svg>');
function ks(n) {
  var t = Ms();
  D(n, t);
}
var Is = /* @__PURE__ */ Rt("<div><!></div>");
function Rs(n, t) {
  Ve(t, !0);
  const e = {
    freehand: ws,
    polygonal: Ss,
    rectangle: ks,
    ellipse: Li
  }, i = /* @__PURE__ */ pi(t, ["$$slots", "$$events", "$$legacy"]), s = new ki(i);
  let r, o = s.props.value ?? null, l = W(null), a = null, c = W(!1), d = null;
  const h = {
    id: s.shared.id,
    state: {
      mode: s.props.mode,
      visible: !0,
      interactive: !0,
      marching_ants: !0,
      smoothing: 1,
      tooltips: ["", ""]
    },
    on_change(g, x) {
      f(g, o) || (u(o, g), o = g, s.props.value = g, x && s.dispatch("input"), s.dispatch("change"));
    }
  };
  function f(g, x) {
    return JSON.stringify(g ?? null) === JSON.stringify(x ?? null);
  }
  function u(g, x) {
    !g && x ? s.dispatch("drawn") : g && !x && s.dispatch("cleared");
  }
  function y(g) {
    if (L(l)) return;
    X(l, g, !0), g.add_tool(s.shared.id, r), a = Nt.of(g), a.join(h, o);
    const x = () => {
      X(c, g.tool === s.shared.id);
    };
    g.addEventListener("tool-change", x), x();
  }
  function p() {
    L(l) && (L(l).tool = L(c) ? null : s.shared.id);
  }
  ye(() => {
    r.parentElement && (r.parentElement.hidden = !0);
    const g = s.props.canvas_id;
    g !== null && (d = Pi(g, y));
  }), gi(() => {
    d?.(), a?.leave(s.shared.id);
  }), Y(() => {
    const g = s.props.value ?? null;
    f(g, o) || (u(o, g), o = g, a?.set_value(s.shared.id, g), s.dispatch("change"));
  }), Y(() => {
    h.state = {
      mode: s.props.mode,
      visible: s.shared.visible !== !1,
      interactive: s.shared.interactive !== !1,
      marching_ants: s.props.marching_ants !== !1,
      smoothing: s.props.smoothing ?? 1,
      tooltips: [
        s.props.draw_tooltip ?? "",
        s.props.clear_tooltip ?? ""
      ]
    }, L(l) && a?.refresh();
  });
  var _ = Is(), m = st(_);
  {
    let g = bt(() => (L(c) ? s.props.disable_tooltip : s.props.enable_tooltip) ?? ""), x = bt(() => s.shared.interactive === !1);
    xi(m, {
      get Icon() {
        return e[s.props.mode];
      },
      get label() {
        return L(g);
      },
      get disabled() {
        return L(x);
      },
      onclick: p
    });
  }
  ci(_, (g) => r = g, () => r), xt(() => rt(_, "hidden", !L(l) || s.shared.visible === !1)), D(n, _), Xe();
}
export {
  Rs as default
};
