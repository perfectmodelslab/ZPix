import { i as Jt, g as Sr, o as aa, q as Qt, c as Ue, a as $t, b as zt, d as na, T as ia, e as sa, f as Ht, r as er, h as Ge, p as tr, j as Xe, m as la, s as Lr, k as pt, E as Pt, l, n as cr, t as zr, u as Cr, v as rr, w as oa, x as dr, y as fa, z as ca, A as We, B as Re, I as Rt, C as da, D as ua, F as ha, N as va, G as ar, H as Pr, J as It, K as _a, L as ga, M as pa, O as ba, P as ma, Q as wa, R as ya, S as xa, U as ka, V as bt, W as Ea, X as Ta, Y as Ma, Z as W, _ as Aa, $ as nr, a0 as St, a1 as Sa, a2 as se, a3 as La, a4 as ur, a5 as ve, a6 as Ir, a7 as nt, a8 as za, a9 as M, aa as Ca, ab as Ut, ac as Pa, ad as Ia, ae as Yt, af as Oa, ag as Na, ah as Or, ai as ja, aj as Fa, ak as Ra, al as qa, am as Nr, an as ut, ao as Ba, ap as hr, aq as Da, ar as Q, as as mt, at as wt, au as z, av as Fe, aw as R, ax as Va, ay as D, az as ne, aA as ce, aB as Ha, aC as Ua, aD as K, aE as jr, aF as Ya } from "./render-BuEbLTW8.js";
function Ka(t) {
  throw new Error("https://svelte.dev/e/lifecycle_outside_component");
}
const Wa = [];
function Za(t, e = !1, r = !1) {
  return Lt(t, /* @__PURE__ */ new Map(), "", Wa, null, r);
}
function Lt(t, e, r, a, i = null, n = !1) {
  if (typeof t == "object" && t !== null) {
    var s = e.get(t);
    if (s !== void 0) return s;
    if (t instanceof Map) return (
      /** @type {Snapshot<T>} */
      new Map(t)
    );
    if (t instanceof Set) return (
      /** @type {Snapshot<T>} */
      new Set(t)
    );
    if (Jt(t)) {
      var f = (
        /** @type {Snapshot<any>} */
        Array(t.length)
      );
      e.set(t, f), i !== null && e.set(i, f);
      for (var o = 0; o < t.length; o += 1) {
        var c = t[o];
        o in t && (f[o] = Lt(c, e, r, a, null, n));
      }
      return f;
    }
    if (Sr(t) === aa) {
      f = {}, e.set(t, f), i !== null && e.set(i, f);
      for (var u in t)
        f[u] = Lt(
          // @ts-expect-error
          t[u],
          e,
          r,
          a,
          null,
          n
        );
      return f;
    }
    if (t instanceof Date)
      return (
        /** @type {Snapshot<T>} */
        structuredClone(t)
      );
    if (typeof /** @type {T & { toJSON?: any } } */
    t.toJSON == "function" && !n)
      return Lt(
        /** @type {T & { toJSON(): any } } */
        t.toJSON(),
        e,
        r,
        a,
        // Associate the instance with the toJSON clone
        t
      );
  }
  if (t instanceof EventTarget)
    return (
      /** @type {Snapshot<T>} */
      t
    );
  try {
    return (
      /** @type {Snapshot<T>} */
      structuredClone(t)
    );
  } catch {
    return (
      /** @type {Snapshot<T>} */
      t
    );
  }
}
function Ga(t, e) {
  if (e) {
    const r = document.body;
    t.autofocus = !0, Qt(() => {
      document.activeElement === r && t.focus();
    });
  }
}
function Fr(t) {
  var e = document.createElement("template");
  return e.innerHTML = t.replaceAll("<!>", "<!---->"), e.content;
}
function it(t, e) {
  var r = (
    /** @type {Effect} */
    $t
  );
  r.nodes === null && (r.nodes = { start: t, end: e, a: null, t: null });
}
// @__NO_SIDE_EFFECTS__
function U(t, e) {
  var r = (e & ia) !== 0, a = (e & sa) !== 0, i, n = !t.startsWith("<!>");
  return () => {
    i === void 0 && (i = Fr(n ? t : "<!>" + t), r || (i = /** @type {TemplateNode} */
    zt(i)));
    var s = (
      /** @type {TemplateNode} */
      a || na ? document.importNode(i, !0) : i.cloneNode(!0)
    );
    if (r) {
      var f = (
        /** @type {TemplateNode} */
        zt(s)
      ), o = (
        /** @type {TemplateNode} */
        s.lastChild
      );
      it(f, o);
    } else
      it(s, s);
    return s;
  };
}
// @__NO_SIDE_EFFECTS__
function Xa(t, e, r = "svg") {
  var a = !t.startsWith("<!>"), i = `<${r}>${a ? t : "<!>" + t}</${r}>`, n;
  return () => {
    if (!n) {
      var s = (
        /** @type {DocumentFragment} */
        Fr(i)
      ), f = (
        /** @type {Element} */
        zt(s)
      );
      n = /** @type {Element} */
      zt(f);
    }
    var o = (
      /** @type {TemplateNode} */
      n.cloneNode(!0)
    );
    return it(o, o), o;
  };
}
// @__NO_SIDE_EFFECTS__
function st(t, e) {
  return /* @__PURE__ */ Xa(t, e, "svg");
}
function Te(t = "") {
  {
    var e = Ue(t + "");
    return it(e, e), e;
  }
}
function be() {
  var t = document.createDocumentFragment(), e = document.createComment(""), r = Ue();
  return t.append(e, r), it(e, r), t;
}
function x(t, e) {
  t !== null && t.before(
    /** @type {Node} */
    e
  );
}
class Ot {
  /** @type {TemplateNode} */
  anchor;
  /** @type {Map<Batch, Key>} */
  #e = /* @__PURE__ */ new Map();
  /**
   * Map of keys to effects that are currently rendered in the DOM.
   * These effects are visible and actively part of the document tree.
   * Example:
   * ```
   * {#if condition}
   * 	foo
   * {:else}
   * 	bar
   * {/if}
   * ```
   * Can result in the entries `true->Effect` and `false->Effect`
   * @type {Map<Key, Effect>}
   */
  #t = /* @__PURE__ */ new Map();
  /**
   * Similar to #onscreen with respect to the keys, but contains branches that are not yet
   * in the DOM, because their insertion is deferred.
   * @type {Map<Key, Branch>}
   */
  #r = /* @__PURE__ */ new Map();
  /**
   * Keys of effects that are currently outroing
   * @type {Set<Key>}
   */
  #a = /* @__PURE__ */ new Set();
  /**
   * Whether to pause (i.e. outro) on change, or destroy immediately.
   * This is necessary for `<svelte:element>`
   */
  #n = !0;
  /**
   * @param {TemplateNode} anchor
   * @param {boolean} transition
   */
  constructor(e, r = !0) {
    this.anchor = e, this.#n = r;
  }
  #i = () => {
    var e = (
      /** @type {Batch} */
      Ht
    );
    if (this.#e.has(e)) {
      var r = (
        /** @type {Key} */
        this.#e.get(e)
      ), a = this.#t.get(r);
      if (a)
        er(a), this.#a.delete(r);
      else {
        var i = this.#r.get(r);
        i && (this.#t.set(r, i.effect), this.#r.delete(r), i.fragment.lastChild.remove(), this.anchor.before(i.fragment), a = i.effect);
      }
      for (const [n, s] of this.#e) {
        if (this.#e.delete(n), n === e)
          break;
        const f = this.#r.get(s);
        f && (Ge(f.effect), this.#r.delete(s));
      }
      for (const [n, s] of this.#t) {
        if (n === r || this.#a.has(n)) continue;
        const f = () => {
          if (Array.from(this.#e.values()).includes(n)) {
            var c = document.createDocumentFragment();
            la(s, c), c.append(Ue()), this.#r.set(n, { effect: s, fragment: c });
          } else
            Ge(s);
          this.#a.delete(n), this.#t.delete(n);
        };
        this.#n || !a ? (this.#a.add(n), tr(s, f, !1)) : f();
      }
    }
  };
  /**
   * @param {Batch} batch
   */
  #s = (e) => {
    this.#e.delete(e);
    const r = Array.from(this.#e.values());
    for (const [a, i] of this.#r)
      r.includes(a) || (Ge(i.effect), this.#r.delete(a));
  };
  /**
   *
   * @param {any} key
   * @param {null | ((target: TemplateNode) => void)} fn
   */
  ensure(e, r) {
    var a = (
      /** @type {Batch} */
      Ht
    ), i = Lr();
    if (r && !this.#t.has(e) && !this.#r.has(e))
      if (i) {
        var n = document.createDocumentFragment(), s = Ue();
        n.append(s), this.#r.set(e, {
          effect: Xe(() => r(s)),
          fragment: n
        });
      } else
        this.#t.set(
          e,
          Xe(() => r(this.anchor))
        );
    if (this.#e.set(a, e), i) {
      for (const [f, o] of this.#t)
        f === e ? a.skipped_effects.delete(o) : a.skipped_effects.add(o);
      for (const [f, o] of this.#r)
        f === e ? a.skipped_effects.delete(o.effect) : a.skipped_effects.add(o.effect);
      a.oncommit(this.#i), a.ondiscard(this.#s);
    } else
      this.#i();
  }
}
function I(t, e, r = !1) {
  var a = new Ot(t), i = r ? Pt : 0;
  function n(s, f) {
    a.ensure(s, f);
  }
  pt(() => {
    var s = !1;
    e((f, o = !0) => {
      s = !0, n(o, f);
    }), s || n(!1, null);
  }, i);
}
function _t(t, e) {
  return e;
}
function Ja(t, e, r) {
  for (var a = [], i = e.length, n, s = e.length, f = 0; f < i; f++) {
    let y = e[f];
    tr(
      y,
      () => {
        if (n) {
          if (n.pending.delete(y), n.done.add(y), n.pending.size === 0) {
            var g = (
              /** @type {Set<EachOutroGroup>} */
              t.outrogroups
            );
            Kt(rr(n.done)), g.delete(n), g.size === 0 && (t.outrogroups = null);
          }
        } else
          s -= 1;
      },
      !1
    );
  }
  if (s === 0) {
    var o = a.length === 0 && r !== null;
    if (o) {
      var c = (
        /** @type {Element} */
        r
      ), u = (
        /** @type {Element} */
        c.parentNode
      );
      ua(u), u.append(c), t.items.clear();
    }
    Kt(e, !o);
  } else
    n = {
      pending: new Set(e),
      done: /* @__PURE__ */ new Set()
    }, (t.outrogroups ??= /* @__PURE__ */ new Set()).add(n);
}
function Kt(t, e = !0) {
  for (var r = 0; r < t.length; r++)
    Ge(t[r], e);
}
var vr;
function gt(t, e, r, a, i, n = null) {
  var s = t, f = /* @__PURE__ */ new Map(), o = (e & zr) !== 0;
  if (o) {
    var c = (
      /** @type {Element} */
      t
    );
    s = c.appendChild(Ue());
  }
  var u = null, y = Cr(() => {
    var d = r();
    return Jt(d) ? d : d == null ? [] : rr(d);
  }), g, E = !0;
  function T() {
    h.fallback = u, Qa(h, g, s, e, a), u !== null && (g.length === 0 ? (u.f & Re) === 0 ? er(u) : (u.f ^= Re, ht(u, null, s)) : tr(u, () => {
      u = null;
    }));
  }
  var b = pt(() => {
    g = /** @type {V[]} */
    l(y);
    for (var d = g.length, q = /* @__PURE__ */ new Set(), _ = (
      /** @type {Batch} */
      Ht
    ), m = Lr(), k = 0; k < d; k += 1) {
      var O = g[k], w = a(O, k), B = E ? null : f.get(w);
      B ? (B.v && cr(B.v, O), B.i && cr(B.i, k), m && _.skipped_effects.delete(B.e)) : (B = $a(
        f,
        E ? s : vr ??= Ue(),
        O,
        w,
        k,
        i,
        e,
        r
      ), E || (B.e.f |= Re), f.set(w, B)), q.add(w);
    }
    if (d === 0 && n && !u && (E ? u = Xe(() => n(s)) : (u = Xe(() => n(vr ??= Ue())), u.f |= Re)), !E)
      if (m) {
        for (const [N, L] of f)
          q.has(N) || _.skipped_effects.add(L.e);
        _.oncommit(T), _.ondiscard(() => {
        });
      } else
        T();
    l(y);
  }), h = { effect: b, items: f, outrogroups: null, fallback: u };
  E = !1;
}
function Qa(t, e, r, a, i) {
  var n = (a & da) !== 0, s = e.length, f = t.items, o = t.effect.first, c, u = null, y, g = [], E = [], T, b, h, d;
  if (n)
    for (d = 0; d < s; d += 1)
      T = e[d], b = i(T, d), h = /** @type {EachItem} */
      f.get(b).e, (h.f & Re) === 0 && (h.nodes?.a?.measure(), (y ??= /* @__PURE__ */ new Set()).add(h));
  for (d = 0; d < s; d += 1) {
    if (T = e[d], b = i(T, d), h = /** @type {EachItem} */
    f.get(b).e, t.outrogroups !== null)
      for (const L of t.outrogroups)
        L.pending.delete(h), L.done.delete(h);
    if ((h.f & Re) !== 0)
      if (h.f ^= Re, h === o)
        ht(h, null, r);
      else {
        var q = u ? u.next : o;
        h === t.effect.last && (t.effect.last = h.prev), h.prev && (h.prev.next = h.next), h.next && (h.next.prev = h.prev), He(t, u, h), He(t, h, q), ht(h, q, r), u = h, g = [], E = [], o = u.next;
        continue;
      }
    if ((h.f & Rt) !== 0 && (er(h), n && (h.nodes?.a?.unfix(), (y ??= /* @__PURE__ */ new Set()).delete(h))), h !== o) {
      if (c !== void 0 && c.has(h)) {
        if (g.length < E.length) {
          var _ = E[0], m;
          u = _.prev;
          var k = g[0], O = g[g.length - 1];
          for (m = 0; m < g.length; m += 1)
            ht(g[m], _, r);
          for (m = 0; m < E.length; m += 1)
            c.delete(E[m]);
          He(t, k.prev, O.next), He(t, u, k), He(t, O, _), o = _, u = O, d -= 1, g = [], E = [];
        } else
          c.delete(h), ht(h, o, r), He(t, h.prev, h.next), He(t, h, u === null ? t.effect.first : u.next), He(t, u, h), u = h;
        continue;
      }
      for (g = [], E = []; o !== null && o !== h; )
        (c ??= /* @__PURE__ */ new Set()).add(o), E.push(o), o = o.next;
      if (o === null)
        continue;
    }
    (h.f & Re) === 0 && g.push(h), u = h, o = h.next;
  }
  if (t.outrogroups !== null) {
    for (const L of t.outrogroups)
      L.pending.size === 0 && (Kt(rr(L.done)), t.outrogroups?.delete(L));
    t.outrogroups.size === 0 && (t.outrogroups = null);
  }
  if (o !== null || c !== void 0) {
    var w = [];
    if (c !== void 0)
      for (h of c)
        (h.f & Rt) === 0 && w.push(h);
    for (; o !== null; )
      (o.f & Rt) === 0 && o !== t.fallback && w.push(o), o = o.next;
    var B = w.length;
    if (B > 0) {
      var N = (a & zr) !== 0 && s === 0 ? r : null;
      if (n) {
        for (d = 0; d < B; d += 1)
          w[d].nodes?.a?.measure();
        for (d = 0; d < B; d += 1)
          w[d].nodes?.a?.fix();
      }
      Ja(t, w, N);
    }
  }
  n && Qt(() => {
    if (y !== void 0)
      for (h of y)
        h.nodes?.a?.apply();
  });
}
function $a(t, e, r, a, i, n, s, f) {
  var o = (s & fa) !== 0 ? (s & ca) === 0 ? We(r, !1, !1) : dr(r) : null, c = (s & oa) !== 0 ? dr(i) : null;
  return {
    v: o,
    i: c,
    e: Xe(() => (n(e, o ?? r, c ?? i, f), () => {
      t.delete(a);
    }))
  };
}
function ht(t, e, r) {
  if (t.nodes)
    for (var a = t.nodes.start, i = t.nodes.end, n = e && (e.f & Re) === 0 ? (
      /** @type {EffectNodes} */
      e.nodes.start
    ) : r; a !== null; ) {
      var s = (
        /** @type {TemplateNode} */
        ha(a)
      );
      if (n.before(a), a === i)
        return;
      a = s;
    }
}
function He(t, e, r) {
  e === null ? t.effect.first = r : e.next = r, r === null ? t.effect.last = e : r.prev = e;
}
function Wt(t, e, r, a, i) {
  var n = e.$$slots?.[r], s = !1;
  n === !0 && (n = e[r === "default" ? "children" : r], s = !0), n === void 0 || n(t, s ? () => a : a);
}
function en(t, e, ...r) {
  var a = new Ot(t);
  pt(() => {
    const i = e() ?? null;
    a.ensure(i, i && ((n) => i(n, ...r)));
  }, Pt);
}
function tn(t, e, r) {
  var a = new Ot(t);
  pt(() => {
    var i = e() ?? null;
    a.ensure(i, i && ((n) => r(n, i)));
  }, Pt);
}
const rn = () => performance.now(), me = {
  // don't access requestAnimationFrame eagerly outside method
  // this allows basic testing of user code without JSDOM
  // bunder will eval and remove ternary when the user's app is built
  tick: (
    /** @param {any} _ */
    (t) => requestAnimationFrame(t)
  ),
  now: () => rn(),
  tasks: /* @__PURE__ */ new Set()
};
function Rr() {
  const t = me.now();
  me.tasks.forEach((e) => {
    e.c(t) || (me.tasks.delete(e), e.f());
  }), me.tasks.size !== 0 && me.tick(Rr);
}
function an(t) {
  let e;
  return me.tasks.size === 0 && me.tick(Rr), {
    promise: new Promise((r) => {
      me.tasks.add(e = { c: t, f: r });
    }),
    abort() {
      me.tasks.delete(e);
    }
  };
}
function nn(t, e, r, a, i, n) {
  var s = null, f = (
    /** @type {TemplateNode} */
    t
  ), o = new Ot(f, !1);
  pt(() => {
    const c = e() || null;
    var u = c === "svg" ? va : null;
    if (c === null) {
      o.ensure(null, null);
      return;
    }
    return o.ensure(c, (y) => {
      if (c) {
        if (s = u ? document.createElementNS(u, c) : document.createElement(c), it(s, s), a) {
          var g = s.appendChild(Ue());
          a(s, g);
        }
        $t.nodes.end = s, y.before(s);
      }
    }), () => {
    };
  }, Pt), ar(() => {
  });
}
function sn(t, e) {
  var r = void 0, a;
  Pr(() => {
    r !== (r = e()) && (a && (Ge(a), a = null), r && (a = Xe(() => {
      It(() => (
        /** @type {(node: Element) => void} */
        r(t)
      ));
    })));
  });
}
function qr(t) {
  var e, r, a = "";
  if (typeof t == "string" || typeof t == "number") a += t;
  else if (typeof t == "object") if (Array.isArray(t)) {
    var i = t.length;
    for (e = 0; e < i; e++) t[e] && (r = qr(t[e])) && (a && (a += " "), a += r);
  } else for (r in t) t[r] && (a && (a += " "), a += r);
  return a;
}
function ln() {
  for (var t, e, r = 0, a = "", i = arguments.length; r < i; r++) (t = arguments[r]) && (e = qr(t)) && (a && (a += " "), a += e);
  return a;
}
function on(t) {
  return typeof t == "object" ? ln(t) : t ?? "";
}
const _r = [...` 	
\r\f \v\uFEFF`];
function fn(t, e, r) {
  var a = t == null ? "" : "" + t;
  if (e && (a = a ? a + " " + e : e), r) {
    for (var i in r)
      if (r[i])
        a = a ? a + " " + i : i;
      else if (a.length)
        for (var n = i.length, s = 0; (s = a.indexOf(i, s)) >= 0; ) {
          var f = s + n;
          (s === 0 || _r.includes(a[s - 1])) && (f === a.length || _r.includes(a[f])) ? a = (s === 0 ? "" : a.substring(0, s)) + a.substring(f + 1) : s = f;
        }
  }
  return a === "" ? null : a;
}
function gr(t, e = !1) {
  var r = e ? " !important;" : ";", a = "";
  for (var i in t) {
    var n = t[i];
    n != null && n !== "" && (a += " " + i + ": " + n + r);
  }
  return a;
}
function qt(t) {
  return t[0] !== "-" || t[1] !== "-" ? t.toLowerCase() : t;
}
function cn(t, e) {
  if (e) {
    var r = "", a, i;
    if (Array.isArray(e) ? (a = e[0], i = e[1]) : a = e, t) {
      t = String(t).replaceAll(/\s*\/\*.*?\*\/\s*/g, "").trim();
      var n = !1, s = 0, f = !1, o = [];
      a && o.push(...Object.keys(a).map(qt)), i && o.push(...Object.keys(i).map(qt));
      var c = 0, u = -1;
      const b = t.length;
      for (var y = 0; y < b; y++) {
        var g = t[y];
        if (f ? g === "/" && t[y - 1] === "*" && (f = !1) : n ? n === g && (n = !1) : g === "/" && t[y + 1] === "*" ? f = !0 : g === '"' || g === "'" ? n = g : g === "(" ? s++ : g === ")" && s--, !f && n === !1 && s === 0) {
          if (g === ":" && u === -1)
            u = y;
          else if (g === ";" || y === b - 1) {
            if (u !== -1) {
              var E = qt(t.substring(c, u).trim());
              if (!o.includes(E)) {
                g !== ";" && y++;
                var T = t.substring(c, y).trim();
                r += " " + T + ";";
              }
            }
            c = y + 1, u = -1;
          }
        }
      }
    }
    return a && (r += gr(a)), i && (r += gr(i, !0)), r = r.trim(), r === "" ? null : r;
  }
  return t == null ? null : String(t);
}
function ge(t, e, r, a, i, n) {
  var s = t.__className;
  if (s !== r || s === void 0) {
    var f = fn(r, a, n);
    f == null ? t.removeAttribute("class") : e ? t.className = f : t.setAttribute("class", f), t.__className = r;
  } else if (n && i !== n)
    for (var o in n) {
      var c = !!n[o];
      (i == null || c !== !!i[o]) && t.classList.toggle(o, c);
    }
  return n;
}
function Bt(t, e = {}, r, a) {
  for (var i in r) {
    var n = r[i];
    e[i] !== n && (r[i] == null ? t.style.removeProperty(i) : t.style.setProperty(i, n, a));
  }
}
function Me(t, e, r, a) {
  var i = t.__style;
  if (i !== e) {
    var n = cn(e, a);
    n == null ? t.removeAttribute("style") : t.style.cssText = n, t.__style = e;
  } else a && (Array.isArray(a) ? (Bt(t, r?.[0], a[0]), Bt(t, r?.[1], a[1], "important")) : Bt(t, r, a));
  return a;
}
function Zt(t, e, r = !1) {
  if (t.multiple) {
    if (e == null)
      return;
    if (!Jt(e))
      return _a();
    for (var a of t.options)
      a.selected = e.includes(pr(a));
    return;
  }
  for (a of t.options) {
    var i = pr(a);
    if (ga(i, e)) {
      a.selected = !0;
      return;
    }
  }
  (!r || e !== void 0) && (t.selectedIndex = -1);
}
function dn(t) {
  var e = new MutationObserver(() => {
    Zt(t, t.__value);
  });
  e.observe(t, {
    // Listen to option element changes
    childList: !0,
    subtree: !0,
    // because of <optgroup>
    // Listen to option element value attribute changes
    // (doesn't get notified of select value changes,
    // because that property is not reflected as an attribute)
    attributes: !0,
    attributeFilter: ["value"]
  }), ar(() => {
    e.disconnect();
  });
}
function pr(t) {
  return "__value" in t ? t.__value : t.value;
}
const vt = /* @__PURE__ */ Symbol("class"), at = /* @__PURE__ */ Symbol("style"), Br = /* @__PURE__ */ Symbol("is custom element"), Dr = /* @__PURE__ */ Symbol("is html");
function un(t, e) {
  e ? t.hasAttribute("selected") || t.setAttribute("selected", "") : t.removeAttribute("selected");
}
function _e(t, e, r, a) {
  var i = Vr(t);
  i[e] !== (i[e] = r) && (e === "loading" && (t[ba] = r), r == null ? t.removeAttribute(e) : typeof r != "string" && Hr(t).includes(e) ? t[e] = r : t.setAttribute(e, r));
}
function hn(t, e, r, a, i = !1, n = !1) {
  var s = Vr(t), f = s[Br], o = !s[Dr], c = e || {}, u = t.tagName === "OPTION";
  for (var y in e)
    y in r || (r[y] = null);
  r.class ? r.class = on(r.class) : r.class = null, r[at] && (r.style ??= null);
  var g = Hr(t);
  for (const _ in r) {
    let m = r[_];
    if (u && _ === "value" && m == null) {
      t.value = t.__value = "", c[_] = m;
      continue;
    }
    if (_ === "class") {
      var E = t.namespaceURI === "http://www.w3.org/1999/xhtml";
      ge(t, E, m, a, e?.[vt], r[vt]), c[_] = m, c[vt] = r[vt];
      continue;
    }
    if (_ === "style") {
      Me(t, m, e?.[at], r[at]), c[_] = m, c[at] = r[at];
      continue;
    }
    var T = c[_];
    if (!(m === T && !(m === void 0 && t.hasAttribute(_)))) {
      c[_] = m;
      var b = _[0] + _[1];
      if (b !== "$$")
        if (b === "on") {
          const k = {}, O = "$$" + _;
          let w = _.slice(2);
          var h = Ma(w);
          if (xa(w) && (w = w.slice(0, -7), k.capture = !0), !h && T) {
            if (m != null) continue;
            t.removeEventListener(w, c[O], k), c[O] = null;
          }
          if (m != null)
            if (h)
              t[`__${w}`] = m, bt([w]);
            else {
              let B = function(N) {
                c[_].call(this, N);
              };
              c[O] = ka(w, t, B, k);
            }
          else h && (t[`__${w}`] = void 0);
        } else if (_ === "style")
          _e(t, _, m);
        else if (_ === "autofocus")
          Ga(
            /** @type {HTMLElement} */
            t,
            !!m
          );
        else if (!f && (_ === "__value" || _ === "value" && m != null))
          t.value = t.__value = m;
        else if (_ === "selected" && u)
          un(
            /** @type {HTMLOptionElement} */
            t,
            m
          );
        else {
          var d = _;
          o || (d = Ea(d));
          var q = d === "defaultValue" || d === "defaultChecked";
          if (m == null && !f && !q)
            if (s[_] = null, d === "value" || d === "checked") {
              let k = (
                /** @type {HTMLInputElement} */
                t
              );
              const O = e === void 0;
              if (d === "value") {
                let w = k.defaultValue;
                k.removeAttribute(d), k.defaultValue = w, k.value = k.__value = O ? w : null;
              } else {
                let w = k.defaultChecked;
                k.removeAttribute(d), k.defaultChecked = w, k.checked = O ? w : !1;
              }
            } else
              t.removeAttribute(_);
          else q || g.includes(d) && (f || typeof m != "string") ? (t[d] = m, d in s && (s[d] = Ta)) : typeof m != "function" && _e(t, d, m);
        }
    }
  }
  return c;
}
function vn(t, e, r = [], a = [], i = [], n, s = !1, f = !1) {
  wa(i, r, a, (o) => {
    var c = void 0, u = {}, y = t.nodeName === "SELECT", g = !1;
    if (Pr(() => {
      var T = e(...o.map(l)), b = hn(
        t,
        c,
        T,
        n,
        s,
        f
      );
      g && y && "value" in T && Zt(
        /** @type {HTMLSelectElement} */
        t,
        T.value
      );
      for (let d of Object.getOwnPropertySymbols(u))
        T[d] || Ge(u[d]);
      for (let d of Object.getOwnPropertySymbols(T)) {
        var h = T[d];
        d.description === ya && (!c || h !== c[d]) && (u[d] && Ge(u[d]), u[d] = Xe(() => sn(t, () => h))), b[d] = h;
      }
      c = b;
    }), y) {
      var E = (
        /** @type {HTMLSelectElement} */
        t
      );
      It(() => {
        Zt(
          E,
          /** @type {Record<string | symbol, any>} */
          c.value,
          !0
        ), dn(E);
      });
    }
    g = !0;
  });
}
function Vr(t) {
  return (
    /** @type {Record<string | symbol, unknown>} **/
    // @ts-expect-error
    t.__attributes ??= {
      [Br]: t.nodeName.includes("-"),
      [Dr]: t.namespaceURI === pa
    }
  );
}
var br = /* @__PURE__ */ new Map();
function Hr(t) {
  var e = t.getAttribute("is") || t.nodeName, r = br.get(e);
  if (r) return r;
  br.set(e, r = []);
  for (var a, i = t, n = Element.prototype; n !== i; ) {
    a = ma(i);
    for (var s in a)
      a[s].set && r.push(s);
    i = Sr(i);
  }
  return r;
}
class ir {
  /** */
  #e = /* @__PURE__ */ new WeakMap();
  /** @type {ResizeObserver | undefined} */
  #t;
  /** @type {ResizeObserverOptions} */
  #r;
  /** @static */
  static entries = /* @__PURE__ */ new WeakMap();
  /** @param {ResizeObserverOptions} options */
  constructor(e) {
    this.#r = e;
  }
  /**
   * @param {Element} element
   * @param {(entry: ResizeObserverEntry) => any} listener
   */
  observe(e, r) {
    var a = this.#e.get(e) || /* @__PURE__ */ new Set();
    return a.add(r), this.#e.set(e, a), this.#a().observe(e, this.#r), () => {
      var i = this.#e.get(e);
      i.delete(r), i.size === 0 && (this.#e.delete(e), this.#t.unobserve(e));
    };
  }
  #a() {
    return this.#t ?? (this.#t = new ResizeObserver(
      /** @param {any} entries */
      (e) => {
        for (var r of e) {
          ir.entries.set(r.target, r);
          for (var a of this.#e.get(r.target) || [])
            a(r);
        }
      }
    ));
  }
}
var _n = /* @__PURE__ */ new ir({
  box: "border-box"
});
function gn(t, e, r) {
  var a = _n.observe(t, () => r(t[e]));
  It(() => (W(() => r(t[e])), a));
}
function mr(t, e) {
  return t === e || t?.[nr] === e;
}
function Ze(t = {}, e, r, a) {
  return It(() => {
    var i, n;
    return Aa(() => {
      i = n, n = [], W(() => {
        t !== r(...n) && (e(t, ...n), i && mr(r(...i), t) && e(null, ...i));
      });
    }), () => {
      Qt(() => {
        n && mr(r(...n), t) && e(null, ...n);
      });
    };
  }), t;
}
function pn(t = !1) {
  const e = (
    /** @type {ComponentContextLegacy} */
    St
  ), r = e.l.u;
  if (!r) return;
  let a = () => ve(e.s);
  if (t) {
    let i = 0, n = (
      /** @type {Record<string, any>} */
      {}
    );
    const s = Ir(() => {
      let f = !1;
      const o = e.s;
      for (const c in o)
        o[c] !== n[c] && (n[c] = o[c], f = !0);
      return f && i++, i;
    });
    a = () => l(s);
  }
  r.b.length && Sa(() => {
    wr(e, a), ur(r.b);
  }), se(() => {
    const i = W(() => r.m.map(La));
    return () => {
      for (const n of i)
        typeof n == "function" && n();
    };
  }), r.a.length && se(() => {
    wr(e, a), ur(r.a);
  });
}
function wr(t, e) {
  if (t.l.s)
    for (const r of t.l.s) l(r);
  e();
}
function Ur(t, e, r) {
  if (t == null)
    return e(void 0), nt;
  const a = W(
    () => t.subscribe(
      e,
      // @ts-expect-error
      r
    )
  );
  return a.unsubscribe ? () => a.unsubscribe() : a;
}
const rt = [];
function bn(t, e = nt) {
  let r = null;
  const a = /* @__PURE__ */ new Set();
  function i(f) {
    if (za(t, f) && (t = f, r)) {
      const o = !rt.length;
      for (const c of a)
        c[1](), rt.push(c, t);
      if (o) {
        for (let c = 0; c < rt.length; c += 2)
          rt[c][0](rt[c + 1]);
        rt.length = 0;
      }
    }
  }
  function n(f) {
    i(f(
      /** @type {T} */
      t
    ));
  }
  function s(f, o = nt) {
    const c = [f, o];
    return a.add(c), a.size === 1 && (r = e(i, n) || nt), f(
      /** @type {T} */
      t
    ), () => {
      a.delete(c), a.size === 0 && r && (r(), r = null);
    };
  }
  return { set: i, update: n, subscribe: s };
}
function Yr(t) {
  let e;
  return Ur(t, (r) => e = r)(), e;
}
let Mt = !1, Gt = /* @__PURE__ */ Symbol();
function yr(t, e, r) {
  const a = r[e] ??= {
    store: null,
    source: We(void 0),
    unsubscribe: nt
  };
  if (a.store !== t && !(Gt in r))
    if (a.unsubscribe(), a.store = t ?? null, t == null)
      a.source.v = void 0, a.unsubscribe = nt;
    else {
      var i = !0;
      a.unsubscribe = Ur(t, (n) => {
        i ? a.source.v = n : M(a.source, n);
      }), i = !1;
    }
  return t && Gt in r ? Yr(t) : l(a.source);
}
function mn() {
  const t = {};
  function e() {
    ar(() => {
      for (var r in t)
        t[r].unsubscribe();
      Ca(t, Gt, {
        enumerable: !1,
        value: !0
      });
    });
  }
  return [t, e];
}
function wn(t) {
  var e = Mt;
  try {
    return Mt = !1, [t(), Mt];
  } finally {
    Mt = e;
  }
}
const yn = {
  get(t, e) {
    if (!t.exclude.includes(e))
      return t.props[e];
  },
  set(t, e) {
    return !1;
  },
  getOwnPropertyDescriptor(t, e) {
    if (!t.exclude.includes(e) && e in t.props)
      return {
        enumerable: !0,
        configurable: !0,
        value: t.props[e]
      };
  },
  has(t, e) {
    return t.exclude.includes(e) ? !1 : e in t.props;
  },
  ownKeys(t) {
    return Reflect.ownKeys(t.props).filter((e) => !t.exclude.includes(e));
  }
};
// @__NO_SIDE_EFFECTS__
function xn(t, e, r) {
  return new Proxy(
    { props: t, exclude: e },
    yn
  );
}
const kn = {
  get(t, e) {
    let r = t.props.length;
    for (; r--; ) {
      let a = t.props[r];
      if (ut(a) && (a = a()), typeof a == "object" && a !== null && e in a) return a[e];
    }
  },
  set(t, e, r) {
    let a = t.props.length;
    for (; a--; ) {
      let i = t.props[a];
      ut(i) && (i = i());
      const n = Ut(i, e);
      if (n && n.set)
        return n.set(r), !0;
    }
    return !1;
  },
  getOwnPropertyDescriptor(t, e) {
    let r = t.props.length;
    for (; r--; ) {
      let a = t.props[r];
      if (ut(a) && (a = a()), typeof a == "object" && a !== null && e in a) {
        const i = Ut(a, e);
        return i && !i.configurable && (i.configurable = !0), i;
      }
    }
  },
  has(t, e) {
    if (e === nr || e === Nr) return !1;
    for (let r of t.props)
      if (ut(r) && (r = r()), r != null && e in r) return !0;
    return !1;
  },
  ownKeys(t) {
    const e = [];
    for (let r of t.props)
      if (ut(r) && (r = r()), !!r) {
        for (const a in r)
          e.includes(a) || e.push(a);
        for (const a of Object.getOwnPropertySymbols(r))
          e.includes(a) || e.push(a);
      }
    return e;
  }
};
function En(...t) {
  return new Proxy({ props: t }, kn);
}
function p(t, e, r, a) {
  var i = !Or || (r & ja) !== 0, n = (r & Na) !== 0, s = (r & Ra) !== 0, f = (
    /** @type {V} */
    a
  ), o = !0, c = () => (o && (o = !1, f = s ? W(
    /** @type {() => V} */
    a
  ) : (
    /** @type {V} */
    a
  )), f), u;
  if (n) {
    var y = nr in t || Nr in t;
    u = Ut(t, e)?.set ?? (y && e in t ? (_) => t[e] = _ : void 0);
  }
  var g, E = !1;
  n ? [g, E] = wn(() => (
    /** @type {V} */
    t[e]
  )) : g = /** @type {V} */
  t[e], g === void 0 && a !== void 0 && (g = c(), u && (i && Pa(), u(g)));
  var T;
  if (i ? T = () => {
    var _ = (
      /** @type {V} */
      t[e]
    );
    return _ === void 0 ? c() : (o = !0, _);
  } : T = () => {
    var _ = (
      /** @type {V} */
      t[e]
    );
    return _ !== void 0 && (f = /** @type {V} */
    void 0), _ === void 0 ? f : _;
  }, i && (r & Ia) === 0)
    return T;
  if (u) {
    var b = t.$$legacy;
    return (
      /** @type {() => V} */
      (function(_, m) {
        return arguments.length > 0 ? ((!i || !m || b || E) && u(m ? T() : _), _) : T();
      })
    );
  }
  var h = !1, d = ((r & Fa) !== 0 ? Ir : Cr)(() => (h = !1, T()));
  n && l(d);
  var q = (
    /** @type {Effect} */
    $t
  );
  return (
    /** @type {() => V} */
    (function(_, m) {
      if (arguments.length > 0) {
        const k = m ? l(d) : i && n ? Yt(_) : _;
        return M(d, k), h = !0, f !== void 0 && (f = k), _;
      }
      return qa && h || (q.f & Oa) !== 0 ? d.v : l(d);
    })
  );
}
Ba();
var Tn = /* @__PURE__ */ st('<svg class="resize-handle svelte-x2rm94" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 10 10"><line x1="1" y1="9" x2="9" y2="1" stroke="gray" stroke-width="0.5" class="svelte-x2rm94"></line><line x1="5" y1="9" x2="9" y2="5" stroke="gray" stroke-width="0.5" class="svelte-x2rm94"></line></svg>'), Mn = /* @__PURE__ */ U("<!> <!>", 1), An = /* @__PURE__ */ U('<div class="placeholder svelte-x2rm94"></div>'), Sn = /* @__PURE__ */ U("<!> <!>", 1);
function Ln(t, e) {
  wt(e, !1);
  let r = p(e, "height", 8, void 0), a = p(e, "min_height", 8, void 0), i = p(e, "max_height", 8, void 0), n = p(e, "width", 8, void 0), s = p(e, "elem_id", 8, ""), f = p(e, "elem_classes", 24, () => []), o = p(e, "variant", 8, "solid"), c = p(e, "border_mode", 8, "base"), u = p(e, "padding", 8, !0), y = p(e, "type", 8, "normal"), g = p(e, "test_id", 8, void 0), E = p(e, "explicit_call", 8, !1), T = p(e, "container", 8, !0), b = p(e, "visible", 8, !0), h = p(e, "allow_overflow", 8, !0), d = p(e, "overflow_behavior", 8, "auto"), q = p(e, "scale", 8, null), _ = p(e, "min_width", 8, 0), m = p(e, "flex", 12, !1), k = p(e, "resizable", 8, !1), O = p(e, "rtl", 8, !1), w = p(e, "fullscreen", 12, !1), B = p(e, "label", 8, void 0), N = We(w()), L = We(), we = y() === "fieldset" ? "fieldset" : "div", Ae = We(0), le = We(0), Y = We(null);
  function Se($) {
    w() && $.key === "Escape" && w(!1);
  }
  const Le = ($) => {
    if ($ !== void 0) {
      if (typeof $ == "number")
        return $ + "px";
      if (typeof $ == "string")
        return $;
    }
  }, Ye = ($) => {
    let v = $.clientY;
    const S = (Z) => {
      const P = Z.clientY - v;
      v = Z.clientY, Va(L, l(L).style.height = `${l(L).offsetHeight + P}px`);
    }, C = () => {
      window.removeEventListener("mousemove", S), window.removeEventListener("mouseup", C);
    };
    window.addEventListener("mousemove", S), window.addEventListener("mouseup", C);
  };
  hr(
    () => (ve(w()), l(N), l(L)),
    () => {
      w() !== l(N) && (M(N, w()), w() ? (M(Y, l(L).getBoundingClientRect()), M(Ae, l(L).offsetHeight), M(le, l(L).offsetWidth), window.addEventListener("keydown", Se)) : (M(Y, null), window.removeEventListener("keydown", Se)));
    }
  ), hr(() => ve(b()), () => {
    b() || m(!1);
  }), Da(), pn();
  var qe = be(), ye = Q(qe);
  {
    var xe = ($) => {
      var v = Sn(), S = Q(v);
      nn(S, () => we, !1, (P, pe) => {
        Ze(P, (he) => M(L, he), () => l(L)), vn(
          P,
          (he, ke) => ({
            "data-testid": g(),
            id: s(),
            class: `block ${he ?? ""}`,
            dir: O() ? "rtl" : "ltr",
            "aria-label": B(),
            style: "",
            [vt]: {
              hidden: b() === "hidden",
              padded: u(),
              flex: m(),
              border_focus: c() === "focus",
              border_contrast: c() === "contrast",
              "hide-container": !E() && !T(),
              fullscreen: w(),
              animating: w() && l(Y) !== null,
              "auto-margin": q() === null
            },
            [at]: ke
          }),
          [
            () => (ve(f()), W(() => f()?.join(" ") || "")),
            () => ({
              height: (ve(w()), ve(r()), W(() => w() ? void 0 : Le(r()))),
              "min-height": (ve(w()), ve(a()), W(() => w() ? void 0 : Le(a()))),
              "max-height": (ve(w()), ve(i()), W(() => w() ? void 0 : Le(i()))),
              "--start-top": (l(Y), W(() => l(Y) ? `${l(Y).top}px` : "0px")),
              "--start-left": (l(Y), W(() => l(Y) ? `${l(Y).left}px` : "0px")),
              "--start-width": (l(Y), W(() => l(Y) ? `${l(Y).width}px` : "0px")),
              "--start-height": (l(Y), W(() => l(Y) ? `${l(Y).height}px` : "0px")),
              width: (ve(w()), ve(n()), W(() => w() ? void 0 : typeof n() == "number" ? `calc(min(${n()}px, 100%))` : Le(n()))),
              "border-style": o(),
              overflow: h() ? d() : "hidden",
              "flex-grow": q(),
              "min-width": `calc(min(${_()}px, 100%))`
            })
          ],
          void 0,
          void 0,
          "svelte-x2rm94"
        );
        var G = Mn(), Be = Q(G);
        Wt(Be, e, "default", {});
        var te = z(Be, 2);
        {
          var Je = (he) => {
            var ke = Tn();
            Fe("mousedown", ke, Ye), x(he, ke);
          };
          I(te, (he) => {
            k() && he(Je);
          });
        }
        x(pe, G);
      });
      var C = z(S, 2);
      {
        var Z = (P) => {
          var pe = An();
          let G;
          R(() => G = Me(pe, "", G, {
            height: l(Ae) + "px",
            width: l(le) + "px"
          })), x(P, pe);
        };
        I(C, (P) => {
          w() && P(Z);
        });
      }
      x($, v);
    };
    I(ye, ($) => {
      (b() === !0 || b() === "hidden") && $(xe);
    });
  }
  x(t, qe), mt();
}
var zn = /* @__PURE__ */ U('<label for="" data-testid="block-label"><span class="svelte-1rr9wu"><!></span> </label>');
function Cn(t, e) {
  let r = p(e, "label", 8, null), a = p(e, "Icon", 8), i = p(e, "show_label", 8, !0), n = p(e, "disable", 8, !1), s = p(e, "float", 8, !0), f = p(e, "rtl", 8, !1);
  var o = zn();
  let c;
  var u = D(o), y = D(u);
  a()(y, {});
  var g = z(u);
  R(() => {
    _e(o, "dir", f() ? "rtl" : "ltr"), c = ge(o, 1, "svelte-1rr9wu", null, c, {
      hide: !i(),
      "sr-only": !i(),
      float: s(),
      "hide-label": n()
    }), ne(g, ` ${r() ?? ""}`), o.dir = o.dir;
  }), x(t, o);
}
function Pn(t) {
  St === null && Ka(), Or && St.l !== null ? In(St).m.push(t) : se(() => {
    const e = W(t);
    if (typeof e == "function") return (
      /** @type {() => void} */
      e
    );
  });
}
function In(t) {
  var e = (
    /** @type {ComponentContextLegacy} */
    t.l
  );
  return e.u ??= { a: [], b: [], m: [] };
}
var On = /* @__PURE__ */ U('<span class="svelte-p4mxsm"> </span>'), Nn = /* @__PURE__ */ U("<button><!> <div><!> <!></div></button>");
function Ct(t, e) {
  let r = p(e, "label", 3, ""), a = p(e, "show_label", 3, !1), i = p(e, "pending", 3, !1), n = p(e, "size", 3, "small"), s = p(e, "padded", 3, !0), f = p(e, "highlight", 3, !1), o = p(e, "disabled", 3, !1), c = p(e, "hasPopup", 3, !1), u = p(e, "color", 3, "var(--block-label-text-color)"), y = p(e, "transparent", 3, !1), g = p(e, "background", 3, "var(--block-background-fill)"), E = p(e, "border", 3, "transparent"), T = ce(() => f() ? "var(--color-accent)" : u());
  var b = Nn();
  let h;
  b.__click = function(...N) {
    e.onclick?.apply(this, N);
  };
  let d;
  var q = D(b);
  {
    var _ = (N) => {
      var L = On(), we = D(L);
      R(() => ne(we, r())), x(N, L);
    };
    I(q, (N) => {
      a() && N(_);
    });
  }
  var m = z(q, 2);
  let k;
  var O = D(m);
  tn(O, () => e.Icon, (N, L) => {
    L(N, {});
  });
  var w = z(O, 2);
  {
    var B = (N) => {
      var L = be(), we = Q(L);
      en(we, () => e.children), x(N, L);
    };
    I(w, (N) => {
      e.children && N(B);
    });
  }
  R(() => {
    h = ge(b, 1, "icon-button svelte-p4mxsm", null, h, {
      pending: i(),
      padded: s(),
      highlight: f(),
      transparent: y()
    }), b.disabled = o(), _e(b, "aria-label", r()), _e(b, "aria-haspopup", c()), _e(b, "title", r()), d = Me(b, "", d, {
      "--border-color": E(),
      color: !o() && l(T) ? l(T) : "var(--block-label-text-color)",
      "--bg-color": o() ? "auto" : g()
    }), k = ge(m, 1, "svelte-p4mxsm", null, k, {
      "x-small": n() === "x-small",
      small: n() === "small",
      large: n() === "large",
      medium: n() === "medium"
    });
  }), x(t, b);
}
bt(["click"]);
var jn = /* @__PURE__ */ st('<svg width="100%" height="100%" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" stroke="currentColor" style="fill-rule:evenodd;clip-rule:evenodd;stroke-linecap:round;stroke-linejoin:round;"><g transform="matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"><path d="M18,6L6.087,17.913" style="fill:none;fill-rule:nonzero;stroke-width:2px;"></path></g><path d="M4.364,4.364L19.636,19.636" style="fill:none;fill-rule:nonzero;stroke-width:2px;"></path></svg>');
function xr(t) {
  var e = jn();
  x(t, e);
}
var Fn = /* @__PURE__ */ st('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-image"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline></svg>');
function Rn(t) {
  var e = Fn();
  x(t, e);
}
var qn = /* @__PURE__ */ st('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-maximize" width="100%" height="100%"><path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"></path></svg>');
function Bn(t) {
  var e = qn();
  x(t, e);
}
var Dn = /* @__PURE__ */ st('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-minimize" width="100%" height="100%"><path d="M8 3v3a2 2 0 0 1-2 2H3m18 0h-3a2 2 0 0 1-2-2V3m0 18v-3a2 2 0 0 1 2-2h3M3 16h3a2 2 0 0 1 2 2v3"></path></svg>');
function Vn(t) {
  var e = Dn();
  x(t, e);
}
const Hn = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], kr = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
Hn.reduce((t, { color: e, primary: r, secondary: a }) => ({
  ...t,
  [e]: {
    primary: kr[e][r],
    secondary: kr[e][a]
  }
}), {});
function Un(t) {
  let e;
  const r = Ua((i) => {
    let n = !1;
    const s = t.subscribe((f) => {
      e = f, n && i();
    });
    return n = !0, s;
  });
  function a() {
    return Ha() ? (r(), e) : Yr(t);
  }
  return "set" in t ? {
    get current() {
      return a();
    },
    set current(i) {
      t.set(i);
    }
  } : {
    get current() {
      return a();
    }
  };
}
const Yn = "__i18n__", Kn = [
  "label",
  "info",
  "placeholder",
  "description",
  "title",
  "value"
], Wn = [
  "elem_id",
  "elem_classes",
  "visible",
  "interactive",
  "server_fns",
  "server",
  "id",
  "target",
  "theme_mode",
  "version",
  "root",
  "autoscroll",
  "max_file_size",
  "formatter",
  "client",
  "load_component",
  "scale",
  "min_width",
  "theme",
  "padding",
  "loading_status",
  "label",
  "show_label",
  "validation_error",
  "show_progress",
  "api_prefix",
  "container",
  "attached_events",
  "register_component",
  "dispatcher"
];
function Zn(t) {
  return typeof t == "string" && t.includes(Yn);
}
class Gn {
  load_component;
  #e = K(Yt({}));
  get shared() {
    return l(this.#e);
  }
  set shared(e) {
    M(this.#e, e, !0);
  }
  #t = K(Yt({}));
  get props() {
    return l(this.#t);
  }
  set props(e) {
    M(this.#t, e, !0);
  }
  #r = K((e) => e);
  get i18n() {
    return l(this.#r);
  }
  set i18n(e) {
    M(this.#r, e, !0);
  }
  i18n_store;
  _i18n_from_store;
  translatable_props = {};
  dispatcher;
  last_update = null;
  shared_props = Wn;
  mounted = !1;
  old_value;
  register_component;
  constructor(e, r) {
    for (const a in e.shared_props)
      this.shared[a] = e.shared_props[a];
    for (const a in e.props)
      a !== "i18n_store" && (this.props[a] = e.props[a]);
    if (r)
      for (const a in r)
        this.props[a] === void 0 && (this.props[a] = r[a]);
    this.i18n = this.props.i18n ?? ((a) => a), this.i18n_store = e.props.i18n_store, this._i18n_from_store = this.i18n_store ? Un(this.i18n_store) : void 0;
    for (const a of Kn)
      this.shared[a] = this._translate_and_store(
        "shared",
        a,
        // @ts-ignore
        e.shared_props[a]
      ), this.props[a] = this._translate_and_store(
        "props",
        a,
        // @ts-ignore
        e.props[a]
      );
    this.load_component = this.shared.load_component, this.register_component = this.shared.register_component || (() => {
    }), this.dispatcher = this.shared.dispatcher || (() => {
    }), this.register_component(
      e.shared_props.id,
      // @ts-ignore
      this.set_data.bind(this),
      this.get_data.bind(this)
    ), se(() => {
      for (const a in e.shared_props)
        this._is_i18n_managed(`shared.${a}`, e.shared_props[a]) || (this.shared[a] = e.shared_props[a]);
      for (const a in e.props)
        a !== "i18n_store" && (this._is_i18n_managed(`props.${a}`, e.props[a]) || (this.props[a] = e.props[a]));
      this.register_component(
        e.shared_props.id,
        // @ts-ignore
        this.set_data.bind(this),
        this.get_data.bind(this)
      ), W(() => {
        this.shared.id = e.shared_props.id;
      });
    }), se(() => this.i18n_store ? this.i18n_store.subscribe(() => {
      for (const [i, n] of Object.entries(this.translatable_props)) {
        const [s, f] = i.split("."), o = this.i18n(n);
        s === "shared" ? this.shared[f] = o : this.props[f] = o;
      }
    }) : void 0);
  }
  // check if props are translatable
  _is_i18n_managed(e, r) {
    const a = this.translatable_props[e];
    return a ? r === a ? !0 : (delete this.translatable_props[e], !1) : !1;
  }
  _translate_and_store(e, r, a) {
    if (typeof a != "string") return a;
    const i = this.i18n(a);
    return i !== a && (this.translatable_props[`${e}.${r}`] = a), i;
  }
  // Reactive variant of `i18n`. Reading it inside a derived or template
  // subscribes to the live locale store (via Svelte's createSubscriber), so
  // the caller re-runs when the locale changes at runtime. The store is only
  // the reactivity trigger; translation always goes through `this.i18n` so a
  // custom formatter passed via props keeps taking effect.
  live_i18n = (e) => (this._i18n_from_store?.current, this.i18n(e));
  dispatch(e, r) {
    this.dispatcher(this.shared.id, e, r);
  }
  async get_data() {
    return Za(this.props);
  }
  update(e) {
    this.set_data(e);
  }
  set_data(e) {
    for (const r in e) {
      const a = e[r], i = Zn(a) ? this._translate_and_store(this.shared_props.includes(r) ? "shared" : "props", r, a) : a;
      if (this.shared_props.includes(r)) {
        const n = r;
        this.shared[n] = i;
        continue;
      }
      this.props[r] = i;
    }
  }
  watch_for_change() {
    se(() => {
      this.mounted || (this.old_value = this.props.value, this.mounted = !0), this.old_value != this.props.value && (this.old_value = this.props.value, this.dispatch("change"));
    });
  }
}
bt(["click"]);
function Dt(t) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], r = 0;
  for (; t > 1e3 && r < e.length - 1; )
    t /= 1e3, r++;
  let a = e[r];
  return (Number.isInteger(t) ? t : t.toFixed(1)) + a;
}
function Er(t) {
  return Object.prototype.toString.call(t) === "[object Date]";
}
function Xt(t, e, r, a) {
  if (typeof r == "number" || Er(r)) {
    const i = a - r, n = (r - e) / (t.dt || 1 / 60), s = t.opts.stiffness * i, f = t.opts.damping * n, o = (s - f) * t.inv_mass, c = (n + o) * t.dt;
    return Math.abs(c) < t.opts.precision && Math.abs(i) < t.opts.precision ? a : (t.settled = !1, Er(r) ? new Date(r.getTime() + c) : r + c);
  } else {
    if (Array.isArray(r))
      return r.map(
        (i, n) => (
          // @ts-ignore
          Xt(t, e[n], r[n], a[n])
        )
      );
    if (typeof r == "object") {
      const i = {};
      for (const n in r)
        i[n] = Xt(t, e[n], r[n], a[n]);
      return i;
    } else
      throw new Error(`Cannot spring ${typeof r} values`);
  }
}
function Tr(t, e = {}) {
  const r = bn(t), { stiffness: a = 0.15, damping: i = 0.8, precision: n = 0.01 } = e;
  let s, f, o, c = (
    /** @type {T} */
    t
  ), u = (
    /** @type {T | undefined} */
    t
  ), y = 1, g = 0, E = !1;
  function T(h, d = {}) {
    u = h;
    const q = o = {};
    return t == null || d.hard || b.stiffness >= 1 && b.damping >= 1 ? (E = !0, s = me.now(), c = h, r.set(t = u), Promise.resolve()) : (d.soft && (g = 1 / ((d.soft === !0 ? 0.5 : +d.soft) * 60), y = 0), f || (s = me.now(), E = !1, f = an((_) => {
      if (E)
        return E = !1, f = null, !1;
      y = Math.min(y + g, 1);
      const m = Math.min(_ - s, 1e3 / 30), k = {
        inv_mass: y,
        opts: b,
        settled: !0,
        dt: m * 60 / 1e3
      }, O = Xt(k, c, t, u);
      return s = _, c = /** @type {T} */
      t, r.set(t = /** @type {T} */
      O), k.settled && (f = null), !k.settled;
    })), new Promise((_) => {
      f.promise.then(() => {
        q === o && _();
      });
    }));
  }
  const b = {
    set: T,
    update: (h, d) => T(h(
      /** @type {T} */
      u,
      /** @type {T} */
      t
    ), d),
    subscribe: r.subscribe,
    stiffness: a,
    damping: i,
    precision: n
  };
  return b;
}
var Xn = /* @__PURE__ */ U('<div><svg viewBox="-1200 -1200 3000 3000" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-11ioq4s"><g><path d="M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z" fill="#FF7C00" fill-opacity="0.4" class="svelte-11ioq4s"></path><path d="M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z" fill="#FF7C00" class="svelte-11ioq4s"></path><path d="M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z" fill="#FF7C00" fill-opacity="0.4" class="svelte-11ioq4s"></path><path d="M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z" fill="#FF7C00" class="svelte-11ioq4s"></path></g><g><path d="M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z" fill="#FF7C00" fill-opacity="0.4" class="svelte-11ioq4s"></path><path d="M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z" fill="#FF7C00" class="svelte-11ioq4s"></path><path d="M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z" fill="#FF7C00" fill-opacity="0.4" class="svelte-11ioq4s"></path><path d="M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z" fill="#FF7C00" class="svelte-11ioq4s"></path></g></svg></div>');
function Jn(t, e) {
  wt(e, !0);
  const r = () => yr(f, "$top", i), a = () => yr(o, "$bottom", i), [i, n] = mn();
  let s = p(e, "margin", 3, !0);
  const f = Tr([0, 0]), o = Tr([0, 0]);
  let c = K(!1);
  async function u() {
    await Promise.all([f.set([125, 140]), o.set([-125, -140])]), await Promise.all([f.set([-125, 140]), o.set([125, -140])]), await Promise.all([f.set([-125, 0]), o.set([125, -0])]), await Promise.all([f.set([125, 0]), o.set([-125, 0])]);
  }
  async function y() {
    await u(), l(c) || y();
  }
  async function g() {
    await Promise.all([f.set([125, 0]), o.set([-125, 0])]), y();
  }
  se(() => (g(), () => {
    M(c, !0);
  }));
  var E = Xn();
  let T;
  var b = D(E), h = D(b), d = z(h);
  R(() => {
    T = ge(E, 1, "svelte-11ioq4s", null, T, { margin: s() }), Me(h, `transform: translate(${r()[0] ?? ""}px, ${r()[1] ?? ""}px);`), Me(d, `transform: translate(${a()[0] ?? ""}px, ${a()[1] ?? ""}px);`);
  }), x(t, E), mt(), n();
}
let At = [], Vt = !1;
const Qn = typeof window < "u", Kr = Qn ? window.requestAnimationFrame : (t) => {
}, Mr = /* @__PURE__ */ new Set();
async function $n(t, e = !0) {
  if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && e !== !0)) {
    if (At.push(t), !Vt) Vt = !0;
    else return;
    await jr(), Kr(() => {
      let r = [0, 0];
      for (let a = 0; a < At.length; a++) {
        const n = At[a].getBoundingClientRect();
        (a === 0 || n.top + window.scrollY <= r[0]) && (r[0] = n.top + window.scrollY, r[1] = a);
      }
      window.scrollTo({ top: r[0] - 20, behavior: "smooth" }), Vt = !1, At = [];
    });
  }
}
var ei = /* @__PURE__ */ U('<div class="validation-error svelte-zbomup"> <button class="svelte-zbomup"><!></button></div>'), ti = /* @__PURE__ */ U('<div class="eta-bar svelte-zbomup"></div>'), ri = /* @__PURE__ */ U("<!> ", 1), ai = /* @__PURE__ */ U("<!> <!> <!> <!>", 1), ni = /* @__PURE__ */ U('<div class="progress-level svelte-zbomup"><div class="progress-level-inner svelte-zbomup"><!></div> <div class="progress-bar-wrap svelte-zbomup"><div class="progress-bar svelte-zbomup"></div></div></div>'), ii = /* @__PURE__ */ U('<p class="loading svelte-zbomup"> </p> <!>', 1), si = /* @__PURE__ */ U("<!> <div><!> <!></div> <!> <!>", 1), li = /* @__PURE__ */ U('<div class="clear-status svelte-zbomup"><!></div> <span class="error svelte-zbomup"> </span> <!>', 1), oi = /* @__PURE__ */ U("<div> <!> </div>"), fi = /* @__PURE__ */ U('<div data-testid="status-tracker"><!> <!></div> <!>', 1);
function ci(t, e) {
  wt(e, !0);
  let r = p(e, "eta", 3, null), a = p(e, "component_id", 3, null), i = p(e, "fn_index", 3, null), n = p(e, "scroll_to_output", 3, !1), s = p(e, "timer", 3, !0), f = p(e, "show_progress", 3, "full"), o = p(e, "message", 3, null), c = p(e, "progress", 3, null), u = p(e, "variant", 3, "default"), y = p(e, "loading_text", 3, "Loading..."), g = p(e, "absolute", 3, !0), E = p(e, "translucent", 3, !1), T = p(e, "border", 3, !1), b = p(e, "validation_error", 7, null), h = p(e, "show_validation_error", 3, !0), d = p(e, "type", 3, null), q = p(e, "used_cache", 3, null), _ = p(e, "cache_duration", 3, null), m = p(e, "avg_time", 3, null), k = p(e, "cache_event_id", 3, null), O, w = !1, B = K(0), N = K(null), L = K(null), we = K(!1), Ae = K(null), le = K(!1), Y = K(!1), Se = K(null), Le = K(null), Ye = K("from cache"), qe = K(!1), ye = null, xe = null, $ = null;
  function v() {
    ye && clearTimeout(ye), xe && clearTimeout(xe), ye = null, xe = null, M(le, !1), M(Y, !1);
  }
  const S = ce(() => !(h() && b()) && (d() === "input" || !e.status || e.status === "complete" || f() === "hidden" || e.status == "streaming"));
  let C = K(0);
  const Z = ce(() => l(L) === null || l(L) <= 0 || !l(C) ? 0 : Math.min(l(C) / l(L), 1)), P = ce(() => l(C).toFixed(1));
  let pe = ce(() => c() == null), G = ce(() => r() ?? l(N));
  function Be() {
    Kr(() => {
      M(C, (performance.now() - l(B)) / 1e3), w && Be();
    });
  }
  let te = ce(() => {
    let A = null;
    c() != null ? A = c().map((X) => {
      if (X.index != null && X.length != null)
        return X.index / X.length;
      if (X.progress != null)
        return X.progress;
    }) : A = null;
    let j, V = "";
    return A ? (j = A[A.length - 1], j === 0 ? V = "0" : V = "150ms") : j = void 0, {
      progress_level: A,
      last_progress_level: j,
      progress_bar_transition: V
    };
  });
  function Je() {
    w || (M(N, M(Ae, null), !0), M(B, performance.now(), !0), w = !0, Be());
  }
  function he() {
    M(N, M(Ae, null), !0), w && (w = !1);
  }
  se(() => {
    e.status === "pending" ? Je() : W(() => {
      he();
    });
  }), se(() => {
    O && n() && (e.status === "pending" || e.status === "complete") && $n(O, e.autoscroll);
  }), se(() => {
    l(G) != null && l(N) !== l(G) && (M(L, (performance.now() - l(B)) / 1e3 + l(G)), M(Ae, l(L).toFixed(1), !0), M(N, l(G), !0));
  });
  function ke() {
    M(we, !1);
  }
  se(() => {
    W(() => {
      ke();
    }), e.status === "error" && o() && M(we, !0);
  }), se(() => {
    if (e.status === "complete" && d() === "output" && q() && _() != null) {
      const A = k() == null ? null : `${a() ?? i() ?? "unknown"}:${i() ?? "unknown"}:${k()}`;
      if (A === $ || A != null && Mr.has(A))
        return;
      $ = A, A != null && Mr.add(A), M(Se, _().toFixed(1), !0), M(Ye, q() === "full" ? "from cache" : "used cache", !0), M(qe, m() != null && m() > _() && m() > 0, !0), M(Le, l(qe) ? m().toFixed(1) : null, !0), M(le, !0), M(Y, !1), ye && clearTimeout(ye), xe && clearTimeout(xe), ye = setTimeout(
        () => {
          M(Y, !0), xe = setTimeout(
            () => {
              M(le, !1), M(Y, !1);
            },
            500
          );
        },
        1750
      );
    } else d() === "output" && !q() && v();
  });
  var yt = fi(), De = Q(yt);
  let xt, lt;
  var kt = D(De);
  {
    var ot = (A) => {
      var j = ei(), V = D(j), X = z(V), re = D(X);
      {
        let ee = ce(() => e.i18n ? e.i18n("common.clear") : "Clear");
        Ct(re, {
          get Icon() {
            return xr;
          },
          get label() {
            return l(ee);
          },
          disabled: !1,
          size: "x-small",
          background: "var(--background-fill-primary)",
          color: "var(--error-background-text)",
          border: "var(--border-color-primary)",
          onclick: () => b(null)
        });
      }
      R(() => ne(V, `${b() ?? ""} `)), x(A, j);
    };
    I(kt, (A) => {
      b() && h() && A(ot);
    });
  }
  var Et = z(kt, 2);
  {
    var Tt = (A) => {
      var j = si(), V = Q(j);
      {
        var X = (H) => {
          var J = ti();
          let fe;
          R(() => fe = Me(J, "", fe, {
            transform: `translateX(${(l(Z) || 0) * 100 - 100}%)`
          })), x(H, J);
        };
        I(V, (H) => {
          u() === "default" && l(pe) && f() === "full" && H(X);
        });
      }
      var re = z(V, 2);
      let ee;
      var de = D(re);
      {
        var Ee = (H) => {
          var J = be(), fe = Q(J);
          gt(fe, 17, c, _t, (Ce, ae) => {
            var ue = be(), Pe = Q(ue);
            {
              var Qe = (Ie) => {
                var Oe = ri(), $e = Q(Oe);
                {
                  var Ft = (Ne) => {
                    var Ke = Te();
                    R((ct, dt) => ne(Ke, `${ct ?? ""}/${dt ?? ""}`), [
                      () => Dt(l(ae).index || 0),
                      () => Dt(l(ae).length)
                    ]), x(Ne, Ke);
                  }, et = (Ne) => {
                    var Ke = Te();
                    R((ct) => ne(Ke, ct), [() => Dt(l(ae).index || 0)]), x(Ne, Ke);
                  };
                  I($e, (Ne) => {
                    l(ae).length != null ? Ne(Ft) : Ne(et, !1);
                  });
                }
                var tt = z($e);
                R(() => ne(tt, ` ${l(ae).unit ?? ""} |  `)), x(Ie, Oe);
              };
              I(Pe, (Ie) => {
                l(ae).index != null && Ie(Qe);
              });
            }
            x(Ce, ue);
          }), x(H, J);
        }, oe = (H) => {
          var J = be(), fe = Q(J);
          {
            var Ce = (ue) => {
              var Pe = Te();
              R(() => ne(Pe, `queue: ${e.queue_position + 1}/${e.queue_size ?? ""} |`)), x(ue, Pe);
            }, ae = (ue) => {
              var Pe = be(), Qe = Q(Pe);
              {
                var Ie = (Oe) => {
                  var $e = Te("processing |");
                  x(Oe, $e);
                };
                I(
                  Qe,
                  (Oe) => {
                    e.queue_position === 0 && Oe(Ie);
                  },
                  !0
                );
              }
              x(ue, Pe);
            };
            I(
              fe,
              (ue) => {
                e.queue_position !== null && e.queue_size !== void 0 && e.queue_position >= 0 ? ue(Ce) : ue(ae, !1);
              },
              !0
            );
          }
          x(H, J);
        };
        I(de, (H) => {
          c() ? H(Ee) : H(oe, !1);
        });
      }
      var Ve = z(de, 2);
      {
        var ft = (H) => {
          var J = Te();
          R(() => ne(J, `${l(P) ?? ""}${r() ? `/${l(Ae)}` : ""}s`)), x(H, J);
        };
        I(Ve, (H) => {
          s() && H(ft);
        });
      }
      var ze = z(re, 2);
      {
        var Wr = (H) => {
          var J = ni(), fe = D(J), Ce = D(fe);
          {
            var ae = (Ie) => {
              var Oe = be(), $e = Q(Oe);
              gt($e, 17, c, _t, (Ft, et, tt) => {
                var Ne = be(), Ke = Q(Ne);
                {
                  var ct = (dt) => {
                    var sr = ai(), lr = Q(sr);
                    {
                      var Jr = (ie) => {
                        var je = Te(" /");
                        x(ie, je);
                      };
                      I(lr, (ie) => {
                        tt !== 0 && ie(Jr);
                      });
                    }
                    var or = z(lr, 2);
                    {
                      var Qr = (ie) => {
                        var je = Te();
                        R(() => ne(je, l(et).desc)), x(ie, je);
                      };
                      I(or, (ie) => {
                        l(et).desc != null && ie(Qr);
                      });
                    }
                    var fr = z(or, 2);
                    {
                      var $r = (ie) => {
                        var je = Te("-");
                        x(ie, je);
                      };
                      I(fr, (ie) => {
                        l(et).desc != null && l(te).progress_level && l(te).progress_level[tt] != null && ie($r);
                      });
                    }
                    var ea = z(fr, 2);
                    {
                      var ta = (ie) => {
                        var je = Te();
                        R((ra) => ne(je, `${ra ?? ""}%`), [
                          () => (100 * (l(te).progress_level[tt] || 0)).toFixed(1)
                        ]), x(ie, je);
                      };
                      I(ea, (ie) => {
                        l(te).progress_level != null && ie(ta);
                      });
                    }
                    x(dt, sr);
                  };
                  I(Ke, (dt) => {
                    (l(et).desc != null || l(te).progress_level && l(te).progress_level[tt] != null) && dt(ct);
                  });
                }
                x(Ft, Ne);
              }), x(Ie, Oe);
            };
            I(Ce, (Ie) => {
              c() != null && Ie(ae);
            });
          }
          var ue = z(fe, 2), Pe = D(ue);
          let Qe;
          R(() => Qe = Me(Pe, "", Qe, {
            width: `${l(te).last_progress_level * 100}%`,
            transition: l(te).progress_bar_transition
          })), x(H, J);
        }, Zr = (H) => {
          var J = be(), fe = Q(J);
          {
            var Ce = (ae) => {
              {
                let ue = ce(() => u() === "default");
                Jn(ae, {
                  get margin() {
                    return l(ue);
                  }
                });
              }
            };
            I(
              fe,
              (ae) => {
                f() === "full" && ae(Ce);
              },
              !0
            );
          }
          x(H, J);
        };
        I(ze, (H) => {
          l(te).last_progress_level != null ? H(Wr) : H(Zr, !1);
        });
      }
      var Gr = z(ze, 2);
      {
        var Xr = (H) => {
          var J = ii(), fe = Q(J), Ce = D(fe), ae = z(fe, 2);
          Wt(ae, e, "additional-loading-text", {}), R(() => ne(Ce, y())), x(H, J);
        };
        I(Gr, (H) => {
          s() || H(Xr);
        });
      }
      R(() => ee = ge(re, 1, "progress-text svelte-zbomup", null, ee, {
        "meta-text-center": u() === "center",
        "meta-text": u() === "default"
      })), x(A, j);
    }, Nt = (A) => {
      var j = be(), V = Q(j);
      {
        var X = (re) => {
          var ee = li(), de = Q(ee), Ee = D(de);
          {
            let ze = ce(() => e.i18n("common.clear"));
            Ct(Ee, {
              get Icon() {
                return xr;
              },
              get label() {
                return l(ze);
              },
              disabled: !1,
              onclick: () => {
                e.on_clear_status?.();
              }
            });
          }
          var oe = z(de, 2), Ve = D(oe), ft = z(oe, 2);
          Wt(ft, e, "error", {}), R((ze) => ne(Ve, ze), [() => e.i18n("common.error")]), x(re, ee);
        };
        I(
          V,
          (re) => {
            e.status === "error" && re(X);
          },
          !0
        );
      }
      x(A, j);
    };
    I(Et, (A) => {
      e.status === "pending" ? A(Tt) : A(Nt, !1);
    });
  }
  Ze(De, (A) => O = A, () => O);
  var jt = z(De, 2);
  {
    var F = (A) => {
      var j = oi();
      let V, X;
      var re = D(j), ee = z(re);
      {
        var de = (oe) => {
          var Ve = Te();
          R(() => ne(Ve, `~${l(Le) ?? ""}s
			→ `)), x(oe, Ve);
        };
        I(ee, (oe) => {
          l(qe) && oe(de);
        });
      }
      var Ee = z(ee);
      R(() => {
        V = ge(j, 1, "cache-indicator svelte-zbomup", null, V, { "fade-out": l(Y) }), X = Me(j, "", X, { position: g() ? "absolute" : "static" }), ne(re, `⚡ ${l(Ye) ?? ""}: `), ne(Ee, `${l(Se) ?? ""}s`);
      }), x(A, j);
    };
    I(jt, (A) => {
      l(le) && A(F);
    });
  }
  R(() => {
    xt = ge(De, 1, `wrap ${u() ?? ""} ${f() ?? ""}`, "svelte-zbomup", xt, {
      "no-click": b() && h(),
      hide: l(S),
      translucent: u() === "center" && (e.status === "pending" || e.status === "error") || E() || f() === "minimal" || b(),
      generating: e.status === "generating" && f() === "full",
      border: T()
    }), lt = Me(De, "", lt, {
      position: g() ? "absolute" : "static",
      padding: g() ? "0" : "var(--size-8) 0"
    });
  }), x(t, yt), mt();
}
const di = (t) => {
  const e = {};
  for (let r = 0, a = t.length; r < a; r++) {
    const i = t[r];
    for (const n in i)
      e[n] ? e[n] = e[n].concat(i[n]) : e[n] = i[n];
  }
  return e;
}, ui = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], hi = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], vi = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
di([
  Object.fromEntries(ui.map((t) => [t, ["*"]])),
  Object.fromEntries(hi.map((t) => [t, ["svg:*"]])),
  Object.fromEntries(vi.map((t) => [t, ["math:*"]]))
]);
bt(["touchstart", "touchmove", "touchend", "click", "keydown"]);
function _i(t, e) {
  wt(e, !0);
  function r(o) {
    return o instanceof HTMLElement && (o.isContentEditable || ["INPUT", "TEXTAREA", "SELECT"].includes(o.tagName));
  }
  function a(o) {
    o.key.toLowerCase() !== "f" || o.repeat || o.defaultPrevented || o.altKey || o.ctrlKey || o.metaKey || r(o.target) && !e.hovered() || (o.preventDefault(), e.onclick(!e.fullscreen));
  }
  var i = be();
  Fe("keydown", Ya, a);
  var n = Q(i);
  {
    var s = (o) => {
      Ct(o, {
        get Icon() {
          return Vn;
        },
        get label() {
          return e.exit_label;
        },
        onclick: () => e.onclick(!1)
      });
    }, f = (o) => {
      Ct(o, {
        get Icon() {
          return Bn;
        },
        get label() {
          return e.label;
        },
        onclick: () => e.onclick(!0)
      });
    };
    I(n, (o) => {
      e.fullscreen ? o(s) : o(f, !1);
    });
  }
  x(t, i), mt();
}
const gi = "canvas-host", Ar = "canvas-host-request";
class pi extends EventTarget {
  constructor(e, r, a, i, n, s) {
    super(), this.id = e, this.stage = r, this.image = a, this.area = i, this.toolbar = n, this.tool_ids = s, this.#e = s[0] ?? null;
  }
  id;
  stage;
  image;
  area;
  toolbar;
  tool_ids;
  #e;
  /** ID of the active tool, if any. */
  get tool() {
    return this.#e;
  }
  set tool(e) {
    e !== this.#e && (this.#e = e, this.#t(), this.dispatchEvent(new Event("tool-change")));
  }
  /** Press the button of the active tool, release the others. */
  #t() {
    for (const e of this.toolbar.children)
      e.querySelector("button")?.setAttribute(
        "aria-pressed",
        String(Number(e.dataset.tool) === this.#e)
      );
  }
  /** Add the button of a tool to the toolbar, in tools order. */
  add_tool(e, r) {
    const a = (n) => this.tool_ids.indexOf(Number(n.dataset.tool));
    r.dataset.tool = String(e);
    const i = [...this.toolbar.children].find((n) => a(n) > a(r));
    this.toolbar.insertBefore(r, i ?? null), this.#t();
  }
}
var bi = /* @__PURE__ */ st('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="9.3 14.3 41.7 37.8"><defs><clipPath id="canvas-photos-clip"><rect x="-16" y="-11" width="32" height="22" rx="0.5"></rect></clipPath><g id="canvas-photos-hills"><circle cx="-14" cy="16" r="12" fill="#56b65b"></circle><circle cx="0" cy="17" r="13" fill="#66c763"></circle><circle cx="15" cy="15" r="14" fill="#7be161"></circle></g></defs><g transform="translate(29 36.5) rotate(9)"><rect x="-17.2" y="-12.2" width="34.4" height="24.4" rx="1" fill="#f2f3fa"></rect><g clip-path="url(#canvas-photos-clip)"><rect x="-16" y="-11" width="32" height="22" fill="#ff9e7a"></rect><circle cx="-11" cy="3" r="3.5" fill="#ffd166"></circle><rect x="-16" y="3" width="32" height="8" fill="#3a8fd9"></rect><g fill="#8cc8ff"><rect x="-14" y="4.5" width="6" height="0.8" rx="0.4"></rect><rect x="-12.5" y="6.2" width="3" height="0.8" rx="0.4"></rect></g><ellipse cx="4" cy="15" rx="18" ry="6.5" fill="#f2d29b"></ellipse></g></g><g transform="translate(31.8 29) rotate(-6)"><rect x="-17.2" y="-12.2" width="34.4" height="24.4" rx="1" fill="#f2f3fa"></rect><g clip-path="url(#canvas-photos-clip)"><rect x="-16" y="-11" width="32" height="22" fill="#52b2ff"></rect><circle cx="-4" cy="-4" r="2.5" fill="#ffcb57"></circle><g fill="#e6e6f6"><circle cx="-15" cy="-1" r="4"></circle><circle cx="-10" cy="0" r="3"></circle><circle cx="10.5" cy="-6.8" r="1.2"></circle><circle cx="12.2" cy="-7.2" r="1.6"></circle><rect x="9.3" y="-6.6" width="6" height="1.6" rx="0.8"></rect></g><use href="#canvas-photos-hills"></use></g></g></svg>');
function mi(t) {
  var e = bi();
  x(t, e);
}
var wi = /* @__PURE__ */ U('<img class="layer svelte-ejrx76" alt=""/>'), yi = /* @__PURE__ */ U('<p class="svelte-ejrx76"> </p>'), xi = /* @__PURE__ */ U('<div class="placeholder svelte-ejrx76"><div class="placeholder-art svelte-ejrx76" aria-hidden="true"><!></div> <!></div>'), ki = /* @__PURE__ */ U('<img class="layer svelte-ejrx76" alt="" loading="lazy"/>'), Ei = /* @__PURE__ */ U('<button class="thumb svelte-ejrx76" role="option"></button>'), Ti = /* @__PURE__ */ U('<div class="thumbs-bar svelte-ejrx76"><button class="thumbs-arrow svelte-ejrx76" tabindex="-1" aria-label="Previous"><svg viewBox="0 0 16 16" aria-hidden="true" class="svelte-ejrx76"><path d="M10 4L6 8L10 12"></path></svg></button> <div role="listbox" aria-orientation="horizontal" tabindex="-1"></div> <button class="thumbs-arrow svelte-ejrx76" tabindex="-1" aria-label="Next"><svg viewBox="0 0 16 16" aria-hidden="true" class="svelte-ejrx76"><path d="M6 4L10 8L6 12"></path></svg></button></div>'), Mi = /* @__PURE__ */ U('<div class="group svelte-ejrx76"><!></div>'), Ai = /* @__PURE__ */ U('<!> <!> <div role="group"><div><img class="layer svelte-ejrx76" alt=""/> <!></div> <!> <!> <div><!> <div class="group toolbar svelte-ejrx76" role="toolbar"></div></div></div>', 1);
function Li(t, e) {
  wt(e, !0);
  let r = null;
  class a extends Gn {
    // Events wait for dropped images, to pass them.
    async get_data() {
      return r && (await r, await jr()), super.get_data();
    }
  }
  const i = /* @__PURE__ */ xn(e, ["$$slots", "$$events", "$$legacy"]), n = new a(i), s = ce(() => n.props.value ?? { docs: [], index: null }), f = ce(() => l(s).index === null ? null : l(s).docs[l(s).index] ?? null);
  let o = K(!1), c = K(!1), u = !1, y, g, E, T, b = K(void 0), h = K(0);
  function d(v) {
    return v.layers[0].object.path;
  }
  function q(v) {
    return { index: v, path: d(l(s).docs[v]) };
  }
  function _(v, S) {
    n.props.value = { docs: v, index: S };
  }
  function m(v) {
    v !== l(s).index && (_(l(s).docs, v), n.dispatch("input"));
  }
  let k = W(() => l(s).docs.map(d)), O = W(() => l(f) && d(l(f)));
  se(() => {
    const v = l(s).docs.map(d), S = l(f) && d(l(f));
    W(() => w(v, S));
  });
  function w(v, S) {
    S === O && v.join(`
`) === k.join(`
`) || (k.forEach((C, Z) => {
      v.includes(C) || n.dispatch("doc_deleted", { index: Z, path: C });
    }), v.forEach((C, Z) => {
      k.includes(C) || n.dispatch("doc_added", { index: Z, path: C });
    }), k.length && !v.length ? n.dispatch("empty") : !k.length && v.length && n.dispatch("filled"), S !== O && l(s).index !== null && n.dispatch("select", q(l(s).index)), k = v, O = S, n.dispatch("change"));
  }
  se(() => {
    const v = l(s).index === null ? null : l(b)?.children[l(s).index];
    v instanceof HTMLElement && (v.scrollIntoView({ block: "nearest", inline: "nearest", behavior: "smooth" }), l(b)?.contains(document.activeElement) && v.focus({ preventScroll: !0 }));
  });
  let B = K(!1), N = K(!1);
  function L() {
    if (!l(b)) return;
    const { scrollLeft: v, scrollWidth: S, clientWidth: C } = l(b);
    M(B, v > 1), M(N, v + C < S - 1);
  }
  se(() => {
    if (!l(b)) return;
    l(s).docs.length, L();
    const v = new ResizeObserver(L);
    return v.observe(l(b)), () => v.disconnect();
  });
  function we(v) {
    n.dispatch("thumb_click", q(v)), m(v);
  }
  function Ae(v) {
    const S = l(s).index, C = l(s).docs.length - 1;
    if (S === null || v.altKey || v.ctrlKey || v.metaKey) return;
    const P = {
      ArrowLeft: Math.max(0, S - 1),
      ArrowRight: Math.min(C, S + 1),
      Home: 0,
      End: C
    }[v.key];
    P !== void 0 && (v.preventDefault(), m(P));
  }
  let le = 0;
  function Y(v) {
    if (l(s).index === null || v.ctrlKey || Math.abs(v.deltaY) <= Math.abs(v.deltaX))
      return;
    v.preventDefault();
    const S = v.deltaMode === WheelEvent.DOM_DELTA_PIXEL ? v.deltaY : v.deltaY * 40;
    if (Math.sign(S) !== Math.sign(le) && (le = 0), le += S, Math.abs(le) < 50) return;
    const C = Math.sign(le);
    le = 0, Se(C);
  }
  function Se(v) {
    l(s).index !== null && m(Math.min(l(s).docs.length - 1, Math.max(0, l(s).index + v)));
  }
  function Le(v) {
    const S = v.target;
    !(S instanceof HTMLImageElement) || !v.dataTransfer || (u = !0, v.dataTransfer.setData("text/uri-list", S.currentSrc));
  }
  function Ye(v) {
    return n.shared.interactive !== !1 && !u && !!v.dataTransfer?.types.includes("Files");
  }
  function qe(v) {
    Ye(v) && (v.preventDefault(), v.dataTransfer.dropEffect = "copy", M(c, !0));
  }
  function ye(v) {
    y.contains(v.relatedTarget) || M(c, !1);
  }
  function xe(v) {
    if (M(c, !1), !Ye(v)) return;
    v.preventDefault();
    const S = [...v.dataTransfer.files].filter((C) => C.type.startsWith("image/"));
    S.length && (r = $(S).finally(() => r = null));
  }
  async function $(v) {
    let S;
    try {
      S = await n.shared.client.upload(
        v.map((P) => ({
          path: P.name,
          orig_name: P.name,
          blob: P,
          size: P.size,
          mime_type: P.type,
          is_stream: !1,
          meta: { _type: "gradio.FileData" }
        })),
        n.shared.root,
        void 0,
        n.shared.max_file_size ?? void 0
      );
    } catch (P) {
      n.dispatch("error", P instanceof Error ? P.message : String(P));
      return;
    }
    const C = (S ?? []).filter((P) => P !== null).map((P) => ({ layers: [{ object: P }], caption: null }));
    if (!C.length) return;
    const Z = l(s).docs.length;
    _([...l(s).docs, ...C], Z + C.length - 1), C.forEach((P, pe) => n.dispatch("doc_dropped", q(Z + pe))), n.dispatch("input");
  }
  Pn(() => {
    const v = new pi(n.shared.id, g, E, y, T, n.props.tools ?? []);
    v.addEventListener("tool-change", () => n.dispatch("tool_selected", { tool: v.tool }));
    const S = (C) => {
      const Z = C.detail;
      Z.canvas_id === v.id && Z.resolve(v);
    };
    return window.addEventListener(Ar, S), window.dispatchEvent(new CustomEvent(gi, { detail: v })), () => window.removeEventListener(Ar, S);
  });
  {
    let v = ce(() => n.props.height ?? void 0);
    Ln(t, {
      get visible() {
        return n.shared.visible;
      },
      variant: "solid",
      padding: !1,
      get elem_id() {
        return n.shared.elem_id;
      },
      get elem_classes() {
        return n.shared.elem_classes;
      },
      get container() {
        return n.shared.container;
      },
      get scale() {
        return n.shared.scale;
      },
      get min_width() {
        return n.shared.min_width;
      },
      allow_overflow: !1,
      get height() {
        return l(v);
      },
      get fullscreen() {
        return l(o);
      },
      set fullscreen(S) {
        M(o, S, !0);
      },
      children: (S, C) => {
        var Z = Ai(), P = Q(Z);
        ci(P, En(
          {
            get autoscroll() {
              return n.shared.autoscroll;
            },
            get i18n() {
              return n.i18n;
            }
          },
          () => n.shared.loading_status,
          {
            on_clear_status: () => n.dispatch("clear_status", n.shared.loading_status)
          }
        ));
        var pe = z(P, 2);
        {
          let F = ce(() => n.shared.label || "Canvas");
          Cn(pe, {
            get show_label() {
              return n.shared.show_label;
            },
            get Icon() {
              return Rn;
            },
            get label() {
              return l(F);
            }
          });
        }
        var G = z(pe, 2);
        let Be;
        var te = D(G);
        let Je, he;
        var ke = D(te);
        Ze(ke, (F) => E = F, () => E);
        var yt = z(ke, 2);
        gt(yt, 17, () => l(f)?.layers.slice(1) ?? [], _t, (F, A) => {
          var j = wi();
          R(() => _e(j, "src", l(A).object.url)), x(F, j);
        }), Ze(te, (F) => g = F, () => g);
        var De = z(te, 2);
        {
          var xt = (F) => {
            var A = xi(), j = D(A), V = D(j);
            mi(V);
            var X = z(j, 2);
            {
              var re = (ee) => {
                var de = yi(), Ee = D(de);
                R(() => ne(Ee, n.props.placeholder)), x(ee, de);
              };
              I(X, (ee) => {
                n.props.placeholder && ee(re);
              });
            }
            x(F, A);
          };
          I(De, (F) => {
            l(f) || F(xt);
          });
        }
        var lt = z(De, 2);
        {
          var kt = (F) => {
            var A = Ti(), j = D(A);
            j.__click = () => Se(-1);
            var V = z(j, 2);
            let X;
            V.__keydown = Ae, gt(V, 21, () => l(s).docs, _t, (ee, de, Ee) => {
              var oe = Ei();
              oe.__click = () => we(Ee), gt(oe, 21, () => l(de).layers, _t, (Ve, ft) => {
                var ze = ki();
                R(() => _e(ze, "src", l(ft).object.url)), x(Ve, ze);
              }), R(() => {
                _e(oe, "aria-selected", Ee === l(s).index), _e(oe, "title", l(de).caption ?? void 0);
              }), x(ee, oe);
            }), Ze(V, (ee) => M(b, ee), () => l(b));
            var re = z(V, 2);
            re.__click = () => Se(1), R(() => {
              j.disabled = !l(s).index, X = ge(V, 1, "thumbs svelte-ejrx76", null, X, {
                "fade-start": l(B),
                "fade-end": l(N)
              }), re.disabled = l(s).index === null || l(s).index === l(s).docs.length - 1;
            }), Fe("wheel", A, Y), Fe("scroll", V, L), x(F, A);
          };
          I(lt, (F) => {
            n.props.thumbs && l(s).docs.length && F(kt);
          });
        }
        var ot = z(lt, 2);
        let Et;
        var Tt = D(ot);
        {
          var Nt = (F) => {
            var A = Mi(), j = D(A);
            _i(j, {
              get fullscreen() {
                return l(o);
              },
              onclick: (V) => M(o, V, !0),
              get label() {
                return n.props.fullscreen_tooltip;
              },
              get exit_label() {
                return n.props.exit_fullscreen_tooltip;
              },
              hovered: () => y.matches(":hover")
            }), x(F, A);
          };
          I(Tt, (F) => {
            n.props.buttons?.includes("fullscreen") && F(Nt);
          });
        }
        var jt = z(Tt, 2);
        Ze(jt, (F) => T = F, () => T), Ze(G, (F) => y = F, () => y), R(() => {
          Be = ge(G, 1, "canvas svelte-ejrx76", null, Be, { "drag-over": l(c) }), _e(G, "aria-label", n.shared.label), Je = ge(te, 1, "stage svelte-ejrx76", null, Je, { hidden: !l(f) }), he = Me(te, "", he, {
            "margin-inline": l(h) ? `calc(${l(h)}px + var(--spacing-lg))` : void 0
          }), _e(ke, "src", l(f)?.layers[0].object.url), Et = ge(ot, 1, "buttons svelte-ejrx76", null, Et, { "below-label": n.shared.show_label });
        }), Fe("dragstart", G, Le), Fe("dragend", G, () => u = !1), Fe("dragover", G, qe), Fe("dragleave", G, ye), Fe("drop", G, xe), gn(ot, "offsetWidth", (F) => M(h, F)), x(S, Z);
      },
      $$slots: { default: !0 }
    });
  }
  mt();
}
bt(["click", "keydown"]);
export {
  Li as default
};
