import { i as hr, g as jr, o as ln, q as vr, c as lt, a as _r, b as qt, d as on, T as cn, e as fn, f as sr, r as pr, h as _t, p as gr, j as pt, m as dn, s as Hr, k as It, E as Kt, l as i, n as kr, t as qr, u as Ur, v as br, w as un, x as Er, y as hn, z as vn, A as vt, B as Qe, I as er, C as _n, D as pn, F as gn, N as bn, G as mr, H as Yr, J as Wt, K as mn, L as wn, M as yn, O as xn, P as kn, Q as En, R as Mn, S as Tn, U as Sn, V as Pt, W as zn, X as An, Y as Ln, Z as X, _ as Cn, $ as wr, a0 as Bt, a1 as In, a2 as fe, a3 as Pn, a4 as Mr, a5 as Le, a6 as Kr, a7 as Et, a8 as On, a9 as w, aa as Nn, ab as lr, ac as Rn, ad as Fn, ae as Ut, af as Dn, ag as Vn, ah as Wr, ai as Bn, aj as jn, ak as Hn, al as qn, am as Zr, an as At, ao as Un, ap as Tr, aq as Yn, ar as $, as as Ot, at as Nt, au as P, av as he, aw as j, ax as Kn, ay as H, az as ce, aA as ae, aB as Wn, aC as Zn, aD as D, aE as Gr, aF as jt } from "./render-BuEbLTW8.js";
function Gn(t) {
  throw new Error("https://svelte.dev/e/lifecycle_outside_component");
}
const Xn = [];
function Jn(t, e = !1, r = !1) {
  return Ht(t, /* @__PURE__ */ new Map(), "", Xn, null, r);
}
function Ht(t, e, r, n, s = null, a = !1) {
  if (typeof t == "object" && t !== null) {
    var l = e.get(t);
    if (l !== void 0) return l;
    if (t instanceof Map) return (
      /** @type {Snapshot<T>} */
      new Map(t)
    );
    if (t instanceof Set) return (
      /** @type {Snapshot<T>} */
      new Set(t)
    );
    if (hr(t)) {
      var o = (
        /** @type {Snapshot<any>} */
        Array(t.length)
      );
      e.set(t, o), s !== null && e.set(s, o);
      for (var f = 0; f < t.length; f += 1) {
        var d = t[f];
        f in t && (o[f] = Ht(d, e, r, n, null, a));
      }
      return o;
    }
    if (jr(t) === ln) {
      o = {}, e.set(t, o), s !== null && e.set(s, o);
      for (var h in t)
        o[h] = Ht(
          // @ts-expect-error
          t[h],
          e,
          r,
          n,
          null,
          a
        );
      return o;
    }
    if (t instanceof Date)
      return (
        /** @type {Snapshot<T>} */
        structuredClone(t)
      );
    if (typeof /** @type {T & { toJSON?: any } } */
    t.toJSON == "function" && !a)
      return Ht(
        /** @type {T & { toJSON(): any } } */
        t.toJSON(),
        e,
        r,
        n,
        // Associate the instance with the toJSON clone
        t
      );
  }
  if (t instanceof EventTarget)
    return (
      /** @type {Snapshot<T>} */
      t
    );
  try {
    return (
      /** @type {Snapshot<T>} */
      structuredClone(t)
    );
  } catch {
    return (
      /** @type {Snapshot<T>} */
      t
    );
  }
}
function Qn(t, e) {
  if (e) {
    const r = document.body;
    t.autofocus = !0, vr(() => {
      document.activeElement === r && t.focus();
    });
  }
}
function Xr(t) {
  var e = document.createElement("template");
  return e.innerHTML = t.replaceAll("<!>", "<!---->"), e.content;
}
function Mt(t, e) {
  var r = (
    /** @type {Effect} */
    _r
  );
  r.nodes === null && (r.nodes = { start: t, end: e, a: null, t: null });
}
// @__NO_SIDE_EFFECTS__
function q(t, e) {
  var r = (e & cn) !== 0, n = (e & fn) !== 0, s, a = !t.startsWith("<!>");
  return () => {
    s === void 0 && (s = Xr(a ? t : "<!>" + t), r || (s = /** @type {TemplateNode} */
    qt(s)));
    var l = (
      /** @type {TemplateNode} */
      n || on ? document.importNode(s, !0) : s.cloneNode(!0)
    );
    if (r) {
      var o = (
        /** @type {TemplateNode} */
        qt(l)
      ), f = (
        /** @type {TemplateNode} */
        l.lastChild
      );
      Mt(o, f);
    } else
      Mt(l, l);
    return l;
  };
}
// @__NO_SIDE_EFFECTS__
function $n(t, e, r = "svg") {
  var n = !t.startsWith("<!>"), s = `<${r}>${n ? t : "<!>" + t}</${r}>`, a;
  return () => {
    if (!a) {
      var l = (
        /** @type {DocumentFragment} */
        Xr(s)
      ), o = (
        /** @type {Element} */
        qt(l)
      );
      a = /** @type {Element} */
      qt(o);
    }
    var f = (
      /** @type {TemplateNode} */
      a.cloneNode(!0)
    );
    return Mt(f, f), f;
  };
}
// @__NO_SIDE_EFFECTS__
function Tt(t, e) {
  return /* @__PURE__ */ $n(t, e, "svg");
}
function Ye(t = "") {
  {
    var e = lt(t + "");
    return Mt(e, e), e;
  }
}
function Be() {
  var t = document.createDocumentFragment(), e = document.createComment(""), r = lt();
  return t.append(e, r), Mt(e, r), t;
}
function k(t, e) {
  t !== null && t.before(
    /** @type {Node} */
    e
  );
}
class Zt {
  /** @type {TemplateNode} */
  anchor;
  /** @type {Map<Batch, Key>} */
  #e = /* @__PURE__ */ new Map();
  /**
   * Map of keys to effects that are currently rendered in the DOM.
   * These effects are visible and actively part of the document tree.
   * Example:
   * ```
   * {#if condition}
   * 	foo
   * {:else}
   * 	bar
   * {/if}
   * ```
   * Can result in the entries `true->Effect` and `false->Effect`
   * @type {Map<Key, Effect>}
   */
  #t = /* @__PURE__ */ new Map();
  /**
   * Similar to #onscreen with respect to the keys, but contains branches that are not yet
   * in the DOM, because their insertion is deferred.
   * @type {Map<Key, Branch>}
   */
  #r = /* @__PURE__ */ new Map();
  /**
   * Keys of effects that are currently outroing
   * @type {Set<Key>}
   */
  #n = /* @__PURE__ */ new Set();
  /**
   * Whether to pause (i.e. outro) on change, or destroy immediately.
   * This is necessary for `<svelte:element>`
   */
  #a = !0;
  /**
   * @param {TemplateNode} anchor
   * @param {boolean} transition
   */
  constructor(e, r = !0) {
    this.anchor = e, this.#a = r;
  }
  #i = () => {
    var e = (
      /** @type {Batch} */
      sr
    );
    if (this.#e.has(e)) {
      var r = (
        /** @type {Key} */
        this.#e.get(e)
      ), n = this.#t.get(r);
      if (n)
        pr(n), this.#n.delete(r);
      else {
        var s = this.#r.get(r);
        s && (this.#t.set(r, s.effect), this.#r.delete(r), s.fragment.lastChild.remove(), this.anchor.before(s.fragment), n = s.effect);
      }
      for (const [a, l] of this.#e) {
        if (this.#e.delete(a), a === e)
          break;
        const o = this.#r.get(l);
        o && (_t(o.effect), this.#r.delete(l));
      }
      for (const [a, l] of this.#t) {
        if (a === r || this.#n.has(a)) continue;
        const o = () => {
          if (Array.from(this.#e.values()).includes(a)) {
            var d = document.createDocumentFragment();
            dn(l, d), d.append(lt()), this.#r.set(a, { effect: l, fragment: d });
          } else
            _t(l);
          this.#n.delete(a), this.#t.delete(a);
        };
        this.#a || !n ? (this.#n.add(a), gr(l, o, !1)) : o();
      }
    }
  };
  /**
   * @param {Batch} batch
   */
  #s = (e) => {
    this.#e.delete(e);
    const r = Array.from(this.#e.values());
    for (const [n, s] of this.#r)
      r.includes(n) || (_t(s.effect), this.#r.delete(n));
  };
  /**
   *
   * @param {any} key
   * @param {null | ((target: TemplateNode) => void)} fn
   */
  ensure(e, r) {
    var n = (
      /** @type {Batch} */
      sr
    ), s = Hr();
    if (r && !this.#t.has(e) && !this.#r.has(e))
      if (s) {
        var a = document.createDocumentFragment(), l = lt();
        a.append(l), this.#r.set(e, {
          effect: pt(() => r(l)),
          fragment: a
        });
      } else
        this.#t.set(
          e,
          pt(() => r(this.anchor))
        );
    if (this.#e.set(n, e), s) {
      for (const [o, f] of this.#t)
        o === e ? n.skipped_effects.delete(f) : n.skipped_effects.add(f);
      for (const [o, f] of this.#r)
        o === e ? n.skipped_effects.delete(f.effect) : n.skipped_effects.add(f.effect);
      n.oncommit(this.#i), n.ondiscard(this.#s);
    } else
      this.#i();
  }
}
function R(t, e, r = !1) {
  var n = new Zt(t), s = r ? Kt : 0;
  function a(l, o) {
    n.ensure(l, o);
  }
  It(() => {
    var l = !1;
    e((o, f = !0) => {
      l = !0, a(f, o);
    }), l || a(!1, null);
  }, s);
}
function xt(t, e) {
  return e;
}
function ea(t, e, r) {
  for (var n = [], s = e.length, a, l = e.length, o = 0; o < s; o++) {
    let y = e[o];
    gr(
      y,
      () => {
        if (a) {
          if (a.pending.delete(y), a.done.add(y), a.pending.size === 0) {
            var p = (
              /** @type {Set<EachOutroGroup>} */
              t.outrogroups
            );
            or(br(a.done)), p.delete(a), p.size === 0 && (t.outrogroups = null);
          }
        } else
          l -= 1;
      },
      !1
    );
  }
  if (l === 0) {
    var f = n.length === 0 && r !== null;
    if (f) {
      var d = (
        /** @type {Element} */
        r
      ), h = (
        /** @type {Element} */
        d.parentNode
      );
      pn(h), h.append(d), t.items.clear();
    }
    or(e, !f);
  } else
    a = {
      pending: new Set(e),
      done: /* @__PURE__ */ new Set()
    }, (t.outrogroups ??= /* @__PURE__ */ new Set()).add(a);
}
function or(t, e = !0) {
  for (var r = 0; r < t.length; r++)
    _t(t[r], e);
}
var Sr;
function kt(t, e, r, n, s, a = null) {
  var l = t, o = /* @__PURE__ */ new Map(), f = (e & qr) !== 0;
  if (f) {
    var d = (
      /** @type {Element} */
      t
    );
    l = d.appendChild(lt());
  }
  var h = null, y = Ur(() => {
    var v = r();
    return hr(v) ? v : v == null ? [] : br(v);
  }), p, T = !0;
  function S() {
    u.fallback = h, ta(u, p, l, e, n), h !== null && (p.length === 0 ? (h.f & Qe) === 0 ? pr(h) : (h.f ^= Qe, Lt(h, null, l)) : gr(h, () => {
      h = null;
    }));
  }
  var E = It(() => {
    p = /** @type {V[]} */
    i(y);
    for (var v = p.length, V = /* @__PURE__ */ new Set(), _ = (
      /** @type {Batch} */
      sr
    ), x = Hr(), z = 0; z < v; z += 1) {
      var O = p[z], m = n(O, z), U = T ? null : o.get(m);
      U ? (U.v && kr(U.v, O), U.i && kr(U.i, z), x && _.skipped_effects.delete(U.e)) : (U = ra(
        o,
        T ? l : Sr ??= lt(),
        O,
        m,
        z,
        s,
        e,
        r
      ), T || (U.e.f |= Qe), o.set(m, U)), V.add(m);
    }
    if (v === 0 && a && !h && (T ? h = pt(() => a(l)) : (h = pt(() => a(Sr ??= lt())), h.f |= Qe)), !T)
      if (x) {
        for (const [F, C] of o)
          V.has(F) || _.skipped_effects.add(C.e);
        _.oncommit(S), _.ondiscard(() => {
        });
      } else
        S();
    i(y);
  }), u = { effect: E, items: o, outrogroups: null, fallback: h };
  T = !1;
}
function ta(t, e, r, n, s) {
  var a = (n & _n) !== 0, l = e.length, o = t.items, f = t.effect.first, d, h = null, y, p = [], T = [], S, E, u, v;
  if (a)
    for (v = 0; v < l; v += 1)
      S = e[v], E = s(S, v), u = /** @type {EachItem} */
      o.get(E).e, (u.f & Qe) === 0 && (u.nodes?.a?.measure(), (y ??= /* @__PURE__ */ new Set()).add(u));
  for (v = 0; v < l; v += 1) {
    if (S = e[v], E = s(S, v), u = /** @type {EachItem} */
    o.get(E).e, t.outrogroups !== null)
      for (const C of t.outrogroups)
        C.pending.delete(u), C.done.delete(u);
    if ((u.f & Qe) !== 0)
      if (u.f ^= Qe, u === f)
        Lt(u, null, r);
      else {
        var V = h ? h.next : f;
        u === t.effect.last && (t.effect.last = u.prev), u.prev && (u.prev.next = u.next), u.next && (u.next.prev = u.prev), it(t, h, u), it(t, u, V), Lt(u, V, r), h = u, p = [], T = [], f = h.next;
        continue;
      }
    if ((u.f & er) !== 0 && (pr(u), a && (u.nodes?.a?.unfix(), (y ??= /* @__PURE__ */ new Set()).delete(u))), u !== f) {
      if (d !== void 0 && d.has(u)) {
        if (p.length < T.length) {
          var _ = T[0], x;
          h = _.prev;
          var z = p[0], O = p[p.length - 1];
          for (x = 0; x < p.length; x += 1)
            Lt(p[x], _, r);
          for (x = 0; x < T.length; x += 1)
            d.delete(T[x]);
          it(t, z.prev, O.next), it(t, h, z), it(t, O, _), f = _, h = O, v -= 1, p = [], T = [];
        } else
          d.delete(u), Lt(u, f, r), it(t, u.prev, u.next), it(t, u, h === null ? t.effect.first : h.next), it(t, h, u), h = u;
        continue;
      }
      for (p = [], T = []; f !== null && f !== u; )
        (d ??= /* @__PURE__ */ new Set()).add(f), T.push(f), f = f.next;
      if (f === null)
        continue;
    }
    (u.f & Qe) === 0 && p.push(u), h = u, f = u.next;
  }
  if (t.outrogroups !== null) {
    for (const C of t.outrogroups)
      C.pending.size === 0 && (or(br(C.done)), t.outrogroups?.delete(C));
    t.outrogroups.size === 0 && (t.outrogroups = null);
  }
  if (f !== null || d !== void 0) {
    var m = [];
    if (d !== void 0)
      for (u of d)
        (u.f & er) === 0 && m.push(u);
    for (; f !== null; )
      (f.f & er) === 0 && f !== t.fallback && m.push(f), f = f.next;
    var U = m.length;
    if (U > 0) {
      var F = (n & qr) !== 0 && l === 0 ? r : null;
      if (a) {
        for (v = 0; v < U; v += 1)
          m[v].nodes?.a?.measure();
        for (v = 0; v < U; v += 1)
          m[v].nodes?.a?.fix();
      }
      ea(t, m, F);
    }
  }
  a && vr(() => {
    if (y !== void 0)
      for (u of y)
        u.nodes?.a?.apply();
  });
}
function ra(t, e, r, n, s, a, l, o) {
  var f = (l & hn) !== 0 ? (l & vn) === 0 ? vt(r, !1, !1) : Er(r) : null, d = (l & un) !== 0 ? Er(s) : null;
  return {
    v: f,
    i: d,
    e: pt(() => (a(e, f ?? r, d ?? s, o), () => {
      t.delete(n);
    }))
  };
}
function Lt(t, e, r) {
  if (t.nodes)
    for (var n = t.nodes.start, s = t.nodes.end, a = e && (e.f & Qe) === 0 ? (
      /** @type {EffectNodes} */
      e.nodes.start
    ) : r; n !== null; ) {
      var l = (
        /** @type {TemplateNode} */
        gn(n)
      );
      if (a.before(n), n === s)
        return;
      n = l;
    }
}
function it(t, e, r) {
  e === null ? t.effect.first = r : e.next = r, r === null ? t.effect.last = e : r.prev = e;
}
function cr(t, e, r, n, s) {
  var a = e.$$slots?.[r], l = !1;
  a === !0 && (a = e[r === "default" ? "children" : r], l = !0), a === void 0 || a(t, l ? () => n : n);
}
function na(t, e, ...r) {
  var n = new Zt(t);
  It(() => {
    const s = e() ?? null;
    n.ensure(s, s && ((a) => s(a, ...r)));
  }, Kt);
}
function aa(t, e, r) {
  var n = new Zt(t);
  It(() => {
    var s = e() ?? null;
    n.ensure(s, s && ((a) => r(a, s)));
  }, Kt);
}
const ia = () => performance.now(), je = {
  // don't access requestAnimationFrame eagerly outside method
  // this allows basic testing of user code without JSDOM
  // bunder will eval and remove ternary when the user's app is built
  tick: (
    /** @param {any} _ */
    (t) => requestAnimationFrame(t)
  ),
  now: () => ia(),
  tasks: /* @__PURE__ */ new Set()
};
function Jr() {
  const t = je.now();
  je.tasks.forEach((e) => {
    e.c(t) || (je.tasks.delete(e), e.f());
  }), je.tasks.size !== 0 && je.tick(Jr);
}
function sa(t) {
  let e;
  return je.tasks.size === 0 && je.tick(Jr), {
    promise: new Promise((r) => {
      je.tasks.add(e = { c: t, f: r });
    }),
    abort() {
      je.tasks.delete(e);
    }
  };
}
function la(t, e, r, n, s, a) {
  var l = null, o = (
    /** @type {TemplateNode} */
    t
  ), f = new Zt(o, !1);
  It(() => {
    const d = e() || null;
    var h = d === "svg" ? bn : null;
    if (d === null) {
      f.ensure(null, null);
      return;
    }
    return f.ensure(d, (y) => {
      if (d) {
        if (l = h ? document.createElementNS(h, d) : document.createElement(d), Mt(l, l), n) {
          var p = l.appendChild(lt());
          n(l, p);
        }
        _r.nodes.end = l, y.before(l);
      }
    }), () => {
    };
  }, Kt), mr(() => {
  });
}
function oa(t, e) {
  var r = void 0, n;
  Yr(() => {
    r !== (r = e()) && (n && (_t(n), n = null), r && (n = pt(() => {
      Wt(() => (
        /** @type {(node: Element) => void} */
        r(t)
      ));
    })));
  });
}
function Qr(t) {
  var e, r, n = "";
  if (typeof t == "string" || typeof t == "number") n += t;
  else if (typeof t == "object") if (Array.isArray(t)) {
    var s = t.length;
    for (e = 0; e < s; e++) t[e] && (r = Qr(t[e])) && (n && (n += " "), n += r);
  } else for (r in t) t[r] && (n && (n += " "), n += r);
  return n;
}
function ca() {
  for (var t, e, r = 0, n = "", s = arguments.length; r < s; r++) (t = arguments[r]) && (e = Qr(t)) && (n && (n += " "), n += e);
  return n;
}
function fa(t) {
  return typeof t == "object" ? ca(t) : t ?? "";
}
const zr = [...` 	
\r\f \v\uFEFF`];
function da(t, e, r) {
  var n = t == null ? "" : "" + t;
  if (e && (n = n ? n + " " + e : e), r) {
    for (var s in r)
      if (r[s])
        n = n ? n + " " + s : s;
      else if (n.length)
        for (var a = s.length, l = 0; (l = n.indexOf(s, l)) >= 0; ) {
          var o = l + a;
          (l === 0 || zr.includes(n[l - 1])) && (o === n.length || zr.includes(n[o])) ? n = (l === 0 ? "" : n.substring(0, l)) + n.substring(o + 1) : l = o;
        }
  }
  return n === "" ? null : n;
}
function Ar(t, e = !1) {
  var r = e ? " !important;" : ";", n = "";
  for (var s in t) {
    var a = t[s];
    a != null && a !== "" && (n += " " + s + ": " + a + r);
  }
  return n;
}
function tr(t) {
  return t[0] !== "-" || t[1] !== "-" ? t.toLowerCase() : t;
}
function ua(t, e) {
  if (e) {
    var r = "", n, s;
    if (Array.isArray(e) ? (n = e[0], s = e[1]) : n = e, t) {
      t = String(t).replaceAll(/\s*\/\*.*?\*\/\s*/g, "").trim();
      var a = !1, l = 0, o = !1, f = [];
      n && f.push(...Object.keys(n).map(tr)), s && f.push(...Object.keys(s).map(tr));
      var d = 0, h = -1;
      const E = t.length;
      for (var y = 0; y < E; y++) {
        var p = t[y];
        if (o ? p === "/" && t[y - 1] === "*" && (o = !1) : a ? a === p && (a = !1) : p === "/" && t[y + 1] === "*" ? o = !0 : p === '"' || p === "'" ? a = p : p === "(" ? l++ : p === ")" && l--, !o && a === !1 && l === 0) {
          if (p === ":" && h === -1)
            h = y;
          else if (p === ";" || y === E - 1) {
            if (h !== -1) {
              var T = tr(t.substring(d, h).trim());
              if (!f.includes(T)) {
                p !== ";" && y++;
                var S = t.substring(d, y).trim();
                r += " " + S + ";";
              }
            }
            d = y + 1, h = -1;
          }
        }
      }
    }
    return n && (r += Ar(n)), s && (r += Ar(s, !0)), r = r.trim(), r === "" ? null : r;
  }
  return t == null ? null : String(t);
}
function ye(t, e, r, n, s, a) {
  var l = t.__className;
  if (l !== r || l === void 0) {
    var o = da(r, n, a);
    o == null ? t.removeAttribute("class") : e ? t.className = o : t.setAttribute("class", o), t.__className = r;
  } else if (a && s !== a)
    for (var f in a) {
      var d = !!a[f];
      (s == null || d !== !!s[f]) && t.classList.toggle(f, d);
    }
  return a;
}
function rr(t, e = {}, r, n) {
  for (var s in r) {
    var a = r[s];
    e[s] !== a && (r[s] == null ? t.style.removeProperty(s) : t.style.setProperty(s, a, n));
  }
}
function Ie(t, e, r, n) {
  var s = t.__style;
  if (s !== e) {
    var a = ua(e, n);
    a == null ? t.removeAttribute("style") : t.style.cssText = a, t.__style = e;
  } else n && (Array.isArray(n) ? (rr(t, r?.[0], n[0]), rr(t, r?.[1], n[1], "important")) : rr(t, r, n));
  return n;
}
function fr(t, e, r = !1) {
  if (t.multiple) {
    if (e == null)
      return;
    if (!hr(e))
      return mn();
    for (var n of t.options)
      n.selected = e.includes(Lr(n));
    return;
  }
  for (n of t.options) {
    var s = Lr(n);
    if (wn(s, e)) {
      n.selected = !0;
      return;
    }
  }
  (!r || e !== void 0) && (t.selectedIndex = -1);
}
function ha(t) {
  var e = new MutationObserver(() => {
    fr(t, t.__value);
  });
  e.observe(t, {
    // Listen to option element changes
    childList: !0,
    subtree: !0,
    // because of <optgroup>
    // Listen to option element value attribute changes
    // (doesn't get notified of select value changes,
    // because that property is not reflected as an attribute)
    attributes: !0,
    attributeFilter: ["value"]
  }), mr(() => {
    e.disconnect();
  });
}
function Lr(t) {
  return "__value" in t ? t.__value : t.value;
}
const Ct = /* @__PURE__ */ Symbol("class"), yt = /* @__PURE__ */ Symbol("style"), $r = /* @__PURE__ */ Symbol("is custom element"), en = /* @__PURE__ */ Symbol("is html");
function va(t, e) {
  e ? t.hasAttribute("selected") || t.setAttribute("selected", "") : t.removeAttribute("selected");
}
function Ce(t, e, r, n) {
  var s = tn(t);
  s[e] !== (s[e] = r) && (e === "loading" && (t[xn] = r), r == null ? t.removeAttribute(e) : typeof r != "string" && rn(t).includes(e) ? t[e] = r : t.setAttribute(e, r));
}
function _a(t, e, r, n, s = !1, a = !1) {
  var l = tn(t), o = l[$r], f = !l[en], d = e || {}, h = t.tagName === "OPTION";
  for (var y in e)
    y in r || (r[y] = null);
  r.class ? r.class = fa(r.class) : r.class = null, r[yt] && (r.style ??= null);
  var p = rn(t);
  for (const _ in r) {
    let x = r[_];
    if (h && _ === "value" && x == null) {
      t.value = t.__value = "", d[_] = x;
      continue;
    }
    if (_ === "class") {
      var T = t.namespaceURI === "http://www.w3.org/1999/xhtml";
      ye(t, T, x, n, e?.[Ct], r[Ct]), d[_] = x, d[Ct] = r[Ct];
      continue;
    }
    if (_ === "style") {
      Ie(t, x, e?.[yt], r[yt]), d[_] = x, d[yt] = r[yt];
      continue;
    }
    var S = d[_];
    if (!(x === S && !(x === void 0 && t.hasAttribute(_)))) {
      d[_] = x;
      var E = _[0] + _[1];
      if (E !== "$$")
        if (E === "on") {
          const z = {}, O = "$$" + _;
          let m = _.slice(2);
          var u = Ln(m);
          if (Tn(m) && (m = m.slice(0, -7), z.capture = !0), !u && S) {
            if (x != null) continue;
            t.removeEventListener(m, d[O], z), d[O] = null;
          }
          if (x != null)
            if (u)
              t[`__${m}`] = x, Pt([m]);
            else {
              let U = function(F) {
                d[_].call(this, F);
              };
              d[O] = Sn(m, t, U, z);
            }
          else u && (t[`__${m}`] = void 0);
        } else if (_ === "style")
          Ce(t, _, x);
        else if (_ === "autofocus")
          Qn(
            /** @type {HTMLElement} */
            t,
            !!x
          );
        else if (!o && (_ === "__value" || _ === "value" && x != null))
          t.value = t.__value = x;
        else if (_ === "selected" && h)
          va(
            /** @type {HTMLOptionElement} */
            t,
            x
          );
        else {
          var v = _;
          f || (v = zn(v));
          var V = v === "defaultValue" || v === "defaultChecked";
          if (x == null && !o && !V)
            if (l[_] = null, v === "value" || v === "checked") {
              let z = (
                /** @type {HTMLInputElement} */
                t
              );
              const O = e === void 0;
              if (v === "value") {
                let m = z.defaultValue;
                z.removeAttribute(v), z.defaultValue = m, z.value = z.__value = O ? m : null;
              } else {
                let m = z.defaultChecked;
                z.removeAttribute(v), z.defaultChecked = m, z.checked = O ? m : !1;
              }
            } else
              t.removeAttribute(_);
          else V || p.includes(v) && (o || typeof x != "string") ? (t[v] = x, v in l && (l[v] = An)) : typeof x != "function" && Ce(t, v, x);
        }
    }
  }
  return d;
}
function pa(t, e, r = [], n = [], s = [], a, l = !1, o = !1) {
  En(s, r, n, (f) => {
    var d = void 0, h = {}, y = t.nodeName === "SELECT", p = !1;
    if (Yr(() => {
      var S = e(...f.map(i)), E = _a(
        t,
        d,
        S,
        a,
        l,
        o
      );
      p && y && "value" in S && fr(
        /** @type {HTMLSelectElement} */
        t,
        S.value
      );
      for (let v of Object.getOwnPropertySymbols(h))
        S[v] || _t(h[v]);
      for (let v of Object.getOwnPropertySymbols(S)) {
        var u = S[v];
        v.description === Mn && (!d || u !== d[v]) && (h[v] && _t(h[v]), h[v] = pt(() => oa(t, () => u))), E[v] = u;
      }
      d = E;
    }), y) {
      var T = (
        /** @type {HTMLSelectElement} */
        t
      );
      Wt(() => {
        fr(
          T,
          /** @type {Record<string | symbol, any>} */
          d.value,
          !0
        ), ha(T);
      });
    }
    p = !0;
  });
}
function tn(t) {
  return (
    /** @type {Record<string | symbol, unknown>} **/
    // @ts-expect-error
    t.__attributes ??= {
      [$r]: t.nodeName.includes("-"),
      [en]: t.namespaceURI === yn
    }
  );
}
var Cr = /* @__PURE__ */ new Map();
function rn(t) {
  var e = t.getAttribute("is") || t.nodeName, r = Cr.get(e);
  if (r) return r;
  Cr.set(e, r = []);
  for (var n, s = t, a = Element.prototype; a !== s; ) {
    n = kn(s);
    for (var l in n)
      n[l].set && r.push(l);
    s = jr(s);
  }
  return r;
}
class yr {
  /** */
  #e = /* @__PURE__ */ new WeakMap();
  /** @type {ResizeObserver | undefined} */
  #t;
  /** @type {ResizeObserverOptions} */
  #r;
  /** @static */
  static entries = /* @__PURE__ */ new WeakMap();
  /** @param {ResizeObserverOptions} options */
  constructor(e) {
    this.#r = e;
  }
  /**
   * @param {Element} element
   * @param {(entry: ResizeObserverEntry) => any} listener
   */
  observe(e, r) {
    var n = this.#e.get(e) || /* @__PURE__ */ new Set();
    return n.add(r), this.#e.set(e, n), this.#n().observe(e, this.#r), () => {
      var s = this.#e.get(e);
      s.delete(r), s.size === 0 && (this.#e.delete(e), this.#t.unobserve(e));
    };
  }
  #n() {
    return this.#t ?? (this.#t = new ResizeObserver(
      /** @param {any} entries */
      (e) => {
        for (var r of e) {
          yr.entries.set(r.target, r);
          for (var n of this.#e.get(r.target) || [])
            n(r);
        }
      }
    ));
  }
}
var ga = /* @__PURE__ */ new yr({
  box: "border-box"
});
function nr(t, e, r) {
  var n = ga.observe(t, () => r(t[e]));
  Wt(() => (X(() => r(t[e])), n));
}
function Ir(t, e) {
  return t === e || t?.[wr] === e;
}
function st(t = {}, e, r, n) {
  return Wt(() => {
    var s, a;
    return Cn(() => {
      s = a, a = n?.() || [], X(() => {
        t !== r(...a) && (e(t, ...a), s && Ir(r(...s), t) && e(null, ...s));
      });
    }), () => {
      vr(() => {
        a && Ir(r(...a), t) && e(null, ...a);
      });
    };
  }), t;
}
function ba(t = !1) {
  const e = (
    /** @type {ComponentContextLegacy} */
    Bt
  ), r = e.l.u;
  if (!r) return;
  let n = () => Le(e.s);
  if (t) {
    let s = 0, a = (
      /** @type {Record<string, any>} */
      {}
    );
    const l = Kr(() => {
      let o = !1;
      const f = e.s;
      for (const d in f)
        f[d] !== a[d] && (a[d] = f[d], o = !0);
      return o && s++, s;
    });
    n = () => i(l);
  }
  r.b.length && In(() => {
    Pr(e, n), Mr(r.b);
  }), fe(() => {
    const s = X(() => r.m.map(Pn));
    return () => {
      for (const a of s)
        typeof a == "function" && a();
    };
  }), r.a.length && fe(() => {
    Pr(e, n), Mr(r.a);
  });
}
function Pr(t, e) {
  if (t.l.s)
    for (const r of t.l.s) i(r);
  e();
}
function nn(t, e, r) {
  if (t == null)
    return e(void 0), Et;
  const n = X(
    () => t.subscribe(
      e,
      // @ts-expect-error
      r
    )
  );
  return n.unsubscribe ? () => n.unsubscribe() : n;
}
const wt = [];
function ma(t, e = Et) {
  let r = null;
  const n = /* @__PURE__ */ new Set();
  function s(o) {
    if (On(t, o) && (t = o, r)) {
      const f = !wt.length;
      for (const d of n)
        d[1](), wt.push(d, t);
      if (f) {
        for (let d = 0; d < wt.length; d += 2)
          wt[d][0](wt[d + 1]);
        wt.length = 0;
      }
    }
  }
  function a(o) {
    s(o(
      /** @type {T} */
      t
    ));
  }
  function l(o, f = Et) {
    const d = [o, f];
    return n.add(d), n.size === 1 && (r = e(s, a) || Et), o(
      /** @type {T} */
      t
    ), () => {
      n.delete(d), n.size === 0 && r && (r(), r = null);
    };
  }
  return { set: s, update: a, subscribe: l };
}
function an(t) {
  let e;
  return nn(t, (r) => e = r)(), e;
}
let Dt = !1, dr = /* @__PURE__ */ Symbol();
function Or(t, e, r) {
  const n = r[e] ??= {
    store: null,
    source: vt(void 0),
    unsubscribe: Et
  };
  if (n.store !== t && !(dr in r))
    if (n.unsubscribe(), n.store = t ?? null, t == null)
      n.source.v = void 0, n.unsubscribe = Et;
    else {
      var s = !0;
      n.unsubscribe = nn(t, (a) => {
        s ? n.source.v = a : w(n.source, a);
      }), s = !1;
    }
  return t && dr in r ? an(t) : i(n.source);
}
function wa() {
  const t = {};
  function e() {
    mr(() => {
      for (var r in t)
        t[r].unsubscribe();
      Nn(t, dr, {
        enumerable: !1,
        value: !0
      });
    });
  }
  return [t, e];
}
function ya(t) {
  var e = Dt;
  try {
    return Dt = !1, [t(), Dt];
  } finally {
    Dt = e;
  }
}
const xa = {
  get(t, e) {
    if (!t.exclude.includes(e))
      return t.props[e];
  },
  set(t, e) {
    return !1;
  },
  getOwnPropertyDescriptor(t, e) {
    if (!t.exclude.includes(e) && e in t.props)
      return {
        enumerable: !0,
        configurable: !0,
        value: t.props[e]
      };
  },
  has(t, e) {
    return t.exclude.includes(e) ? !1 : e in t.props;
  },
  ownKeys(t) {
    return Reflect.ownKeys(t.props).filter((e) => !t.exclude.includes(e));
  }
};
// @__NO_SIDE_EFFECTS__
function ka(t, e, r) {
  return new Proxy(
    { props: t, exclude: e },
    xa
  );
}
const Ea = {
  get(t, e) {
    let r = t.props.length;
    for (; r--; ) {
      let n = t.props[r];
      if (At(n) && (n = n()), typeof n == "object" && n !== null && e in n) return n[e];
    }
  },
  set(t, e, r) {
    let n = t.props.length;
    for (; n--; ) {
      let s = t.props[n];
      At(s) && (s = s());
      const a = lr(s, e);
      if (a && a.set)
        return a.set(r), !0;
    }
    return !1;
  },
  getOwnPropertyDescriptor(t, e) {
    let r = t.props.length;
    for (; r--; ) {
      let n = t.props[r];
      if (At(n) && (n = n()), typeof n == "object" && n !== null && e in n) {
        const s = lr(n, e);
        return s && !s.configurable && (s.configurable = !0), s;
      }
    }
  },
  has(t, e) {
    if (e === wr || e === Zr) return !1;
    for (let r of t.props)
      if (At(r) && (r = r()), r != null && e in r) return !0;
    return !1;
  },
  ownKeys(t) {
    const e = [];
    for (let r of t.props)
      if (At(r) && (r = r()), !!r) {
        for (const n in r)
          e.includes(n) || e.push(n);
        for (const n of Object.getOwnPropertySymbols(r))
          e.includes(n) || e.push(n);
      }
    return e;
  }
};
function Ma(...t) {
  return new Proxy({ props: t }, Ea);
}
function b(t, e, r, n) {
  var s = !Wr || (r & Bn) !== 0, a = (r & Vn) !== 0, l = (r & Hn) !== 0, o = (
    /** @type {V} */
    n
  ), f = !0, d = () => (f && (f = !1, o = l ? X(
    /** @type {() => V} */
    n
  ) : (
    /** @type {V} */
    n
  )), o), h;
  if (a) {
    var y = wr in t || Zr in t;
    h = lr(t, e)?.set ?? (y && e in t ? (_) => t[e] = _ : void 0);
  }
  var p, T = !1;
  a ? [p, T] = ya(() => (
    /** @type {V} */
    t[e]
  )) : p = /** @type {V} */
  t[e], p === void 0 && n !== void 0 && (p = d(), h && (s && Rn(), h(p)));
  var S;
  if (s ? S = () => {
    var _ = (
      /** @type {V} */
      t[e]
    );
    return _ === void 0 ? d() : (f = !0, _);
  } : S = () => {
    var _ = (
      /** @type {V} */
      t[e]
    );
    return _ !== void 0 && (o = /** @type {V} */
    void 0), _ === void 0 ? o : _;
  }, s && (r & Fn) === 0)
    return S;
  if (h) {
    var E = t.$$legacy;
    return (
      /** @type {() => V} */
      (function(_, x) {
        return arguments.length > 0 ? ((!s || !x || E || T) && h(x ? S() : _), _) : S();
      })
    );
  }
  var u = !1, v = ((r & jn) !== 0 ? Kr : Ur)(() => (u = !1, S()));
  a && i(v);
  var V = (
    /** @type {Effect} */
    _r
  );
  return (
    /** @type {() => V} */
    (function(_, x) {
      if (arguments.length > 0) {
        const z = x ? i(v) : s && a ? Ut(_) : _;
        return w(v, z), u = !0, o !== void 0 && (o = z), _;
      }
      return qn && u || (V.f & Dn) !== 0 ? v.v : i(v);
    })
  );
}
Un();
var Ta = /* @__PURE__ */ Tt('<svg class="resize-handle svelte-1brspkc" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 10 10"><line x1="1" y1="9" x2="9" y2="1" stroke="gray" stroke-width="0.5" class="svelte-1brspkc"></line><line x1="5" y1="9" x2="9" y2="5" stroke="gray" stroke-width="0.5" class="svelte-1brspkc"></line></svg>'), Sa = /* @__PURE__ */ q("<!> <!>", 1), za = /* @__PURE__ */ q('<div class="placeholder svelte-1brspkc"></div>'), Aa = /* @__PURE__ */ q("<!> <!>", 1);
function La(t, e) {
  Nt(e, !1);
  let r = b(e, "height", 8, void 0), n = b(e, "min_height", 8, void 0), s = b(e, "max_height", 8, void 0), a = b(e, "width", 8, void 0), l = b(e, "elem_id", 8, ""), o = b(e, "elem_classes", 24, () => []), f = b(e, "variant", 8, "solid"), d = b(e, "border_mode", 8, "base"), h = b(e, "padding", 8, !0), y = b(e, "type", 8, "normal"), p = b(e, "test_id", 8, void 0), T = b(e, "explicit_call", 8, !1), S = b(e, "container", 8, !0), E = b(e, "visible", 8, !0), u = b(e, "allow_overflow", 8, !0), v = b(e, "overflow_behavior", 8, "auto"), V = b(e, "scale", 8, null), _ = b(e, "min_width", 8, 0), x = b(e, "flex", 12, !1), z = b(e, "resizable", 8, !1), O = b(e, "rtl", 8, !1), m = b(e, "fullscreen", 12, !1), U = b(e, "label", 8, void 0), F = vt(m()), C = vt(), xe = y() === "fieldset" ? "fieldset" : "div", Ke = vt(0), We = vt(0), Y = vt(null);
  function ot(J) {
    m() && J.key === "Escape" && m(!1);
  }
  const Ze = (J) => {
    if (J !== void 0) {
      if (typeof J == "number")
        return J + "px";
      if (typeof J == "string")
        return J;
    }
  }, $e = (J) => {
    let ie = J.clientY;
    const W = (tt) => {
      const se = tt.clientY - ie;
      ie = tt.clientY, Kn(C, i(C).style.height = `${i(C).offsetHeight + se}px`);
    }, ve = () => {
      window.removeEventListener("mousemove", W), window.removeEventListener("mouseup", ve);
    };
    window.addEventListener("mousemove", W), window.addEventListener("mouseup", ve);
  };
  Tr(
    () => (Le(m()), i(F), i(C)),
    () => {
      m() !== i(F) && (w(F, m()), m() ? (w(Y, i(C).getBoundingClientRect()), w(Ke, i(C).offsetHeight), w(We, i(C).offsetWidth), window.addEventListener("keydown", ot)) : (w(Y, null), window.removeEventListener("keydown", ot)));
    }
  ), Tr(() => Le(E()), () => {
    E() || x(!1);
  }), Yn(), ba();
  var et = Be(), ke = $(et);
  {
    var Ee = (J) => {
      var ie = Aa(), W = $(ie);
      la(W, () => xe, !1, (se, He) => {
        st(se, (Pe) => w(C, Pe), () => i(C)), pa(
          se,
          (Pe, Oe) => ({
            "data-testid": p(),
            id: l(),
            class: `block ${Pe ?? ""}`,
            dir: O() ? "rtl" : "ltr",
            "aria-label": U(),
            style: "",
            [Ct]: {
              hidden: E() === "hidden",
              padded: h(),
              flex: x(),
              border_focus: d() === "focus",
              border_contrast: d() === "contrast",
              "hide-container": !T() && !S(),
              fullscreen: m(),
              animating: m() && i(Y) !== null,
              "auto-margin": V() === null
            },
            [yt]: Oe
          }),
          [
            () => (Le(o()), X(() => o()?.join(" ") || "")),
            () => ({
              height: (Le(m()), Le(r()), X(() => m() ? void 0 : Ze(r()))),
              "min-height": (Le(m()), Le(n()), X(() => m() ? void 0 : Ze(n()))),
              "max-height": (Le(m()), Le(s()), X(() => m() ? void 0 : Ze(s()))),
              "--start-top": (i(Y), X(() => i(Y) ? `${i(Y).top}px` : "0px")),
              "--start-left": (i(Y), X(() => i(Y) ? `${i(Y).left}px` : "0px")),
              "--start-width": (i(Y), X(() => i(Y) ? `${i(Y).width}px` : "0px")),
              "--start-height": (i(Y), X(() => i(Y) ? `${i(Y).height}px` : "0px")),
              width: (Le(m()), Le(a()), X(() => m() ? void 0 : typeof a() == "number" ? `calc(min(${a()}px, 100%))` : Ze(a()))),
              "border-style": f(),
              overflow: u() ? v() : "hidden",
              "flex-grow": V(),
              "min-width": `calc(min(${_()}px, 100%))`
            })
          ],
          void 0,
          void 0,
          "svelte-1brspkc"
        );
        var pe = Sa(), ge = $(pe);
        cr(ge, e, "default", {});
        var we = P(ge, 2);
        {
          var St = (Pe) => {
            var Oe = Ta();
            he("mousedown", Oe, $e), k(Pe, Oe);
          };
          R(we, (Pe) => {
            z() && Pe(St);
          });
        }
        k(He, pe);
      });
      var ve = P(W, 2);
      {
        var tt = (se) => {
          var He = za();
          let pe;
          j(() => pe = Ie(He, "", pe, {
            height: i(Ke) + "px",
            width: i(We) + "px"
          })), k(se, He);
        };
        R(ve, (se) => {
          m() && se(tt);
        });
      }
      k(J, ie);
    };
    R(ke, (J) => {
      (E() === !0 || E() === "hidden") && J(Ee);
    });
  }
  k(t, et), Ot();
}
var Ca = /* @__PURE__ */ q('<label for="" data-testid="block-label"><span class="svelte-29fz3m"><!></span> </label>');
function Ia(t, e) {
  let r = b(e, "label", 8, null), n = b(e, "Icon", 8), s = b(e, "show_label", 8, !0), a = b(e, "disable", 8, !1), l = b(e, "float", 8, !0), o = b(e, "rtl", 8, !1);
  var f = Ca();
  let d;
  var h = H(f), y = H(h);
  n()(y, {});
  var p = P(h);
  j(() => {
    Ce(f, "dir", o() ? "rtl" : "ltr"), d = ye(f, 1, "svelte-29fz3m", null, d, {
      hide: !s(),
      "sr-only": !s(),
      float: l(),
      "hide-label": a()
    }), ce(p, ` ${r() ?? ""}`), f.dir = f.dir;
  }), k(t, f);
}
function Pa(t) {
  Bt === null && Gn(), Wr && Bt.l !== null ? Oa(Bt).m.push(t) : fe(() => {
    const e = X(t);
    if (typeof e == "function") return (
      /** @type {() => void} */
      e
    );
  });
}
function Oa(t) {
  var e = (
    /** @type {ComponentContextLegacy} */
    t.l
  );
  return e.u ??= { a: [], b: [], m: [] };
}
var Na = /* @__PURE__ */ q('<span class="svelte-y5xc0a"> </span>'), Ra = /* @__PURE__ */ q("<button><!> <div><!> <!></div></button>");
function Yt(t, e) {
  let r = b(e, "label", 3, ""), n = b(e, "show_label", 3, !1), s = b(e, "pending", 3, !1), a = b(e, "size", 3, "small"), l = b(e, "padded", 3, !0), o = b(e, "highlight", 3, !1), f = b(e, "disabled", 3, !1), d = b(e, "hasPopup", 3, !1), h = b(e, "color", 3, "var(--block-label-text-color)"), y = b(e, "transparent", 3, !1), p = b(e, "background", 3, "var(--block-background-fill)"), T = b(e, "border", 3, "transparent"), S = ae(() => o() ? "var(--color-accent)" : h());
  var E = Ra();
  let u;
  E.__click = function(...F) {
    e.onclick?.apply(this, F);
  };
  let v;
  var V = H(E);
  {
    var _ = (F) => {
      var C = Na(), xe = H(C);
      j(() => ce(xe, r())), k(F, C);
    };
    R(V, (F) => {
      n() && F(_);
    });
  }
  var x = P(V, 2);
  let z;
  var O = H(x);
  aa(O, () => e.Icon, (F, C) => {
    C(F, {});
  });
  var m = P(O, 2);
  {
    var U = (F) => {
      var C = Be(), xe = $(C);
      na(xe, () => e.children), k(F, C);
    };
    R(m, (F) => {
      e.children && F(U);
    });
  }
  j(() => {
    u = ye(E, 1, "icon-button svelte-y5xc0a", null, u, {
      pending: s(),
      padded: l(),
      highlight: o(),
      transparent: y()
    }), E.disabled = f(), Ce(E, "aria-label", r()), Ce(E, "aria-haspopup", d()), Ce(E, "title", r()), v = Ie(E, "", v, {
      "--border-color": T(),
      color: !f() && i(S) ? i(S) : "var(--block-label-text-color)",
      "--bg-color": f() ? "auto" : p()
    }), z = ye(x, 1, "svelte-y5xc0a", null, z, {
      "x-small": a() === "x-small",
      small: a() === "small",
      large: a() === "large",
      medium: a() === "medium"
    });
  }), k(t, E);
}
Pt(["click"]);
var Fa = /* @__PURE__ */ Tt('<svg width="100%" height="100%" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" stroke="currentColor" style="fill-rule:evenodd;clip-rule:evenodd;stroke-linecap:round;stroke-linejoin:round;"><g transform="matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"><path d="M18,6L6.087,17.913" style="fill:none;fill-rule:nonzero;stroke-width:2px;"></path></g><path d="M4.364,4.364L19.636,19.636" style="fill:none;fill-rule:nonzero;stroke-width:2px;"></path></svg>');
function Nr(t) {
  var e = Fa();
  k(t, e);
}
var Da = /* @__PURE__ */ Tt('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-image"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline></svg>');
function Va(t) {
  var e = Da();
  k(t, e);
}
var Ba = /* @__PURE__ */ Tt('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-maximize" width="100%" height="100%"><path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"></path></svg>');
function ja(t) {
  var e = Ba();
  k(t, e);
}
var Ha = /* @__PURE__ */ Tt('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-minimize" width="100%" height="100%"><path d="M8 3v3a2 2 0 0 1-2 2H3m18 0h-3a2 2 0 0 1-2-2V3m0 18v-3a2 2 0 0 1 2-2h3M3 16h3a2 2 0 0 1 2 2v3"></path></svg>');
function qa(t) {
  var e = Ha();
  k(t, e);
}
const Ua = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], Rr = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
Ua.reduce((t, { color: e, primary: r, secondary: n }) => ({
  ...t,
  [e]: {
    primary: Rr[e][r],
    secondary: Rr[e][n]
  }
}), {});
function Ya(t) {
  let e;
  const r = Zn((s) => {
    let a = !1;
    const l = t.subscribe((o) => {
      e = o, a && s();
    });
    return a = !0, l;
  });
  function n() {
    return Wn() ? (r(), e) : an(t);
  }
  return "set" in t ? {
    get current() {
      return n();
    },
    set current(s) {
      t.set(s);
    }
  } : {
    get current() {
      return n();
    }
  };
}
const Ka = "__i18n__", Wa = [
  "label",
  "info",
  "placeholder",
  "description",
  "title",
  "value"
], Za = [
  "elem_id",
  "elem_classes",
  "visible",
  "interactive",
  "server_fns",
  "server",
  "id",
  "target",
  "theme_mode",
  "version",
  "root",
  "autoscroll",
  "max_file_size",
  "formatter",
  "client",
  "load_component",
  "scale",
  "min_width",
  "theme",
  "padding",
  "loading_status",
  "label",
  "show_label",
  "validation_error",
  "show_progress",
  "api_prefix",
  "container",
  "attached_events",
  "register_component",
  "dispatcher"
];
function Ga(t) {
  return typeof t == "string" && t.includes(Ka);
}
class Xa {
  load_component;
  #e = D(Ut({}));
  get shared() {
    return i(this.#e);
  }
  set shared(e) {
    w(this.#e, e, !0);
  }
  #t = D(Ut({}));
  get props() {
    return i(this.#t);
  }
  set props(e) {
    w(this.#t, e, !0);
  }
  #r = D((e) => e);
  get i18n() {
    return i(this.#r);
  }
  set i18n(e) {
    w(this.#r, e, !0);
  }
  i18n_store;
  _i18n_from_store;
  translatable_props = {};
  dispatcher;
  last_update = null;
  shared_props = Za;
  mounted = !1;
  old_value;
  register_component;
  constructor(e, r) {
    for (const n in e.shared_props)
      this.shared[n] = e.shared_props[n];
    for (const n in e.props)
      n !== "i18n_store" && (this.props[n] = e.props[n]);
    if (r)
      for (const n in r)
        this.props[n] === void 0 && (this.props[n] = r[n]);
    this.i18n = this.props.i18n ?? ((n) => n), this.i18n_store = e.props.i18n_store, this._i18n_from_store = this.i18n_store ? Ya(this.i18n_store) : void 0;
    for (const n of Wa)
      this.shared[n] = this._translate_and_store(
        "shared",
        n,
        // @ts-ignore
        e.shared_props[n]
      ), this.props[n] = this._translate_and_store(
        "props",
        n,
        // @ts-ignore
        e.props[n]
      );
    this.load_component = this.shared.load_component, this.register_component = this.shared.register_component || (() => {
    }), this.dispatcher = this.shared.dispatcher || (() => {
    }), this.register_component(
      e.shared_props.id,
      // @ts-ignore
      this.set_data.bind(this),
      this.get_data.bind(this)
    ), fe(() => {
      for (const n in e.shared_props)
        this._is_i18n_managed(`shared.${n}`, e.shared_props[n]) || (this.shared[n] = e.shared_props[n]);
      for (const n in e.props)
        n !== "i18n_store" && (this._is_i18n_managed(`props.${n}`, e.props[n]) || (this.props[n] = e.props[n]));
      this.register_component(
        e.shared_props.id,
        // @ts-ignore
        this.set_data.bind(this),
        this.get_data.bind(this)
      ), X(() => {
        this.shared.id = e.shared_props.id;
      });
    }), fe(() => this.i18n_store ? this.i18n_store.subscribe(() => {
      for (const [s, a] of Object.entries(this.translatable_props)) {
        const [l, o] = s.split("."), f = this.i18n(a);
        l === "shared" ? this.shared[o] = f : this.props[o] = f;
      }
    }) : void 0);
  }
  // check if props are translatable
  _is_i18n_managed(e, r) {
    const n = this.translatable_props[e];
    return n ? r === n ? !0 : (delete this.translatable_props[e], !1) : !1;
  }
  _translate_and_store(e, r, n) {
    if (typeof n != "string") return n;
    const s = this.i18n(n);
    return s !== n && (this.translatable_props[`${e}.${r}`] = n), s;
  }
  // Reactive variant of `i18n`. Reading it inside a derived or template
  // subscribes to the live locale store (via Svelte's createSubscriber), so
  // the caller re-runs when the locale changes at runtime. The store is only
  // the reactivity trigger; translation always goes through `this.i18n` so a
  // custom formatter passed via props keeps taking effect.
  live_i18n = (e) => (this._i18n_from_store?.current, this.i18n(e));
  dispatch(e, r) {
    this.dispatcher(this.shared.id, e, r);
  }
  async get_data() {
    return Jn(this.props);
  }
  update(e) {
    this.set_data(e);
  }
  set_data(e) {
    for (const r in e) {
      const n = e[r], s = Ga(n) ? this._translate_and_store(this.shared_props.includes(r) ? "shared" : "props", r, n) : n;
      if (this.shared_props.includes(r)) {
        const a = r;
        this.shared[a] = s;
        continue;
      }
      this.props[r] = s;
    }
  }
  watch_for_change() {
    fe(() => {
      this.mounted || (this.old_value = this.props.value, this.mounted = !0), this.old_value != this.props.value && (this.old_value = this.props.value, this.dispatch("change"));
    });
  }
}
Pt(["click"]);
function ar(t) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], r = 0;
  for (; t > 1e3 && r < e.length - 1; )
    t /= 1e3, r++;
  let n = e[r];
  return (Number.isInteger(t) ? t : t.toFixed(1)) + n;
}
function Fr(t) {
  return Object.prototype.toString.call(t) === "[object Date]";
}
function ur(t, e, r, n) {
  if (typeof r == "number" || Fr(r)) {
    const s = n - r, a = (r - e) / (t.dt || 1 / 60), l = t.opts.stiffness * s, o = t.opts.damping * a, f = (l - o) * t.inv_mass, d = (a + f) * t.dt;
    return Math.abs(d) < t.opts.precision && Math.abs(s) < t.opts.precision ? n : (t.settled = !1, Fr(r) ? new Date(r.getTime() + d) : r + d);
  } else {
    if (Array.isArray(r))
      return r.map(
        (s, a) => (
          // @ts-ignore
          ur(t, e[a], r[a], n[a])
        )
      );
    if (typeof r == "object") {
      const s = {};
      for (const a in r)
        s[a] = ur(t, e[a], r[a], n[a]);
      return s;
    } else
      throw new Error(`Cannot spring ${typeof r} values`);
  }
}
function Dr(t, e = {}) {
  const r = ma(t), { stiffness: n = 0.15, damping: s = 0.8, precision: a = 0.01 } = e;
  let l, o, f, d = (
    /** @type {T} */
    t
  ), h = (
    /** @type {T | undefined} */
    t
  ), y = 1, p = 0, T = !1;
  function S(u, v = {}) {
    h = u;
    const V = f = {};
    return t == null || v.hard || E.stiffness >= 1 && E.damping >= 1 ? (T = !0, l = je.now(), d = u, r.set(t = h), Promise.resolve()) : (v.soft && (p = 1 / ((v.soft === !0 ? 0.5 : +v.soft) * 60), y = 0), o || (l = je.now(), T = !1, o = sa((_) => {
      if (T)
        return T = !1, o = null, !1;
      y = Math.min(y + p, 1);
      const x = Math.min(_ - l, 1e3 / 30), z = {
        inv_mass: y,
        opts: E,
        settled: !0,
        dt: x * 60 / 1e3
      }, O = ur(z, d, t, h);
      return l = _, d = /** @type {T} */
      t, r.set(t = /** @type {T} */
      O), z.settled && (o = null), !z.settled;
    })), new Promise((_) => {
      o.promise.then(() => {
        V === f && _();
      });
    }));
  }
  const E = {
    set: S,
    update: (u, v) => S(u(
      /** @type {T} */
      h,
      /** @type {T} */
      t
    ), v),
    subscribe: r.subscribe,
    stiffness: n,
    damping: s,
    precision: a
  };
  return E;
}
var Ja = /* @__PURE__ */ q('<div><svg viewBox="-1200 -1200 3000 3000" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-13if8lc"><g><path d="M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z" fill="#FF7C00" fill-opacity="0.4" class="svelte-13if8lc"></path><path d="M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z" fill="#FF7C00" class="svelte-13if8lc"></path><path d="M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z" fill="#FF7C00" fill-opacity="0.4" class="svelte-13if8lc"></path><path d="M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z" fill="#FF7C00" class="svelte-13if8lc"></path></g><g><path d="M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z" fill="#FF7C00" fill-opacity="0.4" class="svelte-13if8lc"></path><path d="M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z" fill="#FF7C00" class="svelte-13if8lc"></path><path d="M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z" fill="#FF7C00" fill-opacity="0.4" class="svelte-13if8lc"></path><path d="M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z" fill="#FF7C00" class="svelte-13if8lc"></path></g></svg></div>');
function Qa(t, e) {
  Nt(e, !0);
  const r = () => Or(o, "$top", s), n = () => Or(f, "$bottom", s), [s, a] = wa();
  let l = b(e, "margin", 3, !0);
  const o = Dr([0, 0]), f = Dr([0, 0]);
  let d = D(!1);
  async function h() {
    await Promise.all([o.set([125, 140]), f.set([-125, -140])]), await Promise.all([o.set([-125, 140]), f.set([125, -140])]), await Promise.all([o.set([-125, 0]), f.set([125, -0])]), await Promise.all([o.set([125, 0]), f.set([-125, 0])]);
  }
  async function y() {
    await h(), i(d) || y();
  }
  async function p() {
    await Promise.all([o.set([125, 0]), f.set([-125, 0])]), y();
  }
  fe(() => (p(), () => {
    w(d, !0);
  }));
  var T = Ja();
  let S;
  var E = H(T), u = H(E), v = P(u);
  j(() => {
    S = ye(T, 1, "svelte-13if8lc", null, S, { margin: l() }), Ie(u, `transform: translate(${r()[0] ?? ""}px, ${r()[1] ?? ""}px);`), Ie(v, `transform: translate(${n()[0] ?? ""}px, ${n()[1] ?? ""}px);`);
  }), k(t, T), Ot(), a();
}
let Vt = [], ir = !1;
const $a = typeof window < "u", sn = $a ? window.requestAnimationFrame : (t) => {
}, Vr = /* @__PURE__ */ new Set();
async function ei(t, e = !0) {
  if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && e !== !0)) {
    if (Vt.push(t), !ir) ir = !0;
    else return;
    await Gr(), sn(() => {
      let r = [0, 0];
      for (let n = 0; n < Vt.length; n++) {
        const a = Vt[n].getBoundingClientRect();
        (n === 0 || a.top + window.scrollY <= r[0]) && (r[0] = a.top + window.scrollY, r[1] = n);
      }
      window.scrollTo({ top: r[0] - 20, behavior: "smooth" }), ir = !1, Vt = [];
    });
  }
}
var ti = /* @__PURE__ */ q('<div class="validation-error svelte-1uvc87p"> <button class="svelte-1uvc87p"><!></button></div>'), ri = /* @__PURE__ */ q('<div class="eta-bar svelte-1uvc87p"></div>'), ni = /* @__PURE__ */ q("<!> ", 1), ai = /* @__PURE__ */ q("<!> <!> <!> <!>", 1), ii = /* @__PURE__ */ q('<div class="progress-level svelte-1uvc87p"><div class="progress-level-inner svelte-1uvc87p"><!></div> <div class="progress-bar-wrap svelte-1uvc87p"><div class="progress-bar svelte-1uvc87p"></div></div></div>'), si = /* @__PURE__ */ q('<p class="loading svelte-1uvc87p"> </p> <!>', 1), li = /* @__PURE__ */ q("<!> <div><!> <!></div> <!> <!>", 1), oi = /* @__PURE__ */ q('<div class="clear-status svelte-1uvc87p"><!></div> <span class="error svelte-1uvc87p"> </span> <!>', 1), ci = /* @__PURE__ */ q("<div> <!> </div>"), fi = /* @__PURE__ */ q('<div data-testid="status-tracker"><!> <!></div> <!>', 1);
function di(t, e) {
  Nt(e, !0);
  let r = b(e, "eta", 3, null), n = b(e, "component_id", 3, null), s = b(e, "fn_index", 3, null), a = b(e, "scroll_to_output", 3, !1), l = b(e, "timer", 3, !0), o = b(e, "show_progress", 3, "full"), f = b(e, "message", 3, null), d = b(e, "progress", 3, null), h = b(e, "variant", 3, "default"), y = b(e, "loading_text", 3, "Loading..."), p = b(e, "absolute", 3, !0), T = b(e, "translucent", 3, !1), S = b(e, "border", 3, !1), E = b(e, "validation_error", 7, null), u = b(e, "show_validation_error", 3, !0), v = b(e, "type", 3, null), V = b(e, "used_cache", 3, null), _ = b(e, "cache_duration", 3, null), x = b(e, "avg_time", 3, null), z = b(e, "cache_event_id", 3, null), O, m = !1, U = D(0), F = D(null), C = D(null), xe = D(!1), Ke = D(null), We = D(!1), Y = D(!1), ot = D(null), Ze = D(null), $e = D("from cache"), et = D(!1), ke = null, Ee = null, J = null;
  function ie() {
    ke && clearTimeout(ke), Ee && clearTimeout(Ee), ke = null, Ee = null, w(We, !1), w(Y, !1);
  }
  const W = ae(() => !(u() && E()) && (v() === "input" || !e.status || e.status === "complete" || o() === "hidden" || e.status == "streaming"));
  let ve = D(0);
  const tt = ae(() => i(C) === null || i(C) <= 0 || !i(ve) ? 0 : Math.min(i(ve) / i(C), 1)), se = ae(() => i(ve).toFixed(1));
  let He = ae(() => d() == null), pe = ae(() => r() ?? i(F));
  function ge() {
    sn(() => {
      w(ve, (performance.now() - i(U)) / 1e3), m && ge();
    });
  }
  let we = ae(() => {
    let N = null;
    d() != null ? N = d().map((le) => {
      if (le.index != null && le.length != null)
        return le.index / le.length;
      if (le.progress != null)
        return le.progress;
    }) : N = null;
    let Z, de = "";
    return N ? (Z = N[N.length - 1], Z === 0 ? de = "0" : de = "150ms") : Z = void 0, {
      progress_level: N,
      last_progress_level: Z,
      progress_bar_transition: de
    };
  });
  function St() {
    m || (w(F, w(Ke, null), !0), w(U, performance.now(), !0), m = !0, ge());
  }
  function Pe() {
    w(F, w(Ke, null), !0), m && (m = !1);
  }
  fe(() => {
    e.status === "pending" ? St() : X(() => {
      Pe();
    });
  }), fe(() => {
    O && a() && (e.status === "pending" || e.status === "complete") && ei(O, e.autoscroll);
  }), fe(() => {
    i(pe) != null && i(F) !== i(pe) && (w(C, (performance.now() - i(U)) / 1e3 + i(pe)), w(Ke, i(C).toFixed(1), !0), w(F, i(pe), !0));
  });
  function Oe() {
    w(xe, !1);
  }
  fe(() => {
    X(() => {
      Oe();
    }), e.status === "error" && f() && w(xe, !0);
  }), fe(() => {
    if (e.status === "complete" && v() === "output" && V() && _() != null) {
      const N = z() == null ? null : `${n() ?? s() ?? "unknown"}:${s() ?? "unknown"}:${z()}`;
      if (N === J || N != null && Vr.has(N))
        return;
      J = N, N != null && Vr.add(N), w(ot, _().toFixed(1), !0), w($e, V() === "full" ? "from cache" : "used cache", !0), w(et, x() != null && x() > _() && x() > 0, !0), w(Ze, i(et) ? x().toFixed(1) : null, !0), w(We, !0), w(Y, !1), ke && clearTimeout(ke), Ee && clearTimeout(Ee), ke = setTimeout(
        () => {
          w(Y, !0), Ee = setTimeout(
            () => {
              w(We, !1), w(Y, !1);
            },
            500
          );
        },
        1750
      );
    } else v() === "output" && !V() && ie();
  });
  var zt = fi(), ct = $(zt);
  let Rt, Ge;
  var Ne = H(ct);
  {
    var gt = (N) => {
      var Z = ti(), de = H(Z), le = P(de), be = H(le);
      {
        let Me = ae(() => e.i18n ? e.i18n("common.clear") : "Clear");
        Yt(be, {
          get Icon() {
            return Nr;
          },
          get label() {
            return i(Me);
          },
          disabled: !1,
          size: "x-small",
          background: "var(--background-fill-primary)",
          color: "var(--error-background-text)",
          border: "var(--border-color-primary)",
          onclick: () => E(null)
        });
      }
      j(() => ce(de, `${E() ?? ""} `)), k(N, Z);
    };
    R(Ne, (N) => {
      E() && u() && N(gt);
    });
  }
  var Gt = P(Ne, 2);
  {
    var Xt = (N) => {
      var Z = li(), de = $(Z);
      {
        var le = (B) => {
          var K = ri();
          let Q;
          j(() => Q = Ie(K, "", Q, {
            transform: `translateX(${(i(tt) || 0) * 100 - 100}%)`
          })), k(B, K);
        };
        R(de, (B) => {
          h() === "default" && i(He) && o() === "full" && B(le);
        });
      }
      var be = P(de, 2);
      let Me;
      var c = H(be);
      {
        var g = (B) => {
          var K = Be(), Q = $(K);
          kt(Q, 17, d, xt, (Se, ee) => {
            var re = Be(), Re = $(re);
            {
              var rt = (Fe) => {
                var ze = ni(), nt = $(ze);
                {
                  var bt = (Ae) => {
                    var qe = Ye();
                    j((dt, ut) => ce(qe, `${dt ?? ""}/${ut ?? ""}`), [
                      () => ar(i(ee).index || 0),
                      () => ar(i(ee).length)
                    ]), k(Ae, qe);
                  }, at = (Ae) => {
                    var qe = Ye();
                    j((dt) => ce(qe, dt), [() => ar(i(ee).index || 0)]), k(Ae, qe);
                  };
                  R(nt, (Ae) => {
                    i(ee).length != null ? Ae(bt) : Ae(at, !1);
                  });
                }
                var De = P(nt);
                j(() => ce(De, ` ${i(ee).unit ?? ""} |  `)), k(Fe, ze);
              };
              R(Re, (Fe) => {
                i(ee).index != null && Fe(rt);
              });
            }
            k(Se, re);
          }), k(B, K);
        }, M = (B) => {
          var K = Be(), Q = $(K);
          {
            var Se = (re) => {
              var Re = Ye();
              j(() => ce(Re, `queue: ${e.queue_position + 1}/${e.queue_size ?? ""} |`)), k(re, Re);
            }, ee = (re) => {
              var Re = Be(), rt = $(Re);
              {
                var Fe = (ze) => {
                  var nt = Ye("processing |");
                  k(ze, nt);
                };
                R(
                  rt,
                  (ze) => {
                    e.queue_position === 0 && ze(Fe);
                  },
                  !0
                );
              }
              k(re, Re);
            };
            R(
              Q,
              (re) => {
                e.queue_position !== null && e.queue_size !== void 0 && e.queue_position >= 0 ? re(Se) : re(ee, !1);
              },
              !0
            );
          }
          k(B, K);
        };
        R(c, (B) => {
          d() ? B(g) : B(M, !1);
        });
      }
      var A = P(c, 2);
      {
        var I = (B) => {
          var K = Ye();
          j(() => ce(K, `${i(se) ?? ""}${r() ? `/${i(Ke)}` : ""}s`)), k(B, K);
        };
        R(A, (B) => {
          l() && B(I);
        });
      }
      var te = P(be, 2);
      {
        var me = (B) => {
          var K = ii(), Q = H(K), Se = H(Q);
          {
            var ee = (Fe) => {
              var ze = Be(), nt = $(ze);
              kt(nt, 17, d, xt, (bt, at, De) => {
                var Ae = Be(), qe = $(Ae);
                {
                  var dt = (ut) => {
                    var L = ai(), ne = $(L);
                    {
                      var oe = (G) => {
                        var Ve = Ye(" /");
                        k(G, Ve);
                      };
                      R(ne, (G) => {
                        De !== 0 && G(oe);
                      });
                    }
                    var ue = P(ne, 2);
                    {
                      var Ue = (G) => {
                        var Ve = Ye();
                        j(() => ce(Ve, i(at).desc)), k(G, Ve);
                      };
                      R(ue, (G) => {
                        i(at).desc != null && G(Ue);
                      });
                    }
                    var Xe = P(ue, 2);
                    {
                      var Je = (G) => {
                        var Ve = Ye("-");
                        k(G, Ve);
                      };
                      R(Xe, (G) => {
                        i(at).desc != null && i(we).progress_level && i(we).progress_level[De] != null && G(Je);
                      });
                    }
                    var ht = P(Xe, 2);
                    {
                      var mt = (G) => {
                        var Ve = Ye();
                        j(($t) => ce(Ve, `${$t ?? ""}%`), [
                          () => (100 * (i(we).progress_level[De] || 0)).toFixed(1)
                        ]), k(G, Ve);
                      };
                      R(ht, (G) => {
                        i(we).progress_level != null && G(mt);
                      });
                    }
                    k(ut, L);
                  };
                  R(qe, (ut) => {
                    (i(at).desc != null || i(we).progress_level && i(we).progress_level[De] != null) && ut(dt);
                  });
                }
                k(bt, Ae);
              }), k(Fe, ze);
            };
            R(Se, (Fe) => {
              d() != null && Fe(ee);
            });
          }
          var re = P(Q, 2), Re = H(re);
          let rt;
          j(() => rt = Ie(Re, "", rt, {
            width: `${i(we).last_progress_level * 100}%`,
            transition: i(we).progress_bar_transition
          })), k(B, K);
        }, Te = (B) => {
          var K = Be(), Q = $(K);
          {
            var Se = (ee) => {
              {
                let re = ae(() => h() === "default");
                Qa(ee, {
                  get margin() {
                    return i(re);
                  }
                });
              }
            };
            R(
              Q,
              (ee) => {
                o() === "full" && ee(Se);
              },
              !0
            );
          }
          k(B, K);
        };
        R(te, (B) => {
          i(we).last_progress_level != null ? B(me) : B(Te, !1);
        });
      }
      var ft = P(te, 2);
      {
        var _e = (B) => {
          var K = si(), Q = $(K), Se = H(Q), ee = P(Q, 2);
          cr(ee, e, "additional-loading-text", {}), j(() => ce(Se, y())), k(B, K);
        };
        R(ft, (B) => {
          l() || B(_e);
        });
      }
      j(() => Me = ye(be, 1, "progress-text svelte-1uvc87p", null, Me, {
        "meta-text-center": h() === "center",
        "meta-text": h() === "default"
      })), k(N, Z);
    }, Jt = (N) => {
      var Z = Be(), de = $(Z);
      {
        var le = (be) => {
          var Me = oi(), c = $(Me), g = H(c);
          {
            let te = ae(() => e.i18n("common.clear"));
            Yt(g, {
              get Icon() {
                return Nr;
              },
              get label() {
                return i(te);
              },
              disabled: !1,
              onclick: () => {
                e.on_clear_status?.();
              }
            });
          }
          var M = P(c, 2), A = H(M), I = P(M, 2);
          cr(I, e, "error", {}), j((te) => ce(A, te), [() => e.i18n("common.error")]), k(be, Me);
        };
        R(
          de,
          (be) => {
            e.status === "error" && be(le);
          },
          !0
        );
      }
      k(N, Z);
    };
    R(Gt, (N) => {
      e.status === "pending" ? N(Xt) : N(Jt, !1);
    });
  }
  st(ct, (N) => O = N, () => O);
  var Qt = P(ct, 2);
  {
    var Ft = (N) => {
      var Z = ci();
      let de, le;
      var be = H(Z), Me = P(be);
      {
        var c = (M) => {
          var A = Ye();
          j(() => ce(A, `~${i(Ze) ?? ""}s
			→ `)), k(M, A);
        };
        R(Me, (M) => {
          i(et) && M(c);
        });
      }
      var g = P(Me);
      j(() => {
        de = ye(Z, 1, "cache-indicator svelte-1uvc87p", null, de, { "fade-out": i(Y) }), le = Ie(Z, "", le, { position: p() ? "absolute" : "static" }), ce(be, `⚡ ${i($e) ?? ""}: `), ce(g, `${i(ot) ?? ""}s`);
      }), k(N, Z);
    };
    R(Qt, (N) => {
      i(We) && N(Ft);
    });
  }
  j(() => {
    Rt = ye(ct, 1, `wrap ${h() ?? ""} ${o() ?? ""}`, "svelte-1uvc87p", Rt, {
      "no-click": E() && u(),
      hide: i(W),
      translucent: h() === "center" && (e.status === "pending" || e.status === "error") || T() || o() === "minimal" || E(),
      generating: e.status === "generating" && o() === "full",
      border: S()
    }), Ge = Ie(ct, "", Ge, {
      position: p() ? "absolute" : "static",
      padding: p() ? "0" : "var(--size-8) 0"
    });
  }), k(t, zt), Ot();
}
const ui = (t) => {
  const e = {};
  for (let r = 0, n = t.length; r < n; r++) {
    const s = t[r];
    for (const a in s)
      e[a] ? e[a] = e[a].concat(s[a]) : e[a] = s[a];
  }
  return e;
}, hi = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], vi = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], _i = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
ui([
  Object.fromEntries(hi.map((t) => [t, ["*"]])),
  Object.fromEntries(vi.map((t) => [t, ["svg:*"]])),
  Object.fromEntries(_i.map((t) => [t, ["math:*"]]))
]);
Pt(["touchstart", "touchmove", "touchend", "click", "keydown"]);
function pi(t, e) {
  Nt(e, !0);
  function r(f) {
    return f instanceof HTMLElement && (f.isContentEditable || ["INPUT", "TEXTAREA", "SELECT"].includes(f.tagName));
  }
  function n(f) {
    f.key.toLowerCase() !== "f" || f.repeat || f.defaultPrevented || f.altKey || f.ctrlKey || f.metaKey || r(f.target) && !e.hovered() || (f.preventDefault(), e.onclick(!e.fullscreen));
  }
  var s = Be();
  he("keydown", jt, n);
  var a = $(s);
  {
    var l = (f) => {
      Yt(f, {
        get Icon() {
          return qa;
        },
        get label() {
          return e.exit_label;
        },
        onclick: () => e.onclick(!1)
      });
    }, o = (f) => {
      Yt(f, {
        get Icon() {
          return ja;
        },
        get label() {
          return e.label;
        },
        onclick: () => e.onclick(!0)
      });
    };
    R(a, (f) => {
      e.fullscreen ? f(l) : f(o, !1);
    });
  }
  k(t, s), Ot();
}
const gi = "canvas-host", Br = "canvas-host-request";
class bi extends EventTarget {
  constructor(e, r, n, s, a, l, o) {
    super(), this.id = e, this.doc_el = r, this.frame = n, this.image = s, this.area = a, this.toolbars = l, this.tool_groups = o, this.#e = o.flat()[0] ?? null;
  }
  id;
  doc_el;
  frame;
  image;
  area;
  toolbars;
  tool_groups;
  #e;
  /** ID of the active tool, if any. */
  get tool() {
    return this.#e;
  }
  set tool(e) {
    e !== this.#e && (this.#e = e, this.#t(), this.dispatchEvent(new Event("tool-change")));
  }
  /** Press the button of the active tool, release the others. */
  #t() {
    for (const e of this.toolbars)
      for (const r of e.children)
        r.querySelector("button")?.setAttribute(
          "aria-pressed",
          String(Number(r.dataset.tool) === this.#e)
        );
  }
  /** Add the button of a tool to the toolbar of its group, in tools order. */
  add_tool(e, r) {
    const n = this.tool_groups.findIndex((o) => o.includes(e)), s = this.toolbars[n];
    if (!s) return;
    const a = (o) => this.tool_groups[n].indexOf(Number(o.dataset.tool));
    r.dataset.tool = String(e);
    const l = [...s.children].find((o) => a(o) > a(r));
    s.insertBefore(r, l ?? null), this.#t();
  }
}
var mi = /* @__PURE__ */ Tt('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="9.3 14.3 41.7 37.8"><defs><clipPath id="canvas-photos-clip"><rect x="-16" y="-11" width="32" height="22" rx="0.5"></rect></clipPath><g id="canvas-photos-hills"><circle cx="-14" cy="16" r="12" fill="#56b65b"></circle><circle cx="0" cy="17" r="13" fill="#66c763"></circle><circle cx="15" cy="15" r="14" fill="#7be161"></circle></g></defs><g transform="translate(29 36.5) rotate(9)"><rect x="-17.2" y="-12.2" width="34.4" height="24.4" rx="1" fill="#f2f3fa"></rect><g clip-path="url(#canvas-photos-clip)"><rect x="-16" y="-11" width="32" height="22" fill="#ff9e7a"></rect><circle cx="-11" cy="3" r="3.5" fill="#ffd166"></circle><rect x="-16" y="3" width="32" height="8" fill="#3a8fd9"></rect><g fill="#8cc8ff"><rect x="-14" y="4.5" width="6" height="0.8" rx="0.4"></rect><rect x="-12.5" y="6.2" width="3" height="0.8" rx="0.4"></rect></g><ellipse cx="4" cy="15" rx="18" ry="6.5" fill="#f2d29b"></ellipse></g></g><g transform="translate(31.8 29) rotate(-6)"><rect x="-17.2" y="-12.2" width="34.4" height="24.4" rx="1" fill="#f2f3fa"></rect><g clip-path="url(#canvas-photos-clip)"><rect x="-16" y="-11" width="32" height="22" fill="#52b2ff"></rect><circle cx="-4" cy="-4" r="2.5" fill="#ffcb57"></circle><g fill="#e6e6f6"><circle cx="-15" cy="-1" r="4"></circle><circle cx="-10" cy="0" r="3"></circle><circle cx="10.5" cy="-6.8" r="1.2"></circle><circle cx="12.2" cy="-7.2" r="1.6"></circle><rect x="9.3" y="-6.6" width="6" height="1.6" rx="0.8"></rect></g><use href="#canvas-photos-hills"></use></g></g></svg>');
function wi(t) {
  var e = mi();
  k(t, e);
}
var yi = /* @__PURE__ */ q('<img class="layer svelte-1sbzryu" alt=""/>'), xi = /* @__PURE__ */ q('<div class="zoom-hint svelte-1sbzryu"> </div>'), ki = /* @__PURE__ */ q('<p class="svelte-1sbzryu"> </p>'), Ei = /* @__PURE__ */ q('<div class="placeholder svelte-1sbzryu"><div class="placeholder-art svelte-1sbzryu" aria-hidden="true"><!></div> <!></div>'), Mi = /* @__PURE__ */ q('<img class="layer svelte-1sbzryu" alt="" loading="lazy"/>'), Ti = /* @__PURE__ */ q('<button class="thumb svelte-1sbzryu" role="option"></button>'), Si = /* @__PURE__ */ q('<div class="thumbs-bar svelte-1sbzryu"><button class="thumbs-arrow svelte-1sbzryu" tabindex="-1" aria-label="Previous"><svg viewBox="0 0 16 16" aria-hidden="true" class="svelte-1sbzryu"><path d="M10 4L6 8L10 12"></path></svg></button> <div role="listbox" aria-orientation="horizontal" tabindex="-1"></div> <button class="thumbs-arrow svelte-1sbzryu" tabindex="-1" aria-label="Next"><svg viewBox="0 0 16 16" aria-hidden="true" class="svelte-1sbzryu"><path d="M6 4L10 8L6 12"></path></svg></button></div>'), zi = /* @__PURE__ */ q('<div class="group svelte-1sbzryu"><!></div>'), Ai = /* @__PURE__ */ q('<div class="group toolbar svelte-1sbzryu" role="toolbar"></div>'), Li = /* @__PURE__ */ q('<!> <!> <div role="group"><div><div><img class="layer svelte-1sbzryu" alt=""/> <!></div> <!></div> <!> <!>  <div><!> <!></div></div>', 1);
function Ii(t, e) {
  Nt(e, !0);
  let r = null;
  class n extends Xa {
    // Events wait for dropped images, to pass them.
    async get_data() {
      return r && (await r, await Gr()), super.get_data();
    }
  }
  const s = /* @__PURE__ */ ka(e, ["$$slots", "$$events", "$$legacy"]), a = new n(s), l = ae(() => a.props.value ?? { docs: [], index: null }), o = ae(() => i(l).index === null ? null : i(l).docs[i(l).index] ?? null);
  let f = D(!1), d = D(!1), h = !1, y, p, T, S;
  const E = [];
  let u = D(void 0), v = D(0);
  function V(c) {
    return c.layers[0].object.path;
  }
  function _(c) {
    return { index: c, path: V(i(l).docs[c]) };
  }
  function x(c, g) {
    a.props.value = { docs: c, index: g };
  }
  function z(c) {
    c !== i(l).index && (x(i(l).docs, c), a.dispatch("input"));
  }
  let O = X(() => i(l).docs.map(V)), m = X(() => i(o) && V(i(o)));
  fe(() => {
    const c = i(l).docs.map(V), g = i(o) && V(i(o));
    X(() => U(c, g));
  });
  function U(c, g) {
    g === m && c.join(`
`) === O.join(`
`) || (O.forEach((M, A) => {
      c.includes(M) || a.dispatch("doc_deleted", { index: A, path: M });
    }), c.forEach((M, A) => {
      O.includes(M) || a.dispatch("doc_added", { index: A, path: M });
    }), O.length && !c.length ? a.dispatch("empty") : !O.length && c.length && a.dispatch("filled"), g !== m && i(l).index !== null && a.dispatch("select", _(i(l).index)), O = c, m = g, a.dispatch("change"));
  }
  fe(() => {
    const c = i(l).index === null ? null : i(u)?.children[i(l).index];
    c instanceof HTMLElement && (c.scrollIntoView({ block: "nearest", inline: "nearest", behavior: "smooth" }), i(u)?.contains(document.activeElement) && c.focus({ preventScroll: !0 }));
  });
  let F = D(!1), C = D(!1);
  function xe() {
    if (!i(u)) return;
    const { scrollLeft: c, scrollWidth: g, clientWidth: M } = i(u);
    w(F, c > 1), w(C, c + M < g - 1);
  }
  fe(() => {
    if (!i(u)) return;
    i(l).docs.length, xe();
    const c = new ResizeObserver(xe);
    return c.observe(i(u)), () => c.disconnect();
  });
  function Ke(c) {
    a.dispatch("thumb_click", _(c)), z(c);
  }
  function We(c) {
    const g = i(l).index, M = i(l).docs.length - 1;
    if (g === null || c.altKey || c.ctrlKey || c.metaKey) return;
    const I = {
      ArrowLeft: Math.max(0, g - 1),
      ArrowRight: Math.min(M, g + 1),
      Home: 0,
      End: M
    }[c.key];
    I !== void 0 && (c.preventDefault(), z(I));
  }
  function Y() {
    let c = 0;
    return (g) => {
      const M = g.deltaMode === WheelEvent.DOM_DELTA_PIXEL ? g.deltaY : g.deltaY * 40;
      if (Math.sign(M) !== Math.sign(c) && (c = 0), c += M, Math.abs(c) < 50) return 0;
      const A = Math.sign(c);
      return c = 0, A;
    };
  }
  const ot = Y();
  function Ze(c) {
    if (i(l).index === null || c.ctrlKey || Math.abs(c.deltaY) <= Math.abs(c.deltaX))
      return;
    c.preventDefault();
    const g = ot(c);
    g && $e(g);
  }
  function $e(c) {
    i(l).index !== null && z(Math.min(i(l).docs.length - 1, Math.max(0, i(l).index + c)));
  }
  const et = 2 ** (1 / 3);
  let ke = D(0), Ee = D(0);
  const J = ae(() => [i(ke), i(Ee)]);
  let ie = D(null), W = D(0), ve = D(Ut([0.5, 0.5]));
  const tt = Y();
  function se(c) {
    const g = et ** c, M = i(ke) * g, A = i(Ee) * g;
    if (!i(ie)) return [M, A];
    const I = Math.min(M / i(ie).width, A / i(ie).height);
    return [i(ie).width * I, i(ie).height * I];
  }
  function He(c, g, M) {
    return g <= c ? (c - g) / 2 : Math.min(0, Math.max(c - g, c / 2 - M * g));
  }
  function pe(c, g) {
    const M = se(c);
    return [0, 1].map((A) => {
      const I = i(J)[A];
      return (I / 2 - He(I, M[A], g[A])) / M[A];
    });
  }
  const ge = ae(() => {
    if (!i(ie)) return null;
    const c = se(i(W)), [g, M] = [0, 1].map((A) => He(i(J)[A], c[A], i(ve)[A]));
    return { left: g, top: M, width: c[0], height: c[1] };
  }), we = ae(() => i(W) > 0 && !!i(ie) && se(i(W))[0] * devicePixelRatio >= i(ie).width);
  fe(() => {
    i(o) || w(W, 0);
  });
  function St(c) {
    const g = a.props.max_zoom_levels ?? 0;
    if (!i(o) || g <= 0 || Math.abs(c.deltaY) <= Math.abs(c.deltaX)) return;
    c.preventDefault();
    const M = Math.min(g, Math.max(0, i(W) - tt(c)));
    if (M === i(W)) return;
    const A = p.getBoundingClientRect(), I = [c.clientX - A.left, c.clientY - A.top], te = se(i(W)), me = se(M);
    w(
      ve,
      pe(M, [0, 1].map((Te) => {
        const ft = i(J)[Te];
        return (I[Te] - He(ft, te[Te], i(ve)[Te])) / te[Te] + (ft / 2 - I[Te]) / me[Te];
      })),
      !0
    ), w(W, M, !0);
  }
  function Pe() {
    w(ie, { width: S.naturalWidth, height: S.naturalHeight }, !0);
  }
  let Oe = D(!1);
  fe(() => {
    if (!i(W)) return;
    w(Oe, !0);
    const c = setTimeout(() => w(Oe, !1), 2500);
    return () => {
      clearTimeout(c), w(Oe, !1);
    };
  });
  function zt(c, g, M) {
    const A = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="-3.5 -3.5 31 31" fill="none" stroke-linecap="round" stroke-linejoin="round"><g stroke="white" stroke-width="4">${c}</g><path fill="white" d="${g}"/><g stroke="black" stroke-width="2">${c}</g></svg>`;
    return `url("data:image/svg+xml,${encodeURIComponent(A)}") 12 12, ${M}`;
  }
  const ct = zt('<path d="M18 11V6a2 2 0 0 0-2-2a2 2 0 0 0-2 2"/><path d="M14 10V4a2 2 0 0 0-2-2a2 2 0 0 0-2 2v2"/><path d="M10 10.5V6a2 2 0 0 0-2-2a2 2 0 0 0-2 2v8"/><path d="M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82L7 15"/>', "M6 14V6a2 2 0 0 1 4 0V4a2 2 0 0 1 4 0v2a2 2 0 0 1 4 0v2a2 2 0 0 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82Z", "grab"), Rt = zt('<path d="M18 11.5V9a2 2 0 0 0-2-2a2 2 0 0 0-2 2v1.4"/><path d="M14 10V8a2 2 0 0 0-2-2a2 2 0 0 0-2 2v2"/><path d="M10 9.9V9a2 2 0 0 0-2-2a2 2 0 0 0-2 2v5"/><path d="M6 14a2 2 0 0 0-2-2a2 2 0 0 0-2 2"/><path d="M18 11a2 2 0 1 1 4 0v3a8 8 0 0 1-8 8h-4a8 8 0 0 1-8-8 2 2 0 1 1 4 0"/>', "M2 14a2 2 0 0 1 4 0V9a2 2 0 0 1 4 0V8a2 2 0 0 1 4 0v1a2 2 0 0 1 4 0v2a2 2 0 0 1 4 0v3a8 8 0 0 1-8 8h-4a8 8 0 0 1-8-8Z", "grabbing");
  let Ge = D(!1), Ne = D(null);
  const gt = ae(() => i(Ne) ? Rt : i(Ge) && i(W) ? ct : null);
  function Gt(c) {
    c.code !== "Space" || c.altKey || c.ctrlKey || c.metaKey || !p.matches(":hover") || (c.preventDefault(), w(Ge, !0));
  }
  function Xt(c) {
    c.code !== "Space" || !i(Ge) || (c.preventDefault(), w(Ge, !1));
  }
  function Jt(c) {
    !i(Ge) || !i(W) || c.button !== 0 || !T.contains(c.target) || (c.preventDefault(), c.stopPropagation(), p.setPointerCapture(c.pointerId), w(
      Ne,
      {
        id: c.pointerId,
        client: [c.clientX, c.clientY],
        center: pe(i(W), i(ve))
      },
      !0
    ));
  }
  function Qt(c) {
    if (c.pointerId !== i(Ne)?.id) return;
    const { client: g, center: M } = i(Ne), A = se(i(W)), I = [c.clientX - g[0], c.clientY - g[1]];
    w(ve, pe(i(W), [0, 1].map((te) => M[te] - I[te] / A[te])), !0);
  }
  function Ft(c) {
    c.pointerId === i(Ne)?.id && w(Ne, null);
  }
  function N(c) {
    if (i(gt)) {
      c.preventDefault();
      return;
    }
    const g = c.target;
    !(g instanceof HTMLImageElement) || !c.dataTransfer || (h = !0, c.dataTransfer.setData("text/uri-list", g.currentSrc));
  }
  function Z(c) {
    return a.shared.interactive !== !1 && !h && !!c.dataTransfer?.types.includes("Files");
  }
  function de(c) {
    Z(c) && (c.preventDefault(), c.dataTransfer.dropEffect = "copy", w(d, !0));
  }
  function le(c) {
    y.contains(c.relatedTarget) || w(d, !1);
  }
  function be(c) {
    if (w(d, !1), !Z(c)) return;
    c.preventDefault();
    const g = [...c.dataTransfer.files].filter((M) => M.type.startsWith("image/"));
    g.length && (r = Me(g).finally(() => r = null));
  }
  async function Me(c) {
    let g;
    try {
      g = await a.shared.client.upload(
        c.map((I) => ({
          path: I.name,
          orig_name: I.name,
          blob: I,
          size: I.size,
          mime_type: I.type,
          is_stream: !1,
          meta: { _type: "gradio.FileData" }
        })),
        a.shared.root,
        void 0,
        a.shared.max_file_size ?? void 0
      );
    } catch (I) {
      a.dispatch("error", I instanceof Error ? I.message : String(I));
      return;
    }
    const M = (g ?? []).filter((I) => I !== null).map((I) => ({
      layers: [{ object: I, imported: !0, source_file: null }],
      caption: null
    }));
    if (!M.length) return;
    const A = i(l).docs.length;
    x([...i(l).docs, ...M], A + M.length - 1), M.forEach((I, te) => a.dispatch("doc_dropped", _(A + te))), a.dispatch("input");
  }
  Pa(() => {
    const c = new bi(a.shared.id, T, p, S, y, E, a.props.tools ?? []);
    c.addEventListener("tool-change", () => a.dispatch("tool_selected", { tool: c.tool }));
    const g = (M) => {
      const A = M.detail;
      A.canvas_id === c.id && A.resolve(c);
    };
    return window.addEventListener(Br, g), window.dispatchEvent(new CustomEvent(gi, { detail: c })), () => window.removeEventListener(Br, g);
  }), he("keydown", jt, Gt), he("keyup", jt, Xt), he("blur", jt, () => w(Ge, !1));
  {
    let c = ae(() => a.props.height ?? void 0);
    La(t, {
      get visible() {
        return a.shared.visible;
      },
      variant: "solid",
      padding: !1,
      get elem_id() {
        return a.shared.elem_id;
      },
      get elem_classes() {
        return a.shared.elem_classes;
      },
      get container() {
        return a.shared.container;
      },
      get scale() {
        return a.shared.scale;
      },
      get min_width() {
        return a.shared.min_width;
      },
      allow_overflow: !1,
      get height() {
        return i(c);
      },
      get fullscreen() {
        return i(f);
      },
      set fullscreen(g) {
        w(f, g, !0);
      },
      children: (g, M) => {
        var A = Li(), I = $(A);
        di(I, Ma(
          {
            get autoscroll() {
              return a.shared.autoscroll;
            },
            get i18n() {
              return a.i18n;
            }
          },
          () => a.shared.loading_status,
          {
            on_clear_status: () => a.dispatch("clear_status", a.shared.loading_status)
          }
        ));
        var te = P(I, 2);
        {
          let L = ae(() => a.shared.label || "Canvas");
          Ia(te, {
            get show_label() {
              return a.shared.show_label;
            },
            get Icon() {
              return Va;
            },
            get label() {
              return i(L);
            }
          });
        }
        var me = P(te, 2);
        let Te, ft;
        var _e = H(me);
        let B;
        _e.__pointermove = Qt, _e.__pointerup = Ft;
        let K;
        var Q = H(_e);
        let Se, ee;
        var re = H(Q);
        st(re, (L) => S = L, () => S);
        var Re = P(re, 2);
        kt(Re, 17, () => i(o)?.layers.slice(1) ?? [], xt, (L, ne) => {
          var oe = yi();
          j(() => Ce(oe, "src", i(ne).object.url)), k(L, oe);
        }), st(Q, (L) => T = L, () => T);
        var rt = P(Q, 2);
        {
          var Fe = (L) => {
            var ne = xi(), oe = H(ne);
            j(() => ce(oe, a.props.pan_tooltip)), k(L, ne);
          };
          R(rt, (L) => {
            i(Oe) && a.props.pan_tooltip && L(Fe);
          });
        }
        st(_e, (L) => p = L, () => p);
        var ze = P(_e, 2);
        {
          var nt = (L) => {
            var ne = Ei(), oe = H(ne), ue = H(oe);
            wi(ue);
            var Ue = P(oe, 2);
            {
              var Xe = (Je) => {
                var ht = ki(), mt = H(ht);
                j(() => ce(mt, a.props.placeholder)), k(Je, ht);
              };
              R(Ue, (Je) => {
                a.props.placeholder && Je(Xe);
              });
            }
            k(L, ne);
          };
          R(ze, (L) => {
            i(o) || L(nt);
          });
        }
        var bt = P(ze, 2);
        {
          var at = (L) => {
            var ne = Si(), oe = H(ne);
            oe.__click = () => $e(-1);
            var ue = P(oe, 2);
            let Ue;
            ue.__keydown = We, kt(ue, 21, () => i(l).docs, xt, (Je, ht, mt) => {
              var G = Ti();
              G.__click = () => Ke(mt), kt(G, 21, () => i(ht).layers, xt, (Ve, $t) => {
                var xr = Mi();
                j(() => Ce(xr, "src", i($t).object.url)), k(Ve, xr);
              }), j(() => {
                Ce(G, "aria-selected", mt === i(l).index), Ce(G, "title", i(ht).caption ?? void 0);
              }), k(Je, G);
            }), st(ue, (Je) => w(u, Je), () => i(u));
            var Xe = P(ue, 2);
            Xe.__click = () => $e(1), j(() => {
              oe.disabled = !i(l).index, Ue = ye(ue, 1, "thumbs svelte-1sbzryu", null, Ue, {
                "fade-start": i(F),
                "fade-end": i(C)
              }), Xe.disabled = i(l).index === null || i(l).index === i(l).docs.length - 1;
            }), he("wheel", ne, Ze), he("scroll", ue, xe), k(L, ne);
          };
          R(bt, (L) => {
            i(l).docs.length && L(at);
          });
        }
        var De = P(bt, 2);
        let Ae;
        De.__mousedown = (L) => L.preventDefault();
        var qe = H(De);
        {
          var dt = (L) => {
            var ne = zi(), oe = H(ne);
            pi(oe, {
              get fullscreen() {
                return i(f);
              },
              onclick: (ue) => w(f, ue, !0),
              get label() {
                return a.props.fullscreen_tooltip;
              },
              get exit_label() {
                return a.props.exit_fullscreen_tooltip;
              },
              hovered: () => y.matches(":hover")
            }), k(L, ne);
          };
          R(qe, (L) => {
            a.props.buttons?.includes("fullscreen") && L(dt);
          });
        }
        var ut = P(qe, 2);
        kt(ut, 17, () => a.props.tools ?? [], xt, (L, ne, oe) => {
          var ue = Ai();
          st(ue, (Ue, Xe) => E[Xe] = Ue, (Ue) => E?.[Ue], () => [oe]), k(L, ue);
        }), st(me, (L) => y = L, () => y), j(() => {
          Te = ye(me, 1, "canvas svelte-1sbzryu", null, Te, { "drag-over": i(d), panning: !!i(Ne) }), Ce(me, "aria-label", a.shared.label), ft = Ie(me, "", ft, { cursor: i(Ne) ? i(gt) : void 0 }), B = ye(_e, 1, "frame svelte-1sbzryu", null, B, { hidden: !i(o) }), K = Ie(_e, "", K, {
            "margin-inline": i(v) ? `calc(${i(v)}px + var(--spacing-lg))` : void 0
          }), Se = ye(Q, 1, "doc svelte-1sbzryu", null, Se, { pixelated: i(we), panning: !!i(gt) }), ee = Ie(Q, "", ee, {
            cursor: i(gt),
            left: i(ge) && `${i(ge).left}px`,
            top: i(ge) && `${i(ge).top}px`,
            width: i(ge) && `${i(ge).width}px`,
            height: i(ge) && `${i(ge).height}px`
          }), Ce(re, "src", i(o)?.layers[0].object.url), Ae = ye(De, 1, "buttons svelte-1sbzryu", null, Ae, { "below-label": a.shared.show_label });
        }), he("dragstart", me, N), he("dragend", me, () => h = !1), he("dragover", me, de), he("dragleave", me, le), he("drop", me, be), he("wheel", _e, St), he("pointerdown", _e, Jt, !0), he("pointercancel", _e, Ft), he("load", re, Pe), nr(_e, "clientWidth", (L) => w(ke, L)), nr(_e, "clientHeight", (L) => w(Ee, L)), nr(De, "offsetWidth", (L) => w(v, L)), k(g, A);
      },
      $$slots: { default: !0 }
    });
  }
  Ot();
}
Pt(["pointermove", "pointerup", "click", "keydown", "mousedown"]);
export {
  Ii as default
};
