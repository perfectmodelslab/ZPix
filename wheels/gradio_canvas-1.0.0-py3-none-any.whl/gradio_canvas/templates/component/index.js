import { i as Jt, g as Sr, o as aa, q as Qt, c as Ue, a as $t, b as zt, d as na, T as sa, e as ia, f as Ht, r as er, h as Ge, p as tr, j as Xe, m as la, s as Lr, k as pt, E as It, l, n as cr, t as zr, u as Cr, v as rr, w as oa, x as dr, y as fa, z as ca, A as We, B as De, I as Dt, C as da, D as ua, F as ha, N as va, G as ar, H as Ir, J as Pt, K as _a, L as ga, M as pa, O as ba, P as ma, Q as wa, R as ya, S as xa, U as ka, V as bt, W as Ea, X as Ta, Y as Ma, Z, _ as Aa, $ as nr, a0 as St, a1 as Sa, a2 as ie, a3 as La, a4 as ur, a5 as ve, a6 as Pr, a7 as lt, a8 as za, a9 as A, aa as Ca, ab as Ut, ac as Ia, ad as Pa, ae as Yt, af as Oa, ag as Na, ah as Or, ai as Fa, aj as Ra, ak as Da, al as Ba, am as Nr, an as vt, ao as Va, ap as hr, aq as ja, ar as Q, as as mt, at as wt, au as z, av as Re, aw as B, ax as qa, ay as q, az as ne, aA as ce, aB as Ha, aC as Ua, aD as W, aE as Fr, aF as Ya } from "./render-BuEbLTW8.js";
function Ka(t) {
  throw new Error("https://svelte.dev/e/lifecycle_outside_component");
}
const Wa = [];
function Za(t, e = !1, r = !1) {
  return Lt(t, /* @__PURE__ */ new Map(), "", Wa, null, r);
}
function Lt(t, e, r, a, s = null, n = !1) {
  if (typeof t == "object" && t !== null) {
    var i = e.get(t);
    if (i !== void 0) return i;
    if (t instanceof Map) return (
      /** @type {Snapshot<T>} */
      new Map(t)
    );
    if (t instanceof Set) return (
      /** @type {Snapshot<T>} */
      new Set(t)
    );
    if (Jt(t)) {
      var o = (
        /** @type {Snapshot<any>} */
        Array(t.length)
      );
      e.set(t, o), s !== null && e.set(s, o);
      for (var f = 0; f < t.length; f += 1) {
        var c = t[f];
        f in t && (o[f] = Lt(c, e, r, a, null, n));
      }
      return o;
    }
    if (Sr(t) === aa) {
      o = {}, e.set(t, o), s !== null && e.set(s, o);
      for (var u in t)
        o[u] = Lt(
          // @ts-expect-error
          t[u],
          e,
          r,
          a,
          null,
          n
        );
      return o;
    }
    if (t instanceof Date)
      return (
        /** @type {Snapshot<T>} */
        structuredClone(t)
      );
    if (typeof /** @type {T & { toJSON?: any } } */
    t.toJSON == "function" && !n)
      return Lt(
        /** @type {T & { toJSON(): any } } */
        t.toJSON(),
        e,
        r,
        a,
        // Associate the instance with the toJSON clone
        t
      );
  }
  if (t instanceof EventTarget)
    return (
      /** @type {Snapshot<T>} */
      t
    );
  try {
    return (
      /** @type {Snapshot<T>} */
      structuredClone(t)
    );
  } catch {
    return (
      /** @type {Snapshot<T>} */
      t
    );
  }
}
function Ga(t, e) {
  if (e) {
    const r = document.body;
    t.autofocus = !0, Qt(() => {
      document.activeElement === r && t.focus();
    });
  }
}
function Rr(t) {
  var e = document.createElement("template");
  return e.innerHTML = t.replaceAll("<!>", "<!---->"), e.content;
}
function ot(t, e) {
  var r = (
    /** @type {Effect} */
    $t
  );
  r.nodes === null && (r.nodes = { start: t, end: e, a: null, t: null });
}
// @__NO_SIDE_EFFECTS__
function H(t, e) {
  var r = (e & sa) !== 0, a = (e & ia) !== 0, s, n = !t.startsWith("<!>");
  return () => {
    s === void 0 && (s = Rr(n ? t : "<!>" + t), r || (s = /** @type {TemplateNode} */
    zt(s)));
    var i = (
      /** @type {TemplateNode} */
      a || na ? document.importNode(s, !0) : s.cloneNode(!0)
    );
    if (r) {
      var o = (
        /** @type {TemplateNode} */
        zt(i)
      ), f = (
        /** @type {TemplateNode} */
        i.lastChild
      );
      ot(o, f);
    } else
      ot(i, i);
    return i;
  };
}
// @__NO_SIDE_EFFECTS__
function Xa(t, e, r = "svg") {
  var a = !t.startsWith("<!>"), s = `<${r}>${a ? t : "<!>" + t}</${r}>`, n;
  return () => {
    if (!n) {
      var i = (
        /** @type {DocumentFragment} */
        Rr(s)
      ), o = (
        /** @type {Element} */
        zt(i)
      );
      n = /** @type {Element} */
      zt(o);
    }
    var f = (
      /** @type {TemplateNode} */
      n.cloneNode(!0)
    );
    return ot(f, f), f;
  };
}
// @__NO_SIDE_EFFECTS__
function ft(t, e) {
  return /* @__PURE__ */ Xa(t, e, "svg");
}
function Te(t = "") {
  {
    var e = Ue(t + "");
    return ot(e, e), e;
  }
}
function be() {
  var t = document.createDocumentFragment(), e = document.createComment(""), r = Ue();
  return t.append(e, r), ot(e, r), t;
}
function x(t, e) {
  t !== null && t.before(
    /** @type {Node} */
    e
  );
}
class Ot {
  /** @type {TemplateNode} */
  anchor;
  /** @type {Map<Batch, Key>} */
  #e = /* @__PURE__ */ new Map();
  /**
   * Map of keys to effects that are currently rendered in the DOM.
   * These effects are visible and actively part of the document tree.
   * Example:
   * ```
   * {#if condition}
   * 	foo
   * {:else}
   * 	bar
   * {/if}
   * ```
   * Can result in the entries `true->Effect` and `false->Effect`
   * @type {Map<Key, Effect>}
   */
  #t = /* @__PURE__ */ new Map();
  /**
   * Similar to #onscreen with respect to the keys, but contains branches that are not yet
   * in the DOM, because their insertion is deferred.
   * @type {Map<Key, Branch>}
   */
  #r = /* @__PURE__ */ new Map();
  /**
   * Keys of effects that are currently outroing
   * @type {Set<Key>}
   */
  #a = /* @__PURE__ */ new Set();
  /**
   * Whether to pause (i.e. outro) on change, or destroy immediately.
   * This is necessary for `<svelte:element>`
   */
  #n = !0;
  /**
   * @param {TemplateNode} anchor
   * @param {boolean} transition
   */
  constructor(e, r = !0) {
    this.anchor = e, this.#n = r;
  }
  #s = () => {
    var e = (
      /** @type {Batch} */
      Ht
    );
    if (this.#e.has(e)) {
      var r = (
        /** @type {Key} */
        this.#e.get(e)
      ), a = this.#t.get(r);
      if (a)
        er(a), this.#a.delete(r);
      else {
        var s = this.#r.get(r);
        s && (this.#t.set(r, s.effect), this.#r.delete(r), s.fragment.lastChild.remove(), this.anchor.before(s.fragment), a = s.effect);
      }
      for (const [n, i] of this.#e) {
        if (this.#e.delete(n), n === e)
          break;
        const o = this.#r.get(i);
        o && (Ge(o.effect), this.#r.delete(i));
      }
      for (const [n, i] of this.#t) {
        if (n === r || this.#a.has(n)) continue;
        const o = () => {
          if (Array.from(this.#e.values()).includes(n)) {
            var c = document.createDocumentFragment();
            la(i, c), c.append(Ue()), this.#r.set(n, { effect: i, fragment: c });
          } else
            Ge(i);
          this.#a.delete(n), this.#t.delete(n);
        };
        this.#n || !a ? (this.#a.add(n), tr(i, o, !1)) : o();
      }
    }
  };
  /**
   * @param {Batch} batch
   */
  #i = (e) => {
    this.#e.delete(e);
    const r = Array.from(this.#e.values());
    for (const [a, s] of this.#r)
      r.includes(a) || (Ge(s.effect), this.#r.delete(a));
  };
  /**
   *
   * @param {any} key
   * @param {null | ((target: TemplateNode) => void)} fn
   */
  ensure(e, r) {
    var a = (
      /** @type {Batch} */
      Ht
    ), s = Lr();
    if (r && !this.#t.has(e) && !this.#r.has(e))
      if (s) {
        var n = document.createDocumentFragment(), i = Ue();
        n.append(i), this.#r.set(e, {
          effect: Xe(() => r(i)),
          fragment: n
        });
      } else
        this.#t.set(
          e,
          Xe(() => r(this.anchor))
        );
    if (this.#e.set(a, e), s) {
      for (const [o, f] of this.#t)
        o === e ? a.skipped_effects.delete(f) : a.skipped_effects.add(f);
      for (const [o, f] of this.#r)
        o === e ? a.skipped_effects.delete(f.effect) : a.skipped_effects.add(f.effect);
      a.oncommit(this.#s), a.ondiscard(this.#i);
    } else
      this.#s();
  }
}
function O(t, e, r = !1) {
  var a = new Ot(t), s = r ? It : 0;
  function n(i, o) {
    a.ensure(i, o);
  }
  pt(() => {
    var i = !1;
    e((o, f = !0) => {
      i = !0, n(f, o);
    }), i || n(!1, null);
  }, s);
}
function st(t, e) {
  return e;
}
function Ja(t, e, r) {
  for (var a = [], s = e.length, n, i = e.length, o = 0; o < s; o++) {
    let y = e[o];
    tr(
      y,
      () => {
        if (n) {
          if (n.pending.delete(y), n.done.add(y), n.pending.size === 0) {
            var g = (
              /** @type {Set<EachOutroGroup>} */
              t.outrogroups
            );
            Kt(rr(n.done)), g.delete(n), g.size === 0 && (t.outrogroups = null);
          }
        } else
          i -= 1;
      },
      !1
    );
  }
  if (i === 0) {
    var f = a.length === 0 && r !== null;
    if (f) {
      var c = (
        /** @type {Element} */
        r
      ), u = (
        /** @type {Element} */
        c.parentNode
      );
      ua(u), u.append(c), t.items.clear();
    }
    Kt(e, !f);
  } else
    n = {
      pending: new Set(e),
      done: /* @__PURE__ */ new Set()
    }, (t.outrogroups ??= /* @__PURE__ */ new Set()).add(n);
}
function Kt(t, e = !0) {
  for (var r = 0; r < t.length; r++)
    Ge(t[r], e);
}
var vr;
function it(t, e, r, a, s, n = null) {
  var i = t, o = /* @__PURE__ */ new Map(), f = (e & zr) !== 0;
  if (f) {
    var c = (
      /** @type {Element} */
      t
    );
    i = c.appendChild(Ue());
  }
  var u = null, y = Cr(() => {
    var d = r();
    return Jt(d) ? d : d == null ? [] : rr(d);
  }), g, E = !0;
  function T() {
    h.fallback = u, Qa(h, g, i, e, a), u !== null && (g.length === 0 ? (u.f & De) === 0 ? er(u) : (u.f ^= De, _t(u, null, i)) : tr(u, () => {
      u = null;
    }));
  }
  var b = pt(() => {
    g = /** @type {V[]} */
    l(y);
    for (var d = g.length, V = /* @__PURE__ */ new Set(), _ = (
      /** @type {Batch} */
      Ht
    ), m = Lr(), k = 0; k < d; k += 1) {
      var N = g[k], w = a(N, k), j = E ? null : o.get(w);
      j ? (j.v && cr(j.v, N), j.i && cr(j.i, k), m && _.skipped_effects.delete(j.e)) : (j = $a(
        o,
        E ? i : vr ??= Ue(),
        N,
        w,
        k,
        s,
        e,
        r
      ), E || (j.e.f |= De), o.set(w, j)), V.add(w);
    }
    if (d === 0 && n && !u && (E ? u = Xe(() => n(i)) : (u = Xe(() => n(vr ??= Ue())), u.f |= De)), !E)
      if (m) {
        for (const [F, L] of o)
          V.has(F) || _.skipped_effects.add(L.e);
        _.oncommit(T), _.ondiscard(() => {
        });
      } else
        T();
    l(y);
  }), h = { effect: b, items: o, outrogroups: null, fallback: u };
  E = !1;
}
function Qa(t, e, r, a, s) {
  var n = (a & da) !== 0, i = e.length, o = t.items, f = t.effect.first, c, u = null, y, g = [], E = [], T, b, h, d;
  if (n)
    for (d = 0; d < i; d += 1)
      T = e[d], b = s(T, d), h = /** @type {EachItem} */
      o.get(b).e, (h.f & De) === 0 && (h.nodes?.a?.measure(), (y ??= /* @__PURE__ */ new Set()).add(h));
  for (d = 0; d < i; d += 1) {
    if (T = e[d], b = s(T, d), h = /** @type {EachItem} */
    o.get(b).e, t.outrogroups !== null)
      for (const L of t.outrogroups)
        L.pending.delete(h), L.done.delete(h);
    if ((h.f & De) !== 0)
      if (h.f ^= De, h === f)
        _t(h, null, r);
      else {
        var V = u ? u.next : f;
        h === t.effect.last && (t.effect.last = h.prev), h.prev && (h.prev.next = h.next), h.next && (h.next.prev = h.prev), He(t, u, h), He(t, h, V), _t(h, V, r), u = h, g = [], E = [], f = u.next;
        continue;
      }
    if ((h.f & Dt) !== 0 && (er(h), n && (h.nodes?.a?.unfix(), (y ??= /* @__PURE__ */ new Set()).delete(h))), h !== f) {
      if (c !== void 0 && c.has(h)) {
        if (g.length < E.length) {
          var _ = E[0], m;
          u = _.prev;
          var k = g[0], N = g[g.length - 1];
          for (m = 0; m < g.length; m += 1)
            _t(g[m], _, r);
          for (m = 0; m < E.length; m += 1)
            c.delete(E[m]);
          He(t, k.prev, N.next), He(t, u, k), He(t, N, _), f = _, u = N, d -= 1, g = [], E = [];
        } else
          c.delete(h), _t(h, f, r), He(t, h.prev, h.next), He(t, h, u === null ? t.effect.first : u.next), He(t, u, h), u = h;
        continue;
      }
      for (g = [], E = []; f !== null && f !== h; )
        (c ??= /* @__PURE__ */ new Set()).add(f), E.push(f), f = f.next;
      if (f === null)
        continue;
    }
    (h.f & De) === 0 && g.push(h), u = h, f = h.next;
  }
  if (t.outrogroups !== null) {
    for (const L of t.outrogroups)
      L.pending.size === 0 && (Kt(rr(L.done)), t.outrogroups?.delete(L));
    t.outrogroups.size === 0 && (t.outrogroups = null);
  }
  if (f !== null || c !== void 0) {
    var w = [];
    if (c !== void 0)
      for (h of c)
        (h.f & Dt) === 0 && w.push(h);
    for (; f !== null; )
      (f.f & Dt) === 0 && f !== t.fallback && w.push(f), f = f.next;
    var j = w.length;
    if (j > 0) {
      var F = (a & zr) !== 0 && i === 0 ? r : null;
      if (n) {
        for (d = 0; d < j; d += 1)
          w[d].nodes?.a?.measure();
        for (d = 0; d < j; d += 1)
          w[d].nodes?.a?.fix();
      }
      Ja(t, w, F);
    }
  }
  n && Qt(() => {
    if (y !== void 0)
      for (h of y)
        h.nodes?.a?.apply();
  });
}
function $a(t, e, r, a, s, n, i, o) {
  var f = (i & fa) !== 0 ? (i & ca) === 0 ? We(r, !1, !1) : dr(r) : null, c = (i & oa) !== 0 ? dr(s) : null;
  return {
    v: f,
    i: c,
    e: Xe(() => (n(e, f ?? r, c ?? s, o), () => {
      t.delete(a);
    }))
  };
}
function _t(t, e, r) {
  if (t.nodes)
    for (var a = t.nodes.start, s = t.nodes.end, n = e && (e.f & De) === 0 ? (
      /** @type {EffectNodes} */
      e.nodes.start
    ) : r; a !== null; ) {
      var i = (
        /** @type {TemplateNode} */
        ha(a)
      );
      if (n.before(a), a === s)
        return;
      a = i;
    }
}
function He(t, e, r) {
  e === null ? t.effect.first = r : e.next = r, r === null ? t.effect.last = e : r.prev = e;
}
function Wt(t, e, r, a, s) {
  var n = e.$$slots?.[r], i = !1;
  n === !0 && (n = e[r === "default" ? "children" : r], i = !0), n === void 0 || n(t, i ? () => a : a);
}
function en(t, e, ...r) {
  var a = new Ot(t);
  pt(() => {
    const s = e() ?? null;
    a.ensure(s, s && ((n) => s(n, ...r)));
  }, It);
}
function tn(t, e, r) {
  var a = new Ot(t);
  pt(() => {
    var s = e() ?? null;
    a.ensure(s, s && ((n) => r(n, s)));
  }, It);
}
const rn = () => performance.now(), me = {
  // don't access requestAnimationFrame eagerly outside method
  // this allows basic testing of user code without JSDOM
  // bunder will eval and remove ternary when the user's app is built
  tick: (
    /** @param {any} _ */
    (t) => requestAnimationFrame(t)
  ),
  now: () => rn(),
  tasks: /* @__PURE__ */ new Set()
};
function Dr() {
  const t = me.now();
  me.tasks.forEach((e) => {
    e.c(t) || (me.tasks.delete(e), e.f());
  }), me.tasks.size !== 0 && me.tick(Dr);
}
function an(t) {
  let e;
  return me.tasks.size === 0 && me.tick(Dr), {
    promise: new Promise((r) => {
      me.tasks.add(e = { c: t, f: r });
    }),
    abort() {
      me.tasks.delete(e);
    }
  };
}
function nn(t, e, r, a, s, n) {
  var i = null, o = (
    /** @type {TemplateNode} */
    t
  ), f = new Ot(o, !1);
  pt(() => {
    const c = e() || null;
    var u = c === "svg" ? va : null;
    if (c === null) {
      f.ensure(null, null);
      return;
    }
    return f.ensure(c, (y) => {
      if (c) {
        if (i = u ? document.createElementNS(u, c) : document.createElement(c), ot(i, i), a) {
          var g = i.appendChild(Ue());
          a(i, g);
        }
        $t.nodes.end = i, y.before(i);
      }
    }), () => {
    };
  }, It), ar(() => {
  });
}
function sn(t, e) {
  var r = void 0, a;
  Ir(() => {
    r !== (r = e()) && (a && (Ge(a), a = null), r && (a = Xe(() => {
      Pt(() => (
        /** @type {(node: Element) => void} */
        r(t)
      ));
    })));
  });
}
function Br(t) {
  var e, r, a = "";
  if (typeof t == "string" || typeof t == "number") a += t;
  else if (typeof t == "object") if (Array.isArray(t)) {
    var s = t.length;
    for (e = 0; e < s; e++) t[e] && (r = Br(t[e])) && (a && (a += " "), a += r);
  } else for (r in t) t[r] && (a && (a += " "), a += r);
  return a;
}
function ln() {
  for (var t, e, r = 0, a = "", s = arguments.length; r < s; r++) (t = arguments[r]) && (e = Br(t)) && (a && (a += " "), a += e);
  return a;
}
function on(t) {
  return typeof t == "object" ? ln(t) : t ?? "";
}
const _r = [...` 	
\r\f \v\uFEFF`];
function fn(t, e, r) {
  var a = t == null ? "" : "" + t;
  if (e && (a = a ? a + " " + e : e), r) {
    for (var s in r)
      if (r[s])
        a = a ? a + " " + s : s;
      else if (a.length)
        for (var n = s.length, i = 0; (i = a.indexOf(s, i)) >= 0; ) {
          var o = i + n;
          (i === 0 || _r.includes(a[i - 1])) && (o === a.length || _r.includes(a[o])) ? a = (i === 0 ? "" : a.substring(0, i)) + a.substring(o + 1) : i = o;
        }
  }
  return a === "" ? null : a;
}
function gr(t, e = !1) {
  var r = e ? " !important;" : ";", a = "";
  for (var s in t) {
    var n = t[s];
    n != null && n !== "" && (a += " " + s + ": " + n + r);
  }
  return a;
}
function Bt(t) {
  return t[0] !== "-" || t[1] !== "-" ? t.toLowerCase() : t;
}
function cn(t, e) {
  if (e) {
    var r = "", a, s;
    if (Array.isArray(e) ? (a = e[0], s = e[1]) : a = e, t) {
      t = String(t).replaceAll(/\s*\/\*.*?\*\/\s*/g, "").trim();
      var n = !1, i = 0, o = !1, f = [];
      a && f.push(...Object.keys(a).map(Bt)), s && f.push(...Object.keys(s).map(Bt));
      var c = 0, u = -1;
      const b = t.length;
      for (var y = 0; y < b; y++) {
        var g = t[y];
        if (o ? g === "/" && t[y - 1] === "*" && (o = !1) : n ? n === g && (n = !1) : g === "/" && t[y + 1] === "*" ? o = !0 : g === '"' || g === "'" ? n = g : g === "(" ? i++ : g === ")" && i--, !o && n === !1 && i === 0) {
          if (g === ":" && u === -1)
            u = y;
          else if (g === ";" || y === b - 1) {
            if (u !== -1) {
              var E = Bt(t.substring(c, u).trim());
              if (!f.includes(E)) {
                g !== ";" && y++;
                var T = t.substring(c, y).trim();
                r += " " + T + ";";
              }
            }
            c = y + 1, u = -1;
          }
        }
      }
    }
    return a && (r += gr(a)), s && (r += gr(s, !0)), r = r.trim(), r === "" ? null : r;
  }
  return t == null ? null : String(t);
}
function ge(t, e, r, a, s, n) {
  var i = t.__className;
  if (i !== r || i === void 0) {
    var o = fn(r, a, n);
    o == null ? t.removeAttribute("class") : e ? t.className = o : t.setAttribute("class", o), t.__className = r;
  } else if (n && s !== n)
    for (var f in n) {
      var c = !!n[f];
      (s == null || c !== !!s[f]) && t.classList.toggle(f, c);
    }
  return n;
}
function Vt(t, e = {}, r, a) {
  for (var s in r) {
    var n = r[s];
    e[s] !== n && (r[s] == null ? t.style.removeProperty(s) : t.style.setProperty(s, n, a));
  }
}
function Me(t, e, r, a) {
  var s = t.__style;
  if (s !== e) {
    var n = cn(e, a);
    n == null ? t.removeAttribute("style") : t.style.cssText = n, t.__style = e;
  } else a && (Array.isArray(a) ? (Vt(t, r?.[0], a[0]), Vt(t, r?.[1], a[1], "important")) : Vt(t, r, a));
  return a;
}
function Zt(t, e, r = !1) {
  if (t.multiple) {
    if (e == null)
      return;
    if (!Jt(e))
      return _a();
    for (var a of t.options)
      a.selected = e.includes(pr(a));
    return;
  }
  for (a of t.options) {
    var s = pr(a);
    if (ga(s, e)) {
      a.selected = !0;
      return;
    }
  }
  (!r || e !== void 0) && (t.selectedIndex = -1);
}
function dn(t) {
  var e = new MutationObserver(() => {
    Zt(t, t.__value);
  });
  e.observe(t, {
    // Listen to option element changes
    childList: !0,
    subtree: !0,
    // because of <optgroup>
    // Listen to option element value attribute changes
    // (doesn't get notified of select value changes,
    // because that property is not reflected as an attribute)
    attributes: !0,
    attributeFilter: ["value"]
  }), ar(() => {
    e.disconnect();
  });
}
function pr(t) {
  return "__value" in t ? t.__value : t.value;
}
const gt = /* @__PURE__ */ Symbol("class"), nt = /* @__PURE__ */ Symbol("style"), Vr = /* @__PURE__ */ Symbol("is custom element"), jr = /* @__PURE__ */ Symbol("is html");
function un(t, e) {
  e ? t.hasAttribute("selected") || t.setAttribute("selected", "") : t.removeAttribute("selected");
}
function _e(t, e, r, a) {
  var s = qr(t);
  s[e] !== (s[e] = r) && (e === "loading" && (t[ba] = r), r == null ? t.removeAttribute(e) : typeof r != "string" && Hr(t).includes(e) ? t[e] = r : t.setAttribute(e, r));
}
function hn(t, e, r, a, s = !1, n = !1) {
  var i = qr(t), o = i[Vr], f = !i[jr], c = e || {}, u = t.tagName === "OPTION";
  for (var y in e)
    y in r || (r[y] = null);
  r.class ? r.class = on(r.class) : r.class = null, r[nt] && (r.style ??= null);
  var g = Hr(t);
  for (const _ in r) {
    let m = r[_];
    if (u && _ === "value" && m == null) {
      t.value = t.__value = "", c[_] = m;
      continue;
    }
    if (_ === "class") {
      var E = t.namespaceURI === "http://www.w3.org/1999/xhtml";
      ge(t, E, m, a, e?.[gt], r[gt]), c[_] = m, c[gt] = r[gt];
      continue;
    }
    if (_ === "style") {
      Me(t, m, e?.[nt], r[nt]), c[_] = m, c[nt] = r[nt];
      continue;
    }
    var T = c[_];
    if (!(m === T && !(m === void 0 && t.hasAttribute(_)))) {
      c[_] = m;
      var b = _[0] + _[1];
      if (b !== "$$")
        if (b === "on") {
          const k = {}, N = "$$" + _;
          let w = _.slice(2);
          var h = Ma(w);
          if (xa(w) && (w = w.slice(0, -7), k.capture = !0), !h && T) {
            if (m != null) continue;
            t.removeEventListener(w, c[N], k), c[N] = null;
          }
          if (m != null)
            if (h)
              t[`__${w}`] = m, bt([w]);
            else {
              let j = function(F) {
                c[_].call(this, F);
              };
              c[N] = ka(w, t, j, k);
            }
          else h && (t[`__${w}`] = void 0);
        } else if (_ === "style")
          _e(t, _, m);
        else if (_ === "autofocus")
          Ga(
            /** @type {HTMLElement} */
            t,
            !!m
          );
        else if (!o && (_ === "__value" || _ === "value" && m != null))
          t.value = t.__value = m;
        else if (_ === "selected" && u)
          un(
            /** @type {HTMLOptionElement} */
            t,
            m
          );
        else {
          var d = _;
          f || (d = Ea(d));
          var V = d === "defaultValue" || d === "defaultChecked";
          if (m == null && !o && !V)
            if (i[_] = null, d === "value" || d === "checked") {
              let k = (
                /** @type {HTMLInputElement} */
                t
              );
              const N = e === void 0;
              if (d === "value") {
                let w = k.defaultValue;
                k.removeAttribute(d), k.defaultValue = w, k.value = k.__value = N ? w : null;
              } else {
                let w = k.defaultChecked;
                k.removeAttribute(d), k.defaultChecked = w, k.checked = N ? w : !1;
              }
            } else
              t.removeAttribute(_);
          else V || g.includes(d) && (o || typeof m != "string") ? (t[d] = m, d in i && (i[d] = Ta)) : typeof m != "function" && _e(t, d, m);
        }
    }
  }
  return c;
}
function vn(t, e, r = [], a = [], s = [], n, i = !1, o = !1) {
  wa(s, r, a, (f) => {
    var c = void 0, u = {}, y = t.nodeName === "SELECT", g = !1;
    if (Ir(() => {
      var T = e(...f.map(l)), b = hn(
        t,
        c,
        T,
        n,
        i,
        o
      );
      g && y && "value" in T && Zt(
        /** @type {HTMLSelectElement} */
        t,
        T.value
      );
      for (let d of Object.getOwnPropertySymbols(u))
        T[d] || Ge(u[d]);
      for (let d of Object.getOwnPropertySymbols(T)) {
        var h = T[d];
        d.description === ya && (!c || h !== c[d]) && (u[d] && Ge(u[d]), u[d] = Xe(() => sn(t, () => h))), b[d] = h;
      }
      c = b;
    }), y) {
      var E = (
        /** @type {HTMLSelectElement} */
        t
      );
      Pt(() => {
        Zt(
          E,
          /** @type {Record<string | symbol, any>} */
          c.value,
          !0
        ), dn(E);
      });
    }
    g = !0;
  });
}
function qr(t) {
  return (
    /** @type {Record<string | symbol, unknown>} **/
    // @ts-expect-error
    t.__attributes ??= {
      [Vr]: t.nodeName.includes("-"),
      [jr]: t.namespaceURI === pa
    }
  );
}
var br = /* @__PURE__ */ new Map();
function Hr(t) {
  var e = t.getAttribute("is") || t.nodeName, r = br.get(e);
  if (r) return r;
  br.set(e, r = []);
  for (var a, s = t, n = Element.prototype; n !== s; ) {
    a = ma(s);
    for (var i in a)
      a[i].set && r.push(i);
    s = Sr(s);
  }
  return r;
}
class sr {
  /** */
  #e = /* @__PURE__ */ new WeakMap();
  /** @type {ResizeObserver | undefined} */
  #t;
  /** @type {ResizeObserverOptions} */
  #r;
  /** @static */
  static entries = /* @__PURE__ */ new WeakMap();
  /** @param {ResizeObserverOptions} options */
  constructor(e) {
    this.#r = e;
  }
  /**
   * @param {Element} element
   * @param {(entry: ResizeObserverEntry) => any} listener
   */
  observe(e, r) {
    var a = this.#e.get(e) || /* @__PURE__ */ new Set();
    return a.add(r), this.#e.set(e, a), this.#a().observe(e, this.#r), () => {
      var s = this.#e.get(e);
      s.delete(r), s.size === 0 && (this.#e.delete(e), this.#t.unobserve(e));
    };
  }
  #a() {
    return this.#t ?? (this.#t = new ResizeObserver(
      /** @param {any} entries */
      (e) => {
        for (var r of e) {
          sr.entries.set(r.target, r);
          for (var a of this.#e.get(r.target) || [])
            a(r);
        }
      }
    ));
  }
}
var _n = /* @__PURE__ */ new sr({
  box: "border-box"
});
function gn(t, e, r) {
  var a = _n.observe(t, () => r(t[e]));
  Pt(() => (Z(() => r(t[e])), a));
}
function mr(t, e) {
  return t === e || t?.[nr] === e;
}
function Ze(t = {}, e, r, a) {
  return Pt(() => {
    var s, n;
    return Aa(() => {
      s = n, n = a?.() || [], Z(() => {
        t !== r(...n) && (e(t, ...n), s && mr(r(...s), t) && e(null, ...s));
      });
    }), () => {
      Qt(() => {
        n && mr(r(...n), t) && e(null, ...n);
      });
    };
  }), t;
}
function pn(t = !1) {
  const e = (
    /** @type {ComponentContextLegacy} */
    St
  ), r = e.l.u;
  if (!r) return;
  let a = () => ve(e.s);
  if (t) {
    let s = 0, n = (
      /** @type {Record<string, any>} */
      {}
    );
    const i = Pr(() => {
      let o = !1;
      const f = e.s;
      for (const c in f)
        f[c] !== n[c] && (n[c] = f[c], o = !0);
      return o && s++, s;
    });
    a = () => l(i);
  }
  r.b.length && Sa(() => {
    wr(e, a), ur(r.b);
  }), ie(() => {
    const s = Z(() => r.m.map(La));
    return () => {
      for (const n of s)
        typeof n == "function" && n();
    };
  }), r.a.length && ie(() => {
    wr(e, a), ur(r.a);
  });
}
function wr(t, e) {
  if (t.l.s)
    for (const r of t.l.s) l(r);
  e();
}
function Ur(t, e, r) {
  if (t == null)
    return e(void 0), lt;
  const a = Z(
    () => t.subscribe(
      e,
      // @ts-expect-error
      r
    )
  );
  return a.unsubscribe ? () => a.unsubscribe() : a;
}
const at = [];
function bn(t, e = lt) {
  let r = null;
  const a = /* @__PURE__ */ new Set();
  function s(o) {
    if (za(t, o) && (t = o, r)) {
      const f = !at.length;
      for (const c of a)
        c[1](), at.push(c, t);
      if (f) {
        for (let c = 0; c < at.length; c += 2)
          at[c][0](at[c + 1]);
        at.length = 0;
      }
    }
  }
  function n(o) {
    s(o(
      /** @type {T} */
      t
    ));
  }
  function i(o, f = lt) {
    const c = [o, f];
    return a.add(c), a.size === 1 && (r = e(s, n) || lt), o(
      /** @type {T} */
      t
    ), () => {
      a.delete(c), a.size === 0 && r && (r(), r = null);
    };
  }
  return { set: s, update: n, subscribe: i };
}
function Yr(t) {
  let e;
  return Ur(t, (r) => e = r)(), e;
}
let Mt = !1, Gt = /* @__PURE__ */ Symbol();
function yr(t, e, r) {
  const a = r[e] ??= {
    store: null,
    source: We(void 0),
    unsubscribe: lt
  };
  if (a.store !== t && !(Gt in r))
    if (a.unsubscribe(), a.store = t ?? null, t == null)
      a.source.v = void 0, a.unsubscribe = lt;
    else {
      var s = !0;
      a.unsubscribe = Ur(t, (n) => {
        s ? a.source.v = n : A(a.source, n);
      }), s = !1;
    }
  return t && Gt in r ? Yr(t) : l(a.source);
}
function mn() {
  const t = {};
  function e() {
    ar(() => {
      for (var r in t)
        t[r].unsubscribe();
      Ca(t, Gt, {
        enumerable: !1,
        value: !0
      });
    });
  }
  return [t, e];
}
function wn(t) {
  var e = Mt;
  try {
    return Mt = !1, [t(), Mt];
  } finally {
    Mt = e;
  }
}
const yn = {
  get(t, e) {
    if (!t.exclude.includes(e))
      return t.props[e];
  },
  set(t, e) {
    return !1;
  },
  getOwnPropertyDescriptor(t, e) {
    if (!t.exclude.includes(e) && e in t.props)
      return {
        enumerable: !0,
        configurable: !0,
        value: t.props[e]
      };
  },
  has(t, e) {
    return t.exclude.includes(e) ? !1 : e in t.props;
  },
  ownKeys(t) {
    return Reflect.ownKeys(t.props).filter((e) => !t.exclude.includes(e));
  }
};
// @__NO_SIDE_EFFECTS__
function xn(t, e, r) {
  return new Proxy(
    { props: t, exclude: e },
    yn
  );
}
const kn = {
  get(t, e) {
    let r = t.props.length;
    for (; r--; ) {
      let a = t.props[r];
      if (vt(a) && (a = a()), typeof a == "object" && a !== null && e in a) return a[e];
    }
  },
  set(t, e, r) {
    let a = t.props.length;
    for (; a--; ) {
      let s = t.props[a];
      vt(s) && (s = s());
      const n = Ut(s, e);
      if (n && n.set)
        return n.set(r), !0;
    }
    return !1;
  },
  getOwnPropertyDescriptor(t, e) {
    let r = t.props.length;
    for (; r--; ) {
      let a = t.props[r];
      if (vt(a) && (a = a()), typeof a == "object" && a !== null && e in a) {
        const s = Ut(a, e);
        return s && !s.configurable && (s.configurable = !0), s;
      }
    }
  },
  has(t, e) {
    if (e === nr || e === Nr) return !1;
    for (let r of t.props)
      if (vt(r) && (r = r()), r != null && e in r) return !0;
    return !1;
  },
  ownKeys(t) {
    const e = [];
    for (let r of t.props)
      if (vt(r) && (r = r()), !!r) {
        for (const a in r)
          e.includes(a) || e.push(a);
        for (const a of Object.getOwnPropertySymbols(r))
          e.includes(a) || e.push(a);
      }
    return e;
  }
};
function En(...t) {
  return new Proxy({ props: t }, kn);
}
function p(t, e, r, a) {
  var s = !Or || (r & Fa) !== 0, n = (r & Na) !== 0, i = (r & Da) !== 0, o = (
    /** @type {V} */
    a
  ), f = !0, c = () => (f && (f = !1, o = i ? Z(
    /** @type {() => V} */
    a
  ) : (
    /** @type {V} */
    a
  )), o), u;
  if (n) {
    var y = nr in t || Nr in t;
    u = Ut(t, e)?.set ?? (y && e in t ? (_) => t[e] = _ : void 0);
  }
  var g, E = !1;
  n ? [g, E] = wn(() => (
    /** @type {V} */
    t[e]
  )) : g = /** @type {V} */
  t[e], g === void 0 && a !== void 0 && (g = c(), u && (s && Ia(), u(g)));
  var T;
  if (s ? T = () => {
    var _ = (
      /** @type {V} */
      t[e]
    );
    return _ === void 0 ? c() : (f = !0, _);
  } : T = () => {
    var _ = (
      /** @type {V} */
      t[e]
    );
    return _ !== void 0 && (o = /** @type {V} */
    void 0), _ === void 0 ? o : _;
  }, s && (r & Pa) === 0)
    return T;
  if (u) {
    var b = t.$$legacy;
    return (
      /** @type {() => V} */
      (function(_, m) {
        return arguments.length > 0 ? ((!s || !m || b || E) && u(m ? T() : _), _) : T();
      })
    );
  }
  var h = !1, d = ((r & Ra) !== 0 ? Pr : Cr)(() => (h = !1, T()));
  n && l(d);
  var V = (
    /** @type {Effect} */
    $t
  );
  return (
    /** @type {() => V} */
    (function(_, m) {
      if (arguments.length > 0) {
        const k = m ? l(d) : s && n ? Yt(_) : _;
        return A(d, k), h = !0, o !== void 0 && (o = k), _;
      }
      return Ba && h || (V.f & Oa) !== 0 ? d.v : l(d);
    })
  );
}
Va();
var Tn = /* @__PURE__ */ ft('<svg class="resize-handle svelte-1brspkc" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 10 10"><line x1="1" y1="9" x2="9" y2="1" stroke="gray" stroke-width="0.5" class="svelte-1brspkc"></line><line x1="5" y1="9" x2="9" y2="5" stroke="gray" stroke-width="0.5" class="svelte-1brspkc"></line></svg>'), Mn = /* @__PURE__ */ H("<!> <!>", 1), An = /* @__PURE__ */ H('<div class="placeholder svelte-1brspkc"></div>'), Sn = /* @__PURE__ */ H("<!> <!>", 1);
function Ln(t, e) {
  wt(e, !1);
  let r = p(e, "height", 8, void 0), a = p(e, "min_height", 8, void 0), s = p(e, "max_height", 8, void 0), n = p(e, "width", 8, void 0), i = p(e, "elem_id", 8, ""), o = p(e, "elem_classes", 24, () => []), f = p(e, "variant", 8, "solid"), c = p(e, "border_mode", 8, "base"), u = p(e, "padding", 8, !0), y = p(e, "type", 8, "normal"), g = p(e, "test_id", 8, void 0), E = p(e, "explicit_call", 8, !1), T = p(e, "container", 8, !0), b = p(e, "visible", 8, !0), h = p(e, "allow_overflow", 8, !0), d = p(e, "overflow_behavior", 8, "auto"), V = p(e, "scale", 8, null), _ = p(e, "min_width", 8, 0), m = p(e, "flex", 12, !1), k = p(e, "resizable", 8, !1), N = p(e, "rtl", 8, !1), w = p(e, "fullscreen", 12, !1), j = p(e, "label", 8, void 0), F = We(w()), L = We(), we = y() === "fieldset" ? "fieldset" : "div", Ae = We(0), le = We(0), K = We(null);
  function Se(ee) {
    w() && ee.key === "Escape" && w(!1);
  }
  const Le = (ee) => {
    if (ee !== void 0) {
      if (typeof ee == "number")
        return ee + "px";
      if (typeof ee == "string")
        return ee;
    }
  }, Ye = (ee) => {
    let v = ee.clientY;
    const S = (G) => {
      const P = G.clientY - v;
      v = G.clientY, qa(L, l(L).style.height = `${l(L).offsetHeight + P}px`);
    }, C = () => {
      window.removeEventListener("mousemove", S), window.removeEventListener("mouseup", C);
    };
    window.addEventListener("mousemove", S), window.addEventListener("mouseup", C);
  };
  hr(
    () => (ve(w()), l(F), l(L)),
    () => {
      w() !== l(F) && (A(F, w()), w() ? (A(K, l(L).getBoundingClientRect()), A(Ae, l(L).offsetHeight), A(le, l(L).offsetWidth), window.addEventListener("keydown", Se)) : (A(K, null), window.removeEventListener("keydown", Se)));
    }
  ), hr(() => ve(b()), () => {
    b() || m(!1);
  }), ja(), pn();
  var Be = be(), ye = Q(Be);
  {
    var xe = (ee) => {
      var v = Sn(), S = Q(v);
      nn(S, () => we, !1, (P, pe) => {
        Ze(P, (he) => A(L, he), () => l(L)), vn(
          P,
          (he, ke) => ({
            "data-testid": g(),
            id: i(),
            class: `block ${he ?? ""}`,
            dir: N() ? "rtl" : "ltr",
            "aria-label": j(),
            style: "",
            [gt]: {
              hidden: b() === "hidden",
              padded: u(),
              flex: m(),
              border_focus: c() === "focus",
              border_contrast: c() === "contrast",
              "hide-container": !E() && !T(),
              fullscreen: w(),
              animating: w() && l(K) !== null,
              "auto-margin": V() === null
            },
            [nt]: ke
          }),
          [
            () => (ve(o()), Z(() => o()?.join(" ") || "")),
            () => ({
              height: (ve(w()), ve(r()), Z(() => w() ? void 0 : Le(r()))),
              "min-height": (ve(w()), ve(a()), Z(() => w() ? void 0 : Le(a()))),
              "max-height": (ve(w()), ve(s()), Z(() => w() ? void 0 : Le(s()))),
              "--start-top": (l(K), Z(() => l(K) ? `${l(K).top}px` : "0px")),
              "--start-left": (l(K), Z(() => l(K) ? `${l(K).left}px` : "0px")),
              "--start-width": (l(K), Z(() => l(K) ? `${l(K).width}px` : "0px")),
              "--start-height": (l(K), Z(() => l(K) ? `${l(K).height}px` : "0px")),
              width: (ve(w()), ve(n()), Z(() => w() ? void 0 : typeof n() == "number" ? `calc(min(${n()}px, 100%))` : Le(n()))),
              "border-style": f(),
              overflow: h() ? d() : "hidden",
              "flex-grow": V(),
              "min-width": `calc(min(${_()}px, 100%))`
            })
          ],
          void 0,
          void 0,
          "svelte-1brspkc"
        );
        var X = Mn(), Ve = Q(X);
        Wt(Ve, e, "default", {});
        var re = z(Ve, 2);
        {
          var Je = (he) => {
            var ke = Tn();
            Re("mousedown", ke, Ye), x(he, ke);
          };
          O(re, (he) => {
            k() && he(Je);
          });
        }
        x(pe, X);
      });
      var C = z(S, 2);
      {
        var G = (P) => {
          var pe = An();
          let X;
          B(() => X = Me(pe, "", X, {
            height: l(Ae) + "px",
            width: l(le) + "px"
          })), x(P, pe);
        };
        O(C, (P) => {
          w() && P(G);
        });
      }
      x(ee, v);
    };
    O(ye, (ee) => {
      (b() === !0 || b() === "hidden") && ee(xe);
    });
  }
  x(t, Be), mt();
}
var zn = /* @__PURE__ */ H('<label for="" data-testid="block-label"><span class="svelte-29fz3m"><!></span> </label>');
function Cn(t, e) {
  let r = p(e, "label", 8, null), a = p(e, "Icon", 8), s = p(e, "show_label", 8, !0), n = p(e, "disable", 8, !1), i = p(e, "float", 8, !0), o = p(e, "rtl", 8, !1);
  var f = zn();
  let c;
  var u = q(f), y = q(u);
  a()(y, {});
  var g = z(u);
  B(() => {
    _e(f, "dir", o() ? "rtl" : "ltr"), c = ge(f, 1, "svelte-29fz3m", null, c, {
      hide: !s(),
      "sr-only": !s(),
      float: i(),
      "hide-label": n()
    }), ne(g, ` ${r() ?? ""}`), f.dir = f.dir;
  }), x(t, f);
}
function In(t) {
  St === null && Ka(), Or && St.l !== null ? Pn(St).m.push(t) : ie(() => {
    const e = Z(t);
    if (typeof e == "function") return (
      /** @type {() => void} */
      e
    );
  });
}
function Pn(t) {
  var e = (
    /** @type {ComponentContextLegacy} */
    t.l
  );
  return e.u ??= { a: [], b: [], m: [] };
}
var On = /* @__PURE__ */ H('<span class="svelte-y5xc0a"> </span>'), Nn = /* @__PURE__ */ H("<button><!> <div><!> <!></div></button>");
function Ct(t, e) {
  let r = p(e, "label", 3, ""), a = p(e, "show_label", 3, !1), s = p(e, "pending", 3, !1), n = p(e, "size", 3, "small"), i = p(e, "padded", 3, !0), o = p(e, "highlight", 3, !1), f = p(e, "disabled", 3, !1), c = p(e, "hasPopup", 3, !1), u = p(e, "color", 3, "var(--block-label-text-color)"), y = p(e, "transparent", 3, !1), g = p(e, "background", 3, "var(--block-background-fill)"), E = p(e, "border", 3, "transparent"), T = ce(() => o() ? "var(--color-accent)" : u());
  var b = Nn();
  let h;
  b.__click = function(...F) {
    e.onclick?.apply(this, F);
  };
  let d;
  var V = q(b);
  {
    var _ = (F) => {
      var L = On(), we = q(L);
      B(() => ne(we, r())), x(F, L);
    };
    O(V, (F) => {
      a() && F(_);
    });
  }
  var m = z(V, 2);
  let k;
  var N = q(m);
  tn(N, () => e.Icon, (F, L) => {
    L(F, {});
  });
  var w = z(N, 2);
  {
    var j = (F) => {
      var L = be(), we = Q(L);
      en(we, () => e.children), x(F, L);
    };
    O(w, (F) => {
      e.children && F(j);
    });
  }
  B(() => {
    h = ge(b, 1, "icon-button svelte-y5xc0a", null, h, {
      pending: s(),
      padded: i(),
      highlight: o(),
      transparent: y()
    }), b.disabled = f(), _e(b, "aria-label", r()), _e(b, "aria-haspopup", c()), _e(b, "title", r()), d = Me(b, "", d, {
      "--border-color": E(),
      color: !f() && l(T) ? l(T) : "var(--block-label-text-color)",
      "--bg-color": f() ? "auto" : g()
    }), k = ge(m, 1, "svelte-y5xc0a", null, k, {
      "x-small": n() === "x-small",
      small: n() === "small",
      large: n() === "large",
      medium: n() === "medium"
    });
  }), x(t, b);
}
bt(["click"]);
var Fn = /* @__PURE__ */ ft('<svg width="100%" height="100%" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" stroke="currentColor" style="fill-rule:evenodd;clip-rule:evenodd;stroke-linecap:round;stroke-linejoin:round;"><g transform="matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"><path d="M18,6L6.087,17.913" style="fill:none;fill-rule:nonzero;stroke-width:2px;"></path></g><path d="M4.364,4.364L19.636,19.636" style="fill:none;fill-rule:nonzero;stroke-width:2px;"></path></svg>');
function xr(t) {
  var e = Fn();
  x(t, e);
}
var Rn = /* @__PURE__ */ ft('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-image"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline></svg>');
function Dn(t) {
  var e = Rn();
  x(t, e);
}
var Bn = /* @__PURE__ */ ft('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-maximize" width="100%" height="100%"><path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"></path></svg>');
function Vn(t) {
  var e = Bn();
  x(t, e);
}
var jn = /* @__PURE__ */ ft('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-minimize" width="100%" height="100%"><path d="M8 3v3a2 2 0 0 1-2 2H3m18 0h-3a2 2 0 0 1-2-2V3m0 18v-3a2 2 0 0 1 2-2h3M3 16h3a2 2 0 0 1 2 2v3"></path></svg>');
function qn(t) {
  var e = jn();
  x(t, e);
}
const Hn = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], kr = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
Hn.reduce((t, { color: e, primary: r, secondary: a }) => ({
  ...t,
  [e]: {
    primary: kr[e][r],
    secondary: kr[e][a]
  }
}), {});
function Un(t) {
  let e;
  const r = Ua((s) => {
    let n = !1;
    const i = t.subscribe((o) => {
      e = o, n && s();
    });
    return n = !0, i;
  });
  function a() {
    return Ha() ? (r(), e) : Yr(t);
  }
  return "set" in t ? {
    get current() {
      return a();
    },
    set current(s) {
      t.set(s);
    }
  } : {
    get current() {
      return a();
    }
  };
}
const Yn = "__i18n__", Kn = [
  "label",
  "info",
  "placeholder",
  "description",
  "title",
  "value"
], Wn = [
  "elem_id",
  "elem_classes",
  "visible",
  "interactive",
  "server_fns",
  "server",
  "id",
  "target",
  "theme_mode",
  "version",
  "root",
  "autoscroll",
  "max_file_size",
  "formatter",
  "client",
  "load_component",
  "scale",
  "min_width",
  "theme",
  "padding",
  "loading_status",
  "label",
  "show_label",
  "validation_error",
  "show_progress",
  "api_prefix",
  "container",
  "attached_events",
  "register_component",
  "dispatcher"
];
function Zn(t) {
  return typeof t == "string" && t.includes(Yn);
}
class Gn {
  load_component;
  #e = W(Yt({}));
  get shared() {
    return l(this.#e);
  }
  set shared(e) {
    A(this.#e, e, !0);
  }
  #t = W(Yt({}));
  get props() {
    return l(this.#t);
  }
  set props(e) {
    A(this.#t, e, !0);
  }
  #r = W((e) => e);
  get i18n() {
    return l(this.#r);
  }
  set i18n(e) {
    A(this.#r, e, !0);
  }
  i18n_store;
  _i18n_from_store;
  translatable_props = {};
  dispatcher;
  last_update = null;
  shared_props = Wn;
  mounted = !1;
  old_value;
  register_component;
  constructor(e, r) {
    for (const a in e.shared_props)
      this.shared[a] = e.shared_props[a];
    for (const a in e.props)
      a !== "i18n_store" && (this.props[a] = e.props[a]);
    if (r)
      for (const a in r)
        this.props[a] === void 0 && (this.props[a] = r[a]);
    this.i18n = this.props.i18n ?? ((a) => a), this.i18n_store = e.props.i18n_store, this._i18n_from_store = this.i18n_store ? Un(this.i18n_store) : void 0;
    for (const a of Kn)
      this.shared[a] = this._translate_and_store(
        "shared",
        a,
        // @ts-ignore
        e.shared_props[a]
      ), this.props[a] = this._translate_and_store(
        "props",
        a,
        // @ts-ignore
        e.props[a]
      );
    this.load_component = this.shared.load_component, this.register_component = this.shared.register_component || (() => {
    }), this.dispatcher = this.shared.dispatcher || (() => {
    }), this.register_component(
      e.shared_props.id,
      // @ts-ignore
      this.set_data.bind(this),
      this.get_data.bind(this)
    ), ie(() => {
      for (const a in e.shared_props)
        this._is_i18n_managed(`shared.${a}`, e.shared_props[a]) || (this.shared[a] = e.shared_props[a]);
      for (const a in e.props)
        a !== "i18n_store" && (this._is_i18n_managed(`props.${a}`, e.props[a]) || (this.props[a] = e.props[a]));
      this.register_component(
        e.shared_props.id,
        // @ts-ignore
        this.set_data.bind(this),
        this.get_data.bind(this)
      ), Z(() => {
        this.shared.id = e.shared_props.id;
      });
    }), ie(() => this.i18n_store ? this.i18n_store.subscribe(() => {
      for (const [s, n] of Object.entries(this.translatable_props)) {
        const [i, o] = s.split("."), f = this.i18n(n);
        i === "shared" ? this.shared[o] = f : this.props[o] = f;
      }
    }) : void 0);
  }
  // check if props are translatable
  _is_i18n_managed(e, r) {
    const a = this.translatable_props[e];
    return a ? r === a ? !0 : (delete this.translatable_props[e], !1) : !1;
  }
  _translate_and_store(e, r, a) {
    if (typeof a != "string") return a;
    const s = this.i18n(a);
    return s !== a && (this.translatable_props[`${e}.${r}`] = a), s;
  }
  // Reactive variant of `i18n`. Reading it inside a derived or template
  // subscribes to the live locale store (via Svelte's createSubscriber), so
  // the caller re-runs when the locale changes at runtime. The store is only
  // the reactivity trigger; translation always goes through `this.i18n` so a
  // custom formatter passed via props keeps taking effect.
  live_i18n = (e) => (this._i18n_from_store?.current, this.i18n(e));
  dispatch(e, r) {
    this.dispatcher(this.shared.id, e, r);
  }
  async get_data() {
    return Za(this.props);
  }
  update(e) {
    this.set_data(e);
  }
  set_data(e) {
    for (const r in e) {
      const a = e[r], s = Zn(a) ? this._translate_and_store(this.shared_props.includes(r) ? "shared" : "props", r, a) : a;
      if (this.shared_props.includes(r)) {
        const n = r;
        this.shared[n] = s;
        continue;
      }
      this.props[r] = s;
    }
  }
  watch_for_change() {
    ie(() => {
      this.mounted || (this.old_value = this.props.value, this.mounted = !0), this.old_value != this.props.value && (this.old_value = this.props.value, this.dispatch("change"));
    });
  }
}
bt(["click"]);
function jt(t) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], r = 0;
  for (; t > 1e3 && r < e.length - 1; )
    t /= 1e3, r++;
  let a = e[r];
  return (Number.isInteger(t) ? t : t.toFixed(1)) + a;
}
function Er(t) {
  return Object.prototype.toString.call(t) === "[object Date]";
}
function Xt(t, e, r, a) {
  if (typeof r == "number" || Er(r)) {
    const s = a - r, n = (r - e) / (t.dt || 1 / 60), i = t.opts.stiffness * s, o = t.opts.damping * n, f = (i - o) * t.inv_mass, c = (n + f) * t.dt;
    return Math.abs(c) < t.opts.precision && Math.abs(s) < t.opts.precision ? a : (t.settled = !1, Er(r) ? new Date(r.getTime() + c) : r + c);
  } else {
    if (Array.isArray(r))
      return r.map(
        (s, n) => (
          // @ts-ignore
          Xt(t, e[n], r[n], a[n])
        )
      );
    if (typeof r == "object") {
      const s = {};
      for (const n in r)
        s[n] = Xt(t, e[n], r[n], a[n]);
      return s;
    } else
      throw new Error(`Cannot spring ${typeof r} values`);
  }
}
function Tr(t, e = {}) {
  const r = bn(t), { stiffness: a = 0.15, damping: s = 0.8, precision: n = 0.01 } = e;
  let i, o, f, c = (
    /** @type {T} */
    t
  ), u = (
    /** @type {T | undefined} */
    t
  ), y = 1, g = 0, E = !1;
  function T(h, d = {}) {
    u = h;
    const V = f = {};
    return t == null || d.hard || b.stiffness >= 1 && b.damping >= 1 ? (E = !0, i = me.now(), c = h, r.set(t = u), Promise.resolve()) : (d.soft && (g = 1 / ((d.soft === !0 ? 0.5 : +d.soft) * 60), y = 0), o || (i = me.now(), E = !1, o = an((_) => {
      if (E)
        return E = !1, o = null, !1;
      y = Math.min(y + g, 1);
      const m = Math.min(_ - i, 1e3 / 30), k = {
        inv_mass: y,
        opts: b,
        settled: !0,
        dt: m * 60 / 1e3
      }, N = Xt(k, c, t, u);
      return i = _, c = /** @type {T} */
      t, r.set(t = /** @type {T} */
      N), k.settled && (o = null), !k.settled;
    })), new Promise((_) => {
      o.promise.then(() => {
        V === f && _();
      });
    }));
  }
  const b = {
    set: T,
    update: (h, d) => T(h(
      /** @type {T} */
      u,
      /** @type {T} */
      t
    ), d),
    subscribe: r.subscribe,
    stiffness: a,
    damping: s,
    precision: n
  };
  return b;
}
var Xn = /* @__PURE__ */ H('<div><svg viewBox="-1200 -1200 3000 3000" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-13if8lc"><g><path d="M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z" fill="#FF7C00" fill-opacity="0.4" class="svelte-13if8lc"></path><path d="M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z" fill="#FF7C00" class="svelte-13if8lc"></path><path d="M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z" fill="#FF7C00" fill-opacity="0.4" class="svelte-13if8lc"></path><path d="M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z" fill="#FF7C00" class="svelte-13if8lc"></path></g><g><path d="M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z" fill="#FF7C00" fill-opacity="0.4" class="svelte-13if8lc"></path><path d="M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z" fill="#FF7C00" class="svelte-13if8lc"></path><path d="M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z" fill="#FF7C00" fill-opacity="0.4" class="svelte-13if8lc"></path><path d="M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z" fill="#FF7C00" class="svelte-13if8lc"></path></g></svg></div>');
function Jn(t, e) {
  wt(e, !0);
  const r = () => yr(o, "$top", s), a = () => yr(f, "$bottom", s), [s, n] = mn();
  let i = p(e, "margin", 3, !0);
  const o = Tr([0, 0]), f = Tr([0, 0]);
  let c = W(!1);
  async function u() {
    await Promise.all([o.set([125, 140]), f.set([-125, -140])]), await Promise.all([o.set([-125, 140]), f.set([125, -140])]), await Promise.all([o.set([-125, 0]), f.set([125, -0])]), await Promise.all([o.set([125, 0]), f.set([-125, 0])]);
  }
  async function y() {
    await u(), l(c) || y();
  }
  async function g() {
    await Promise.all([o.set([125, 0]), f.set([-125, 0])]), y();
  }
  ie(() => (g(), () => {
    A(c, !0);
  }));
  var E = Xn();
  let T;
  var b = q(E), h = q(b), d = z(h);
  B(() => {
    T = ge(E, 1, "svelte-13if8lc", null, T, { margin: i() }), Me(h, `transform: translate(${r()[0] ?? ""}px, ${r()[1] ?? ""}px);`), Me(d, `transform: translate(${a()[0] ?? ""}px, ${a()[1] ?? ""}px);`);
  }), x(t, E), mt(), n();
}
let At = [], qt = !1;
const Qn = typeof window < "u", Kr = Qn ? window.requestAnimationFrame : (t) => {
}, Mr = /* @__PURE__ */ new Set();
async function $n(t, e = !0) {
  if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && e !== !0)) {
    if (At.push(t), !qt) qt = !0;
    else return;
    await Fr(), Kr(() => {
      let r = [0, 0];
      for (let a = 0; a < At.length; a++) {
        const n = At[a].getBoundingClientRect();
        (a === 0 || n.top + window.scrollY <= r[0]) && (r[0] = n.top + window.scrollY, r[1] = a);
      }
      window.scrollTo({ top: r[0] - 20, behavior: "smooth" }), qt = !1, At = [];
    });
  }
}
var es = /* @__PURE__ */ H('<div class="validation-error svelte-1uvc87p"> <button class="svelte-1uvc87p"><!></button></div>'), ts = /* @__PURE__ */ H('<div class="eta-bar svelte-1uvc87p"></div>'), rs = /* @__PURE__ */ H("<!> ", 1), as = /* @__PURE__ */ H("<!> <!> <!> <!>", 1), ns = /* @__PURE__ */ H('<div class="progress-level svelte-1uvc87p"><div class="progress-level-inner svelte-1uvc87p"><!></div> <div class="progress-bar-wrap svelte-1uvc87p"><div class="progress-bar svelte-1uvc87p"></div></div></div>'), ss = /* @__PURE__ */ H('<p class="loading svelte-1uvc87p"> </p> <!>', 1), is = /* @__PURE__ */ H("<!> <div><!> <!></div> <!> <!>", 1), ls = /* @__PURE__ */ H('<div class="clear-status svelte-1uvc87p"><!></div> <span class="error svelte-1uvc87p"> </span> <!>', 1), os = /* @__PURE__ */ H("<div> <!> </div>"), fs = /* @__PURE__ */ H('<div data-testid="status-tracker"><!> <!></div> <!>', 1);
function cs(t, e) {
  wt(e, !0);
  let r = p(e, "eta", 3, null), a = p(e, "component_id", 3, null), s = p(e, "fn_index", 3, null), n = p(e, "scroll_to_output", 3, !1), i = p(e, "timer", 3, !0), o = p(e, "show_progress", 3, "full"), f = p(e, "message", 3, null), c = p(e, "progress", 3, null), u = p(e, "variant", 3, "default"), y = p(e, "loading_text", 3, "Loading..."), g = p(e, "absolute", 3, !0), E = p(e, "translucent", 3, !1), T = p(e, "border", 3, !1), b = p(e, "validation_error", 7, null), h = p(e, "show_validation_error", 3, !0), d = p(e, "type", 3, null), V = p(e, "used_cache", 3, null), _ = p(e, "cache_duration", 3, null), m = p(e, "avg_time", 3, null), k = p(e, "cache_event_id", 3, null), N, w = !1, j = W(0), F = W(null), L = W(null), we = W(!1), Ae = W(null), le = W(!1), K = W(!1), Se = W(null), Le = W(null), Ye = W("from cache"), Be = W(!1), ye = null, xe = null, ee = null;
  function v() {
    ye && clearTimeout(ye), xe && clearTimeout(xe), ye = null, xe = null, A(le, !1), A(K, !1);
  }
  const S = ce(() => !(h() && b()) && (d() === "input" || !e.status || e.status === "complete" || o() === "hidden" || e.status == "streaming"));
  let C = W(0);
  const G = ce(() => l(L) === null || l(L) <= 0 || !l(C) ? 0 : Math.min(l(C) / l(L), 1)), P = ce(() => l(C).toFixed(1));
  let pe = ce(() => c() == null), X = ce(() => r() ?? l(F));
  function Ve() {
    Kr(() => {
      A(C, (performance.now() - l(j)) / 1e3), w && Ve();
    });
  }
  let re = ce(() => {
    let M = null;
    c() != null ? M = c().map((Y) => {
      if (Y.index != null && Y.length != null)
        return Y.index / Y.length;
      if (Y.progress != null)
        return Y.progress;
    }) : M = null;
    let I, D = "";
    return M ? (I = M[M.length - 1], I === 0 ? D = "0" : D = "150ms") : I = void 0, {
      progress_level: M,
      last_progress_level: I,
      progress_bar_transition: D
    };
  });
  function Je() {
    w || (A(F, A(Ae, null), !0), A(j, performance.now(), !0), w = !0, Ve());
  }
  function he() {
    A(F, A(Ae, null), !0), w && (w = !1);
  }
  ie(() => {
    e.status === "pending" ? Je() : Z(() => {
      he();
    });
  }), ie(() => {
    N && n() && (e.status === "pending" || e.status === "complete") && $n(N, e.autoscroll);
  }), ie(() => {
    l(X) != null && l(F) !== l(X) && (A(L, (performance.now() - l(j)) / 1e3 + l(X)), A(Ae, l(L).toFixed(1), !0), A(F, l(X), !0));
  });
  function ke() {
    A(we, !1);
  }
  ie(() => {
    Z(() => {
      ke();
    }), e.status === "error" && f() && A(we, !0);
  }), ie(() => {
    if (e.status === "complete" && d() === "output" && V() && _() != null) {
      const M = k() == null ? null : `${a() ?? s() ?? "unknown"}:${s() ?? "unknown"}:${k()}`;
      if (M === ee || M != null && Mr.has(M))
        return;
      ee = M, M != null && Mr.add(M), A(Se, _().toFixed(1), !0), A(Ye, V() === "full" ? "from cache" : "used cache", !0), A(Be, m() != null && m() > _() && m() > 0, !0), A(Le, l(Be) ? m().toFixed(1) : null, !0), A(le, !0), A(K, !1), ye && clearTimeout(ye), xe && clearTimeout(xe), ye = setTimeout(
        () => {
          A(K, !0), xe = setTimeout(
            () => {
              A(le, !1), A(K, !1);
            },
            500
          );
        },
        1750
      );
    } else d() === "output" && !V() && v();
  });
  var yt = fs(), je = Q(yt);
  let xt, ct;
  var kt = q(je);
  {
    var Qe = (M) => {
      var I = es(), D = q(I), Y = z(D), $ = q(Y);
      {
        let te = ce(() => e.i18n ? e.i18n("common.clear") : "Clear");
        Ct($, {
          get Icon() {
            return xr;
          },
          get label() {
            return l(te);
          },
          disabled: !1,
          size: "x-small",
          background: "var(--background-fill-primary)",
          color: "var(--error-background-text)",
          border: "var(--border-color-primary)",
          onclick: () => b(null)
        });
      }
      B(() => ne(D, `${b() ?? ""} `)), x(M, I);
    };
    O(kt, (M) => {
      b() && h() && M(Qe);
    });
  }
  var Et = z(kt, 2);
  {
    var Tt = (M) => {
      var I = is(), D = Q(I);
      {
        var Y = (U) => {
          var J = ts();
          let fe;
          B(() => fe = Me(J, "", fe, {
            transform: `translateX(${(l(G) || 0) * 100 - 100}%)`
          })), x(U, J);
        };
        O(D, (U) => {
          u() === "default" && l(pe) && o() === "full" && U(Y);
        });
      }
      var $ = z(D, 2);
      let te;
      var de = q($);
      {
        var Ee = (U) => {
          var J = be(), fe = Q(J);
          it(fe, 17, c, st, (Ce, ae) => {
            var ue = be(), Ie = Q(ue);
            {
              var $e = (Pe) => {
                var Oe = rs(), et = Q(Oe);
                {
                  var Rt = (Ne) => {
                    var Ke = Te();
                    B((ut, ht) => ne(Ke, `${ut ?? ""}/${ht ?? ""}`), [
                      () => jt(l(ae).index || 0),
                      () => jt(l(ae).length)
                    ]), x(Ne, Ke);
                  }, tt = (Ne) => {
                    var Ke = Te();
                    B((ut) => ne(Ke, ut), [() => jt(l(ae).index || 0)]), x(Ne, Ke);
                  };
                  O(et, (Ne) => {
                    l(ae).length != null ? Ne(Rt) : Ne(tt, !1);
                  });
                }
                var rt = z(et);
                B(() => ne(rt, ` ${l(ae).unit ?? ""} |  `)), x(Pe, Oe);
              };
              O(Ie, (Pe) => {
                l(ae).index != null && Pe($e);
              });
            }
            x(Ce, ue);
          }), x(U, J);
        }, oe = (U) => {
          var J = be(), fe = Q(J);
          {
            var Ce = (ue) => {
              var Ie = Te();
              B(() => ne(Ie, `queue: ${e.queue_position + 1}/${e.queue_size ?? ""} |`)), x(ue, Ie);
            }, ae = (ue) => {
              var Ie = be(), $e = Q(Ie);
              {
                var Pe = (Oe) => {
                  var et = Te("processing |");
                  x(Oe, et);
                };
                O(
                  $e,
                  (Oe) => {
                    e.queue_position === 0 && Oe(Pe);
                  },
                  !0
                );
              }
              x(ue, Ie);
            };
            O(
              fe,
              (ue) => {
                e.queue_position !== null && e.queue_size !== void 0 && e.queue_position >= 0 ? ue(Ce) : ue(ae, !1);
              },
              !0
            );
          }
          x(U, J);
        };
        O(de, (U) => {
          c() ? U(Ee) : U(oe, !1);
        });
      }
      var qe = z(de, 2);
      {
        var dt = (U) => {
          var J = Te();
          B(() => ne(J, `${l(P) ?? ""}${r() ? `/${l(Ae)}` : ""}s`)), x(U, J);
        };
        O(qe, (U) => {
          i() && U(dt);
        });
      }
      var ze = z($, 2);
      {
        var Wr = (U) => {
          var J = ns(), fe = q(J), Ce = q(fe);
          {
            var ae = (Pe) => {
              var Oe = be(), et = Q(Oe);
              it(et, 17, c, st, (Rt, tt, rt) => {
                var Ne = be(), Ke = Q(Ne);
                {
                  var ut = (ht) => {
                    var ir = as(), lr = Q(ir);
                    {
                      var Jr = (se) => {
                        var Fe = Te(" /");
                        x(se, Fe);
                      };
                      O(lr, (se) => {
                        rt !== 0 && se(Jr);
                      });
                    }
                    var or = z(lr, 2);
                    {
                      var Qr = (se) => {
                        var Fe = Te();
                        B(() => ne(Fe, l(tt).desc)), x(se, Fe);
                      };
                      O(or, (se) => {
                        l(tt).desc != null && se(Qr);
                      });
                    }
                    var fr = z(or, 2);
                    {
                      var $r = (se) => {
                        var Fe = Te("-");
                        x(se, Fe);
                      };
                      O(fr, (se) => {
                        l(tt).desc != null && l(re).progress_level && l(re).progress_level[rt] != null && se($r);
                      });
                    }
                    var ea = z(fr, 2);
                    {
                      var ta = (se) => {
                        var Fe = Te();
                        B((ra) => ne(Fe, `${ra ?? ""}%`), [
                          () => (100 * (l(re).progress_level[rt] || 0)).toFixed(1)
                        ]), x(se, Fe);
                      };
                      O(ea, (se) => {
                        l(re).progress_level != null && se(ta);
                      });
                    }
                    x(ht, ir);
                  };
                  O(Ke, (ht) => {
                    (l(tt).desc != null || l(re).progress_level && l(re).progress_level[rt] != null) && ht(ut);
                  });
                }
                x(Rt, Ne);
              }), x(Pe, Oe);
            };
            O(Ce, (Pe) => {
              c() != null && Pe(ae);
            });
          }
          var ue = z(fe, 2), Ie = q(ue);
          let $e;
          B(() => $e = Me(Ie, "", $e, {
            width: `${l(re).last_progress_level * 100}%`,
            transition: l(re).progress_bar_transition
          })), x(U, J);
        }, Zr = (U) => {
          var J = be(), fe = Q(J);
          {
            var Ce = (ae) => {
              {
                let ue = ce(() => u() === "default");
                Jn(ae, {
                  get margin() {
                    return l(ue);
                  }
                });
              }
            };
            O(
              fe,
              (ae) => {
                o() === "full" && ae(Ce);
              },
              !0
            );
          }
          x(U, J);
        };
        O(ze, (U) => {
          l(re).last_progress_level != null ? U(Wr) : U(Zr, !1);
        });
      }
      var Gr = z(ze, 2);
      {
        var Xr = (U) => {
          var J = ss(), fe = Q(J), Ce = q(fe), ae = z(fe, 2);
          Wt(ae, e, "additional-loading-text", {}), B(() => ne(Ce, y())), x(U, J);
        };
        O(Gr, (U) => {
          i() || U(Xr);
        });
      }
      B(() => te = ge($, 1, "progress-text svelte-1uvc87p", null, te, {
        "meta-text-center": u() === "center",
        "meta-text": u() === "default"
      })), x(M, I);
    }, Nt = (M) => {
      var I = be(), D = Q(I);
      {
        var Y = ($) => {
          var te = ls(), de = Q(te), Ee = q(de);
          {
            let ze = ce(() => e.i18n("common.clear"));
            Ct(Ee, {
              get Icon() {
                return xr;
              },
              get label() {
                return l(ze);
              },
              disabled: !1,
              onclick: () => {
                e.on_clear_status?.();
              }
            });
          }
          var oe = z(de, 2), qe = q(oe), dt = z(oe, 2);
          Wt(dt, e, "error", {}), B((ze) => ne(qe, ze), [() => e.i18n("common.error")]), x($, te);
        };
        O(
          D,
          ($) => {
            e.status === "error" && $(Y);
          },
          !0
        );
      }
      x(M, I);
    };
    O(Et, (M) => {
      e.status === "pending" ? M(Tt) : M(Nt, !1);
    });
  }
  Ze(je, (M) => N = M, () => N);
  var Ft = z(je, 2);
  {
    var R = (M) => {
      var I = os();
      let D, Y;
      var $ = q(I), te = z($);
      {
        var de = (oe) => {
          var qe = Te();
          B(() => ne(qe, `~${l(Le) ?? ""}s
			→ `)), x(oe, qe);
        };
        O(te, (oe) => {
          l(Be) && oe(de);
        });
      }
      var Ee = z(te);
      B(() => {
        D = ge(I, 1, "cache-indicator svelte-1uvc87p", null, D, { "fade-out": l(K) }), Y = Me(I, "", Y, { position: g() ? "absolute" : "static" }), ne($, `⚡ ${l(Ye) ?? ""}: `), ne(Ee, `${l(Se) ?? ""}s`);
      }), x(M, I);
    };
    O(Ft, (M) => {
      l(le) && M(R);
    });
  }
  B(() => {
    xt = ge(je, 1, `wrap ${u() ?? ""} ${o() ?? ""}`, "svelte-1uvc87p", xt, {
      "no-click": b() && h(),
      hide: l(S),
      translucent: u() === "center" && (e.status === "pending" || e.status === "error") || E() || o() === "minimal" || b(),
      generating: e.status === "generating" && o() === "full",
      border: T()
    }), ct = Me(je, "", ct, {
      position: g() ? "absolute" : "static",
      padding: g() ? "0" : "var(--size-8) 0"
    });
  }), x(t, yt), mt();
}
const ds = (t) => {
  const e = {};
  for (let r = 0, a = t.length; r < a; r++) {
    const s = t[r];
    for (const n in s)
      e[n] ? e[n] = e[n].concat(s[n]) : e[n] = s[n];
  }
  return e;
}, us = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], hs = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], vs = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
ds([
  Object.fromEntries(us.map((t) => [t, ["*"]])),
  Object.fromEntries(hs.map((t) => [t, ["svg:*"]])),
  Object.fromEntries(vs.map((t) => [t, ["math:*"]]))
]);
bt(["touchstart", "touchmove", "touchend", "click", "keydown"]);
function _s(t, e) {
  wt(e, !0);
  function r(f) {
    return f instanceof HTMLElement && (f.isContentEditable || ["INPUT", "TEXTAREA", "SELECT"].includes(f.tagName));
  }
  function a(f) {
    f.key.toLowerCase() !== "f" || f.repeat || f.defaultPrevented || f.altKey || f.ctrlKey || f.metaKey || r(f.target) && !e.hovered() || (f.preventDefault(), e.onclick(!e.fullscreen));
  }
  var s = be();
  Re("keydown", Ya, a);
  var n = Q(s);
  {
    var i = (f) => {
      Ct(f, {
        get Icon() {
          return qn;
        },
        get label() {
          return e.exit_label;
        },
        onclick: () => e.onclick(!1)
      });
    }, o = (f) => {
      Ct(f, {
        get Icon() {
          return Vn;
        },
        get label() {
          return e.label;
        },
        onclick: () => e.onclick(!0)
      });
    };
    O(n, (f) => {
      e.fullscreen ? f(i) : f(o, !1);
    });
  }
  x(t, s), mt();
}
const gs = "canvas-host", Ar = "canvas-host-request";
class ps extends EventTarget {
  constructor(e, r, a, s, n, i) {
    super(), this.id = e, this.stage = r, this.image = a, this.area = s, this.toolbars = n, this.tool_groups = i, this.#e = i.flat()[0] ?? null;
  }
  id;
  stage;
  image;
  area;
  toolbars;
  tool_groups;
  #e;
  /** ID of the active tool, if any. */
  get tool() {
    return this.#e;
  }
  set tool(e) {
    e !== this.#e && (this.#e = e, this.#t(), this.dispatchEvent(new Event("tool-change")));
  }
  /** Press the button of the active tool, release the others. */
  #t() {
    for (const e of this.toolbars)
      for (const r of e.children)
        r.querySelector("button")?.setAttribute(
          "aria-pressed",
          String(Number(r.dataset.tool) === this.#e)
        );
  }
  /** Add the button of a tool to the toolbar of its group, in tools order. */
  add_tool(e, r) {
    const a = this.tool_groups.findIndex((o) => o.includes(e)), s = this.toolbars[a];
    if (!s) return;
    const n = (o) => this.tool_groups[a].indexOf(Number(o.dataset.tool));
    r.dataset.tool = String(e);
    const i = [...s.children].find((o) => n(o) > n(r));
    s.insertBefore(r, i ?? null), this.#t();
  }
}
var bs = /* @__PURE__ */ ft('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="9.3 14.3 41.7 37.8"><defs><clipPath id="canvas-photos-clip"><rect x="-16" y="-11" width="32" height="22" rx="0.5"></rect></clipPath><g id="canvas-photos-hills"><circle cx="-14" cy="16" r="12" fill="#56b65b"></circle><circle cx="0" cy="17" r="13" fill="#66c763"></circle><circle cx="15" cy="15" r="14" fill="#7be161"></circle></g></defs><g transform="translate(29 36.5) rotate(9)"><rect x="-17.2" y="-12.2" width="34.4" height="24.4" rx="1" fill="#f2f3fa"></rect><g clip-path="url(#canvas-photos-clip)"><rect x="-16" y="-11" width="32" height="22" fill="#ff9e7a"></rect><circle cx="-11" cy="3" r="3.5" fill="#ffd166"></circle><rect x="-16" y="3" width="32" height="8" fill="#3a8fd9"></rect><g fill="#8cc8ff"><rect x="-14" y="4.5" width="6" height="0.8" rx="0.4"></rect><rect x="-12.5" y="6.2" width="3" height="0.8" rx="0.4"></rect></g><ellipse cx="4" cy="15" rx="18" ry="6.5" fill="#f2d29b"></ellipse></g></g><g transform="translate(31.8 29) rotate(-6)"><rect x="-17.2" y="-12.2" width="34.4" height="24.4" rx="1" fill="#f2f3fa"></rect><g clip-path="url(#canvas-photos-clip)"><rect x="-16" y="-11" width="32" height="22" fill="#52b2ff"></rect><circle cx="-4" cy="-4" r="2.5" fill="#ffcb57"></circle><g fill="#e6e6f6"><circle cx="-15" cy="-1" r="4"></circle><circle cx="-10" cy="0" r="3"></circle><circle cx="10.5" cy="-6.8" r="1.2"></circle><circle cx="12.2" cy="-7.2" r="1.6"></circle><rect x="9.3" y="-6.6" width="6" height="1.6" rx="0.8"></rect></g><use href="#canvas-photos-hills"></use></g></g></svg>');
function ms(t) {
  var e = bs();
  x(t, e);
}
var ws = /* @__PURE__ */ H('<img class="layer svelte-1sbzryu" alt=""/>'), ys = /* @__PURE__ */ H('<p class="svelte-1sbzryu"> </p>'), xs = /* @__PURE__ */ H('<div class="placeholder svelte-1sbzryu"><div class="placeholder-art svelte-1sbzryu" aria-hidden="true"><!></div> <!></div>'), ks = /* @__PURE__ */ H('<img class="layer svelte-1sbzryu" alt="" loading="lazy"/>'), Es = /* @__PURE__ */ H('<button class="thumb svelte-1sbzryu" role="option"></button>'), Ts = /* @__PURE__ */ H('<div class="thumbs-bar svelte-1sbzryu"><button class="thumbs-arrow svelte-1sbzryu" tabindex="-1" aria-label="Previous"><svg viewBox="0 0 16 16" aria-hidden="true" class="svelte-1sbzryu"><path d="M10 4L6 8L10 12"></path></svg></button> <div role="listbox" aria-orientation="horizontal" tabindex="-1"></div> <button class="thumbs-arrow svelte-1sbzryu" tabindex="-1" aria-label="Next"><svg viewBox="0 0 16 16" aria-hidden="true" class="svelte-1sbzryu"><path d="M6 4L10 8L6 12"></path></svg></button></div>'), Ms = /* @__PURE__ */ H('<div class="group svelte-1sbzryu"><!></div>'), As = /* @__PURE__ */ H('<div class="group toolbar svelte-1sbzryu" role="toolbar"></div>'), Ss = /* @__PURE__ */ H('<!> <!> <div role="group"><div><img class="layer svelte-1sbzryu" alt=""/> <!></div> <!> <!>  <div><!> <!></div></div>', 1);
function zs(t, e) {
  wt(e, !0);
  let r = null;
  class a extends Gn {
    // Events wait for dropped images, to pass them.
    async get_data() {
      return r && (await r, await Fr()), super.get_data();
    }
  }
  const s = /* @__PURE__ */ xn(e, ["$$slots", "$$events", "$$legacy"]), n = new a(s), i = ce(() => n.props.value ?? { docs: [], index: null }), o = ce(() => l(i).index === null ? null : l(i).docs[l(i).index] ?? null);
  let f = W(!1), c = W(!1), u = !1, y, g, E;
  const T = [];
  let b = W(void 0), h = W(0);
  function d(v) {
    return v.layers[0].object.path;
  }
  function V(v) {
    return { index: v, path: d(l(i).docs[v]) };
  }
  function _(v, S) {
    n.props.value = { docs: v, index: S };
  }
  function m(v) {
    v !== l(i).index && (_(l(i).docs, v), n.dispatch("input"));
  }
  let k = Z(() => l(i).docs.map(d)), N = Z(() => l(o) && d(l(o)));
  ie(() => {
    const v = l(i).docs.map(d), S = l(o) && d(l(o));
    Z(() => w(v, S));
  });
  function w(v, S) {
    S === N && v.join(`
`) === k.join(`
`) || (k.forEach((C, G) => {
      v.includes(C) || n.dispatch("doc_deleted", { index: G, path: C });
    }), v.forEach((C, G) => {
      k.includes(C) || n.dispatch("doc_added", { index: G, path: C });
    }), k.length && !v.length ? n.dispatch("empty") : !k.length && v.length && n.dispatch("filled"), S !== N && l(i).index !== null && n.dispatch("select", V(l(i).index)), k = v, N = S, n.dispatch("change"));
  }
  ie(() => {
    const v = l(i).index === null ? null : l(b)?.children[l(i).index];
    v instanceof HTMLElement && (v.scrollIntoView({ block: "nearest", inline: "nearest", behavior: "smooth" }), l(b)?.contains(document.activeElement) && v.focus({ preventScroll: !0 }));
  });
  let j = W(!1), F = W(!1);
  function L() {
    if (!l(b)) return;
    const { scrollLeft: v, scrollWidth: S, clientWidth: C } = l(b);
    A(j, v > 1), A(F, v + C < S - 1);
  }
  ie(() => {
    if (!l(b)) return;
    l(i).docs.length, L();
    const v = new ResizeObserver(L);
    return v.observe(l(b)), () => v.disconnect();
  });
  function we(v) {
    n.dispatch("thumb_click", V(v)), m(v);
  }
  function Ae(v) {
    const S = l(i).index, C = l(i).docs.length - 1;
    if (S === null || v.altKey || v.ctrlKey || v.metaKey) return;
    const P = {
      ArrowLeft: Math.max(0, S - 1),
      ArrowRight: Math.min(C, S + 1),
      Home: 0,
      End: C
    }[v.key];
    P !== void 0 && (v.preventDefault(), m(P));
  }
  let le = 0;
  function K(v) {
    if (l(i).index === null || v.ctrlKey || Math.abs(v.deltaY) <= Math.abs(v.deltaX))
      return;
    v.preventDefault();
    const S = v.deltaMode === WheelEvent.DOM_DELTA_PIXEL ? v.deltaY : v.deltaY * 40;
    if (Math.sign(S) !== Math.sign(le) && (le = 0), le += S, Math.abs(le) < 50) return;
    const C = Math.sign(le);
    le = 0, Se(C);
  }
  function Se(v) {
    l(i).index !== null && m(Math.min(l(i).docs.length - 1, Math.max(0, l(i).index + v)));
  }
  function Le(v) {
    const S = v.target;
    !(S instanceof HTMLImageElement) || !v.dataTransfer || (u = !0, v.dataTransfer.setData("text/uri-list", S.currentSrc));
  }
  function Ye(v) {
    return n.shared.interactive !== !1 && !u && !!v.dataTransfer?.types.includes("Files");
  }
  function Be(v) {
    Ye(v) && (v.preventDefault(), v.dataTransfer.dropEffect = "copy", A(c, !0));
  }
  function ye(v) {
    y.contains(v.relatedTarget) || A(c, !1);
  }
  function xe(v) {
    if (A(c, !1), !Ye(v)) return;
    v.preventDefault();
    const S = [...v.dataTransfer.files].filter((C) => C.type.startsWith("image/"));
    S.length && (r = ee(S).finally(() => r = null));
  }
  async function ee(v) {
    let S;
    try {
      S = await n.shared.client.upload(
        v.map((P) => ({
          path: P.name,
          orig_name: P.name,
          blob: P,
          size: P.size,
          mime_type: P.type,
          is_stream: !1,
          meta: { _type: "gradio.FileData" }
        })),
        n.shared.root,
        void 0,
        n.shared.max_file_size ?? void 0
      );
    } catch (P) {
      n.dispatch("error", P instanceof Error ? P.message : String(P));
      return;
    }
    const C = (S ?? []).filter((P) => P !== null).map((P) => ({
      layers: [{ object: P, imported: !0, source_file: null }],
      caption: null
    }));
    if (!C.length) return;
    const G = l(i).docs.length;
    _([...l(i).docs, ...C], G + C.length - 1), C.forEach((P, pe) => n.dispatch("doc_dropped", V(G + pe))), n.dispatch("input");
  }
  In(() => {
    const v = new ps(n.shared.id, g, E, y, T, n.props.tools ?? []);
    v.addEventListener("tool-change", () => n.dispatch("tool_selected", { tool: v.tool }));
    const S = (C) => {
      const G = C.detail;
      G.canvas_id === v.id && G.resolve(v);
    };
    return window.addEventListener(Ar, S), window.dispatchEvent(new CustomEvent(gs, { detail: v })), () => window.removeEventListener(Ar, S);
  });
  {
    let v = ce(() => n.props.height ?? void 0);
    Ln(t, {
      get visible() {
        return n.shared.visible;
      },
      variant: "solid",
      padding: !1,
      get elem_id() {
        return n.shared.elem_id;
      },
      get elem_classes() {
        return n.shared.elem_classes;
      },
      get container() {
        return n.shared.container;
      },
      get scale() {
        return n.shared.scale;
      },
      get min_width() {
        return n.shared.min_width;
      },
      allow_overflow: !1,
      get height() {
        return l(v);
      },
      get fullscreen() {
        return l(f);
      },
      set fullscreen(S) {
        A(f, S, !0);
      },
      children: (S, C) => {
        var G = Ss(), P = Q(G);
        cs(P, En(
          {
            get autoscroll() {
              return n.shared.autoscroll;
            },
            get i18n() {
              return n.i18n;
            }
          },
          () => n.shared.loading_status,
          {
            on_clear_status: () => n.dispatch("clear_status", n.shared.loading_status)
          }
        ));
        var pe = z(P, 2);
        {
          let R = ce(() => n.shared.label || "Canvas");
          Cn(pe, {
            get show_label() {
              return n.shared.show_label;
            },
            get Icon() {
              return Dn;
            },
            get label() {
              return l(R);
            }
          });
        }
        var X = z(pe, 2);
        let Ve;
        var re = q(X);
        let Je, he;
        var ke = q(re);
        Ze(ke, (R) => E = R, () => E);
        var yt = z(ke, 2);
        it(yt, 17, () => l(o)?.layers.slice(1) ?? [], st, (R, M) => {
          var I = ws();
          B(() => _e(I, "src", l(M).object.url)), x(R, I);
        }), Ze(re, (R) => g = R, () => g);
        var je = z(re, 2);
        {
          var xt = (R) => {
            var M = xs(), I = q(M), D = q(I);
            ms(D);
            var Y = z(I, 2);
            {
              var $ = (te) => {
                var de = ys(), Ee = q(de);
                B(() => ne(Ee, n.props.placeholder)), x(te, de);
              };
              O(Y, (te) => {
                n.props.placeholder && te($);
              });
            }
            x(R, M);
          };
          O(je, (R) => {
            l(o) || R(xt);
          });
        }
        var ct = z(je, 2);
        {
          var kt = (R) => {
            var M = Ts(), I = q(M);
            I.__click = () => Se(-1);
            var D = z(I, 2);
            let Y;
            D.__keydown = Ae, it(D, 21, () => l(i).docs, st, (te, de, Ee) => {
              var oe = Es();
              oe.__click = () => we(Ee), it(oe, 21, () => l(de).layers, st, (qe, dt) => {
                var ze = ks();
                B(() => _e(ze, "src", l(dt).object.url)), x(qe, ze);
              }), B(() => {
                _e(oe, "aria-selected", Ee === l(i).index), _e(oe, "title", l(de).caption ?? void 0);
              }), x(te, oe);
            }), Ze(D, (te) => A(b, te), () => l(b));
            var $ = z(D, 2);
            $.__click = () => Se(1), B(() => {
              I.disabled = !l(i).index, Y = ge(D, 1, "thumbs svelte-1sbzryu", null, Y, {
                "fade-start": l(j),
                "fade-end": l(F)
              }), $.disabled = l(i).index === null || l(i).index === l(i).docs.length - 1;
            }), Re("wheel", M, K), Re("scroll", D, L), x(R, M);
          };
          O(ct, (R) => {
            l(i).docs.length && R(kt);
          });
        }
        var Qe = z(ct, 2);
        let Et;
        Qe.__mousedown = (R) => R.preventDefault();
        var Tt = q(Qe);
        {
          var Nt = (R) => {
            var M = Ms(), I = q(M);
            _s(I, {
              get fullscreen() {
                return l(f);
              },
              onclick: (D) => A(f, D, !0),
              get label() {
                return n.props.fullscreen_tooltip;
              },
              get exit_label() {
                return n.props.exit_fullscreen_tooltip;
              },
              hovered: () => y.matches(":hover")
            }), x(R, M);
          };
          O(Tt, (R) => {
            n.props.buttons?.includes("fullscreen") && R(Nt);
          });
        }
        var Ft = z(Tt, 2);
        it(Ft, 17, () => n.props.tools ?? [], st, (R, M, I) => {
          var D = As();
          Ze(D, (Y, $) => T[$] = Y, (Y) => T?.[Y], () => [I]), x(R, D);
        }), Ze(X, (R) => y = R, () => y), B(() => {
          Ve = ge(X, 1, "canvas svelte-1sbzryu", null, Ve, { "drag-over": l(c) }), _e(X, "aria-label", n.shared.label), Je = ge(re, 1, "stage svelte-1sbzryu", null, Je, { hidden: !l(o) }), he = Me(re, "", he, {
            "margin-inline": l(h) ? `calc(${l(h)}px + var(--spacing-lg))` : void 0
          }), _e(ke, "src", l(o)?.layers[0].object.url), Et = ge(Qe, 1, "buttons svelte-1sbzryu", null, Et, { "below-label": n.shared.show_label });
        }), Re("dragstart", X, Le), Re("dragend", X, () => u = !1), Re("dragover", X, Be), Re("dragleave", X, ye), Re("drop", X, xe), gn(Qe, "offsetWidth", (R) => A(h, R)), x(S, G);
      },
      $$slots: { default: !0 }
    });
  }
  mt();
}
bt(["click", "keydown", "mousedown"]);
export {
  zs as default
};
