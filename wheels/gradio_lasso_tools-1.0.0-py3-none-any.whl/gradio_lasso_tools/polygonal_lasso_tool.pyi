"""PolygonalLassoTool Gradio custom component."""

from .lasso_tool import LassoTool

from gradio.events import Dependency

# Its module lies next to LassoTool's, so Gradio serves it the same frontend.
class PolygonalLassoTool(LassoTool):
    """
    Lets user draw a polygonal lasso, clicking vertices joined by straight
    segments, over the document displayed by a canvas, which hosts this tool,
    e.g. to mask a region to edit.

    Lasso tools of a canvas, e.g. a FreehandLassoTool and a PolygonalLassoTool,
    share one selection: their values follow each other.
    """

    POLYGONAL = True
    from typing import Callable, Literal, Sequence, Any, TYPE_CHECKING
    from gradio.blocks import Block
    if TYPE_CHECKING:
        from gradio.components import Timer
        from gradio.components.base import Component