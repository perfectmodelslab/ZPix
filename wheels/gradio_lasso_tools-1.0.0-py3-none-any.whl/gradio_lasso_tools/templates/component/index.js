import { i as we, g as he, o as Ee, a as rt, b as Se, T as Me, c as ke, d as Ie, e as pt, f as Pt, r as Pe, h as at, p as Le, j as Lt, m as Re, s as Ae, k as wt, E as Et, L as Ne, N as Oe, l as Ce, n as Te, q as Be, u as V, t as ze, S as De, v as $e, w as je, x as Z, y as Fe, z as K, A as ae, B as gt, C as L, D as tt, F as Rt, G as et, H as Ge, I as Ke, J as He, K as Ye, M as q, O as At, P as W, Q as Ue, R as qe } from "./render-BKVekDVV.js";
function fe(n) {
  throw new Error("https://svelte.dev/e/lifecycle_outside_component");
}
const We = [];
function Xe(n, t = !1, e = !1) {
  return it(n, /* @__PURE__ */ new Map(), "", We, null, e);
}
function it(n, t, e, i, s = null, r = !1) {
  if (typeof n == "object" && n !== null) {
    var o = t.get(n);
    if (o !== void 0) return o;
    if (n instanceof Map) return (
      /** @type {Snapshot<T>} */
      new Map(n)
    );
    if (n instanceof Set) return (
      /** @type {Snapshot<T>} */
      new Set(n)
    );
    if (we(n)) {
      var l = (
        /** @type {Snapshot<any>} */
        Array(n.length)
      );
      t.set(n, l), s !== null && t.set(s, l);
      for (var a = 0; a < n.length; a += 1) {
        var f = n[a];
        a in n && (l[a] = it(f, t, e, i, null, r));
      }
      return l;
    }
    if (he(n) === Ee) {
      l = {}, t.set(n, l), s !== null && t.set(s, l);
      for (var d in n)
        l[d] = it(
          // @ts-expect-error
          n[d],
          t,
          e,
          i,
          null,
          r
        );
      return l;
    }
    if (n instanceof Date)
      return (
        /** @type {Snapshot<T>} */
        structuredClone(n)
      );
    if (typeof /** @type {T & { toJSON?: any } } */
    n.toJSON == "function" && !r)
      return it(
        /** @type {T & { toJSON(): any } } */
        n.toJSON(),
        t,
        e,
        i,
        // Associate the instance with the toJSON clone
        n
      );
  }
  if (n instanceof EventTarget)
    return (
      /** @type {Snapshot<T>} */
      n
    );
  try {
    return (
      /** @type {Snapshot<T>} */
      structuredClone(n)
    );
  } catch {
    return (
      /** @type {Snapshot<T>} */
      n
    );
  }
}
function ce(n) {
  var t = document.createElement("template");
  return t.innerHTML = n.replaceAll("<!>", "<!---->"), t.content;
}
function ot(n, t) {
  var e = (
    /** @type {Effect} */
    Ie
  );
  e.nodes === null && (e.nodes = { start: n, end: t, a: null, t: null });
}
// @__NO_SIDE_EFFECTS__
function St(n, t) {
  var e = (t & Me) !== 0, i = (t & ke) !== 0, s, r = !n.startsWith("<!>");
  return () => {
    s === void 0 && (s = ce(r ? n : "<!>" + n), e || (s = /** @type {TemplateNode} */
    rt(s)));
    var o = (
      /** @type {TemplateNode} */
      i || Se ? document.importNode(s, !0) : s.cloneNode(!0)
    );
    if (e) {
      var l = (
        /** @type {TemplateNode} */
        rt(o)
      ), a = (
        /** @type {TemplateNode} */
        o.lastChild
      );
      ot(l, a);
    } else
      ot(o, o);
    return o;
  };
}
// @__NO_SIDE_EFFECTS__
function Qe(n, t, e = "svg") {
  var i = !n.startsWith("<!>"), s = `<${e}>${i ? n : "<!>" + n}</${e}>`, r;
  return () => {
    if (!r) {
      var o = (
        /** @type {DocumentFragment} */
        ce(s)
      ), l = (
        /** @type {Element} */
        rt(o)
      );
      r = /** @type {Element} */
      rt(l);
    }
    var a = (
      /** @type {TemplateNode} */
      r.cloneNode(!0)
    );
    return ot(a, a), a;
  };
}
// @__NO_SIDE_EFFECTS__
function ue(n, t) {
  return /* @__PURE__ */ Qe(n, t, "svg");
}
function Ve() {
  var n = document.createDocumentFragment(), t = document.createComment(""), e = pt();
  return n.append(t, e), ot(t, e), n;
}
function H(n, t) {
  n !== null && n.before(
    /** @type {Node} */
    t
  );
}
class Mt {
  /** @type {TemplateNode} */
  anchor;
  /** @type {Map<Batch, Key>} */
  #t = /* @__PURE__ */ new Map();
  /**
   * Map of keys to effects that are currently rendered in the DOM.
   * These effects are visible and actively part of the document tree.
   * Example:
   * ```
   * {#if condition}
   * 	foo
   * {:else}
   * 	bar
   * {/if}
   * ```
   * Can result in the entries `true->Effect` and `false->Effect`
   * @type {Map<Key, Effect>}
   */
  #e = /* @__PURE__ */ new Map();
  /**
   * Similar to #onscreen with respect to the keys, but contains branches that are not yet
   * in the DOM, because their insertion is deferred.
   * @type {Map<Key, Branch>}
   */
  #i = /* @__PURE__ */ new Map();
  /**
   * Keys of effects that are currently outroing
   * @type {Set<Key>}
   */
  #o = /* @__PURE__ */ new Set();
  /**
   * Whether to pause (i.e. outro) on change, or destroy immediately.
   * This is necessary for `<svelte:element>`
   */
  #f = !0;
  /**
   * @param {TemplateNode} anchor
   * @param {boolean} transition
   */
  constructor(t, e = !0) {
    this.anchor = t, this.#f = e;
  }
  #d = () => {
    var t = (
      /** @type {Batch} */
      Pt
    );
    if (this.#t.has(t)) {
      var e = (
        /** @type {Key} */
        this.#t.get(t)
      ), i = this.#e.get(e);
      if (i)
        Pe(i), this.#o.delete(e);
      else {
        var s = this.#i.get(e);
        s && (this.#e.set(e, s.effect), this.#i.delete(e), s.fragment.lastChild.remove(), this.anchor.before(s.fragment), i = s.effect);
      }
      for (const [r, o] of this.#t) {
        if (this.#t.delete(r), r === t)
          break;
        const l = this.#i.get(o);
        l && (at(l.effect), this.#i.delete(o));
      }
      for (const [r, o] of this.#e) {
        if (r === e || this.#o.has(r)) continue;
        const l = () => {
          if (Array.from(this.#t.values()).includes(r)) {
            var f = document.createDocumentFragment();
            Re(o, f), f.append(pt()), this.#i.set(r, { effect: o, fragment: f });
          } else
            at(o);
          this.#o.delete(r), this.#e.delete(r);
        };
        this.#f || !i ? (this.#o.add(r), Le(o, l, !1)) : l();
      }
    }
  };
  /**
   * @param {Batch} batch
   */
  #p = (t) => {
    this.#t.delete(t);
    const e = Array.from(this.#t.values());
    for (const [i, s] of this.#i)
      e.includes(i) || (at(s.effect), this.#i.delete(i));
  };
  /**
   *
   * @param {any} key
   * @param {null | ((target: TemplateNode) => void)} fn
   */
  ensure(t, e) {
    var i = (
      /** @type {Batch} */
      Pt
    ), s = Ae();
    if (e && !this.#e.has(t) && !this.#i.has(t))
      if (s) {
        var r = document.createDocumentFragment(), o = pt();
        r.append(o), this.#i.set(t, {
          effect: Lt(() => e(o)),
          fragment: r
        });
      } else
        this.#e.set(
          t,
          Lt(() => e(this.anchor))
        );
    if (this.#t.set(i, t), s) {
      for (const [l, a] of this.#e)
        l === t ? i.skipped_effects.delete(a) : i.skipped_effects.add(a);
      for (const [l, a] of this.#i)
        l === t ? i.skipped_effects.delete(a.effect) : i.skipped_effects.add(a.effect);
      i.oncommit(this.#d), i.ondiscard(this.#p);
    } else
      this.#d();
  }
}
function Nt(n, t, e = !1) {
  var i = new Mt(n), s = e ? Et : 0;
  function r(o, l) {
    i.ensure(o, l);
  }
  wt(() => {
    var o = !1;
    t((l, a = !0) => {
      o = !0, r(a, l);
    }), o || r(!1, null);
  }, s);
}
function Je(n, t, ...e) {
  var i = new Mt(n);
  wt(() => {
    const s = t() ?? null;
    i.ensure(s, s && ((r) => s(r, ...e)));
  }, Et);
}
function Ze(n, t, e) {
  var i = new Mt(n);
  wt(() => {
    var s = t() ?? null;
    i.ensure(s, s && ((r) => e(r, s)));
  }, Et);
}
const Ot = [...` 	
\r\f \v\uFEFF`];
function ti(n, t, e) {
  var i = n == null ? "" : "" + n;
  if (e) {
    for (var s in e)
      if (e[s])
        i = i ? i + " " + s : s;
      else if (i.length)
        for (var r = s.length, o = 0; (o = i.indexOf(s, o)) >= 0; ) {
          var l = o + r;
          (o === 0 || Ot.includes(i[o - 1])) && (l === i.length || Ot.includes(i[l])) ? i = (o === 0 ? "" : i.substring(0, o)) + i.substring(l + 1) : o = l;
        }
  }
  return i === "" ? null : i;
}
function Ct(n, t = !1) {
  var e = t ? " !important;" : ";", i = "";
  for (var s in n) {
    var r = n[s];
    r != null && r !== "" && (i += " " + s + ": " + r + e);
  }
  return i;
}
function ei(n, t) {
  if (t) {
    var e = "", i, s;
    return Array.isArray(t) ? (i = t[0], s = t[1]) : i = t, i && (e += Ct(i)), s && (e += Ct(s, !0)), e = e.trim(), e === "" ? null : e;
  }
  return String(n);
}
function Tt(n, t, e, i, s, r) {
  var o = n.__className;
  if (o !== e || o === void 0) {
    var l = ti(e, i, r);
    l == null ? n.removeAttribute("class") : n.className = l, n.__className = e;
  } else if (r && s !== r)
    for (var a in r) {
      var f = !!r[a];
      (s == null || f !== !!s[a]) && n.classList.toggle(a, f);
    }
  return r;
}
function ft(n, t = {}, e, i) {
  for (var s in e) {
    var r = e[s];
    t[s] !== r && (e[s] == null ? n.style.removeProperty(s) : n.style.setProperty(s, r, i));
  }
}
function ii(n, t, e, i) {
  var s = n.__style;
  if (s !== t) {
    var r = ei(t, i);
    r == null ? n.removeAttribute("style") : n.style.cssText = r, n.__style = t;
  } else i && (Array.isArray(i) ? (ft(n, e?.[0], i[0]), ft(n, e?.[1], i[1], "important")) : ft(n, e, i));
  return i;
}
const si = /* @__PURE__ */ Symbol("is custom element"), ni = /* @__PURE__ */ Symbol("is html");
function st(n, t, e, i) {
  var s = ri(n);
  s[t] !== (s[t] = e) && (t === "loading" && (n[Ne] = e), e == null ? n.removeAttribute(t) : typeof e != "string" && oi(n).includes(t) ? n[t] = e : n.setAttribute(t, e));
}
function ri(n) {
  return (
    /** @type {Record<string | symbol, unknown>} **/
    // @ts-expect-error
    n.__attributes ??= {
      [si]: n.nodeName.includes("-"),
      [ni]: n.namespaceURI === Oe
    }
  );
}
var Bt = /* @__PURE__ */ new Map();
function oi(n) {
  var t = n.getAttribute("is") || n.nodeName, e = Bt.get(t);
  if (e) return e;
  Bt.set(t, e = []);
  for (var i, s = n, r = Element.prototype; r !== s; ) {
    i = Ce(s);
    for (var o in i)
      i[o].set && e.push(o);
    s = he(s);
  }
  return e;
}
function zt(n, t) {
  return n === t || n?.[De] === t;
}
function li(n = {}, t, e, i) {
  return Te(() => {
    var s, r;
    return Be(() => {
      s = r, r = [], V(() => {
        n !== e(...r) && (t(n, ...r), s && zt(e(...s), n) && t(null, ...s));
      });
    }), () => {
      ze(() => {
        r && zt(e(...r), n) && t(null, ...r);
      });
    };
  }), n;
}
function hi(n, t, e) {
  if (n == null)
    return t(void 0), $e;
  const i = V(
    () => n.subscribe(
      t,
      // @ts-expect-error
      e
    )
  );
  return i.unsubscribe ? () => i.unsubscribe() : i;
}
function ai(n) {
  let t;
  return hi(n, (e) => t = e)(), t;
}
const fi = {
  get(n, t) {
    if (!n.exclude.includes(t))
      return n.props[t];
  },
  set(n, t) {
    return !1;
  },
  getOwnPropertyDescriptor(n, t) {
    if (!n.exclude.includes(t) && t in n.props)
      return {
        enumerable: !0,
        configurable: !0,
        value: n.props[t]
      };
  },
  has(n, t) {
    return n.exclude.includes(t) ? !1 : t in n.props;
  },
  ownKeys(n) {
    return Reflect.ownKeys(n.props).filter((t) => !n.exclude.includes(t));
  }
};
// @__NO_SIDE_EFFECTS__
function ci(n, t, e) {
  return new Proxy(
    { props: n, exclude: t },
    fi
  );
}
function A(n, t, e, i) {
  var s = (
    /** @type {V} */
    i
  ), r = !0, o = () => (r && (r = !1, s = /** @type {V} */
  i), s), l;
  l = /** @type {V} */
  n[t], l === void 0 && i !== void 0 && (l = o());
  var a;
  return a = () => {
    var f = (
      /** @type {V} */
      n[t]
    );
    return f === void 0 ? o() : (r = !0, f);
  }, a;
}
je();
function de(n) {
  Z === null && fe(), Fe && Z.l !== null ? di(Z).m.push(n) : K(() => {
    const t = V(n);
    if (typeof t == "function") return (
      /** @type {() => void} */
      t
    );
  });
}
function ui(n) {
  Z === null && fe(), de(() => () => V(n));
}
function di(n) {
  var t = (
    /** @type {ComponentContextLegacy} */
    n.l
  );
  return t.u ??= { a: [], b: [], m: [] };
}
var pi = /* @__PURE__ */ St('<span class="svelte-1gprlt0"> </span>'), gi = /* @__PURE__ */ St("<button><!> <div><!> <!></div></button>");
function yi(n, t) {
  let e = A(t, "label", 3, ""), i = A(t, "show_label", 3, !1), s = A(t, "pending", 3, !1), r = A(t, "size", 3, "small"), o = A(t, "padded", 3, !0), l = A(t, "highlight", 3, !1), a = A(t, "disabled", 3, !1), f = A(t, "hasPopup", 3, !1), d = A(t, "color", 3, "var(--block-label-text-color)"), h = A(t, "transparent", 3, !1), c = A(t, "background", 3, "var(--block-background-fill)"), u = A(t, "border", 3, "transparent"), y = et(() => l() ? "var(--color-accent)" : d());
  var g = gi();
  let _;
  g.__click = function(...b) {
    t.onclick?.apply(this, b);
  };
  let p;
  var m = tt(g);
  {
    var v = (b) => {
      var S = pi(), I = tt(S);
      gt(() => Ge(I, e())), H(b, S);
    };
    Nt(m, (b) => {
      i() && b(v);
    });
  }
  var x = Rt(m, 2);
  let w;
  var E = tt(x);
  Ze(E, () => t.Icon, (b, S) => {
    S(b, {});
  });
  var R = Rt(E, 2);
  {
    var M = (b) => {
      var S = Ve(), I = Ke(S);
      Je(I, () => t.children), H(b, S);
    };
    Nt(R, (b) => {
      t.children && b(M);
    });
  }
  gt(() => {
    _ = Tt(g, 1, "icon-button svelte-1gprlt0", null, _, {
      pending: s(),
      padded: o(),
      highlight: l(),
      transparent: h()
    }), g.disabled = a(), st(g, "aria-label", e()), st(g, "aria-haspopup", f()), st(g, "title", e()), p = ii(g, "", p, {
      "--border-color": u(),
      color: !a() && L(y) ? L(y) : "var(--block-label-text-color)",
      "--bg-color": a() ? "auto" : c()
    }), w = Tt(x, 1, "svelte-1gprlt0", null, w, {
      "x-small": r() === "x-small",
      small: r() === "small",
      large: r() === "large",
      medium: r() === "medium"
    });
  }), H(n, g);
}
ae(["click"]);
const mi = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], Dt = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
mi.reduce((n, { color: t, primary: e, secondary: i }) => ({
  ...n,
  [t]: {
    primary: Dt[t][e],
    secondary: Dt[t][i]
  }
}), {});
function _i(n) {
  let t;
  const e = Ye((s) => {
    let r = !1;
    const o = n.subscribe((l) => {
      t = l, r && s();
    });
    return r = !0, o;
  });
  function i() {
    return He() ? (e(), t) : ai(n);
  }
  return "set" in n ? {
    get current() {
      return i();
    },
    set current(s) {
      n.set(s);
    }
  } : {
    get current() {
      return i();
    }
  };
}
const xi = "__i18n__", bi = [
  "label",
  "info",
  "placeholder",
  "description",
  "title",
  "value"
], vi = [
  "elem_id",
  "elem_classes",
  "visible",
  "interactive",
  "server_fns",
  "server",
  "id",
  "target",
  "theme_mode",
  "version",
  "root",
  "autoscroll",
  "max_file_size",
  "formatter",
  "client",
  "load_component",
  "scale",
  "min_width",
  "theme",
  "padding",
  "loading_status",
  "label",
  "show_label",
  "validation_error",
  "show_progress",
  "api_prefix",
  "container",
  "attached_events",
  "register_component",
  "dispatcher"
];
function wi(n) {
  return typeof n == "string" && n.includes(xi);
}
class Ei {
  load_component;
  #t = q(At({}));
  get shared() {
    return L(this.#t);
  }
  set shared(t) {
    W(this.#t, t, !0);
  }
  #e = q(At({}));
  get props() {
    return L(this.#e);
  }
  set props(t) {
    W(this.#e, t, !0);
  }
  #i = q((t) => t);
  get i18n() {
    return L(this.#i);
  }
  set i18n(t) {
    W(this.#i, t, !0);
  }
  i18n_store;
  _i18n_from_store;
  translatable_props = {};
  dispatcher;
  last_update = null;
  shared_props = vi;
  mounted = !1;
  old_value;
  register_component;
  constructor(t, e) {
    for (const i in t.shared_props)
      this.shared[i] = t.shared_props[i];
    for (const i in t.props)
      i !== "i18n_store" && (this.props[i] = t.props[i]);
    if (e)
      for (const i in e)
        this.props[i] === void 0 && (this.props[i] = e[i]);
    this.i18n = this.props.i18n ?? ((i) => i), this.i18n_store = t.props.i18n_store, this._i18n_from_store = this.i18n_store ? _i(this.i18n_store) : void 0;
    for (const i of bi)
      this.shared[i] = this._translate_and_store(
        "shared",
        i,
        // @ts-ignore
        t.shared_props[i]
      ), this.props[i] = this._translate_and_store(
        "props",
        i,
        // @ts-ignore
        t.props[i]
      );
    this.load_component = this.shared.load_component, this.register_component = this.shared.register_component || (() => {
    }), this.dispatcher = this.shared.dispatcher || (() => {
    }), this.register_component(
      t.shared_props.id,
      // @ts-ignore
      this.set_data.bind(this),
      this.get_data.bind(this)
    ), K(() => {
      for (const i in t.shared_props)
        this._is_i18n_managed(`shared.${i}`, t.shared_props[i]) || (this.shared[i] = t.shared_props[i]);
      for (const i in t.props)
        i !== "i18n_store" && (this._is_i18n_managed(`props.${i}`, t.props[i]) || (this.props[i] = t.props[i]));
      this.register_component(
        t.shared_props.id,
        // @ts-ignore
        this.set_data.bind(this),
        this.get_data.bind(this)
      ), V(() => {
        this.shared.id = t.shared_props.id;
      });
    }), K(() => this.i18n_store ? this.i18n_store.subscribe(() => {
      for (const [s, r] of Object.entries(this.translatable_props)) {
        const [o, l] = s.split("."), a = this.i18n(r);
        o === "shared" ? this.shared[l] = a : this.props[l] = a;
      }
    }) : void 0);
  }
  // check if props are translatable
  _is_i18n_managed(t, e) {
    const i = this.translatable_props[t];
    return i ? e === i ? !0 : (delete this.translatable_props[t], !1) : !1;
  }
  _translate_and_store(t, e, i) {
    if (typeof i != "string") return i;
    const s = this.i18n(i);
    return s !== i && (this.translatable_props[`${t}.${e}`] = i), s;
  }
  // Reactive variant of `i18n`. Reading it inside a derived or template
  // subscribes to the live locale store (via Svelte's createSubscriber), so
  // the caller re-runs when the locale changes at runtime. The store is only
  // the reactivity trigger; translation always goes through `this.i18n` so a
  // custom formatter passed via props keeps taking effect.
  live_i18n = (t) => (this._i18n_from_store?.current, this.i18n(t));
  dispatch(t, e) {
    this.dispatcher(this.shared.id, t, e);
  }
  async get_data() {
    return Xe(this.props);
  }
  update(t) {
    this.set_data(t);
  }
  set_data(t) {
    for (const e in t) {
      const i = t[e], s = wi(i) ? this._translate_and_store(this.shared_props.includes(e) ? "shared" : "props", e, i) : i;
      if (this.shared_props.includes(e)) {
        const r = e;
        this.shared[r] = s;
        continue;
      }
      this.props[e] = s;
    }
  }
  watch_for_change() {
    K(() => {
      this.mounted || (this.old_value = this.props.value, this.mounted = !0), this.old_value != this.props.value && (this.old_value = this.props.value, this.dispatch("change"));
    });
  }
}
ae(["click"]);
const $t = "canvas-host", Si = "canvas-host-request";
function Mi(n, t) {
  const e = (i) => {
    const s = i.detail;
    s.id === n && t(s);
  };
  return window.addEventListener($t, e), window.dispatchEvent(
    new CustomEvent(Si, { detail: { canvas_id: n, resolve: t } })
  ), () => window.removeEventListener($t, e);
}
class j {
  constructor(t, e) {
    this.next = null, this.key = t, this.data = e, this.left = null, this.right = null;
  }
}
function ki(n, t) {
  return n > t ? 1 : n < t ? -1 : 0;
}
function z(n, t, e) {
  const i = new j(null, null);
  let s = i, r = i;
  for (; ; ) {
    const o = e(n, t.key);
    if (o < 0) {
      if (t.left === null) break;
      if (e(n, t.left.key) < 0) {
        const l = t.left;
        if (t.left = l.right, l.right = t, t = l, t.left === null) break;
      }
      r.left = t, r = t, t = t.left;
    } else if (o > 0) {
      if (t.right === null) break;
      if (e(n, t.right.key) > 0) {
        const l = t.right;
        if (t.right = l.left, l.left = t, t = l, t.right === null) break;
      }
      s.right = t, s = t, t = t.right;
    } else break;
  }
  return s.right = t.left, r.left = t.right, t.left = i.right, t.right = i.left, t;
}
function ct(n, t, e, i) {
  const s = new j(n, t);
  if (e === null)
    return s.left = s.right = null, s;
  e = z(n, e, i);
  const r = i(n, e.key);
  return r < 0 ? (s.left = e.left, s.right = e, e.left = null) : r >= 0 && (s.right = e.right, s.left = e, e.right = null), s;
}
function jt(n, t, e) {
  let i = null, s = null;
  if (t) {
    t = z(n, t, e);
    const r = e(t.key, n);
    r === 0 ? (i = t.left, s = t.right) : r < 0 ? (s = t.right, t.right = null, i = t) : (i = t.left, t.left = null, s = t);
  }
  return { left: i, right: s };
}
function Ii(n, t, e) {
  return t === null ? n : (n === null || (t = z(n.key, t, e), t.left = n), t);
}
function yt(n, t, e, i, s) {
  if (n) {
    i(`${t}${e ? "└── " : "├── "}${s(n)}
`);
    const r = t + (e ? "    " : "│   ");
    n.left && yt(n.left, r, !1, i, s), n.right && yt(n.right, r, !0, i, s);
  }
}
class kt {
  constructor(t = ki) {
    this._root = null, this._size = 0, this._comparator = t;
  }
  /**
   * Inserts a key, allows duplicates
   */
  insert(t, e) {
    return this._size++, this._root = ct(t, e, this._root, this._comparator);
  }
  /**
   * Adds a key, if it is not present in the tree
   */
  add(t, e) {
    const i = new j(t, e);
    this._root === null && (i.left = i.right = null, this._size++, this._root = i);
    const s = this._comparator, r = z(t, this._root, s), o = s(t, r.key);
    return o === 0 ? this._root = r : (o < 0 ? (i.left = r.left, i.right = r, r.left = null) : o > 0 && (i.right = r.right, i.left = r, r.right = null), this._size++, this._root = i), this._root;
  }
  /**
   * @param  {Key} key
   * @return {Node|null}
   */
  remove(t) {
    this._root = this._remove(t, this._root, this._comparator);
  }
  /**
   * Deletes i from the tree if it's there
   */
  _remove(t, e, i) {
    let s;
    return e === null ? null : (e = z(t, e, i), i(t, e.key) === 0 ? (e.left === null ? s = e.right : (s = z(t, e.left, i), s.right = e.right), this._size--, s) : e);
  }
  /**
   * Removes and returns the node with smallest key
   */
  pop() {
    let t = this._root;
    if (t) {
      for (; t.left; ) t = t.left;
      return this._root = z(t.key, this._root, this._comparator), this._root = this._remove(t.key, this._root, this._comparator), { key: t.key, data: t.data };
    }
    return null;
  }
  /**
   * Find without splaying
   */
  findStatic(t) {
    let e = this._root;
    const i = this._comparator;
    for (; e; ) {
      const s = i(t, e.key);
      if (s === 0) return e;
      s < 0 ? e = e.left : e = e.right;
    }
    return null;
  }
  find(t) {
    return this._root && (this._root = z(t, this._root, this._comparator), this._comparator(t, this._root.key) !== 0) ? null : this._root;
  }
  contains(t) {
    let e = this._root;
    const i = this._comparator;
    for (; e; ) {
      const s = i(t, e.key);
      if (s === 0) return !0;
      s < 0 ? e = e.left : e = e.right;
    }
    return !1;
  }
  forEach(t, e) {
    let i = this._root;
    const s = [];
    let r = !1;
    for (; !r; )
      i !== null ? (s.push(i), i = i.left) : s.length !== 0 ? (i = s.pop(), t.call(e, i), i = i.right) : r = !0;
    return this;
  }
  /**
   * Walk key range from `low` to `high`. Stops if `fn` returns a value.
   */
  range(t, e, i, s) {
    const r = [], o = this._comparator;
    let l = this._root, a;
    for (; r.length !== 0 || l; )
      if (l)
        r.push(l), l = l.left;
      else {
        if (l = r.pop(), a = o(l.key, e), a > 0)
          break;
        if (o(l.key, t) >= 0 && i.call(s, l))
          return this;
        l = l.right;
      }
    return this;
  }
  /**
   * Returns array of keys
   */
  keys() {
    const t = [];
    return this.forEach(({ key: e }) => {
      t.push(e);
    }), t;
  }
  /**
   * Returns array of all the data in the nodes
   */
  values() {
    const t = [];
    return this.forEach(({ data: e }) => {
      t.push(e);
    }), t;
  }
  min() {
    return this._root ? this.minNode(this._root).key : null;
  }
  max() {
    return this._root ? this.maxNode(this._root).key : null;
  }
  minNode(t = this._root) {
    if (t) for (; t.left; ) t = t.left;
    return t;
  }
  maxNode(t = this._root) {
    if (t) for (; t.right; ) t = t.right;
    return t;
  }
  /**
   * Returns node at given index
   */
  at(t) {
    let e = this._root, i = !1, s = 0;
    const r = [];
    for (; !i; )
      if (e)
        r.push(e), e = e.left;
      else if (r.length > 0) {
        if (e = r.pop(), s === t) return e;
        s++, e = e.right;
      } else i = !0;
    return null;
  }
  next(t) {
    let e = this._root, i = null;
    if (t.right) {
      for (i = t.right; i.left; ) i = i.left;
      return i;
    }
    const s = this._comparator;
    for (; e; ) {
      const r = s(t.key, e.key);
      if (r === 0) break;
      r < 0 ? (i = e, e = e.left) : e = e.right;
    }
    return i;
  }
  prev(t) {
    let e = this._root, i = null;
    if (t.left !== null) {
      for (i = t.left; i.right; ) i = i.right;
      return i;
    }
    const s = this._comparator;
    for (; e; ) {
      const r = s(t.key, e.key);
      if (r === 0) break;
      r < 0 ? e = e.left : (i = e, e = e.right);
    }
    return i;
  }
  clear() {
    return this._root = null, this._size = 0, this;
  }
  toList() {
    return Li(this._root);
  }
  /**
   * Bulk-load items. Both array have to be same size
   */
  load(t, e = [], i = !1) {
    let s = t.length;
    const r = this._comparator;
    if (i && xt(t, e, 0, s - 1, r), this._root === null)
      this._root = mt(t, e, 0, s), this._size = s;
    else {
      const o = Ri(
        this.toList(),
        Pi(t, e),
        r
      );
      s = this._size + s, this._root = _t({ head: o }, 0, s);
    }
    return this;
  }
  isEmpty() {
    return this._root === null;
  }
  get size() {
    return this._size;
  }
  get root() {
    return this._root;
  }
  toString(t = (e) => String(e.key)) {
    const e = [];
    return yt(this._root, "", !0, (i) => e.push(i), t), e.join("");
  }
  update(t, e, i) {
    const s = this._comparator;
    let { left: r, right: o } = jt(t, this._root, s);
    s(t, e) < 0 ? o = ct(e, i, o, s) : r = ct(e, i, r, s), this._root = Ii(r, o, s);
  }
  split(t) {
    return jt(t, this._root, this._comparator);
  }
  *[Symbol.iterator]() {
    let t = this._root;
    const e = [];
    let i = !1;
    for (; !i; )
      t !== null ? (e.push(t), t = t.left) : e.length !== 0 ? (t = e.pop(), yield t, t = t.right) : i = !0;
  }
}
function mt(n, t, e, i) {
  const s = i - e;
  if (s > 0) {
    const r = e + Math.floor(s / 2), o = n[r], l = t[r], a = new j(o, l);
    return a.left = mt(n, t, e, r), a.right = mt(n, t, r + 1, i), a;
  }
  return null;
}
function Pi(n, t) {
  const e = new j(null, null);
  let i = e;
  for (let s = 0; s < n.length; s++)
    i = i.next = new j(n[s], t[s]);
  return i.next = null, e.next;
}
function Li(n) {
  let t = n;
  const e = [];
  let i = !1;
  const s = new j(null, null);
  let r = s;
  for (; !i; )
    t ? (e.push(t), t = t.left) : e.length > 0 ? (t = r = r.next = e.pop(), t = t.right) : i = !0;
  return r.next = null, s.next;
}
function _t(n, t, e) {
  const i = e - t;
  if (i > 0) {
    const s = t + Math.floor(i / 2), r = _t(n, t, s), o = n.head;
    return o.left = r, n.head = n.head.next, o.right = _t(n, s + 1, e), o;
  }
  return null;
}
function Ri(n, t, e) {
  const i = new j(null, null);
  let s = i, r = n, o = t;
  for (; r !== null && o !== null; )
    e(r.key, o.key) < 0 ? (s.next = r, r = r.next) : (s.next = o, o = o.next), s = s.next;
  return r !== null ? s.next = r : o !== null && (s.next = o), i.next;
}
function xt(n, t, e, i, s) {
  if (e >= i) return;
  const r = n[e + i >> 1];
  let o = e - 1, l = i + 1;
  for (; ; ) {
    do
      o++;
    while (s(n[o], r) < 0);
    do
      l--;
    while (s(n[l], r) > 0);
    if (o >= l) break;
    let a = n[o];
    n[o] = n[l], n[l] = a, a = t[o], t[o] = t[l], t[l] = a;
  }
  xt(n, t, e, l, s), xt(n, t, l + 1, i, s);
}
const B = 11102230246251565e-32, k = 134217729, Ai = (3 + 8 * B) * B;
function ut(n, t, e, i, s) {
  let r, o, l, a, f = t[0], d = i[0], h = 0, c = 0;
  d > f == d > -f ? (r = f, f = t[++h]) : (r = d, d = i[++c]);
  let u = 0;
  if (h < n && c < e)
    for (d > f == d > -f ? (o = f + r, l = r - (o - f), f = t[++h]) : (o = d + r, l = r - (o - d), d = i[++c]), r = o, l !== 0 && (s[u++] = l); h < n && c < e; )
      d > f == d > -f ? (o = r + f, a = o - r, l = r - (o - a) + (f - a), f = t[++h]) : (o = r + d, a = o - r, l = r - (o - a) + (d - a), d = i[++c]), r = o, l !== 0 && (s[u++] = l);
  for (; h < n; )
    o = r + f, a = o - r, l = r - (o - a) + (f - a), f = t[++h], r = o, l !== 0 && (s[u++] = l);
  for (; c < e; )
    o = r + d, a = o - r, l = r - (o - a) + (d - a), d = i[++c], r = o, l !== 0 && (s[u++] = l);
  return (r !== 0 || u === 0) && (s[u++] = r), u;
}
function Ni(n, t) {
  let e = t[0];
  for (let i = 1; i < n; i++) e += t[i];
  return e;
}
function J(n) {
  return new Float64Array(n);
}
const Oi = (3 + 16 * B) * B, Ci = (2 + 12 * B) * B, Ti = (9 + 64 * B) * B * B, G = J(4), Ft = J(8), Gt = J(12), Kt = J(16), P = J(4);
function Bi(n, t, e, i, s, r, o) {
  let l, a, f, d, h, c, u, y, g, _, p, m, v, x, w, E, R, M;
  const b = n - s, S = e - s, I = t - r, O = i - r;
  x = b * O, c = k * b, u = c - (c - b), y = b - u, c = k * O, g = c - (c - O), _ = O - g, w = y * _ - (x - u * g - y * g - u * _), E = I * S, c = k * I, u = c - (c - I), y = I - u, c = k * S, g = c - (c - S), _ = S - g, R = y * _ - (E - u * g - y * g - u * _), p = w - R, h = w - p, G[0] = w - (p + h) + (h - R), m = x + p, h = m - x, v = x - (m - h) + (p - h), p = v - E, h = v - p, G[1] = v - (p + h) + (h - E), M = m + p, h = M - m, G[2] = m - (M - h) + (p - h), G[3] = M;
  let T = Ni(4, G), Y = Ci * o;
  if (T >= Y || -T >= Y || (h = n - b, l = n - (b + h) + (h - s), h = e - S, f = e - (S + h) + (h - s), h = t - I, a = t - (I + h) + (h - r), h = i - O, d = i - (O + h) + (h - r), l === 0 && a === 0 && f === 0 && d === 0) || (Y = Ti * o + Ai * Math.abs(T), T += b * d + O * l - (I * f + S * a), T >= Y || -T >= Y)) return T;
  x = l * O, c = k * l, u = c - (c - l), y = l - u, c = k * O, g = c - (c - O), _ = O - g, w = y * _ - (x - u * g - y * g - u * _), E = a * S, c = k * a, u = c - (c - a), y = a - u, c = k * S, g = c - (c - S), _ = S - g, R = y * _ - (E - u * g - y * g - u * _), p = w - R, h = w - p, P[0] = w - (p + h) + (h - R), m = x + p, h = m - x, v = x - (m - h) + (p - h), p = v - E, h = v - p, P[1] = v - (p + h) + (h - E), M = m + p, h = M - m, P[2] = m - (M - h) + (p - h), P[3] = M;
  const xe = ut(4, G, 4, P, Ft);
  x = b * d, c = k * b, u = c - (c - b), y = b - u, c = k * d, g = c - (c - d), _ = d - g, w = y * _ - (x - u * g - y * g - u * _), E = I * f, c = k * I, u = c - (c - I), y = I - u, c = k * f, g = c - (c - f), _ = f - g, R = y * _ - (E - u * g - y * g - u * _), p = w - R, h = w - p, P[0] = w - (p + h) + (h - R), m = x + p, h = m - x, v = x - (m - h) + (p - h), p = v - E, h = v - p, P[1] = v - (p + h) + (h - E), M = m + p, h = M - m, P[2] = m - (M - h) + (p - h), P[3] = M;
  const be = ut(xe, Ft, 4, P, Gt);
  x = l * d, c = k * l, u = c - (c - l), y = l - u, c = k * d, g = c - (c - d), _ = d - g, w = y * _ - (x - u * g - y * g - u * _), E = a * f, c = k * a, u = c - (c - a), y = a - u, c = k * f, g = c - (c - f), _ = f - g, R = y * _ - (E - u * g - y * g - u * _), p = w - R, h = w - p, P[0] = w - (p + h) + (h - R), m = x + p, h = m - x, v = x - (m - h) + (p - h), p = v - E, h = v - p, P[1] = v - (p + h) + (h - E), M = m + p, h = M - m, P[2] = m - (M - h) + (p - h), P[3] = M;
  const ve = ut(be, Gt, 4, P, Kt);
  return Kt[ve - 1];
}
function zi(n, t, e, i, s, r) {
  const o = (t - r) * (e - s), l = (n - s) * (i - r), a = o - l, f = Math.abs(o + l);
  return Math.abs(a) >= Oi * f ? a : -Bi(n, t, e, i, s, r, f);
}
const U = (n, t) => n.ll.x <= t.x && t.x <= n.ur.x && n.ll.y <= t.y && t.y <= n.ur.y, bt = (n, t) => {
  if (t.ur.x < n.ll.x || n.ur.x < t.ll.x || t.ur.y < n.ll.y || n.ur.y < t.ll.y) return null;
  const e = n.ll.x < t.ll.x ? t.ll.x : n.ll.x, i = n.ur.x < t.ur.x ? n.ur.x : t.ur.x, s = n.ll.y < t.ll.y ? t.ll.y : n.ll.y, r = n.ur.y < t.ur.y ? n.ur.y : t.ur.y;
  return {
    ll: {
      x: e,
      y: s
    },
    ur: {
      x: i,
      y: r
    }
  };
};
let D = Number.EPSILON;
D === void 0 && (D = Math.pow(2, -52));
const Di = D * D, Ht = (n, t) => {
  if (-D < n && n < D && -D < t && t < D)
    return 0;
  const e = n - t;
  return e * e < Di * n * t ? 0 : n < t ? -1 : 1;
};
class $i {
  constructor() {
    this.reset();
  }
  reset() {
    this.xRounder = new Yt(), this.yRounder = new Yt();
  }
  round(t, e) {
    return {
      x: this.xRounder.round(t),
      y: this.yRounder.round(e)
    };
  }
}
class Yt {
  constructor() {
    this.tree = new kt(), this.round(0);
  }
  // Note: this can rounds input values backwards or forwards.
  //       You might ask, why not restrict this to just rounding
  //       forwards? Wouldn't that allow left endpoints to always
  //       remain left endpoints during splitting (never change to
  //       right). No - it wouldn't, because we snap intersections
  //       to endpoints (to establish independence from the segment
  //       angle for t-intersections).
  round(t) {
    const e = this.tree.add(t), i = this.tree.prev(e);
    if (i !== null && Ht(e.key, i.key) === 0)
      return this.tree.remove(t), i.key;
    const s = this.tree.next(e);
    return s !== null && Ht(e.key, s.key) === 0 ? (this.tree.remove(t), s.key) : t;
  }
}
const Q = new $i(), nt = (n, t) => n.x * t.y - n.y * t.x, pe = (n, t) => n.x * t.x + n.y * t.y, Ut = (n, t, e) => {
  const i = zi(n.x, n.y, t.x, t.y, e.x, e.y);
  return i > 0 ? -1 : i < 0 ? 1 : 0;
}, lt = (n) => Math.sqrt(pe(n, n)), ji = (n, t, e) => {
  const i = {
    x: t.x - n.x,
    y: t.y - n.y
  }, s = {
    x: e.x - n.x,
    y: e.y - n.y
  };
  return nt(s, i) / lt(s) / lt(i);
}, Fi = (n, t, e) => {
  const i = {
    x: t.x - n.x,
    y: t.y - n.y
  }, s = {
    x: e.x - n.x,
    y: e.y - n.y
  };
  return pe(s, i) / lt(s) / lt(i);
}, qt = (n, t, e) => t.y === 0 ? null : {
  x: n.x + t.x / t.y * (e - n.y),
  y: e
}, Wt = (n, t, e) => t.x === 0 ? null : {
  x: e,
  y: n.y + t.y / t.x * (e - n.x)
}, Gi = (n, t, e, i) => {
  if (t.x === 0) return Wt(e, i, n.x);
  if (i.x === 0) return Wt(n, t, e.x);
  if (t.y === 0) return qt(e, i, n.y);
  if (i.y === 0) return qt(n, t, e.y);
  const s = nt(t, i);
  if (s == 0) return null;
  const r = {
    x: e.x - n.x,
    y: e.y - n.y
  }, o = nt(r, t) / s, l = nt(r, i) / s, a = n.x + l * t.x, f = e.x + o * i.x, d = n.y + l * t.y, h = e.y + o * i.y, c = (a + f) / 2, u = (d + h) / 2;
  return {
    x: c,
    y: u
  };
};
class N {
  // for ordering sweep events in the sweep event queue
  static compare(t, e) {
    const i = N.comparePoints(t.point, e.point);
    return i !== 0 ? i : (t.point !== e.point && t.link(e), t.isLeft !== e.isLeft ? t.isLeft ? 1 : -1 : $.compare(t.segment, e.segment));
  }
  // for ordering points in sweep line order
  static comparePoints(t, e) {
    return t.x < e.x ? -1 : t.x > e.x ? 1 : t.y < e.y ? -1 : t.y > e.y ? 1 : 0;
  }
  // Warning: 'point' input will be modified and re-used (for performance)
  constructor(t, e) {
    t.events === void 0 ? t.events = [this] : t.events.push(this), this.point = t, this.isLeft = e;
  }
  link(t) {
    if (t.point === this.point)
      throw new Error("Tried to link already linked events");
    const e = t.point.events;
    for (let i = 0, s = e.length; i < s; i++) {
      const r = e[i];
      this.point.events.push(r), r.point = this.point;
    }
    this.checkForConsuming();
  }
  /* Do a pass over our linked events and check to see if any pair
   * of segments match, and should be consumed. */
  checkForConsuming() {
    const t = this.point.events.length;
    for (let e = 0; e < t; e++) {
      const i = this.point.events[e];
      if (i.segment.consumedBy === void 0)
        for (let s = e + 1; s < t; s++) {
          const r = this.point.events[s];
          r.consumedBy === void 0 && i.otherSE.point.events === r.otherSE.point.events && i.segment.consume(r.segment);
        }
    }
  }
  getAvailableLinkedEvents() {
    const t = [];
    for (let e = 0, i = this.point.events.length; e < i; e++) {
      const s = this.point.events[e];
      s !== this && !s.segment.ringOut && s.segment.isInResult() && t.push(s);
    }
    return t;
  }
  /**
   * Returns a comparator function for sorting linked events that will
   * favor the event that will give us the smallest left-side angle.
   * All ring construction starts as low as possible heading to the right,
   * so by always turning left as sharp as possible we'll get polygons
   * without uncessary loops & holes.
   *
   * The comparator function has a compute cache such that it avoids
   * re-computing already-computed values.
   */
  getLeftmostComparator(t) {
    const e = /* @__PURE__ */ new Map(), i = (s) => {
      const r = s.otherSE;
      e.set(s, {
        sine: ji(this.point, t.point, r.point),
        cosine: Fi(this.point, t.point, r.point)
      });
    };
    return (s, r) => {
      e.has(s) || i(s), e.has(r) || i(r);
      const {
        sine: o,
        cosine: l
      } = e.get(s), {
        sine: a,
        cosine: f
      } = e.get(r);
      return o >= 0 && a >= 0 ? l < f ? 1 : l > f ? -1 : 0 : o < 0 && a < 0 ? l < f ? -1 : l > f ? 1 : 0 : a < o ? -1 : a > o ? 1 : 0;
    };
  }
}
let Ki = 0;
class $ {
  /* This compare() function is for ordering segments in the sweep
   * line tree, and does so according to the following criteria:
   *
   * Consider the vertical line that lies an infinestimal step to the
   * right of the right-more of the two left endpoints of the input
   * segments. Imagine slowly moving a point up from negative infinity
   * in the increasing y direction. Which of the two segments will that
   * point intersect first? That segment comes 'before' the other one.
   *
   * If neither segment would be intersected by such a line, (if one
   * or more of the segments are vertical) then the line to be considered
   * is directly on the right-more of the two left inputs.
   */
  static compare(t, e) {
    const i = t.leftSE.point.x, s = e.leftSE.point.x, r = t.rightSE.point.x, o = e.rightSE.point.x;
    if (o < i) return 1;
    if (r < s) return -1;
    const l = t.leftSE.point.y, a = e.leftSE.point.y, f = t.rightSE.point.y, d = e.rightSE.point.y;
    if (i < s) {
      if (a < l && a < f) return 1;
      if (a > l && a > f) return -1;
      const h = t.comparePoint(e.leftSE.point);
      if (h < 0) return 1;
      if (h > 0) return -1;
      const c = e.comparePoint(t.rightSE.point);
      return c !== 0 ? c : -1;
    }
    if (i > s) {
      if (l < a && l < d) return -1;
      if (l > a && l > d) return 1;
      const h = e.comparePoint(t.leftSE.point);
      if (h !== 0) return h;
      const c = t.comparePoint(e.rightSE.point);
      return c < 0 ? 1 : c > 0 ? -1 : 1;
    }
    if (l < a) return -1;
    if (l > a) return 1;
    if (r < o) {
      const h = e.comparePoint(t.rightSE.point);
      if (h !== 0) return h;
    }
    if (r > o) {
      const h = t.comparePoint(e.rightSE.point);
      if (h < 0) return 1;
      if (h > 0) return -1;
    }
    if (r !== o) {
      const h = f - l, c = r - i, u = d - a, y = o - s;
      if (h > c && u < y) return 1;
      if (h < c && u > y) return -1;
    }
    return r > o ? 1 : r < o || f < d ? -1 : f > d ? 1 : t.id < e.id ? -1 : t.id > e.id ? 1 : 0;
  }
  /* Warning: a reference to ringWindings input will be stored,
   *  and possibly will be later modified */
  constructor(t, e, i, s) {
    this.id = ++Ki, this.leftSE = t, t.segment = this, t.otherSE = e, this.rightSE = e, e.segment = this, e.otherSE = t, this.rings = i, this.windings = s;
  }
  static fromRing(t, e, i) {
    let s, r, o;
    const l = N.comparePoints(t, e);
    if (l < 0)
      s = t, r = e, o = 1;
    else if (l > 0)
      s = e, r = t, o = -1;
    else throw new Error(`Tried to create degenerate segment at [${t.x}, ${t.y}]`);
    const a = new N(s, !0), f = new N(r, !1);
    return new $(a, f, [i], [o]);
  }
  /* When a segment is split, the rightSE is replaced with a new sweep event */
  replaceRightSE(t) {
    this.rightSE = t, this.rightSE.segment = this, this.rightSE.otherSE = this.leftSE, this.leftSE.otherSE = this.rightSE;
  }
  bbox() {
    const t = this.leftSE.point.y, e = this.rightSE.point.y;
    return {
      ll: {
        x: this.leftSE.point.x,
        y: t < e ? t : e
      },
      ur: {
        x: this.rightSE.point.x,
        y: t > e ? t : e
      }
    };
  }
  /* A vector from the left point to the right */
  vector() {
    return {
      x: this.rightSE.point.x - this.leftSE.point.x,
      y: this.rightSE.point.y - this.leftSE.point.y
    };
  }
  isAnEndpoint(t) {
    return t.x === this.leftSE.point.x && t.y === this.leftSE.point.y || t.x === this.rightSE.point.x && t.y === this.rightSE.point.y;
  }
  /* Compare this segment with a point.
   *
   * A point P is considered to be colinear to a segment if there
   * exists a distance D such that if we travel along the segment
   * from one * endpoint towards the other a distance D, we find
   * ourselves at point P.
   *
   * Return value indicates:
   *
   *   1: point lies above the segment (to the left of vertical)
   *   0: point is colinear to segment
   *  -1: point lies below the segment (to the right of vertical)
   */
  comparePoint(t) {
    if (this.isAnEndpoint(t)) return 0;
    const e = this.leftSE.point, i = this.rightSE.point, s = this.vector();
    if (e.x === i.x)
      return t.x === e.x ? 0 : t.x < e.x ? 1 : -1;
    const r = (t.y - e.y) / s.y, o = e.x + r * s.x;
    if (t.x === o) return 0;
    const l = (t.x - e.x) / s.x, a = e.y + l * s.y;
    return t.y === a ? 0 : t.y < a ? -1 : 1;
  }
  /**
   * Given another segment, returns the first non-trivial intersection
   * between the two segments (in terms of sweep line ordering), if it exists.
   *
   * A 'non-trivial' intersection is one that will cause one or both of the
   * segments to be split(). As such, 'trivial' vs. 'non-trivial' intersection:
   *
   *   * endpoint of segA with endpoint of segB --> trivial
   *   * endpoint of segA with point along segB --> non-trivial
   *   * endpoint of segB with point along segA --> non-trivial
   *   * point along segA with point along segB --> non-trivial
   *
   * If no non-trivial intersection exists, return null
   * Else, return null.
   */
  getIntersection(t) {
    const e = this.bbox(), i = t.bbox(), s = bt(e, i);
    if (s === null) return null;
    const r = this.leftSE.point, o = this.rightSE.point, l = t.leftSE.point, a = t.rightSE.point, f = U(e, l) && this.comparePoint(l) === 0, d = U(i, r) && t.comparePoint(r) === 0, h = U(e, a) && this.comparePoint(a) === 0, c = U(i, o) && t.comparePoint(o) === 0;
    if (d && f)
      return c && !h ? o : !c && h ? a : null;
    if (d)
      return h && r.x === a.x && r.y === a.y ? null : r;
    if (f)
      return c && o.x === l.x && o.y === l.y ? null : l;
    if (c && h) return null;
    if (c) return o;
    if (h) return a;
    const u = Gi(r, this.vector(), l, t.vector());
    return u === null || !U(s, u) ? null : Q.round(u.x, u.y);
  }
  /**
   * Split the given segment into multiple segments on the given points.
   *  * Each existing segment will retain its leftSE and a new rightSE will be
   *    generated for it.
   *  * A new segment will be generated which will adopt the original segment's
   *    rightSE, and a new leftSE will be generated for it.
   *  * If there are more than two points given to split on, new segments
   *    in the middle will be generated with new leftSE and rightSE's.
   *  * An array of the newly generated SweepEvents will be returned.
   *
   * Warning: input array of points is modified
   */
  split(t) {
    const e = [], i = t.events !== void 0, s = new N(t, !0), r = new N(t, !1), o = this.rightSE;
    this.replaceRightSE(r), e.push(r), e.push(s);
    const l = new $(s, o, this.rings.slice(), this.windings.slice());
    return N.comparePoints(l.leftSE.point, l.rightSE.point) > 0 && l.swapEvents(), N.comparePoints(this.leftSE.point, this.rightSE.point) > 0 && this.swapEvents(), i && (s.checkForConsuming(), r.checkForConsuming()), e;
  }
  /* Swap which event is left and right */
  swapEvents() {
    const t = this.rightSE;
    this.rightSE = this.leftSE, this.leftSE = t, this.leftSE.isLeft = !0, this.rightSE.isLeft = !1;
    for (let e = 0, i = this.windings.length; e < i; e++)
      this.windings[e] *= -1;
  }
  /* Consume another segment. We take their rings under our wing
   * and mark them as consumed. Use for perfectly overlapping segments */
  consume(t) {
    let e = this, i = t;
    for (; e.consumedBy; ) e = e.consumedBy;
    for (; i.consumedBy; ) i = i.consumedBy;
    const s = $.compare(e, i);
    if (s !== 0) {
      if (s > 0) {
        const r = e;
        e = i, i = r;
      }
      if (e.prev === i) {
        const r = e;
        e = i, i = r;
      }
      for (let r = 0, o = i.rings.length; r < o; r++) {
        const l = i.rings[r], a = i.windings[r], f = e.rings.indexOf(l);
        f === -1 ? (e.rings.push(l), e.windings.push(a)) : e.windings[f] += a;
      }
      i.rings = null, i.windings = null, i.consumedBy = e, i.leftSE.consumedBy = e.leftSE, i.rightSE.consumedBy = e.rightSE;
    }
  }
  /* The first segment previous segment chain that is in the result */
  prevInResult() {
    return this._prevInResult !== void 0 ? this._prevInResult : (this.prev ? this.prev.isInResult() ? this._prevInResult = this.prev : this._prevInResult = this.prev.prevInResult() : this._prevInResult = null, this._prevInResult);
  }
  beforeState() {
    if (this._beforeState !== void 0) return this._beforeState;
    if (!this.prev) this._beforeState = {
      rings: [],
      windings: [],
      multiPolys: []
    };
    else {
      const t = this.prev.consumedBy || this.prev;
      this._beforeState = t.afterState();
    }
    return this._beforeState;
  }
  afterState() {
    if (this._afterState !== void 0) return this._afterState;
    const t = this.beforeState();
    this._afterState = {
      rings: t.rings.slice(0),
      windings: t.windings.slice(0),
      multiPolys: []
    };
    const e = this._afterState.rings, i = this._afterState.windings, s = this._afterState.multiPolys;
    for (let l = 0, a = this.rings.length; l < a; l++) {
      const f = this.rings[l], d = this.windings[l], h = e.indexOf(f);
      h === -1 ? (e.push(f), i.push(d)) : i[h] += d;
    }
    const r = [], o = [];
    for (let l = 0, a = e.length; l < a; l++) {
      if (i[l] === 0) continue;
      const f = e[l], d = f.poly;
      if (o.indexOf(d) === -1)
        if (f.isExterior) r.push(d);
        else {
          o.indexOf(d) === -1 && o.push(d);
          const h = r.indexOf(f.poly);
          h !== -1 && r.splice(h, 1);
        }
    }
    for (let l = 0, a = r.length; l < a; l++) {
      const f = r[l].multiPoly;
      s.indexOf(f) === -1 && s.push(f);
    }
    return this._afterState;
  }
  /* Is this segment part of the final result? */
  isInResult() {
    if (this.consumedBy) return !1;
    if (this._isInResult !== void 0) return this._isInResult;
    const t = this.beforeState().multiPolys, e = this.afterState().multiPolys;
    switch (C.type) {
      case "union": {
        const i = t.length === 0, s = e.length === 0;
        this._isInResult = i !== s;
        break;
      }
      case "intersection": {
        let i, s;
        t.length < e.length ? (i = t.length, s = e.length) : (i = e.length, s = t.length), this._isInResult = s === C.numMultiPolys && i < s;
        break;
      }
      case "xor": {
        const i = Math.abs(t.length - e.length);
        this._isInResult = i % 2 === 1;
        break;
      }
      case "difference": {
        const i = (s) => s.length === 1 && s[0].isSubject;
        this._isInResult = i(t) !== i(e);
        break;
      }
      default:
        throw new Error(`Unrecognized operation type found ${C.type}`);
    }
    return this._isInResult;
  }
}
class Xt {
  constructor(t, e, i) {
    if (!Array.isArray(t) || t.length === 0)
      throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
    if (this.poly = e, this.isExterior = i, this.segments = [], typeof t[0][0] != "number" || typeof t[0][1] != "number")
      throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
    const s = Q.round(t[0][0], t[0][1]);
    this.bbox = {
      ll: {
        x: s.x,
        y: s.y
      },
      ur: {
        x: s.x,
        y: s.y
      }
    };
    let r = s;
    for (let o = 1, l = t.length; o < l; o++) {
      if (typeof t[o][0] != "number" || typeof t[o][1] != "number")
        throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
      let a = Q.round(t[o][0], t[o][1]);
      a.x === r.x && a.y === r.y || (this.segments.push($.fromRing(r, a, this)), a.x < this.bbox.ll.x && (this.bbox.ll.x = a.x), a.y < this.bbox.ll.y && (this.bbox.ll.y = a.y), a.x > this.bbox.ur.x && (this.bbox.ur.x = a.x), a.y > this.bbox.ur.y && (this.bbox.ur.y = a.y), r = a);
    }
    (s.x !== r.x || s.y !== r.y) && this.segments.push($.fromRing(r, s, this));
  }
  getSweepEvents() {
    const t = [];
    for (let e = 0, i = this.segments.length; e < i; e++) {
      const s = this.segments[e];
      t.push(s.leftSE), t.push(s.rightSE);
    }
    return t;
  }
}
class Hi {
  constructor(t, e) {
    if (!Array.isArray(t))
      throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
    this.exteriorRing = new Xt(t[0], this, !0), this.bbox = {
      ll: {
        x: this.exteriorRing.bbox.ll.x,
        y: this.exteriorRing.bbox.ll.y
      },
      ur: {
        x: this.exteriorRing.bbox.ur.x,
        y: this.exteriorRing.bbox.ur.y
      }
    }, this.interiorRings = [];
    for (let i = 1, s = t.length; i < s; i++) {
      const r = new Xt(t[i], this, !1);
      r.bbox.ll.x < this.bbox.ll.x && (this.bbox.ll.x = r.bbox.ll.x), r.bbox.ll.y < this.bbox.ll.y && (this.bbox.ll.y = r.bbox.ll.y), r.bbox.ur.x > this.bbox.ur.x && (this.bbox.ur.x = r.bbox.ur.x), r.bbox.ur.y > this.bbox.ur.y && (this.bbox.ur.y = r.bbox.ur.y), this.interiorRings.push(r);
    }
    this.multiPoly = e;
  }
  getSweepEvents() {
    const t = this.exteriorRing.getSweepEvents();
    for (let e = 0, i = this.interiorRings.length; e < i; e++) {
      const s = this.interiorRings[e].getSweepEvents();
      for (let r = 0, o = s.length; r < o; r++)
        t.push(s[r]);
    }
    return t;
  }
}
class Qt {
  constructor(t, e) {
    if (!Array.isArray(t))
      throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
    try {
      typeof t[0][0][0] == "number" && (t = [t]);
    } catch {
    }
    this.polys = [], this.bbox = {
      ll: {
        x: Number.POSITIVE_INFINITY,
        y: Number.POSITIVE_INFINITY
      },
      ur: {
        x: Number.NEGATIVE_INFINITY,
        y: Number.NEGATIVE_INFINITY
      }
    };
    for (let i = 0, s = t.length; i < s; i++) {
      const r = new Hi(t[i], this);
      r.bbox.ll.x < this.bbox.ll.x && (this.bbox.ll.x = r.bbox.ll.x), r.bbox.ll.y < this.bbox.ll.y && (this.bbox.ll.y = r.bbox.ll.y), r.bbox.ur.x > this.bbox.ur.x && (this.bbox.ur.x = r.bbox.ur.x), r.bbox.ur.y > this.bbox.ur.y && (this.bbox.ur.y = r.bbox.ur.y), this.polys.push(r);
    }
    this.isSubject = e;
  }
  getSweepEvents() {
    const t = [];
    for (let e = 0, i = this.polys.length; e < i; e++) {
      const s = this.polys[e].getSweepEvents();
      for (let r = 0, o = s.length; r < o; r++)
        t.push(s[r]);
    }
    return t;
  }
}
class ht {
  /* Given the segments from the sweep line pass, compute & return a series
   * of closed rings from all the segments marked to be part of the result */
  static factory(t) {
    const e = [];
    for (let i = 0, s = t.length; i < s; i++) {
      const r = t[i];
      if (!r.isInResult() || r.ringOut) continue;
      let o = null, l = r.leftSE, a = r.rightSE;
      const f = [l], d = l.point, h = [];
      for (; o = l, l = a, f.push(l), l.point !== d; )
        for (; ; ) {
          const c = l.getAvailableLinkedEvents();
          if (c.length === 0) {
            const g = f[0].point, _ = f[f.length - 1].point;
            throw new Error(`Unable to complete output ring starting at [${g.x}, ${g.y}]. Last matching segment found ends at [${_.x}, ${_.y}].`);
          }
          if (c.length === 1) {
            a = c[0].otherSE;
            break;
          }
          let u = null;
          for (let g = 0, _ = h.length; g < _; g++)
            if (h[g].point === l.point) {
              u = g;
              break;
            }
          if (u !== null) {
            const g = h.splice(u)[0], _ = f.splice(g.index);
            _.unshift(_[0].otherSE), e.push(new ht(_.reverse()));
            continue;
          }
          h.push({
            index: f.length,
            point: l.point
          });
          const y = l.getLeftmostComparator(o);
          a = c.sort(y)[0].otherSE;
          break;
        }
      e.push(new ht(f));
    }
    return e;
  }
  constructor(t) {
    this.events = t;
    for (let e = 0, i = t.length; e < i; e++)
      t[e].segment.ringOut = this;
    this.poly = null;
  }
  getGeom() {
    let t = this.events[0].point;
    const e = [t];
    for (let f = 1, d = this.events.length - 1; f < d; f++) {
      const h = this.events[f].point, c = this.events[f + 1].point;
      Ut(h, t, c) !== 0 && (e.push(h), t = h);
    }
    if (e.length === 1) return null;
    const i = e[0], s = e[1];
    Ut(i, t, s) === 0 && e.shift(), e.push(e[0]);
    const r = this.isExteriorRing() ? 1 : -1, o = this.isExteriorRing() ? 0 : e.length - 1, l = this.isExteriorRing() ? e.length : -1, a = [];
    for (let f = o; f != l; f += r) a.push([e[f].x, e[f].y]);
    return a;
  }
  isExteriorRing() {
    if (this._isExteriorRing === void 0) {
      const t = this.enclosingRing();
      this._isExteriorRing = t ? !t.isExteriorRing() : !0;
    }
    return this._isExteriorRing;
  }
  enclosingRing() {
    return this._enclosingRing === void 0 && (this._enclosingRing = this._calcEnclosingRing()), this._enclosingRing;
  }
  /* Returns the ring that encloses this one, if any */
  _calcEnclosingRing() {
    let t = this.events[0];
    for (let s = 1, r = this.events.length; s < r; s++) {
      const o = this.events[s];
      N.compare(t, o) > 0 && (t = o);
    }
    let e = t.segment.prevInResult(), i = e ? e.prevInResult() : null;
    for (; ; ) {
      if (!e) return null;
      if (!i) return e.ringOut;
      if (i.ringOut !== e.ringOut)
        return i.ringOut.enclosingRing() !== e.ringOut ? e.ringOut : e.ringOut.enclosingRing();
      e = i.prevInResult(), i = e ? e.prevInResult() : null;
    }
  }
}
class Vt {
  constructor(t) {
    this.exteriorRing = t, t.poly = this, this.interiorRings = [];
  }
  addInterior(t) {
    this.interiorRings.push(t), t.poly = this;
  }
  getGeom() {
    const t = [this.exteriorRing.getGeom()];
    if (t[0] === null) return null;
    for (let e = 0, i = this.interiorRings.length; e < i; e++) {
      const s = this.interiorRings[e].getGeom();
      s !== null && t.push(s);
    }
    return t;
  }
}
class Yi {
  constructor(t) {
    this.rings = t, this.polys = this._composePolys(t);
  }
  getGeom() {
    const t = [];
    for (let e = 0, i = this.polys.length; e < i; e++) {
      const s = this.polys[e].getGeom();
      s !== null && t.push(s);
    }
    return t;
  }
  _composePolys(t) {
    const e = [];
    for (let i = 0, s = t.length; i < s; i++) {
      const r = t[i];
      if (!r.poly)
        if (r.isExteriorRing()) e.push(new Vt(r));
        else {
          const o = r.enclosingRing();
          o.poly || e.push(new Vt(o)), o.poly.addInterior(r);
        }
    }
    return e;
  }
}
class Ui {
  constructor(t) {
    let e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : $.compare;
    this.queue = t, this.tree = new kt(e), this.segments = [];
  }
  process(t) {
    const e = t.segment, i = [];
    if (t.consumedBy)
      return t.isLeft ? this.queue.remove(t.otherSE) : this.tree.remove(e), i;
    const s = t.isLeft ? this.tree.add(e) : this.tree.find(e);
    if (!s) throw new Error(`Unable to find segment #${e.id} [${e.leftSE.point.x}, ${e.leftSE.point.y}] -> [${e.rightSE.point.x}, ${e.rightSE.point.y}] in SweepLine tree.`);
    let r = s, o = s, l, a;
    for (; l === void 0; )
      r = this.tree.prev(r), r === null ? l = null : r.key.consumedBy === void 0 && (l = r.key);
    for (; a === void 0; )
      o = this.tree.next(o), o === null ? a = null : o.key.consumedBy === void 0 && (a = o.key);
    if (t.isLeft) {
      let f = null;
      if (l) {
        const h = l.getIntersection(e);
        if (h !== null && (e.isAnEndpoint(h) || (f = h), !l.isAnEndpoint(h))) {
          const c = this._splitSafely(l, h);
          for (let u = 0, y = c.length; u < y; u++)
            i.push(c[u]);
        }
      }
      let d = null;
      if (a) {
        const h = a.getIntersection(e);
        if (h !== null && (e.isAnEndpoint(h) || (d = h), !a.isAnEndpoint(h))) {
          const c = this._splitSafely(a, h);
          for (let u = 0, y = c.length; u < y; u++)
            i.push(c[u]);
        }
      }
      if (f !== null || d !== null) {
        let h = null;
        f === null ? h = d : d === null ? h = f : h = N.comparePoints(f, d) <= 0 ? f : d, this.queue.remove(e.rightSE), i.push(e.rightSE);
        const c = e.split(h);
        for (let u = 0, y = c.length; u < y; u++)
          i.push(c[u]);
      }
      i.length > 0 ? (this.tree.remove(e), i.push(t)) : (this.segments.push(e), e.prev = l);
    } else {
      if (l && a) {
        const f = l.getIntersection(a);
        if (f !== null) {
          if (!l.isAnEndpoint(f)) {
            const d = this._splitSafely(l, f);
            for (let h = 0, c = d.length; h < c; h++)
              i.push(d[h]);
          }
          if (!a.isAnEndpoint(f)) {
            const d = this._splitSafely(a, f);
            for (let h = 0, c = d.length; h < c; h++)
              i.push(d[h]);
          }
        }
      }
      this.tree.remove(e);
    }
    return i;
  }
  /* Safely split a segment that is currently in the datastructures
   * IE - a segment other than the one that is currently being processed. */
  _splitSafely(t, e) {
    this.tree.remove(t);
    const i = t.rightSE;
    this.queue.remove(i);
    const s = t.split(e);
    return s.push(i), t.consumedBy === void 0 && this.tree.add(t), s;
  }
}
const Jt = typeof process < "u" && process.env.POLYGON_CLIPPING_MAX_QUEUE_SIZE || 1e6, qi = typeof process < "u" && process.env.POLYGON_CLIPPING_MAX_SWEEPLINE_SEGMENTS || 1e6;
class Wi {
  run(t, e, i) {
    C.type = t, Q.reset();
    const s = [new Qt(e, !0)];
    for (let h = 0, c = i.length; h < c; h++)
      s.push(new Qt(i[h], !1));
    if (C.numMultiPolys = s.length, C.type === "difference") {
      const h = s[0];
      let c = 1;
      for (; c < s.length; )
        bt(s[c].bbox, h.bbox) !== null ? c++ : s.splice(c, 1);
    }
    if (C.type === "intersection")
      for (let h = 0, c = s.length; h < c; h++) {
        const u = s[h];
        for (let y = h + 1, g = s.length; y < g; y++)
          if (bt(u.bbox, s[y].bbox) === null) return [];
      }
    const r = new kt(N.compare);
    for (let h = 0, c = s.length; h < c; h++) {
      const u = s[h].getSweepEvents();
      for (let y = 0, g = u.length; y < g; y++)
        if (r.insert(u[y]), r.size > Jt)
          throw new Error("Infinite loop when putting segment endpoints in a priority queue (queue size too big).");
    }
    const o = new Ui(r);
    let l = r.size, a = r.pop();
    for (; a; ) {
      const h = a.key;
      if (r.size === l) {
        const u = h.segment;
        throw new Error(`Unable to pop() ${h.isLeft ? "left" : "right"} SweepEvent [${h.point.x}, ${h.point.y}] from segment #${u.id} [${u.leftSE.point.x}, ${u.leftSE.point.y}] -> [${u.rightSE.point.x}, ${u.rightSE.point.y}] from queue.`);
      }
      if (r.size > Jt)
        throw new Error("Infinite loop when passing sweep line over endpoints (queue size too big).");
      if (o.segments.length > qi)
        throw new Error("Infinite loop when passing sweep line over endpoints (too many sweep line segments).");
      const c = o.process(h);
      for (let u = 0, y = c.length; u < y; u++) {
        const g = c[u];
        g.consumedBy === void 0 && r.insert(g);
      }
      l = r.size, a = r.pop();
    }
    Q.reset();
    const f = ht.factory(o.segments);
    return new Yi(f).getGeom();
  }
}
const C = new Wi(), Xi = function(n) {
  for (var t = arguments.length, e = new Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++)
    e[i - 1] = arguments[i];
  return C.run("union", n, e);
}, Qi = function(n) {
  for (var t = arguments.length, e = new Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++)
    e[i - 1] = arguments[i];
  return C.run("intersection", n, e);
}, Vi = function(n) {
  for (var t = arguments.length, e = new Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++)
    e[i - 1] = arguments[i];
  return C.run("xor", n, e);
}, Ji = function(n) {
  for (var t = arguments.length, e = new Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++)
    e[i - 1] = arguments[i];
  return C.run("difference", n, e);
};
var X = {
  union: Xi,
  intersection: Qi,
  xor: Vi,
  difference: Ji
};
function Zt(n, t) {
  const e = n.length;
  return t === 0 ? n : n.map((i, s) => {
    const r = Math.min(t, s, e - 1 - s);
    let [o, l] = [0, 0];
    for (let f = s - r; f <= s + r; f++)
      o += n[f][0], l += n[f][1];
    const a = 2 * r + 1;
    return [o / a, l / a];
  });
}
function Zi(n, t, e) {
  const [i, s] = n, [r, o] = [t[0] - i, t[1] - s], l = Math.PI / 4, a = Math.round(Math.atan2(o, r) / l) * l, f = Math.round(Math.cos(a) * 1e9) / 1e9, d = Math.round(Math.sin(a) * 1e9) / 1e9;
  let h = r * f + o * d;
  return f > 0 && (h = Math.min(h, (e.width - i) / f)), f < 0 && (h = Math.min(h, -i / f)), d > 0 && (h = Math.min(h, (e.height - s) / d)), d < 0 && (h = Math.min(h, -s / d)), h = Math.max(0, h), [i + f * h, s + d * h];
}
function ge(n) {
  const [t, ...e] = n.map((i) => [i]);
  return X.xor(t, ...e);
}
function ye(n) {
  const t = n.flatMap(
    (e) => e.map((i) => i.slice(0, -1).map(([s, r]) => [s, r]))
  );
  return t.length ? t : null;
}
const ts = {
  add: X.union,
  subtract: X.difference,
  intersect: X.intersection
};
function es(n, t, e) {
  try {
    return ye(ts[e](ge(n), [t]));
  } catch (i) {
    return console.warn("Lasso tool couldn't combine lassos:", i), null;
  }
}
function is(n, t) {
  const e = [
    [0, 0],
    [t.width, 0],
    [t.width, t.height],
    [0, t.height]
  ];
  return n ? ye(X.difference([e], ge(n))) : [e];
}
function te(n) {
  return n && n.map((t) => t.map(([e, i]) => [Math.round(e), Math.round(i)]));
}
function ee(n, t, e) {
  return Math.max(t, Math.min(e, n));
}
const dt = 3, ie = 10, se = 1, ss = 8, ns = 500, me = /Mac|iPhone|iPad/.test(navigator.userAgent);
function _e(n) {
  return me ? n.metaKey : n.ctrlKey;
}
const ne = '<path d="M7 22a5 5 0 0 1-2-3.994"/><circle cx="5" cy="16" r="2"/>', rs = {
  freehand: '<path d="M3.704 14.467a10 8 0 1 1 3.115 2.375"/>' + ne,
  // Hexagon inscribed in the freehand loop, a corner on the knot.
  polygonal: '<path d="M4.35 14.11 2.3 8.2 9.1 2.3l9.7 1.9 2.9 7.6-6.8 5.9-7.93-1.36"/>' + ne
}, os = {
  add: '<path d="M22 26h8M26 22v8"/>',
  subtract: '<path d="M22 26h8"/>',
  intersect: '<path d="M23 23l6 6M29 23l-6 6"/>',
  close: '<circle cx="26" cy="26" r="3"/>'
}, re = /* @__PURE__ */ new Map();
function ls(n, t) {
  const e = `${n} ${t}`, i = re.get(e);
  if (i) return i;
  const s = rs[n] + (t ? os[t] : ""), r = t ? 24 : 16, o = r * 1.5, l = `<svg xmlns="http://www.w3.org/2000/svg" width="${r}" height="${r}" viewBox="0 0 ${o} ${o}" fill="none" stroke-linecap="round" stroke-linejoin="round"><g stroke="white" stroke-width="4">${s}</g><g stroke="black" stroke-width="2">${s}</g></svg>`, a = `url("data:image/svg+xml,${encodeURIComponent(l)}") 5 15, crosshair`;
  return re.set(e, a), a;
}
const hs = `
	:host {
		position: absolute;
		display: none;
		z-index: 1;
		touch-action: none;
		user-select: none;
	}

	:host([hidden]) {
		display: none !important;
	}

	/* Cursor changes as overlay gets enabled, for browser to show it at once. */
	:host([disabled]) {
		pointer-events: none;
		cursor: auto;
	}

	svg {
		position: absolute;
		inset: 0;
		width: 100%;
		height: 100%;
		overflow: visible;
		pointer-events: none;
	}

	polyline,
	path {
		display: none;
		fill: none;
		stroke-width: 1px;
	}

	#draft {
		stroke: var(--lasso-tool-color, var(--color-accent, #f97316));
	}

	/* Marching ants: black dashes over a white line. */
	#lasso {
		stroke: white;
	}

	#ants {
		stroke: black;
		stroke-dasharray: 4 4;
		animation: march 0.6s linear infinite;
	}

	:host([static]) #ants {
		animation: none;
	}

	@keyframes march {
		to {
			stroke-dashoffset: -8;
		}
	}
`;
class as extends HTMLElement {
  #t = null;
  /** As drawn, kept intact while browsing images. */
  #e = null;
  /** Resolution of the image lasso was drawn over. */
  #i = null;
  /** Last lasso user cleared, which they may select back, and its resolution. */
  #o = null;
  #f;
  #d;
  #p;
  /** Last emitted value, as JSON, to emit only changes. */
  #M = "null";
  /**
   * Element lasso is drawn within, e.g. the canvas: a drawing leaving it
   * is in fact a drag of image to another element.
   */
  area = null;
  /** Element image shows in, letterbox bands included, which take clicks while drawing. Null for the parent. */
  bands = null;
  /** Neighbors each vertex of freehand segments is averaged with on each side, to smooth the hand's jitter. */
  smoothing = 1;
  #l = "freehand";
  #N = !1;
  #j = ["", ""];
  /** Pointer pressed: not moved yet, dragged, or dragging the image away. */
  #s = null;
  /** Whether an outline is being drawn, pointer pressed or not. */
  #n = !1;
  /** Whether this drag started the outline, which leaving the area drops then. */
  #O = !1;
  /** What lasso being drawn does to the current one, if not replace it. */
  #x = null;
  /** Operation of the shortcut held while pointer is over overlay, if any. */
  #C = null;
  /** Where user pressed, in client pixels, to tell a click from a move. */
  #T = null;
  /** Where user pressed, in image pixels. */
  #F = null;
  /** Lasso as it was when user started drawing, back if user cancels. */
  #k = null;
  /** Vertices of the outline being drawn, applied to the current lasso once closed. */
  #a = null;
  /** Draft length at the end of each segment, back to which Delete goes. */
  #b = [];
  /** Whether pointer draws a freehand segment, else a straight one. */
  #r = !1;
  /** Index of the first vertex of the freehand segment being drawn. */
  #I = 0;
  /** End of the straight segment being drawn, where pointer is. */
  #g = null;
  /** Where pointer is, in client and in image pixels, and keys held then. */
  #v = null;
  #B = null;
  #z = null;
  /** Last click while drawing, to tell a double-click. */
  #P = null;
  /** Element outside overlay that pointer is over, while user drags image. */
  #c = null;
  /** Whether drop target accepts displayed image. */
  #D = !1;
  #L = null;
  #Y = new ResizeObserver(() => this.#G());
  #U = () => this.#G();
  /** Tell what a drag would do, as user presses or releases a shortcut. */
  #$ = (t) => {
    if (!this.matches(":hover")) {
      this.#Q();
      return;
    }
    t.key === "Alt" && t.preventDefault(), this.#K(t);
  };
  /**
   * While user draws: Escape cancels, Delete removes the last segment, and
   * modifiers change the segment being drawn. Captured before others, e.g.
   * the canvas, which leaves fullscreen on Escape.
   */
  #q = (t) => {
    const e = t.type === "keydown";
    if (e && t.key === "Escape") {
      t.preventDefault(), t.stopPropagation(), this.#m();
      return;
    }
    if (e && (t.key === "Delete" || t.key === "Backspace")) {
      this.#dt() && (t.preventDefault(), t.stopPropagation());
      return;
    }
    if (["Shift", "Alt", "Control", "Meta"].includes(t.key)) {
      if (t.key === "Alt" && t.preventDefault(), !e && t.key === "Alt" && this.#l === "freehand" && this.#n && !this.#s && !this.#r) {
        this.#S();
        return;
      }
      this.#v && this.#E(this.#v, t);
    }
  };
  /** Pointer moves anywhere while user presses or draws. */
  #rt = (t) => {
    this.#E([t.clientX, t.clientY], t);
  };
  /** Clicks on letterbox bands add vertices too while drawing, clamped to image. */
  #ot = (t) => {
    const e = t.target, i = this.bands ?? this.parentElement;
    this.#n && e !== this && i?.contains(e) && this.#V(t);
  };
  constructor() {
    super();
    const t = this.attachShadow({ mode: "open" }), e = document.createElement("style");
    e.textContent = hs;
    const i = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    i.innerHTML = '<path id="lasso"></path><path id="ants"></path><polyline id="draft"></polyline>', this.#f = i.querySelector("#draft"), this.#d = i.querySelector("#lasso"), this.#p = i.querySelector("#ants"), t.append(e, i), this.addEventListener("pointerenter", (s) => this.#at(s)), this.addEventListener("pointerleave", () => this.#Q()), this.addEventListener("pointerdown", (s) => this.#V(s)), this.addEventListener("pointermove", (s) => this.#y || this.#K(s)), this.addEventListener("pointerup", (s) => this.#ft(s)), this.addEventListener("pointercancel", () => this.#y && this.#m());
  }
  /**
   * Image to draw the lasso over. Lasso persists when another image is
   * displayed, scaled to its resolution, so user finds it back while
   * browsing images.
   */
  get target() {
    return this.#t;
  }
  set target(t) {
    this.#t !== t && (this.#t && (this.#Y.unobserve(this.#t), this.#t.removeEventListener("load", this.#U)), this.#y && this.#m(), this.#t = t, t && (this.#Y.observe(t), t.addEventListener("load", this.#U))), this.#G();
  }
  /** How user draws. Changing it closes the outline being drawn, if any. */
  get mode() {
    return this.#l;
  }
  set mode(t) {
    t !== this.#l && (this.#et(), this.#l = t, this.#u());
  }
  /** Whether user can't draw. Disabling closes the outline being drawn, if any. */
  get disabled() {
    return this.#N;
  }
  set disabled(t) {
    t !== this.#N && (this.#et(), this.#N = t, this.toggleAttribute("disabled", t), this.#u());
  }
  /**
   * Tooltips shown over the image: while no lasso is drawn, e.g. to tell
   * how to draw one, then once drawn, e.g. to tell how to clear it.
   */
  get tooltips() {
    return this.#j;
  }
  set tooltips(t) {
    this.#j = t, this.#h();
  }
  /**
   * Lasso in pixels of the displayed image, scaled to it.
   * Setting it emits no event.
   */
  get value() {
    return this.#w();
  }
  set value(t) {
    this.#e = t && t.map((e) => e.map(([i, s]) => [i, s])), this.#i = F(this.#t) ?? this.#i, this.#M = JSON.stringify(te(this.#w())), this.#_(), this.#h();
  }
  /** Clear the lasso, which `reselect` brings back. */
  clear() {
    this.#y && this.#m(), this.#e && (this.#o = { lasso: this.#e, size: this.#i }), this.#e = null, this.#_(), this.#h(), this.#R();
  }
  /** Bring back the last lasso cleared, if any, in place of the current one. */
  reselect() {
    this.#y && this.#m(), this.#o && (this.#e = this.#o.lasso, this.#i = this.#o.size, this.#h(), this.#R());
  }
  /** Select what isn't, and only that: the whole image if nothing is. */
  invert() {
    this.#y && this.#m();
    const t = F(this.#t);
    if (!t) return;
    let e;
    try {
      e = is(this.#w(), t);
    } catch (i) {
      console.warn("Lasso tool couldn't invert lasso:", i);
      return;
    }
    if (!e) {
      this.clear();
      return;
    }
    this.#e = e, this.#i = t, this.#h(), this.#R();
  }
  /** Cover image content, letterbox bands excluded. */
  sync() {
    const t = this.#t, e = this.parentElement;
    if (!t?.isConnected || !e || !t.naturalWidth || !t.naturalHeight) {
      this.style.display = "none";
      return;
    }
    const i = t.getBoundingClientRect(), s = e.getBoundingClientRect(), r = Math.min(
      i.width / t.naturalWidth,
      i.height / t.naturalHeight
    ), o = t.naturalWidth * r, l = t.naturalHeight * r;
    if (o <= 0 || l <= 0) {
      this.style.display = "none";
      return;
    }
    const a = i.left - s.left - e.clientLeft + (i.width - o) / 2, f = i.top - s.top - e.clientTop + (i.height - l) / 2;
    this.style.display = "block", this.style.left = `${a}px`, this.style.top = `${f}px`, this.style.width = `${o}px`, this.style.height = `${l}px`;
  }
  /** Whether user presses or draws. */
  get #y() {
    return this.#s !== null || this.#n;
  }
  /** Follow displayed image, which may be another one or resized. */
  #G() {
    this.#i ??= F(this.#t), this.sync(), this.#h(), this.#R();
  }
  /**
   * Lasso scaled to displayed image, whose resolution may differ from the
   * drawn one, so it surrounds the same region.
   */
  #w() {
    const t = this.#e, e = F(this.#t);
    if (!t || !e || !this.#i) return t;
    const i = e.width / this.#i.width, s = e.height / this.#i.height;
    return t.map(
      (r) => r.map(([o, l]) => [o * i, l * s])
    );
  }
  /** Image point at client coordinates, clamped to image. */
  #W([t, e]) {
    const i = this.#t, s = this.getBoundingClientRect(), r = ee(t - s.left, 0, s.width), o = ee(e - s.top, 0, s.height);
    return [
      r / s.width * i.naturalWidth,
      o / s.height * i.naturalHeight
    ];
  }
  /** Distance between image points, in CSS pixels. */
  #lt([t, e], [i, s]) {
    const r = this.#t;
    return Math.hypot(
      (t - i) * this.clientWidth / r.naturalWidth,
      (e - s) * this.clientHeight / r.naturalHeight
    );
  }
  #h() {
    const t = this.#t, e = !!F(t), i = e ? this.#w() : null, s = e ? this.#ht() : null;
    this.title = this.#n ? "" : this.#j[i ? 1 : 0], this.#f.style.display = s ? "inline" : "none", s && this.#f.setAttribute("points", this.#X(s, t));
    for (const r of [this.#d, this.#p])
      r.style.display = i ? "inline" : "none", i && r.setAttribute(
        "d",
        i.map((o) => `M${this.#X(o, t)}Z`).join("")
      );
  }
  /**
   * Outline being drawn, as shown: freehand segment smoothed as on its end,
   * since last vertices settle as next ones come, or straight segment to
   * pointer.
   */
  #ht() {
    const t = this.#a;
    if (!this.#n || !t) return null;
    if (this.#r) {
      const e = this.#I;
      return [...t.slice(0, e), ...Zt(t.slice(e), this.#it())];
    }
    return this.#g ? [...t, this.#g] : t;
  }
  /** SVG points of vertices, in overlay pixels. */
  #X(t, e) {
    const i = this.clientWidth / e.naturalWidth, s = this.clientHeight / e.naturalHeight;
    return t.map(([r, o]) => `${r * i},${o * s}`).join(" ");
  }
  /** Emit value, if changed. */
  #R() {
    const t = te(this.#w()), e = JSON.stringify(t);
    e !== this.#M && (this.#M = e, this.dispatchEvent(new CustomEvent("lasso-change", { detail: t })));
  }
  #at(t) {
    window.addEventListener("keydown", this.#$, !0), window.addEventListener("keyup", this.#$, !0), this.#K(t);
  }
  #Q() {
    window.removeEventListener("keydown", this.#$, !0), window.removeEventListener("keyup", this.#$, !0), this.#C = null, this.#u();
  }
  #K(t) {
    const e = oe(t);
    e !== this.#C && (this.#C = e, this.#u());
  }
  /**
   * A press, unless an outline is being drawn, prepares one, which starts
   * as the pointer moves, or on release for a polygonal lasso. Shift held
   * then adds the lasso drawn to the current one, Alt subtracts it, and both
   * intersect it. Else it replaces the current one as it starts.
   */
  #V(t) {
    if (!this.#t || t.button !== 0 || this.#s) return;
    t.preventDefault(), t.stopPropagation();
    const e = [t.clientX, t.clientY], i = this.#W(e);
    this.#n || (this.#_(), this.#e = this.#w(), this.#i = F(this.#t), this.#k = this.#e, this.#x = oe(t), this.#a = [i], this.#b = [1], this.#st(!0)), this.#s = "press", this.#T = e, this.#F = i, this.setPointerCapture(t.pointerId), this.#E(e, t);
  }
  /**
   * Follow pointer, at `client`, or modifiers, as user presses or draws.
   *
   * A freehand lasso draws freehand while dragged, and straight segments
   * once released with Alt held: from then on, clicks with Alt held add
   * vertices, and releasing Alt while dragging goes freehand again.
   * A polygonal lasso draws straight segments to the pointer, and freehand
   * while dragged with Alt held. Shift snaps a straight segment to 45°.
   */
  #E(t, e) {
    if (this.#v = t, this.#z = e, this.#s === "drop") {
      this.#nt(t);
      return;
    }
    const i = this.#a;
    if (!this.#t || !i) return;
    const s = this.#W(t);
    this.#B = s;
    let r = !1;
    if (this.#s === "press") {
      const [o, l] = this.#T;
      Math.hypot(t[0] - o, t[1] - l) > ie && (this.#s = "drag", r = !0, this.#n || this.#Z(!0));
    }
    if (this.#s === "drag") {
      if (this.#O && this.#gt(t)) {
        this.#pt(), this.#nt(t);
        return;
      }
      const o = this.#l === "freehand" ? this.#r || !e.altKey : e.altKey;
      o && !this.#r ? this.#ut(r ? this.#F : this.#g ?? s) : !o && this.#r && this.#H();
    }
    if (this.#r) {
      const [o, l] = i[i.length - 1];
      Math.hypot(s[0] - o, s[1] - l) >= se && i.push(s);
    } else {
      const o = i[i.length - 1];
      this.#g = e.shiftKey ? Zi(o, s, F(this.#t)) : s;
    }
    this.#h(), this.#u();
  }
  /**
   * Release ends a click, which ends a straight segment, or a drag, which
   * ends a freehand one. A click on the first vertex closes the outline, as
   * do a double-click, a click with Ctrl (Cmd on macOS) held, which adds a
   * vertex first, and releasing a freehand lasso without Alt held.
   */
  #ft(t) {
    const e = this.#s;
    if (!e) return;
    if (this.#s = null, this.#O = !1, e === "drop") {
      this.#D && (this.#A(this.#c, "drop"), this.#c = null), this.#_();
      return;
    }
    if (!this.#n) {
      this.#l === "polygonal" ? (this.#Z(!1), this.#P = { time: t.timeStamp, at: this.#T }, this.#h(), this.#u()) : this.#x ? this.#_() : this.clear();
      return;
    }
    const i = [t.clientX, t.clientY];
    if (this.#r) {
      if (this.#l === "freehand" && !t.altKey) {
        this.#S();
        return;
      }
      this.#H(), this.#E(i, t);
      return;
    }
    if (this.#E(i, t), e === "press" && this.#ct(t.timeStamp, i)) {
      this.#S();
      return;
    }
    if (this.#J()) {
      this.#S();
      return;
    }
    if (this.#tt(this.#g), _e(t) || this.#l === "freehand" && !t.altKey) {
      this.#S();
      return;
    }
    this.#P = e === "press" ? { time: t.timeStamp, at: i } : null, this.#h(), this.#u();
  }
  #ct(t, [e, i]) {
    const s = this.#P;
    return !!s && t - s.time <= ns && Math.hypot(e - s.at[0], i - s.at[1]) <= ie;
  }
  /** Whether pointer is on the first vertex of an outline it can close. */
  #J() {
    const t = this.#a;
    return this.#n && !this.#r && !!t && !!this.#B && t.length >= dt && this.#lt(t[0], this.#B) <= ss;
  }
  /** Start drawing an outline, which replaces the current lasso at once if no shortcut was held. */
  #Z(t) {
    this.#n = !0, this.#O = t, this.#x || (this.#e = null), this.#l === "freehand" && (this.#I = 0, this.#r = !0);
  }
  /** Start a freehand segment, from `point`, after a straight one to it. */
  #ut(t) {
    this.#tt(t), this.#I = this.#a.length - 1, this.#r = !0, this.#g = null;
  }
  /** End the freehand segment, smoothed. */
  #H() {
    const t = this.#a, e = this.#I;
    t.splice(e, 1 / 0, ...Zt(t.slice(e), this.#it())), this.#b.push(t.length), this.#r = !1;
  }
  /** End a straight segment at a vertex. */
  #tt(t) {
    const e = this.#a, [i, s] = e[e.length - 1];
    Math.hypot(t[0] - i, t[1] - s) < se || (e.push(t), this.#b.push(e.length));
  }
  /** Remove the last segment, or cancel the outline if none is left. */
  #dt() {
    if (!this.#n || this.#r) return !1;
    this.#b.pop();
    const t = this.#b.at(-1);
    return t === void 0 ? this.#m() : (this.#a.length = t, this.#P = null, this.#v && this.#z && this.#E(this.#v, this.#z)), !0;
  }
  /** Close the outline being drawn, if any, else forget the press. */
  #et() {
    this.#n ? this.#S() : this.#s && this.#m();
  }
  /** Close the outline from its last vertex to its first, unless it encloses nothing, and apply it. */
  #S() {
    this.#r && this.#H();
    const t = this.#a, e = this.#x, i = this.#e, s = this.#k;
    if (this.#_(), e)
      t && t.length >= dt && (i ? this.#e = es(i, t, e) ?? i : this.#e = e === "add" ? [t] : null);
    else {
      if (!t || t.length < dt) {
        this.#e = s, this.clear();
        return;
      }
      this.#e = [t];
    }
    this.#h(), this.#R();
  }
  #it() {
    return Math.max(0, Math.floor(this.smoothing)) || 0;
  }
  /** Back to lasso as it was before user started drawing. */
  #m() {
    this.#y && this.#s !== "drop" && (this.#e = this.#k), this.#_(), this.#h();
  }
  /** Turn the drawing into a drag of the image. */
  #pt() {
    this.#s = "drop", this.#e = this.#k, this.#n = !1, this.#r = !1, this.#a = null, this.#g = null, this.#h();
  }
  /** Forget ongoing gesture and outline, if any. */
  #_() {
    this.#c && this.#A(this.#c, "dragleave"), this.#st(!1), this.#s = null, this.#n = !1, this.#O = !1, this.#x = null, this.#T = null, this.#F = null, this.#k = null, this.#a = null, this.#b = [], this.#r = !1, this.#I = 0, this.#g = null, this.#v = null, this.#B = null, this.#z = null, this.#P = null, this.#c = null, this.#D = !1, this.#L = null, this.#u();
  }
  /** Follow keys and pointer anywhere, while user presses or draws. */
  #st(t) {
    const e = (t ? window.addEventListener : window.removeEventListener).bind(window);
    e("keydown", this.#q, !0), e("keyup", this.#q, !0), e("pointermove", this.#rt, !0), e("pointerdown", this.#ot, !0);
  }
  /** Cursor of ongoing drop, if any, else of what a click or drag would do. */
  #u() {
    let t = "";
    if (this.#s === "drop")
      t = this.#D ? "copy" : "grabbing";
    else if (!this.#N) {
      const i = this.#y ? this.#x : this.#C;
      t = ls(this.#l, this.#J() ? "close" : i);
    }
    this.style.cursor = t;
    const e = this.bands ?? this.parentElement;
    e && (e.style.cursor = this.#n ? t : "");
  }
  /** Whether pointer left the area lasso is drawn within. */
  #gt([t, e]) {
    const i = (this.area ?? this).getBoundingClientRect();
    return t < i.left || t > i.right || e < i.top || e > i.bottom;
  }
  /**
   * Drag displayed image over the element pointer is over, outside overlay,
   * as browser would do. Overlay can't let browser drag the image itself:
   * it would take any drag over it, those drawing the lasso included.
   */
  #nt([t, e]) {
    const i = document.elementFromPoint(t, e), s = i === this ? null : i;
    s !== this.#c && (s && this.#A(s, "dragenter"), this.#c && this.#A(this.#c, "dragleave"), this.#c = s), this.#D = !!s && !this.#A(s, "dragover"), this.#u();
  }
  /** Returns false if canceled. */
  #A(t, e) {
    return this.#L || (this.#L = new DataTransfer(), this.#L.setData("text/uri-list", this.#t.currentSrc)), t.dispatchEvent(
      new DragEvent(e, {
        bubbles: !0,
        cancelable: !0,
        composed: !0,
        dataTransfer: this.#L
      })
    );
  }
}
function oe(n) {
  return n.shiftKey && n.altKey ? "intersect" : n.shiftKey ? "add" : n.altKey ? "subtract" : null;
}
function F(n) {
  return n?.naturalWidth && n.naturalHeight ? { width: n.naturalWidth, height: n.naturalHeight } : null;
}
const vt = "lasso-tool-overlay";
customElements.get(vt) || customElements.define(vt, as);
const le = /* @__PURE__ */ Symbol.for("gradio_lasso_tools.group");
function fs(n) {
  return n instanceof HTMLElement && (n.isContentEditable || ["INPUT", "TEXTAREA", "SELECT"].includes(n.tagName));
}
class It {
  constructor(t) {
    this.host = t, this.overlay = document.createElement(vt), t.doc_el.append(this.overlay), this.overlay.area = t.area, this.overlay.bands = t.frame, this.overlay.target = t.image, this.overlay.addEventListener("lasso-change", (e) => {
      const i = e.detail;
      for (const s of this.#t.values()) s.on_change(i, !0);
    }), t.addEventListener("tool-change", this.#i), window.addEventListener("keydown", this.#o);
  }
  host;
  overlay;
  #t = /* @__PURE__ */ new Map();
  /** Lasso tool user selected last, which L selects back. */
  #e = null;
  #i = () => this.refresh();
  /**
   * L selects the lasso tool user selected last, or the next one if a lasso
   * tool is selected, unless user types text with pointer away from the
   * canvas area.
   * While a lasso tool is selected, Ctrl+D (Cmd+D on macOS) clears the
   * selection, Ctrl+Shift+D selects it back, and Ctrl+Shift+I inverts it.
   */
  #o = (t) => {
    if (t.defaultPrevented || t.repeat || t.altKey || fs(t.target) && !this.host.area.matches(":hover"))
      return;
    const e = t.key.toLowerCase(), i = _e(t);
    (me ? t.ctrlKey : t.metaKey) || (!i && e === "l" ? this.#M(t) : i && (e === "d" || e === "i" && t.shiftKey) && this.#l(e, t));
  };
  /** Group of the lasso tools of a canvas. */
  static of(t) {
    const e = t;
    return e[le] ??= new It(t);
  }
  /** Add a tool, with its value, which is the selection unless null. */
  join(t, e) {
    this.#t.set(t.id, t), e ? this.set_value(t.id, e) : this.overlay.value && t.on_change(this.overlay.value, !1), this.refresh();
  }
  leave(t) {
    if (this.#t.delete(t), this.#t.size) {
      this.refresh();
      return;
    }
    this.host.removeEventListener("tool-change", this.#i), window.removeEventListener("keydown", this.#o), this.overlay.target = null, this.overlay.remove(), delete this.host[le];
  }
  /** Selection set by an event to a tool's value: the other tools follow. */
  set_value(t, e) {
    this.overlay.value = e;
    for (const i of this.#t.values())
      i.id !== t && i.on_change(e, !1);
  }
  /** Apply tool states, e.g. after one changed. */
  refresh() {
    const t = this.#f();
    t && (this.#e = t.id);
    const e = t ?? this.#d()[0], i = this.overlay;
    i.mode = t?.state.mode ?? i.mode, i.disabled = !t || !this.#p(t), i.hidden = ![...this.#t.values()].some((s) => s.state.visible), i.toggleAttribute("static", e?.state.marching_ants === !1), i.smoothing = e?.state.smoothing ?? 1, i.tooltips = e?.state.tooltips ?? ["", ""];
  }
  #f() {
    return this.host.tool === null ? void 0 : this.#t.get(this.host.tool);
  }
  /** Tools in the order they were given to canvas. */
  #d() {
    return this.host.tool_groups.flat().flatMap((t) => this.#t.get(t) ?? []);
  }
  #p(t) {
    return t.state.visible && t.state.interactive;
  }
  #M(t) {
    const e = this.#d().filter((r) => this.#p(r));
    if (!e.length) return;
    const i = this.#f(), s = i ? e[(e.indexOf(i) + 1) % e.length] : e.find((r) => r.id === this.#e) ?? e[0];
    t.preventDefault(), this.host.tool = s.id;
  }
  #l(t, e) {
    const i = this.#f();
    !i || !this.#p(i) || (e.preventDefault(), t === "i" ? this.overlay.invert() : e.shiftKey ? this.overlay.reselect() : this.overlay.clear());
  }
}
var cs = /* @__PURE__ */ ue('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3.704 14.467a10 8 0 1 1 3.115 2.375"></path><path d="M7 22a5 5 0 0 1-2-3.994"></path><circle cx="5" cy="16" r="2"></circle></svg>');
function us(n) {
  var t = cs();
  H(n, t);
}
var ds = /* @__PURE__ */ ue('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4.35 14.11 2.3 8.2 9.1 2.3l9.7 1.9 2.9 7.6-6.8 5.9-7.93-1.36"></path><path d="M7 22a5 5 0 0 1-2-3.994"></path><circle cx="5" cy="16" r="2"></circle></svg>');
function ps(n) {
  var t = ds();
  H(n, t);
}
var gs = /* @__PURE__ */ St("<div><!></div>");
function ms(n, t) {
  qe(t, !0);
  const e = /* @__PURE__ */ ci(t, ["$$slots", "$$events", "$$legacy"]), i = new Ei(e);
  let s, r = i.props.value ?? null, o = q(null), l = null, a = q(!1), f = null;
  const d = {
    id: i.shared.id,
    state: {
      mode: "freehand",
      visible: !0,
      interactive: !0,
      marching_ants: !0,
      smoothing: 1,
      tooltips: ["", ""]
    },
    on_change(p, m) {
      h(p, r) || (c(r, p), r = p, i.props.value = p, m && i.dispatch("input"), i.dispatch("change"));
    }
  };
  function h(p, m) {
    return JSON.stringify(p ?? null) === JSON.stringify(m ?? null);
  }
  function c(p, m) {
    !p && m ? i.dispatch("drawn") : p && !m && i.dispatch("cleared");
  }
  function u(p) {
    if (L(o)) return;
    W(o, p, !0), p.add_tool(i.shared.id, s), l = It.of(p), l.join(d, r);
    const m = () => {
      W(a, p.tool === i.shared.id);
    };
    p.addEventListener("tool-change", m), m();
  }
  function y() {
    L(o) && (L(o).tool = L(a) ? null : i.shared.id);
  }
  de(() => {
    s.parentElement && (s.parentElement.hidden = !0);
    const p = i.props.canvas_id;
    p !== null && (f = Mi(p, u));
  }), ui(() => {
    f?.(), l?.leave(i.shared.id);
  }), K(() => {
    const p = i.props.value ?? null;
    h(p, r) || (c(r, p), r = p, l?.set_value(i.shared.id, p), i.dispatch("change"));
  }), K(() => {
    d.state = {
      mode: i.props.polygonal ? "polygonal" : "freehand",
      visible: i.shared.visible !== !1,
      interactive: i.shared.interactive !== !1,
      marching_ants: i.props.marching_ants !== !1,
      smoothing: i.props.smoothing ?? 1,
      tooltips: [
        i.props.draw_tooltip ?? "",
        i.props.clear_tooltip ?? ""
      ]
    }, L(o) && l?.refresh();
  });
  var g = gs(), _ = tt(g);
  {
    let p = et(() => i.props.polygonal ? ps : us), m = et(() => (L(a) ? i.props.disable_tooltip : i.props.enable_tooltip) ?? ""), v = et(() => i.shared.interactive === !1);
    yi(_, {
      get Icon() {
        return L(p);
      },
      get label() {
        return L(m);
      },
      get disabled() {
        return L(v);
      },
      onclick: y
    });
  }
  li(g, (p) => s = p, () => s), gt(() => st(g, "hidden", !L(o) || i.shared.visible === !1)), H(n, g), Ue();
}
export {
  ms as default
};
