const p = /* @__PURE__ */ Symbol(), _e = !1;
var ct = Array.isArray, _t = Array.prototype.indexOf, Ht = Array.from, $t = Object.defineProperty, ee = Object.getOwnPropertyDescriptor, vt = Object.prototype, dt = Array.prototype, ht = Object.getPrototypeOf, Ae = Object.isExtensible;
const Jt = () => {
};
function pt(e) {
  for (var t = 0; t < e.length; t++)
    e[t]();
}
function wt() {
  var e, t, n = new Promise((s, r) => {
    e = s, t = r;
  });
  return { promise: n, resolve: e, reject: t };
}
const y = 2, ve = 4, De = 8, Pe = 1 << 24, O = 16, j = 32, H = 64, Ie = 128, T = 512, b = 1024, A = 2048, q = 4096, P = 8192, K = 16384, ye = 32768, de = 65536, Re = 1 << 17, Me = 1 << 18, Ee = 1 << 19, yt = 1 << 20, z = 32768, he = 1 << 21, je = 1 << 22, ne = 1 << 23, ce = /* @__PURE__ */ Symbol("$state"), qe = new class extends Error {
  name = "StaleReactionError";
  message = "The reaction that called `getAbortSignal()` was re-run or destroyed";
}();
function Et(e) {
  throw new Error("https://svelte.dev/e/effect_in_teardown");
}
function gt() {
  throw new Error("https://svelte.dev/e/effect_in_unowned_derived");
}
function bt(e) {
  throw new Error("https://svelte.dev/e/effect_orphan");
}
function mt() {
  throw new Error("https://svelte.dev/e/effect_update_depth_exceeded");
}
function xt() {
  throw new Error("https://svelte.dev/e/state_descriptors_fixed");
}
function kt() {
  throw new Error("https://svelte.dev/e/state_prototype_fixed");
}
function Tt() {
  throw new Error("https://svelte.dev/e/state_unsafe_mutation");
}
function Wt() {
  throw new Error("https://svelte.dev/e/svelte_boundary_reset_onerror");
}
function At(e) {
  return e === this.v;
}
let Rt = !1, M = null;
function Se(e) {
  M = e;
}
function Zt(e, t = !1, n) {
  M = {
    p: M,
    i: !1,
    c: null,
    e: null,
    s: e,
    x: null,
    l: null
  };
}
function Xt(e) {
  var t = (
    /** @type {ComponentContext} */
    M
  ), n = t.e;
  if (n !== null) {
    t.e = null;
    for (var s of n)
      Xe(s);
  }
  return t.i = !0, M = t.p, /** @type {T} */
  {};
}
function Le() {
  return !0;
}
let $ = [];
function St() {
  var e = $;
  $ = [], pt(e);
}
function Ye(e) {
  if ($.length === 0) {
    var t = $;
    queueMicrotask(() => {
      t === $ && St();
    });
  }
  $.push(e);
}
function Ft(e) {
  var t = h;
  if (t === null)
    return _.f |= ne, e;
  if ((t.f & ye) === 0) {
    if ((t.f & Ie) === 0)
      throw e;
    t.b.error(e);
  } else
    Ke(e, t);
}
function Ke(e, t) {
  for (; t !== null; ) {
    if ((t.f & Ie) !== 0)
      try {
        t.b.error(e);
        return;
      } catch (n) {
        e = n;
      }
    t = t.parent;
  }
  throw e;
}
const Ct = -7169;
function m(e, t) {
  e.f = e.f & Ct | t;
}
function ge(e) {
  (e.f & T) !== 0 || e.deps === null ? m(e, b) : m(e, q);
}
function Ue(e) {
  if (e !== null)
    for (const t of e)
      (t.f & y) === 0 || (t.f & z) === 0 || (t.f ^= z, Ue(
        /** @type {Derived} */
        t.deps
      ));
}
function Nt(e, t, n) {
  (e.f & A) !== 0 ? t.add(e) : (e.f & q) !== 0 && n.add(e), Ue(e.deps), m(e, b);
}
const le = /* @__PURE__ */ new Set();
let w = null, R = null, F = [], be = null, pe = !1;
class J {
  committed = !1;
  /**
   * The current values of any sources that are updated in this batch
   * They keys of this map are identical to `this.#previous`
   * @type {Map<Source, any>}
   */
  current = /* @__PURE__ */ new Map();
  /**
   * The values of any sources that are updated in this batch _before_ those updates took place.
   * They keys of this map are identical to `this.#current`
   * @type {Map<Source, any>}
   */
  previous = /* @__PURE__ */ new Map();
  /**
   * When the batch is committed (and the DOM is updated), we need to remove old branches
   * and append new ones by calling the functions added inside (if/each/key/etc) blocks
   * @type {Set<() => void>}
   */
  #n = /* @__PURE__ */ new Set();
  /**
   * If a fork is discarded, we need to destroy any effects that are no longer needed
   * @type {Set<(batch: Batch) => void>}
   */
  #r = /* @__PURE__ */ new Set();
  /**
   * The number of async effects that are currently in flight
   */
  #e = 0;
  /**
   * The number of async effects that are currently in flight, _not_ inside a pending boundary
   */
  #t = 0;
  /**
   * A deferred that resolves when the batch is committed, used with `settled()`
   * TODO replace with Promise.withResolvers once supported widely enough
   * @type {{ promise: Promise<void>, resolve: (value?: any) => void, reject: (reason: unknown) => void } | null}
   */
  #l = null;
  /**
   * Deferred effects (which run after async work has completed) that are DIRTY
   * @type {Set<Effect>}
   */
  #s = /* @__PURE__ */ new Set();
  /**
   * Deferred effects that are MAYBE_DIRTY
   * @type {Set<Effect>}
   */
  #f = /* @__PURE__ */ new Set();
  /**
   * A set of branches that still exist, but will be destroyed when this batch
   * is committed — we skip over these during `process`
   * @type {Set<Effect>}
   */
  skipped_effects = /* @__PURE__ */ new Set();
  is_fork = !1;
  is_deferred() {
    return this.is_fork || this.#t > 0;
  }
  /**
   *
   * @param {Effect[]} root_effects
   */
  process(t) {
    F = [], this.apply();
    var n = [], s = [];
    for (const r of t)
      this.#i(r, n, s);
    this.is_fork || this.#a(), this.is_deferred() ? (this.#u(s), this.#u(n)) : (w = null, Fe(s), Fe(n), this.#l?.resolve()), R = null;
  }
  /**
   * Traverse the effect tree, executing effects or stashing
   * them for later execution as appropriate
   * @param {Effect} root
   * @param {Effect[]} effects
   * @param {Effect[]} render_effects
   */
  #i(t, n, s) {
    t.f ^= b;
    for (var r = t.first, f = null; r !== null; ) {
      var u = r.f, i = (u & (j | H)) !== 0, l = i && (u & b) !== 0, a = l || (u & P) !== 0 || this.skipped_effects.has(r);
      if (!a && r.fn !== null) {
        i ? r.f ^= b : f !== null && (u & (ve | De | Pe)) !== 0 ? f.b.defer_effect(r) : (u & ve) !== 0 ? n.push(r) : fe(r) && ((u & O) !== 0 && this.#s.add(r), re(r));
        var o = r.first;
        if (o !== null) {
          r = o;
          continue;
        }
      }
      var c = r.parent;
      for (r = r.next; r === null && c !== null; )
        c === f && (f = null), r = c.next, c = c.parent;
    }
  }
  /**
   * @param {Effect[]} effects
   */
  #u(t) {
    for (var n = 0; n < t.length; n += 1)
      Nt(t[n], this.#s, this.#f);
  }
  /**
   * Associate a change to a given source with the current
   * batch, noting its previous and current values
   * @param {Source} source
   * @param {any} value
   */
  capture(t, n) {
    n !== p && !this.previous.has(t) && this.previous.set(t, n), (t.f & ne) === 0 && (this.current.set(t, t.v), R?.set(t, t.v));
  }
  activate() {
    w = this, this.apply();
  }
  deactivate() {
    w === this && (w = null, R = null);
  }
  flush() {
    if (this.activate(), F.length > 0) {
      if (Ot(), w !== null && w !== this)
        return;
    } else this.#e === 0 && this.process([]);
    this.deactivate();
  }
  discard() {
    for (const t of this.#r) t(this);
    this.#r.clear();
  }
  #a() {
    if (this.#t === 0) {
      for (const t of this.#n) t();
      this.#n.clear();
    }
    this.#e === 0 && this.#o();
  }
  #o() {
    if (le.size > 1) {
      this.previous.clear();
      var t = R, n = !0;
      for (const r of le) {
        if (r === this) {
          n = !1;
          continue;
        }
        const f = [];
        for (const [i, l] of this.current) {
          if (r.current.has(i))
            if (n && l !== r.current.get(i))
              r.current.set(i, l);
            else
              continue;
          f.push(i);
        }
        if (f.length === 0)
          continue;
        const u = [...r.current.keys()].filter((i) => !this.current.has(i));
        if (u.length > 0) {
          var s = F;
          F = [];
          const i = /* @__PURE__ */ new Set(), l = /* @__PURE__ */ new Map();
          for (const a of f)
            Be(a, u, i, l);
          if (F.length > 0) {
            w = r, r.apply();
            for (const a of F)
              r.#i(a, [], []);
            r.deactivate();
          }
          F = s;
        }
      }
      w = null, R = t;
    }
    this.committed = !0, le.delete(this);
  }
  /**
   *
   * @param {boolean} blocking
   */
  increment(t) {
    this.#e += 1, t && (this.#t += 1);
  }
  /**
   *
   * @param {boolean} blocking
   */
  decrement(t) {
    this.#e -= 1, t && (this.#t -= 1), this.revive();
  }
  revive() {
    for (const t of this.#s)
      this.#f.delete(t), m(t, A), Q(t);
    for (const t of this.#f)
      m(t, q), Q(t);
    this.flush();
  }
  /** @param {() => void} fn */
  oncommit(t) {
    this.#n.add(t);
  }
  /** @param {(batch: Batch) => void} fn */
  ondiscard(t) {
    this.#r.add(t);
  }
  settled() {
    return (this.#l ??= wt()).promise;
  }
  static ensure() {
    if (w === null) {
      const t = w = new J();
      le.add(w), J.enqueue(() => {
        w === t && t.flush();
      });
    }
    return w;
  }
  /** @param {() => void} task */
  static enqueue(t) {
    Ye(t);
  }
  apply() {
  }
}
function Ot() {
  var e = U;
  pe = !0;
  var t = null;
  try {
    var n = 0;
    for (ie(!0); F.length > 0; ) {
      var s = J.ensure();
      if (n++ > 1e3) {
        var r, f;
        Dt();
      }
      s.process(F), I.clear();
    }
  } finally {
    pe = !1, ie(e), be = null;
  }
}
function Dt() {
  try {
    mt();
  } catch (e) {
    Ke(e, be);
  }
}
let C = null;
function Fe(e) {
  var t = e.length;
  if (t !== 0) {
    for (var n = 0; n < t; ) {
      var s = e[n++];
      if ((s.f & (K | P)) === 0 && fe(s) && (C = /* @__PURE__ */ new Set(), re(s), s.deps === null && s.first === null && s.nodes === null && (s.teardown === null && s.ac === null ? nt(s) : s.fn = null), C?.size > 0)) {
        I.clear();
        for (const r of C) {
          if ((r.f & (K | P)) !== 0) continue;
          const f = [r];
          let u = r.parent;
          for (; u !== null; )
            C.has(u) && (C.delete(u), f.push(u)), u = u.parent;
          for (let i = f.length - 1; i >= 0; i--) {
            const l = f[i];
            (l.f & (K | P)) === 0 && re(l);
          }
        }
        C.clear();
      }
    }
    C = null;
  }
}
function Be(e, t, n, s) {
  if (!n.has(e) && (n.add(e), e.reactions !== null))
    for (const r of e.reactions) {
      const f = r.f;
      (f & y) !== 0 ? Be(
        /** @type {Derived} */
        r,
        t,
        n,
        s
      ) : (f & (je | O)) !== 0 && (f & A) === 0 && ze(r, t, s) && (m(r, A), Q(
        /** @type {Effect} */
        r
      ));
    }
}
function ze(e, t, n) {
  const s = n.get(e);
  if (s !== void 0) return s;
  if (e.deps !== null)
    for (const r of e.deps) {
      if (t.includes(r))
        return !0;
      if ((r.f & y) !== 0 && ze(
        /** @type {Derived} */
        r,
        t,
        n
      ))
        return n.set(
          /** @type {Derived} */
          r,
          !0
        ), !0;
    }
  return n.set(e, !1), !1;
}
function Q(e) {
  for (var t = be = e; t.parent !== null; ) {
    t = t.parent;
    var n = t.f;
    if (pe && t === h && (n & O) !== 0 && (n & Me) === 0)
      return;
    if ((n & (H | j)) !== 0) {
      if ((n & b) === 0) return;
      t.f ^= b;
    }
  }
  F.push(t);
}
function en(e) {
  let t = 0, n = $e(0), s;
  return () => {
    xe() && (X(n), Lt(() => (t === 0 && (s = Vt(() => e(() => te(n)))), t += 1, () => {
      Ye(() => {
        t -= 1, t === 0 && (s?.(), s = void 0, te(n));
      });
    })));
  };
}
function Ge(e) {
  var t = e.effects;
  if (t !== null) {
    e.effects = null;
    for (var n = 0; n < t.length; n += 1)
      G(
        /** @type {Effect} */
        t[n]
      );
  }
}
function Pt(e) {
  for (var t = e.parent; t !== null; ) {
    if ((t.f & y) === 0)
      return (t.f & K) === 0 ? (
        /** @type {Effect} */
        t
      ) : null;
    t = t.parent;
  }
  return null;
}
function me(e) {
  var t, n = h;
  ue(Pt(e));
  try {
    e.f &= ~z, Ge(e), t = it(e);
  } finally {
    ue(n);
  }
  return t;
}
function Ve(e) {
  var t = me(e);
  if (!e.equals(t) && (e.wv = ft(), (!w?.is_fork || e.deps === null) && (e.v = t, e.deps === null))) {
    m(e, b);
    return;
  }
  V || (R !== null ? (xe() || w?.is_fork) && R.set(e, t) : ge(e));
}
let we = /* @__PURE__ */ new Set();
const I = /* @__PURE__ */ new Map();
let He = !1;
function $e(e, t) {
  var n = {
    f: 0,
    // TODO ideally we could skip this altogether, but it causes type errors
    v: e,
    reactions: null,
    equals: At,
    rv: 0,
    wv: 0
  };
  return n;
}
// @__NO_SIDE_EFFECTS__
function D(e, t) {
  const n = $e(e);
  return Bt(n), n;
}
function L(e, t, n = !1) {
  _ !== null && // since we are untracking the function inside `$inspect.with` we need to add this check
  // to ensure we error if state is set inside an inspect effect
  (!S || (_.f & Re) !== 0) && Le() && (_.f & (y | O | je | Re)) !== 0 && !N?.includes(e) && Tt();
  let s = n ? Z(t) : t;
  return It(e, s);
}
function It(e, t) {
  if (!e.equals(t)) {
    var n = e.v;
    V ? I.set(e, t) : I.set(e, n), e.v = t;
    var s = J.ensure();
    if (s.capture(e, n), (e.f & y) !== 0) {
      const r = (
        /** @type {Derived} */
        e
      );
      (e.f & A) !== 0 && me(r), ge(r);
    }
    e.wv = ft(), Je(e, A), h !== null && (h.f & b) !== 0 && (h.f & (j | H)) === 0 && (k === null ? zt([e]) : k.push(e)), !s.is_fork && we.size > 0 && !He && Mt();
  }
  return t;
}
function Mt() {
  He = !1;
  var e = U;
  ie(!0);
  const t = Array.from(we);
  try {
    for (const n of t)
      (n.f & b) !== 0 && m(n, q), fe(n) && re(n);
  } finally {
    ie(e);
  }
  we.clear();
}
function te(e) {
  L(e, e.v + 1);
}
function Je(e, t) {
  var n = e.reactions;
  if (n !== null)
    for (var s = n.length, r = 0; r < s; r++) {
      var f = n[r], u = f.f, i = (u & A) === 0;
      if (i && m(f, t), (u & y) !== 0) {
        var l = (
          /** @type {Derived} */
          f
        );
        R?.delete(l), (u & z) === 0 && (u & T && (f.f |= z), Je(l, q));
      } else i && ((u & O) !== 0 && C !== null && C.add(
        /** @type {Effect} */
        f
      ), Q(
        /** @type {Effect} */
        f
      ));
    }
}
function Z(e) {
  if (typeof e != "object" || e === null || ce in e)
    return e;
  const t = ht(e);
  if (t !== vt && t !== dt)
    return e;
  var n = /* @__PURE__ */ new Map(), s = ct(e), r = /* @__PURE__ */ D(0), f = B, u = (i) => {
    if (B === f)
      return i();
    var l = _, a = B;
    W(null), Oe(f);
    var o = i();
    return W(l), Oe(a), o;
  };
  return s && n.set("length", /* @__PURE__ */ D(
    /** @type {any[]} */
    e.length
  )), new Proxy(
    /** @type {any} */
    e,
    {
      defineProperty(i, l, a) {
        (!("value" in a) || a.configurable === !1 || a.enumerable === !1 || a.writable === !1) && xt();
        var o = n.get(l);
        return o === void 0 ? o = u(() => {
          var c = /* @__PURE__ */ D(a.value);
          return n.set(l, c), c;
        }) : L(o, a.value, !0), !0;
      },
      deleteProperty(i, l) {
        var a = n.get(l);
        if (a === void 0) {
          if (l in i) {
            const o = u(() => /* @__PURE__ */ D(p));
            n.set(l, o), te(r);
          }
        } else
          L(a, p), te(r);
        return !0;
      },
      get(i, l, a) {
        if (l === ce)
          return e;
        var o = n.get(l), c = l in i;
        if (o === void 0 && (!c || ee(i, l)?.writable) && (o = u(() => {
          var d = Z(c ? i[l] : p), E = /* @__PURE__ */ D(d);
          return E;
        }), n.set(l, o)), o !== void 0) {
          var v = X(o);
          return v === p ? void 0 : v;
        }
        return Reflect.get(i, l, a);
      },
      getOwnPropertyDescriptor(i, l) {
        var a = Reflect.getOwnPropertyDescriptor(i, l);
        if (a && "value" in a) {
          var o = n.get(l);
          o && (a.value = X(o));
        } else if (a === void 0) {
          var c = n.get(l), v = c?.v;
          if (c !== void 0 && v !== p)
            return {
              enumerable: !0,
              configurable: !0,
              value: v,
              writable: !0
            };
        }
        return a;
      },
      has(i, l) {
        if (l === ce)
          return !0;
        var a = n.get(l), o = a !== void 0 && a.v !== p || Reflect.has(i, l);
        if (a !== void 0 || h !== null && (!o || ee(i, l)?.writable)) {
          a === void 0 && (a = u(() => {
            var v = o ? Z(i[l]) : p, d = /* @__PURE__ */ D(v);
            return d;
          }), n.set(l, a));
          var c = X(a);
          if (c === p)
            return !1;
        }
        return o;
      },
      set(i, l, a, o) {
        var c = n.get(l), v = l in i;
        if (s && l === "length")
          for (var d = a; d < /** @type {Source<number>} */
          c.v; d += 1) {
            var E = n.get(d + "");
            E !== void 0 ? L(E, p) : d in i && (E = u(() => /* @__PURE__ */ D(p)), n.set(d + "", E));
          }
        if (c === void 0)
          (!v || ee(i, l)?.writable) && (c = u(() => /* @__PURE__ */ D(void 0)), L(c, Z(a)), n.set(l, c));
        else {
          v = c.v !== p;
          var ot = u(() => Z(a));
          L(c, ot);
        }
        var ke = Reflect.getOwnPropertyDescriptor(i, l);
        if (ke?.set && ke.set.call(o, a), !v) {
          if (s && typeof l == "string") {
            var Te = (
              /** @type {Source<number>} */
              n.get("length")
            ), oe = Number(l);
            Number.isInteger(oe) && oe >= Te.v && L(Te, oe + 1);
          }
          te(r);
        }
        return !0;
      },
      ownKeys(i) {
        X(r);
        var l = Reflect.ownKeys(i).filter((c) => {
          var v = n.get(c);
          return v === void 0 || v.v !== p;
        });
        for (var [a, o] of n)
          o.v !== p && !(a in i) && l.push(a);
        return l;
      },
      setPrototypeOf() {
        kt();
      }
    }
  );
}
var Ce, Qe;
function tn() {
  if (Ce === void 0) {
    Ce = window;
    var e = Element.prototype, t = Node.prototype, n = Text.prototype;
    ee(t, "firstChild").get, Qe = ee(t, "nextSibling").get, Ae(e) && (e.__click = void 0, e.__className = void 0, e.__attributes = null, e.__style = void 0, e.__e = void 0), Ae(n) && (n.__t = void 0);
  }
}
function nn(e = "") {
  return document.createTextNode(e);
}
// @__NO_SIDE_EFFECTS__
function We(e) {
  return (
    /** @type {TemplateNode | null} */
    Qe.call(e)
  );
}
function Ze(e) {
  var t = _, n = h;
  W(null), ue(null);
  try {
    return e();
  } finally {
    W(t), ue(n);
  }
}
function jt(e) {
  h === null && (_ === null && bt(), gt()), V && Et();
}
function qt(e, t) {
  var n = t.last;
  n === null ? t.last = t.first = e : (n.next = e, e.prev = n, t.last = e);
}
function se(e, t, n) {
  var s = h;
  s !== null && (s.f & P) !== 0 && (e |= P);
  var r = {
    ctx: M,
    deps: null,
    nodes: null,
    f: e | A | T,
    first: null,
    fn: t,
    last: null,
    next: null,
    parent: s,
    b: s && s.b,
    prev: null,
    teardown: null,
    wv: 0,
    ac: null
  };
  if (n)
    try {
      re(r), r.f |= ye;
    } catch (i) {
      throw G(r), i;
    }
  else t !== null && Q(r);
  var f = r;
  if (n && f.deps === null && f.teardown === null && f.nodes === null && f.first === f.last && // either `null`, or a singular child
  (f.f & Ee) === 0 && (f = f.first, (e & O) !== 0 && (e & de) !== 0 && f !== null && (f.f |= de)), f !== null && (f.parent = s, s !== null && qt(f, s), _ !== null && (_.f & y) !== 0 && (e & H) === 0)) {
    var u = (
      /** @type {Derived} */
      _
    );
    (u.effects ??= []).push(f);
  }
  return r;
}
function xe() {
  return _ !== null && !S;
}
function rn(e) {
  jt();
  var t = (
    /** @type {Effect} */
    h.f
  ), n = !_ && (t & j) !== 0 && (t & ye) === 0;
  if (n) {
    var s = (
      /** @type {ComponentContext} */
      M
    );
    (s.e ??= []).push(e);
  } else
    return Xe(e);
}
function Xe(e) {
  return se(ve | yt, e, !1);
}
function sn(e) {
  J.ensure();
  const t = se(H | Ee, e, !0);
  return (n = {}) => new Promise((s) => {
    n.outro ? Ut(t, () => {
      G(t), s(void 0);
    }) : (G(t), s(void 0));
  });
}
function Lt(e, t = 0) {
  return se(De | t, e, !0);
}
function fn(e, t = 0) {
  var n = se(O | t, e, !0);
  return n;
}
function ln(e) {
  return se(j | Ee, e, !0);
}
function et(e) {
  var t = e.teardown;
  if (t !== null) {
    const n = V, s = _;
    Ne(!0), W(null);
    try {
      t.call(null);
    } finally {
      Ne(n), W(s);
    }
  }
}
function tt(e, t = !1) {
  var n = e.first;
  for (e.first = e.last = null; n !== null; ) {
    const r = n.ac;
    r !== null && Ze(() => {
      r.abort(qe);
    });
    var s = n.next;
    (n.f & H) !== 0 ? n.parent = null : G(n, t), n = s;
  }
}
function Yt(e) {
  for (var t = e.first; t !== null; ) {
    var n = t.next;
    (t.f & j) === 0 && G(t), t = n;
  }
}
function G(e, t = !0) {
  var n = !1;
  (t || (e.f & Me) !== 0) && e.nodes !== null && e.nodes.end !== null && (Kt(
    e.nodes.start,
    /** @type {TemplateNode} */
    e.nodes.end
  ), n = !0), tt(e, t && !n), ae(e, 0), m(e, K);
  var s = e.nodes && e.nodes.t;
  if (s !== null)
    for (const f of s)
      f.stop();
  et(e);
  var r = e.parent;
  r !== null && r.first !== null && nt(e), e.next = e.prev = e.teardown = e.ctx = e.deps = e.fn = e.nodes = e.ac = null;
}
function Kt(e, t) {
  for (; e !== null; ) {
    var n = e === t ? null : /* @__PURE__ */ We(e);
    e.remove(), e = n;
  }
}
function nt(e) {
  var t = e.parent, n = e.prev, s = e.next;
  n !== null && (n.next = s), s !== null && (s.prev = n), t !== null && (t.first === e && (t.first = s), t.last === e && (t.last = n));
}
function Ut(e, t, n = !0) {
  var s = [];
  rt(e, s, !0);
  var r = () => {
    n && G(e), t && t();
  }, f = s.length;
  if (f > 0) {
    var u = () => --f || r();
    for (var i of s)
      i.out(u);
  } else
    r();
}
function rt(e, t, n) {
  if ((e.f & P) === 0) {
    e.f ^= P;
    var s = e.nodes && e.nodes.t;
    if (s !== null)
      for (const i of s)
        (i.is_global || n) && t.push(i);
    for (var r = e.first; r !== null; ) {
      var f = r.next, u = (r.f & de) !== 0 || // If this is a branch effect without a block effect parent,
      // it means the parent block effect was pruned. In that case,
      // transparency information was transferred to the branch effect.
      (r.f & j) !== 0 && (e.f & O) !== 0;
      rt(r, t, u ? n : !1), r = f;
    }
  }
}
function un(e, t) {
  if (e.nodes)
    for (var n = e.nodes.start, s = e.nodes.end; n !== null; ) {
      var r = n === s ? null : /* @__PURE__ */ We(n);
      t.append(n), n = r;
    }
}
let U = !1;
function ie(e) {
  U = e;
}
let V = !1;
function Ne(e) {
  V = e;
}
let _ = null, S = !1;
function W(e) {
  _ = e;
}
let h = null;
function ue(e) {
  h = e;
}
let N = null;
function Bt(e) {
  _ !== null && (N === null ? N = [e] : N.push(e));
}
let g = null, x = 0, k = null;
function zt(e) {
  k = e;
}
let st = 1, Y = 0, B = Y;
function Oe(e) {
  B = e;
}
function ft() {
  return ++st;
}
function fe(e) {
  var t = e.f;
  if ((t & A) !== 0)
    return !0;
  if (t & y && (e.f &= ~z), (t & q) !== 0) {
    for (var n = (
      /** @type {Value[]} */
      e.deps
    ), s = n.length, r = 0; r < s; r++) {
      var f = n[r];
      if (fe(
        /** @type {Derived} */
        f
      ) && Ve(
        /** @type {Derived} */
        f
      ), f.wv > e.wv)
        return !0;
    }
    (t & T) !== 0 && // During time traveling we don't want to reset the status so that
    // traversal of the graph in the other batches still happens
    R === null && m(e, b);
  }
  return !1;
}
function lt(e, t, n = !0) {
  var s = e.reactions;
  if (s !== null && !N?.includes(e))
    for (var r = 0; r < s.length; r++) {
      var f = s[r];
      (f.f & y) !== 0 ? lt(
        /** @type {Derived} */
        f,
        t,
        !1
      ) : t === f && (n ? m(f, A) : (f.f & b) !== 0 && m(f, q), Q(
        /** @type {Effect} */
        f
      ));
    }
}
function it(e) {
  var t = g, n = x, s = k, r = _, f = N, u = M, i = S, l = B, a = e.f;
  g = /** @type {null | Value[]} */
  null, x = 0, k = null, _ = (a & (j | H)) === 0 ? e : null, N = null, Se(e.ctx), S = !1, B = ++Y, e.ac !== null && (Ze(() => {
    e.ac.abort(qe);
  }), e.ac = null);
  try {
    e.f |= he;
    var o = (
      /** @type {Function} */
      e.fn
    ), c = o(), v = e.deps;
    if (g !== null) {
      var d;
      if (ae(e, x), v !== null && x > 0)
        for (v.length = x + g.length, d = 0; d < g.length; d++)
          v[x + d] = g[d];
      else
        e.deps = v = g;
      if (xe() && (e.f & T) !== 0)
        for (d = x; d < v.length; d++)
          (v[d].reactions ??= []).push(e);
    } else v !== null && x < v.length && (ae(e, x), v.length = x);
    if (Le() && k !== null && !S && v !== null && (e.f & (y | q | A)) === 0)
      for (d = 0; d < /** @type {Source[]} */
      k.length; d++)
        lt(
          k[d],
          /** @type {Effect} */
          e
        );
    if (r !== null && r !== e) {
      if (Y++, r.deps !== null)
        for (let E = 0; E < n; E += 1)
          r.deps[E].rv = Y;
      if (t !== null)
        for (const E of t)
          E.rv = Y;
      k !== null && (s === null ? s = k : s.push(.../** @type {Source[]} */
      k));
    }
    return (e.f & ne) !== 0 && (e.f ^= ne), c;
  } catch (E) {
    return Ft(E);
  } finally {
    e.f ^= he, g = t, x = n, k = s, _ = r, N = f, Se(u), S = i, B = l;
  }
}
function Gt(e, t) {
  let n = t.reactions;
  if (n !== null) {
    var s = _t.call(n, e);
    if (s !== -1) {
      var r = n.length - 1;
      r === 0 ? n = t.reactions = null : (n[s] = n[r], n.pop());
    }
  }
  if (n === null && (t.f & y) !== 0 && // Destroying a child effect while updating a parent effect can cause a dependency to appear
  // to be unused, when in fact it is used by the currently-updating parent. Checking `new_deps`
  // allows us to skip the expensive work of disconnecting and immediately reconnecting it
  (g === null || !g.includes(t))) {
    var f = (
      /** @type {Derived} */
      t
    );
    (f.f & T) !== 0 && (f.f ^= T, f.f &= ~z), ge(f), Ge(f), ae(f, 0);
  }
}
function ae(e, t) {
  var n = e.deps;
  if (n !== null)
    for (var s = t; s < n.length; s++)
      Gt(e, n[s]);
}
function re(e) {
  var t = e.f;
  if ((t & K) === 0) {
    m(e, b);
    var n = h, s = U;
    h = e, U = !0;
    try {
      (t & (O | Pe)) !== 0 ? Yt(e) : tt(e), et(e);
      var r = it(e);
      e.teardown = typeof r == "function" ? r : null, e.wv = st;
      var f;
      _e && Rt && (e.f & A) !== 0 && e.deps;
    } finally {
      U = s, h = n;
    }
  }
}
function X(e) {
  var t = e.f, n = (t & y) !== 0;
  if (_ !== null && !S) {
    var s = h !== null && (h.f & K) !== 0;
    if (!s && !N?.includes(e)) {
      var r = _.deps;
      if ((_.f & he) !== 0)
        e.rv < Y && (e.rv = Y, g === null && r !== null && r[x] === e ? x++ : g === null ? g = [e] : g.push(e));
      else {
        (_.deps ??= []).push(e);
        var f = e.reactions;
        f === null ? e.reactions = [_] : f.includes(_) || f.push(_);
      }
    }
  }
  if (V && I.has(e))
    return I.get(e);
  if (n) {
    var u = (
      /** @type {Derived} */
      e
    );
    if (V) {
      var i = u.v;
      return ((u.f & b) === 0 && u.reactions !== null || at(u)) && (i = me(u)), I.set(u, i), i;
    }
    var l = (u.f & T) === 0 && !S && _ !== null && (U || (_.f & T) !== 0), a = u.deps === null;
    fe(u) && (l && (u.f |= T), Ve(u)), l && !a && ut(u);
  }
  if (R?.has(e))
    return R.get(e);
  if ((e.f & ne) !== 0)
    throw e.v;
  return e.v;
}
function ut(e) {
  if (e.deps !== null) {
    e.f |= T;
    for (const t of e.deps)
      (t.reactions ??= []).push(e), (t.f & y) !== 0 && (t.f & T) === 0 && ut(
        /** @type {Derived} */
        t
      );
  }
}
function at(e) {
  if (e.v === p) return !0;
  if (e.deps === null) return !1;
  for (const t of e.deps)
    if (I.has(t) || (t.f & y) !== 0 && at(
      /** @type {Derived} */
      t
    ))
      return !0;
  return !1;
}
function Vt(e) {
  var t = S;
  try {
    return S = !0, e();
  } finally {
    S = t;
  }
}
export {
  un as A,
  J as B,
  m as C,
  A as D,
  Q as E,
  It as F,
  G,
  Ke as H,
  Ye as I,
  Wt as J,
  $e as K,
  de as L,
  q as M,
  Ee as N,
  Ie as O,
  $t as P,
  tn as Q,
  Ht as R,
  sn as S,
  rn as a,
  en as b,
  M as c,
  X as d,
  xe as e,
  L as f,
  ht as g,
  Xt as h,
  ct as i,
  Zt as j,
  h as k,
  fn as l,
  ln as m,
  Jt as n,
  vt as o,
  Z as p,
  Ut as q,
  nn as r,
  D as s,
  Nt as t,
  Vt as u,
  ue as v,
  W as w,
  Se as x,
  Ft as y,
  _ as z
};
