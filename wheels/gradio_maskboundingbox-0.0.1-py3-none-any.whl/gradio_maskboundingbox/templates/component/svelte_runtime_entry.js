import { b as V, k as E, l as A, m as u, B as b, q as T, r as I, t as M, v as w, w as g, x as F, y as x, z as N, A as q, C as O, D as Y, E as P, M as j, F as z, d as U, G as R, H as B, I as $, c as L, J as G, K as H, L as J, N as K, O as Q, P as W, Q as X, R as Z, S as ee, j as te, h as se } from "./runtime-Du6aj1Oe.js";
function ie() {
  console.warn("https://svelte.dev/e/svelte_boundary_reset_noop");
}
var re = J | K | Q;
function ne(t, e, s) {
  new ae(t, e, s);
}
class ae {
  /** @type {Boundary | null} */
  parent;
  is_pending = !1;
  /** @type {TemplateNode} */
  #t;
  /** @type {TemplateNode | null} */
  #m = null;
  /** @type {BoundaryProps} */
  #i;
  /** @type {((anchor: Node) => void)} */
  #f;
  /** @type {Effect} */
  #r;
  /** @type {Effect | null} */
  #s = null;
  /** @type {Effect | null} */
  #e = null;
  /** @type {Effect | null} */
  #n = null;
  /** @type {DocumentFragment | null} */
  #a = null;
  /** @type {TemplateNode | null} */
  #o = null;
  #u = 0;
  #h = 0;
  #c = !1;
  /** @type {Set<Effect>} */
  #_ = /* @__PURE__ */ new Set();
  /** @type {Set<Effect>} */
  #d = /* @__PURE__ */ new Set();
  /**
   * A source containing the number of pending async deriveds/expressions.
   * Only created if `$effect.pending()` is used inside the boundary,
   * otherwise updating the source results in needless `Batch.ensure()`
   * calls followed by no-op flushes
   * @type {Source<number> | null}
   */
  #l = null;
  #b = V(() => (this.#l = H(this.#u), () => {
    this.#l = null;
  }));
  /**
   * @param {TemplateNode} node
   * @param {BoundaryProps} props
   * @param {((anchor: Node) => void)} children
   */
  constructor(e, s, o) {
    this.#t = e, this.#i = s, this.#f = o, this.parent = /** @type {Effect} */
    E.b, this.is_pending = !!this.#i.pending, this.#r = A(() => {
      E.b = this;
      {
        var a = this.#v();
        try {
          this.#s = u(() => o(a));
        } catch (i) {
          this.error(i);
        }
        this.#h > 0 ? this.#g() : this.is_pending = !1;
      }
      return () => {
        this.#o?.remove();
      };
    }, re);
  }
  #E() {
    try {
      this.#s = u(() => this.#f(this.#t));
    } catch (e) {
      this.error(e);
    }
  }
  #w() {
    const e = this.#i.pending;
    e && (this.#e = u(() => e(this.#t)), b.enqueue(() => {
      var s = this.#v();
      this.#s = this.#p(() => (b.ensure(), u(() => this.#f(s)))), this.#h > 0 ? this.#g() : (T(
        /** @type {Effect} */
        this.#e,
        () => {
          this.#e = null;
        }
      ), this.is_pending = !1);
    }));
  }
  #v() {
    var e = this.#t;
    return this.is_pending && (this.#o = I(), this.#t.before(this.#o), e = this.#o), e;
  }
  /**
   * Defer an effect inside a pending boundary until the boundary resolves
   * @param {Effect} effect
   */
  defer_effect(e) {
    M(e, this.#_, this.#d);
  }
  /**
   * Returns `false` if the effect exists inside a boundary whose pending snippet is shown
   * @returns {boolean}
   */
  is_rendered() {
    return !this.is_pending && (!this.parent || this.parent.is_rendered());
  }
  has_pending_snippet() {
    return !!this.#i.pending;
  }
  /**
   * @param {() => Effect | null} fn
   */
  #p(e) {
    var s = E, o = N, a = L;
    w(this.#r), g(this.#r), F(this.#r.ctx);
    try {
      return e();
    } catch (i) {
      return x(i), null;
    } finally {
      w(s), g(o), F(a);
    }
  }
  #g() {
    const e = (
      /** @type {(anchor: Node) => void} */
      this.#i.pending
    );
    this.#s !== null && (this.#a = document.createDocumentFragment(), this.#a.append(
      /** @type {TemplateNode} */
      this.#o
    ), q(this.#s, this.#a)), this.#e === null && (this.#e = u(() => e(this.#t)));
  }
  /**
   * Updates the pending count associated with the currently visible pending snippet,
   * if any, such that we can replace the snippet with content once work is done
   * @param {1 | -1} d
   */
  #y(e) {
    if (!this.has_pending_snippet()) {
      this.parent && this.parent.#y(e);
      return;
    }
    if (this.#h += e, this.#h === 0) {
      this.is_pending = !1;
      for (const s of this.#_)
        O(s, Y), P(s);
      for (const s of this.#d)
        O(s, j), P(s);
      this.#_.clear(), this.#d.clear(), this.#e && T(this.#e, () => {
        this.#e = null;
      }), this.#a && (this.#t.before(this.#a), this.#a = null);
    }
  }
  /**
   * Update the source that powers `$effect.pending()` inside this boundary,
   * and controls when the current `pending` snippet (if any) is removed.
   * Do not call from inside the class
   * @param {1 | -1} d
   */
  update_pending_count(e) {
    this.#y(e), this.#u += e, this.#l && z(this.#l, this.#u);
  }
  get_effect_pending() {
    return this.#b(), U(
      /** @type {Source<number>} */
      this.#l
    );
  }
  /** @param {unknown} error */
  error(e) {
    var s = this.#i.onerror;
    let o = this.#i.failed;
    if (this.#c || !s && !o)
      throw e;
    this.#s && (R(this.#s), this.#s = null), this.#e && (R(this.#e), this.#e = null), this.#n && (R(this.#n), this.#n = null);
    var a = !1, i = !1;
    const c = () => {
      if (a) {
        ie();
        return;
      }
      a = !0, i && G(), b.ensure(), this.#u = 0, this.#n !== null && T(this.#n, () => {
        this.#n = null;
      }), this.is_pending = this.has_pending_snippet(), this.#s = this.#p(() => (this.#c = !1, u(() => this.#f(this.#t)))), this.#h > 0 ? this.#g() : this.is_pending = !1;
    };
    var f = N;
    try {
      g(null), i = !0, s?.(e, c), i = !1;
    } catch (h) {
      B(h, this.#r && this.#r.parent);
    } finally {
      g(f);
    }
    o && $(() => {
      this.#n = this.#p(() => {
        b.ensure(), this.#c = !0;
        try {
          return u(() => {
            o(
              this.#t,
              () => e,
              () => c
            );
          });
        } catch (h) {
          return B(
            h,
            /** @type {Effect} */
            this.#r.parent
          ), null;
        } finally {
          this.#c = !1;
        }
      });
    });
  }
}
const oe = ["touchstart", "touchmove"];
function he(t) {
  return oe.includes(t);
}
const le = /* @__PURE__ */ new Set(), C = /* @__PURE__ */ new Set();
let D = null;
function m(t) {
  var e = this, s = (
    /** @type {Node} */
    e.ownerDocument
  ), o = t.type, a = t.composedPath?.() || [], i = (
    /** @type {null | Element} */
    a[0] || t.target
  );
  D = t;
  var c = 0, f = D === t && t.__root;
  if (f) {
    var h = a.indexOf(f);
    if (h !== -1 && (e === document || e === /** @type {any} */
    window)) {
      t.__root = e;
      return;
    }
    var _ = a.indexOf(e);
    if (_ === -1)
      return;
    h <= _ && (c = h);
  }
  if (i = /** @type {Element} */
  a[c] || t.target, i !== e) {
    W(t, "currentTarget", {
      configurable: !0,
      get() {
        return i || s;
      }
    });
    var S = N, l = E;
    g(null), w(null);
    try {
      for (var r, n = []; i !== null; ) {
        var d = i.assignedSlot || i.parentNode || /** @type {any} */
        i.host || null;
        try {
          var v = i["__" + o];
          v != null && (!/** @type {any} */
          i.disabled || // DOM could've been updated already by the time this is reached, so we check this as well
          // -> the target could not have been disabled because it emits the event in the first place
          t.target === i) && v.call(i, t);
        } catch (y) {
          r ? n.push(y) : r = y;
        }
        if (t.cancelBubble || d === e || d === null)
          break;
        i = d;
      }
      if (r) {
        for (let y of n)
          queueMicrotask(() => {
            throw y;
          });
        throw r;
      }
    } finally {
      t.__root = e, delete t.currentTarget, g(S), w(l);
    }
  }
}
function _e(t, e) {
  return fe(t, e);
}
const p = /* @__PURE__ */ new Map();
function fe(t, { target: e, anchor: s, props: o = {}, events: a, context: i, intro: c = !0 }) {
  X();
  var f = /* @__PURE__ */ new Set(), h = (l) => {
    for (var r = 0; r < l.length; r++) {
      var n = l[r];
      if (!f.has(n)) {
        f.add(n);
        var d = he(n);
        e.addEventListener(n, m, { passive: d });
        var v = p.get(n);
        v === void 0 ? (document.addEventListener(n, m, { passive: d }), p.set(n, 1)) : p.set(n, v + 1);
      }
    }
  };
  h(Z(le)), C.add(h);
  var _ = void 0, S = ee(() => {
    var l = s ?? e.appendChild(I());
    return ne(
      /** @type {TemplateNode} */
      l,
      {
        pending: () => {
        }
      },
      (r) => {
        if (i) {
          te({});
          var n = (
            /** @type {ComponentContext} */
            L
          );
          n.c = i;
        }
        a && (o.$$events = a), _ = t(r, o) || {}, i && se();
      }
    ), () => {
      for (var r of f) {
        e.removeEventListener(r, m);
        var n = (
          /** @type {number} */
          p.get(r)
        );
        --n === 0 ? (document.removeEventListener(r, m), p.delete(r)) : p.set(r, n);
      }
      C.delete(h), l !== s && l.parentNode?.removeChild(l);
    };
  });
  return k.set(_, S), _;
}
let k = /* @__PURE__ */ new WeakMap();
function de(t, e) {
  const s = k.get(t);
  return s ? (k.delete(t), s(e)) : Promise.resolve();
}
const ue = "5";
typeof window < "u" && ((window.__svelte ??= {}).v ??= /* @__PURE__ */ new Set()).add(ue);
const pe = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null
}, Symbol.toStringTag, { value: "Module" }));
export {
  pe as SVELTE_VERSION,
  _e as mount,
  de as unmount
};
