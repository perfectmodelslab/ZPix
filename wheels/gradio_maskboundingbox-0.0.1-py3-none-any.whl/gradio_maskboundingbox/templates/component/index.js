import { i as R, g as A, o as T, n as D, u as g, c as O, a as f, e as B, b as N, s as _, p as k, d as y, f as x, h as W, j as Y } from "./runtime-Du6aj1Oe.js";
function H(s) {
  throw new Error("https://svelte.dev/e/lifecycle_outside_component");
}
const P = [];
function X(s, t = !1, i = !1) {
  return b(s, /* @__PURE__ */ new Map(), "", P, null, i);
}
function b(s, t, i, e, n = null, r = !1) {
  if (typeof s == "object" && s !== null) {
    var d = t.get(s);
    if (d !== void 0) return d;
    if (s instanceof Map) return (
      /** @type {Snapshot<T>} */
      new Map(s)
    );
    if (s instanceof Set) return (
      /** @type {Snapshot<T>} */
      new Set(s)
    );
    if (R(s)) {
      var a = (
        /** @type {Snapshot<any>} */
        Array(s.length)
      );
      t.set(s, a), n !== null && t.set(n, a);
      for (var c = 0; c < s.length; c += 1) {
        var l = s[c];
        c in s && (a[c] = b(l, t, i, e, null, r));
      }
      return a;
    }
    if (A(s) === T) {
      a = {}, t.set(s, a), n !== null && t.set(n, a);
      for (var u in s)
        a[u] = b(
          // @ts-expect-error
          s[u],
          t,
          i,
          e,
          null,
          r
        );
      return a;
    }
    if (s instanceof Date)
      return (
        /** @type {Snapshot<T>} */
        structuredClone(s)
      );
    if (typeof /** @type {T & { toJSON?: any } } */
    s.toJSON == "function" && !r)
      return b(
        /** @type {T & { toJSON(): any } } */
        s.toJSON(),
        t,
        i,
        e,
        // Associate the instance with the toJSON clone
        s
      );
  }
  if (s instanceof EventTarget)
    return (
      /** @type {Snapshot<T>} */
      s
    );
  try {
    return (
      /** @type {Snapshot<T>} */
      structuredClone(s)
    );
  } catch {
    return (
      /** @type {Snapshot<T>} */
      s
    );
  }
}
function I(s, t, i) {
  if (s == null)
    return t(void 0), D;
  const e = g(
    () => s.subscribe(
      t,
      // @ts-expect-error
      i
    )
  );
  return e.unsubscribe ? () => e.unsubscribe() : e;
}
function J(s) {
  let t;
  return I(s, (i) => t = i)(), t;
}
const j = {
  get(s, t) {
    if (!s.exclude.includes(t))
      return s.props[t];
  },
  set(s, t) {
    return !1;
  },
  getOwnPropertyDescriptor(s, t) {
    if (!s.exclude.includes(t) && t in s.props)
      return {
        enumerable: !0,
        configurable: !0,
        value: s.props[t]
      };
  },
  has(s, t) {
    return s.exclude.includes(t) ? !1 : t in s.props;
  },
  ownKeys(s) {
    return Reflect.ownKeys(s.props).filter((t) => !s.exclude.includes(t));
  }
};
// @__NO_SIDE_EFFECTS__
function F(s, t, i) {
  return new Proxy(
    { props: s, exclude: t },
    j
  );
}
const G = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], z = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
G.reduce((s, { color: t, primary: i, secondary: e }) => ({
  ...s,
  [t]: {
    primary: z[t][i],
    secondary: z[t][e]
  }
}), {});
function C(s) {
  O === null && H(), f(() => {
    const t = g(s);
    if (typeof t == "function") return (
      /** @type {() => void} */
      t
    );
  });
}
function K(s) {
  O === null && H(), C(() => () => g(s));
}
function V(s) {
  let t;
  const i = N((n) => {
    let r = !1;
    const d = s.subscribe((a) => {
      t = a, r && n();
    });
    return r = !0, d;
  });
  function e() {
    return B() ? (i(), t) : J(s);
  }
  return "set" in s ? {
    get current() {
      return e();
    },
    set current(n) {
      s.set(n);
    }
  } : {
    get current() {
      return e();
    }
  };
}
const q = "__i18n__", Z = [
  "label",
  "info",
  "placeholder",
  "description",
  "title",
  "value"
], Q = [
  "elem_id",
  "elem_classes",
  "visible",
  "interactive",
  "server_fns",
  "server",
  "id",
  "target",
  "theme_mode",
  "version",
  "root",
  "autoscroll",
  "max_file_size",
  "formatter",
  "client",
  "load_component",
  "scale",
  "min_width",
  "theme",
  "padding",
  "loading_status",
  "label",
  "show_label",
  "validation_error",
  "show_progress",
  "api_prefix",
  "container",
  "attached_events",
  "register_component",
  "dispatcher"
];
function U(s) {
  return typeof s == "string" && s.includes(q);
}
class tt {
  load_component;
  #t = _(k({}));
  get shared() {
    return y(this.#t);
  }
  set shared(t) {
    x(this.#t, t, !0);
  }
  #s = _(k({}));
  get props() {
    return y(this.#s);
  }
  set props(t) {
    x(this.#s, t, !0);
  }
  #i = _((t) => t);
  get i18n() {
    return y(this.#i);
  }
  set i18n(t) {
    x(this.#i, t, !0);
  }
  i18n_store;
  _i18n_from_store;
  translatable_props = {};
  dispatcher;
  last_update = null;
  shared_props = Q;
  mounted = !1;
  old_value;
  register_component;
  constructor(t, i) {
    for (const e in t.shared_props)
      this.shared[e] = t.shared_props[e];
    for (const e in t.props)
      e !== "i18n_store" && (this.props[e] = t.props[e]);
    if (i)
      for (const e in i)
        this.props[e] === void 0 && (this.props[e] = i[e]);
    this.i18n = this.props.i18n ?? ((e) => e), this.i18n_store = t.props.i18n_store, this._i18n_from_store = this.i18n_store ? V(this.i18n_store) : void 0;
    for (const e of Z)
      this.shared[e] = this._translate_and_store(
        "shared",
        e,
        // @ts-ignore
        t.shared_props[e]
      ), this.props[e] = this._translate_and_store(
        "props",
        e,
        // @ts-ignore
        t.props[e]
      );
    this.load_component = this.shared.load_component, this.register_component = this.shared.register_component || (() => {
    }), this.dispatcher = this.shared.dispatcher || (() => {
    }), this.register_component(
      t.shared_props.id,
      // @ts-ignore
      this.set_data.bind(this),
      this.get_data.bind(this)
    ), f(() => {
      for (const e in t.shared_props)
        this._is_i18n_managed(`shared.${e}`, t.shared_props[e]) || (this.shared[e] = t.shared_props[e]);
      for (const e in t.props)
        e !== "i18n_store" && (this._is_i18n_managed(`props.${e}`, t.props[e]) || (this.props[e] = t.props[e]));
      this.register_component(
        t.shared_props.id,
        // @ts-ignore
        this.set_data.bind(this),
        this.get_data.bind(this)
      ), g(() => {
        this.shared.id = t.shared_props.id;
      });
    }), f(() => this.i18n_store ? this.i18n_store.subscribe(() => {
      for (const [n, r] of Object.entries(this.translatable_props)) {
        const [d, a] = n.split("."), c = this.i18n(r);
        d === "shared" ? this.shared[a] = c : this.props[a] = c;
      }
    }) : void 0);
  }
  // check if props are translatable
  _is_i18n_managed(t, i) {
    const e = this.translatable_props[t];
    return e ? i === e ? !0 : (delete this.translatable_props[t], !1) : !1;
  }
  _translate_and_store(t, i, e) {
    if (typeof e != "string") return e;
    const n = this.i18n(e);
    return n !== e && (this.translatable_props[`${t}.${i}`] = e), n;
  }
  // Reactive variant of `i18n`. Reading it inside a derived or template
  // subscribes to the live locale store (via Svelte's createSubscriber), so
  // the caller re-runs when the locale changes at runtime. The store is only
  // the reactivity trigger; translation always goes through `this.i18n` so a
  // custom formatter passed via props keeps taking effect.
  live_i18n = (t) => (this._i18n_from_store?.current, this.i18n(t));
  dispatch(t, i) {
    this.dispatcher(this.shared.id, t, i);
  }
  async get_data() {
    return X(this.props);
  }
  update(t) {
    this.set_data(t);
  }
  set_data(t) {
    for (const i in t) {
      const e = t[i], n = U(e) ? this._translate_and_store(this.shared_props.includes(i) ? "shared" : "props", i, e) : e;
      if (this.shared_props.includes(i)) {
        const r = i;
        this.shared[r] = n;
        continue;
      }
      this.props[i] = n;
    }
  }
  watch_for_change() {
    f(() => {
      this.mounted || (this.old_value = this.props.value, this.mounted = !0), this.old_value != this.props.value && (this.old_value = this.props.value, this.dispatch("change"));
    });
  }
}
const et = ["n", "e", "s", "w"], st = ["ne", "se", "sw", "nw"], $ = 3, it = 10, nt = `
	:host {
		position: absolute;
		display: none;
		z-index: 1;
		cursor: crosshair;
		touch-action: none;
		user-select: none;
	}

	:host([hidden]) {
		display: none !important;
	}

	:host([disabled]) {
		pointer-events: none;
	}

	/* During a gesture, its cursor (set on host) stays, whatever is pointed. */
	:host([gesture]) * {
		cursor: inherit !important;
	}

	/* Dims image outside the bounding box, so region to edit stands out. */
	#shade {
		position: absolute;
		inset: 0;
		overflow: hidden;
		pointer-events: none;
		opacity: 0;
		transition: opacity 0.3s;
	}

	/* Fades in and out rather than flashing. */
	:host([dimmed]) #shade {
		opacity: 1;
	}

	#hole {
		position: absolute;
		box-shadow: 0 0 0 100vmax var(--mask-bbox-dim, rgba(0, 0, 0, 0.3));
	}

	#bbox,
	#draft {
		position: absolute;
		display: none;
		box-sizing: border-box;
		border: 2px solid var(--mask-bbox-color, var(--color-accent, #f97316));
	}

	#bbox {
		cursor: move;
	}

	#draft {
		border-style: dashed;
	}

	/* Bounding box that the one user draws may replace. */
	:host([drafting]) #bbox {
		opacity: 0.5;
	}

	:host([disabled]) #bbox {
		cursor: default;
	}

	:host([disabled]) .edge,
	:host([disabled]) .corner {
		display: none;
	}

	/* Bounding box resizes from its edges and corners, wider than its border. */
	.edge,
	.corner {
		position: absolute;
	}

	.edge.n, .edge.s {
		left: 0;
		right: 0;
		height: var(--mask-bbox-edge-size, 12px);
		cursor: ns-resize;
	}

	.edge.e, .edge.w {
		top: 0;
		bottom: 0;
		width: var(--mask-bbox-edge-size, 12px);
		cursor: ew-resize;
	}

	.edge.n { top: 0; transform: translateY(-50%); }
	.edge.e { right: 0; transform: translateX(50%); }
	.edge.s { bottom: 0; transform: translateY(50%); }
	.edge.w { left: 0; transform: translateX(-50%); }

	/* Hint that the bounding box resizes. */
	.corner {
		width: var(--mask-bbox-corner-size, var(--size-2, 8px));
		height: var(--mask-bbox-corner-size, var(--size-2, 8px));
		border-radius: 50%;
		background: white;
		box-shadow: 0 0 0 1px #f7f6f6bc, 1px 1px 4px #0000001a;
	}

	/* Corner is grabbed beyond its dot, like edges beyond the border. */
	.corner::before {
		content: "";
		position: absolute;
		inset: -2px;
	}

	.corner.ne { right: 0; top: 0; transform: translate(50%, -50%); cursor: nesw-resize; }
	.corner.se { right: 0; bottom: 0; transform: translate(50%, 50%); cursor: nwse-resize; }
	.corner.sw { left: 0; bottom: 0; transform: translate(-50%, 50%); cursor: nesw-resize; }
	.corner.nw { left: 0; top: 0; transform: translate(-50%, -50%); cursor: nwse-resize; }
`;
class rt extends HTMLElement {
  constructor() {
    super(), this.#t = null, this.#s = null, this.#i = null, this.#y = "null", this.area = null, this.#x = ["", ""], this.#e = null, this.#u = null, this.#o = null, this.#d = null, this.#c = null, this.#w = null, this.#n = null, this.#p = !1, this.#l = null, this.#v = new ResizeObserver(() => this.sync()), this.#E = () => this.#k();
    const t = this.attachShadow({ mode: "open" }), i = document.createElement("style");
    i.textContent = nt, this.#r = document.createElement("div"), this.#r.id = "bbox", this.#r.innerHTML = [
      ...et.map((n) => `<div class="edge ${n}" data-handle="${n}"></div>`),
      ...st.map((n) => `<div class="corner ${n}" data-handle="${n}"></div>`)
    ].join(""), this.#r.title = "", this.#f = document.createElement("div"), this.#f.id = "draft";
    const e = document.createElement("div");
    e.id = "shade", this.#_ = document.createElement("div"), this.#_.id = "hole", e.append(this.#_), t.append(i, e, this.#r, this.#f), this.addEventListener("pointerdown", (n) => this.#$(n)), this.addEventListener("pointermove", (n) => this.#S(n)), this.addEventListener("pointerup", () => this.#L()), this.addEventListener("pointercancel", () => this.#O()), this.addEventListener("click", (n) => n.stopPropagation());
  }
  #t;
  #s;
  #i;
  #r;
  #f;
  #_;
  #y;
  #x;
  #e;
  #u;
  #o;
  #d;
  #c;
  #w;
  #n;
  #p;
  #l;
  #v;
  #E;
  /**
   * Image to draw the bounding box over. Bounding box persists when another
   * image is displayed, scaled to its resolution, so user finds it back
   * while browsing images.
   */
  get target() {
    return this.#t;
  }
  set target(t) {
    this.#t !== t && (this.#t && (this.#v.unobserve(this.#t), this.#t.removeEventListener("load", this.#E)), this.#t = t, this.#h(), t && (this.#v.observe(t), t.addEventListener("load", this.#E))), this.#k();
  }
  /**
   * Tooltips shown over the image: while no bounding box is drawn, e.g. to
   * tell how to draw one, then outside the drawn one, e.g. to tell how to
   * clear it.
   */
  get tooltips() {
    return this.#x;
  }
  set tooltips(t) {
    this.#x = t, this.#a();
  }
  /**
   * Bounding box in pixels of the displayed image, scaled to it.
   * Setting it emits no event.
   */
  get value() {
    return this.#b();
  }
  set value(t) {
    this.#s = t ? { ...t } : null, this.#i = p(this.#t) ?? this.#i, this.#y = JSON.stringify(S(this.#b())), this.#h(), this.#a();
  }
  clear() {
    this.#s = null, this.#h(), this.#a(), this.#M();
  }
  /** Cover image content, letterbox bands excluded. */
  sync() {
    const t = this.#t, i = this.parentElement;
    if (!t?.isConnected || !i || !t.naturalWidth || !t.naturalHeight) {
      this.style.display = "none";
      return;
    }
    const e = t.getBoundingClientRect(), n = i.getBoundingClientRect(), r = Math.min(
      e.width / t.naturalWidth,
      e.height / t.naturalHeight
    ), d = t.naturalWidth * r, a = t.naturalHeight * r;
    if (d <= 0 || a <= 0) {
      this.style.display = "none";
      return;
    }
    const c = e.left - n.left - i.clientLeft + (e.width - d) / 2, l = e.top - n.top - i.clientTop + (e.height - a) / 2;
    this.style.display = "block", this.style.left = `${c}px`, this.style.top = `${l}px`, this.style.width = `${d}px`, this.style.height = `${a}px`;
  }
  /** Follow displayed image, which may be another one. */
  #k() {
    this.#i ??= p(this.#t), this.sync(), this.#a(), this.#M();
  }
  /**
   * Bounding box scaled to displayed image, whose resolution may differ
   * from the drawn one, so it covers the same region.
   */
  #b() {
    const t = this.#s, i = p(this.#t);
    if (!t || !i || !this.#i) return t;
    const e = i.width / this.#i.width, n = i.height / this.#i.height;
    return {
      x: t.x * e,
      y: t.y * n,
      width: t.width * e,
      height: t.height * n
    };
  }
  #z(t) {
    const i = this.#t, e = this.getBoundingClientRect(), n = Math.max(0, Math.min(e.width, t.clientX - e.left)), r = Math.max(0, Math.min(e.height, t.clientY - e.top));
    return {
      x: n / e.width * i.naturalWidth,
      y: r / e.height * i.naturalHeight
    };
  }
  #a() {
    const t = this.#t, i = !!t?.naturalWidth && !!t.naturalHeight, e = i ? this.#b() : null, n = i ? this.#c : null, r = n ?? e;
    this.title = this.#x[e ? 1 : 0], this.toggleAttribute("dimmed", !!r), this.toggleAttribute("drafting", !!n), this.#r.style.display = e ? "block" : "none", this.#f.style.display = n ? "block" : "none", r && w(this.#_, r, t), e && w(this.#r, e, t), n && w(this.#f, n, t);
  }
  /** Emit value, if changed. */
  #M() {
    const t = S(this.#b()), i = JSON.stringify(t);
    i !== this.#y && (this.#y = i, this.dispatchEvent(new CustomEvent("bbox-change", { detail: t })));
  }
  /**
   * Outside the bounding box, a click clears it, and a drag draws a new one.
   * Drag direction tells how. To the right, the new bounding box replaces
   * the current one at once. To the left, user may as well drag displayed
   * image to another element, e.g. a prompt left of the gallery: the new
   * bounding box only replaces the current one on release, and leaving the
   * area (gallery) turns the drawing into a drop.
   *
   * Inside, a drag moves the bounding box, or resizes it from an edge or corner.
   */
  #$(t) {
    if (!this.#t || t.button !== 0) return;
    t.preventDefault(), t.stopPropagation(), this.#h();
    const i = t.composedPath(), e = i.find(
      (r) => r instanceof HTMLElement && !!r.dataset.handle
    ), n = this.#b();
    this.#s = n, this.#i = p(this.#t), this.#d = n, this.#o = this.#z(t), e && n ? (this.#e = "resize", this.#w = e.dataset.handle, this.#g(getComputedStyle(e).cursor)) : i.includes(this.#r) && n ? (this.#e = "drag", this.#g("move")) : (this.#e = "press", this.#u = { x: t.clientX, y: t.clientY }), this.setPointerCapture(t.pointerId);
  }
  #S(t) {
    if (!this.#t || !this.#e) return;
    if (this.#e === "press") {
      const n = t.clientX - this.#u.x, r = t.clientY - this.#u.y;
      if (Math.hypot(n, r) <= it) return;
      this.#e = n < 0 ? "draft" : "draw", this.#g("crosshair");
    }
    if (this.#e === "draft" && this.#R(t) && (this.#e = "drop", this.#c = null, this.#a()), this.#e === "drop") {
      this.#A(t);
      return;
    }
    const i = this.#t, e = this.#z(t);
    if (this.#e === "draw")
      this.#s = v(this.#o, e);
    else if (this.#e === "draft")
      this.#c = v(this.#o, e);
    else if (this.#e === "drag") {
      const n = this.#d;
      this.#s = {
        ...n,
        x: L(
          n.x + e.x - this.#o.x,
          0,
          i.naturalWidth - n.width
        ),
        y: L(
          n.y + e.y - this.#o.y,
          0,
          i.naturalHeight - n.height
        )
      };
    } else {
      const n = this.#d, r = this.#w, d = { x: n.x, y: n.y }, a = { x: n.x + n.width, y: n.y + n.height };
      r.includes("n") && (d.y = e.y), r.includes("s") && (a.y = e.y), r.includes("w") && (d.x = e.x), r.includes("e") && (a.x = e.x), this.#s = v(d, a);
    }
    this.#a();
  }
  #L() {
    const t = this.#e;
    t === "press" ? this.clear() : t === "drop" ? (this.#p && (this.#m(this.#n, "drop"), this.#n = null), this.#h()) : t && (t === "draft" && (this.#s = this.#c), this.#H());
  }
  #O() {
    this.#e && this.#C();
  }
  /** Keep bounding box as user edited it, unless it's too small. */
  #H() {
    const t = this.#s;
    if (this.#h(), !t || t.width < $ || t.height < $) {
      this.clear();
      return;
    }
    this.#a(), this.#M();
  }
  /** Back to bounding box as it was before user pressed. */
  #C() {
    this.#s = this.#d, this.#h(), this.#a();
  }
  /** Forget ongoing gesture, if any. */
  #h() {
    this.#n && this.#m(this.#n, "dragleave"), this.#e = null, this.#u = null, this.#o = null, this.#d = null, this.#c = null, this.#w = null, this.#n = null, this.#p = !1, this.#l = null, this.#g(null);
  }
  /** Cursor of ongoing gesture, whatever is pointed, if any. */
  #g(t) {
    this.style.cursor = t ?? "", this.toggleAttribute("gesture", !!t);
  }
  /** Whether pointer left the area bounding box is drawn within. */
  #R(t) {
    const i = (this.area ?? this).getBoundingClientRect();
    return t.clientX < i.left || t.clientX > i.right || t.clientY < i.top || t.clientY > i.bottom;
  }
  /**
   * Drag displayed image over the element pointer is over, outside overlay,
   * as browser would do. Overlay can't let browser drag the image itself:
   * it would take any drag over it, those editing the bounding box included.
   */
  #A(t) {
    const i = document.elementFromPoint(t.clientX, t.clientY), e = i === this ? null : i;
    e !== this.#n && (e && this.#m(e, "dragenter"), this.#n && this.#m(this.#n, "dragleave"), this.#n = e), this.#p = !!e && !this.#m(e, "dragover"), this.#g(this.#p ? "copy" : "grabbing");
  }
  /** Returns false if canceled. */
  #m(t, i) {
    return this.#l || (this.#l = new DataTransfer(), this.#l.setData("text/uri-list", this.#t.currentSrc)), t.dispatchEvent(
      new DragEvent(i, {
        bubbles: !0,
        cancelable: !0,
        composed: !0,
        dataTransfer: this.#l
      })
    );
  }
}
function p(s) {
  return s?.naturalWidth && s.naturalHeight ? { width: s.naturalWidth, height: s.naturalHeight } : null;
}
function w(s, t, i) {
  s.style.left = `${t.x / i.naturalWidth * 100}%`, s.style.top = `${t.y / i.naturalHeight * 100}%`, s.style.width = `${t.width / i.naturalWidth * 100}%`, s.style.height = `${t.height / i.naturalHeight * 100}%`;
}
function S(s) {
  return s && {
    x: Math.round(s.x),
    y: Math.round(s.y),
    width: Math.round(s.width),
    height: Math.round(s.height)
  };
}
function L(s, t, i) {
  return Math.max(t, Math.min(i, s));
}
function v(s, t) {
  return {
    x: Math.min(s.x, t.x),
    y: Math.min(s.y, t.y),
    width: Math.abs(t.x - s.x),
    height: Math.abs(t.y - s.y)
  };
}
const E = "mask-bounding-box-overlay";
customElements.get(E) || customElements.define(E, rt);
function ot(s, t) {
  Y(t, !0);
  var i;
  const e = /* @__PURE__ */ F(t, ["$$slots", "$$events", "$$legacy"]), n = new tt(e), r = document.createElement(E);
  let d = (i = n.props.value) !== null && i !== void 0 ? i : null;
  r.value = d;
  let a = null;
  function c(h, o) {
    return JSON.stringify(h ?? null) === JSON.stringify(o ?? null);
  }
  function l(h, o) {
    !h && o ? n.dispatch("drawn") : h && !o && n.dispatch("cleared");
  }
  function u(h) {
    const o = h.querySelector('.media-button img[data-testid="detailed-image"]');
    if (!o) {
      r.target = null, r.remove();
      return;
    }
    const M = o.parentElement;
    r.parentElement !== M && M.append(r), r.area = h, r.target = o;
  }
  function m() {
    const h = n.props.gallery_elem_id, o = h ? document.getElementById(h) : null;
    if (a?.disconnect(), !o) {
      if (!h) return;
      a = new MutationObserver(m), a.observe(document.body, { childList: !0, subtree: !0 });
      return;
    }
    a = new MutationObserver(() => u(o)), a.observe(o, {
      childList: !0,
      subtree: !0,
      attributes: !0,
      attributeFilter: ["src"]
    }), u(o);
  }
  C(() => {
    r.addEventListener("bbox-change", (h) => {
      const o = h.detail;
      l(d, o), d = o, n.props.value = o, n.dispatch("input"), n.dispatch("change");
    }), m();
  }), K(() => {
    a?.disconnect(), r.target = null, r.remove();
  }), f(() => {
    var h;
    const o = (h = n.props.value) !== null && h !== void 0 ? h : null;
    c(o, d) || (l(d, o), d = o, r.value = o, n.dispatch("change"));
  }), f(() => {
    var h, o;
    r.toggleAttribute("disabled", n.shared.interactive === !1), r.toggleAttribute("hidden", n.shared.visible === !1), r.tooltips = [
      (h = n.props.draw_tooltip) !== null && h !== void 0 ? h : "",
      (o = n.props.clear_tooltip) !== null && o !== void 0 ? o : ""
    ];
  }), W();
}
export {
  ot as default
};
