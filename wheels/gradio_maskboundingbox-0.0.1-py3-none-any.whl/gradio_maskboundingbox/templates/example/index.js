import { e as U, g as Y, i as q, T as G, a as B, c as T, b as D, r as H, d as S, p as j, f as M, m as z, s as J, h as K, E as W, j as Q, u as V, k as O, l as R, n as v, o as X, q as m, t as g, v as Z, w as $, x as ee, P as te, y as se, z as ae, D as re, A as ne, B as ie, C as fe, F as le, G as ce, S as ue, L as oe, H as x, I as de, J as he, K as _e, M as ve } from "./render-Auu2J1pj.js";
U();
function ge(a) {
  var e = document.createElement("template");
  return e.innerHTML = a.replaceAll("<!>", "<!---->"), e.content;
}
function F(a, e) {
  var t = (
    /** @type {Effect} */
    B
  );
  t.nodes === null && (t.nodes = { start: a, end: e, a: null, t: null });
}
// @__NO_SIDE_EFFECTS__
function me(a, e) {
  var t = (e & G) !== 0, s, i = !a.startsWith("<!>");
  return () => {
    s === void 0 && (s = ge(i ? a : "<!>" + a), s = /** @type {TemplateNode} */
    Y(s));
    var r = (
      /** @type {TemplateNode} */
      t || q ? document.importNode(s, !0) : s.cloneNode(!0)
    );
    return F(r, r), r;
  };
}
function y(a = "") {
  {
    var e = T(a + "");
    return F(e, e), e;
  }
}
function P(a, e) {
  a !== null && a.before(
    /** @type {Node} */
    e
  );
}
class be {
  /** @type {TemplateNode} */
  anchor;
  /** @type {Map<Batch, Key>} */
  #t = /* @__PURE__ */ new Map();
  /**
   * Map of keys to effects that are currently rendered in the DOM.
   * These effects are visible and actively part of the document tree.
   * Example:
   * ```
   * {#if condition}
   * 	foo
   * {:else}
   * 	bar
   * {/if}
   * ```
   * Can result in the entries `true->Effect` and `false->Effect`
   * @type {Map<Key, Effect>}
   */
  #s = /* @__PURE__ */ new Map();
  /**
   * Similar to #onscreen with respect to the keys, but contains branches that are not yet
   * in the DOM, because their insertion is deferred.
   * @type {Map<Key, Branch>}
   */
  #e = /* @__PURE__ */ new Map();
  /**
   * Keys of effects that are currently outroing
   * @type {Set<Key>}
   */
  #a = /* @__PURE__ */ new Set();
  /**
   * Whether to pause (i.e. outro) on change, or destroy immediately.
   * This is necessary for `<svelte:element>`
   */
  #r = !0;
  /**
   * @param {TemplateNode} anchor
   * @param {boolean} transition
   */
  constructor(e, t = !0) {
    this.anchor = e, this.#r = t;
  }
  #n = () => {
    var e = (
      /** @type {Batch} */
      D
    );
    if (this.#t.has(e)) {
      var t = (
        /** @type {Key} */
        this.#t.get(e)
      ), s = this.#s.get(t);
      if (s)
        H(s), this.#a.delete(t);
      else {
        var i = this.#e.get(t);
        i && (this.#s.set(t, i.effect), this.#e.delete(t), i.fragment.lastChild.remove(), this.anchor.before(i.fragment), s = i.effect);
      }
      for (const [r, n] of this.#t) {
        if (this.#t.delete(r), r === e)
          break;
        const f = this.#e.get(n);
        f && (S(f.effect), this.#e.delete(n));
      }
      for (const [r, n] of this.#s) {
        if (r === t || this.#a.has(r)) continue;
        const f = () => {
          if (Array.from(this.#t.values()).includes(r)) {
            var c = document.createDocumentFragment();
            z(n, c), c.append(T()), this.#e.set(r, { effect: n, fragment: c });
          } else
            S(n);
          this.#a.delete(r), this.#s.delete(r);
        };
        this.#r || !s ? (this.#a.add(r), j(n, f, !1)) : f();
      }
    }
  };
  /**
   * @param {Batch} batch
   */
  #i = (e) => {
    this.#t.delete(e);
    const t = Array.from(this.#t.values());
    for (const [s, i] of this.#e)
      t.includes(s) || (S(i.effect), this.#e.delete(s));
  };
  /**
   *
   * @param {any} key
   * @param {null | ((target: TemplateNode) => void)} fn
   */
  ensure(e, t) {
    var s = (
      /** @type {Batch} */
      D
    ), i = J();
    if (t && !this.#s.has(e) && !this.#e.has(e))
      if (i) {
        var r = document.createDocumentFragment(), n = T();
        r.append(n), this.#e.set(e, {
          effect: M(() => t(n)),
          fragment: r
        });
      } else
        this.#s.set(
          e,
          M(() => t(this.anchor))
        );
    if (this.#t.set(s, e), i) {
      for (const [f, l] of this.#s)
        f === e ? s.skipped_effects.delete(l) : s.skipped_effects.add(l);
      for (const [f, l] of this.#e)
        f === e ? s.skipped_effects.delete(l.effect) : s.skipped_effects.add(l.effect);
      s.oncommit(this.#n), s.ondiscard(this.#i);
    } else
      this.#n();
  }
}
function pe(a, e, t = !1) {
  var s = new be(a), i = t ? W : 0;
  function r(n, f) {
    s.ensure(n, f);
  }
  K(() => {
    var n = !1;
    e((f, l = !0) => {
      n = !0, r(l, f);
    }), n || r(!1, null);
  }, i);
}
const L = [...` 	
\r\f \v\uFEFF`];
function Ee(a, e, t) {
  var s = "" + a;
  if (t) {
    for (var i in t)
      if (t[i])
        s = s ? s + " " + i : i;
      else if (s.length)
        for (var r = i.length, n = 0; (n = s.indexOf(i, n)) >= 0; ) {
          var f = n + r;
          (n === 0 || L.includes(s[n - 1])) && (f === s.length || L.includes(s[f])) ? s = (n === 0 ? "" : s.substring(0, n)) + s.substring(f + 1) : n = f;
        }
  }
  return s === "" ? null : s;
}
function Se(a, e, t, s, i, r) {
  var n = a.__className;
  if (n !== t || n === void 0) {
    var f = Ee(t, s, r);
    f == null ? a.removeAttribute("class") : a.className = f, a.__className = t;
  } else if (r && i !== r)
    for (var l in r) {
      var c = !!r[l];
      (i == null || c !== !!i[l]) && a.classList.toggle(l, c);
    }
  return r;
}
function Pe(a = !1) {
  const e = (
    /** @type {ComponentContextLegacy} */
    Q
  ), t = e.l.u;
  if (!t) return;
  let s = () => g(e.s);
  if (a) {
    let i = 0, r = (
      /** @type {Record<string, any>} */
      {}
    );
    const n = Z(() => {
      let f = !1;
      const l = e.s;
      for (const c in l)
        l[c] !== r[c] && (r[c] = l[c], f = !0);
      return f && i++, i;
    });
    s = () => m(n);
  }
  t.b.length && V(() => {
    I(e, s), R(t.b);
  }), O(() => {
    const i = v(() => t.m.map(X));
    return () => {
      for (const r of i)
        typeof r == "function" && r();
    };
  }), t.a.length && O(() => {
    I(e, s), R(t.a);
  });
}
function I(a, e) {
  if (a.l.s)
    for (const t of a.l.s) m(t);
  e();
}
let p = !1;
function Ae(a) {
  var e = p;
  try {
    return p = !1, [a(), p];
  } finally {
    p = e;
  }
}
function A(a, e, t, s) {
  var i = !ne || (t & ie) !== 0, r = (t & fe) !== 0, n = (
    /** @type {V} */
    s
  ), f = !0, l = () => (f && (f = !1, n = /** @type {V} */
  s), n), c;
  {
    var d = ue in a || oe in a;
    c = $(a, e)?.set ?? (d && e in a ? (u) => a[e] = u : void 0);
  }
  var o, w = !1;
  [o, w] = Ae(() => (
    /** @type {V} */
    a[e]
  )), o === void 0 && s !== void 0 && (o = l(), c && (i && ee(), c(o)));
  var h;
  if (i ? h = () => {
    var u = (
      /** @type {V} */
      a[e]
    );
    return u === void 0 ? l() : (f = !0, u);
  } : h = () => {
    var u = (
      /** @type {V} */
      a[e]
    );
    return u !== void 0 && (n = /** @type {V} */
    void 0), u === void 0 ? n : u;
  }, i && (t & te) === 0)
    return h;
  if (c) {
    var k = a.$$legacy;
    return (
      /** @type {() => V} */
      (function(u, b) {
        return arguments.length > 0 ? ((!i || !b || k || w) && c(b ? h() : u), u) : h();
      })
    );
  }
  var E = !1, _ = le(() => (E = !1, h()));
  m(_);
  var C = (
    /** @type {Effect} */
    B
  );
  return (
    /** @type {() => V} */
    (function(u, b) {
      if (arguments.length > 0) {
        const N = b ? m(_) : i && r ? se(u) : u;
        return ae(_, N), E = !0, n !== void 0 && (n = N), u;
      }
      return ce && E || (C.f & re) !== 0 ? _.v : m(_);
    })
  );
}
var Te = /* @__PURE__ */ me("<div><!></div>");
function Ne(a, e) {
  he(e, !1);
  let t = A(e, "value", 8), s = A(e, "type", 8), i = A(e, "selected", 8, !1);
  Pe();
  var r = Te();
  let n;
  var f = _e(r);
  {
    var l = (d) => {
      var o = y();
      x(() => ve(o, `${g(t()), v(() => t().x) ?? ""}, ${g(t()), v(() => t().y) ?? ""} · ${g(t()), v(() => t().width) ?? ""}×${g(t()), v(() => t().height) ?? ""}`)), P(d, o);
    }, c = (d) => {
      var o = y("—");
      P(d, o);
    };
    pe(f, (d) => {
      t() ? d(l) : d(c, !1);
    });
  }
  x(() => n = Se(r, 1, "svelte-exvtcd", null, n, {
    table: s() === "table",
    gallery: s() === "gallery",
    selected: i()
  })), P(a, r), de();
}
export {
  Ne as default
};
