const Mn = 1, jn = 2, y = /* @__PURE__ */ Symbol(), In = "http://www.w3.org/1999/xhtml", Fe = !1;
var Pt = Array.isArray, Ct = Array.prototype.indexOf, Dt = Array.from, Mt = Object.defineProperty, ce = Object.getOwnPropertyDescriptor, qn = Object.getOwnPropertyDescriptors, jt = Object.prototype, It = Array.prototype, qt = Object.getPrototypeOf, ze = Object.isExtensible;
const Ln = () => {
};
function Lt(e) {
  for (var t = 0; t < e.length; t++)
    e[t]();
}
function et() {
  var e, t, n = new Promise((r, i) => {
    e = r, t = i;
  });
  return { promise: n, resolve: e, reject: t };
}
const m = 2, me = 4, Se = 8, tt = 1 << 24, B = 16, U = 32, re = 64, je = 128, R = 512, E = 1024, b = 2048, Y = 4096, D = 8192, $ = 16384, Ie = 32768, he = 65536, He = 1 << 17, nt = 1 << 18, ae = 1 << 19, Vt = 1 << 20, te = 32768, Ne = 1 << 21, qe = 1 << 22, z = 1 << 23, Oe = /* @__PURE__ */ Symbol("$state"), Vn = /* @__PURE__ */ Symbol(""), se = new class extends Error {
  name = "StaleReactionError";
  message = "The reaction that called `getAbortSignal()` was re-run or destroyed";
}();
function Bt() {
  throw new Error("https://svelte.dev/e/async_derived_orphan");
}
function Ut(e) {
  throw new Error("https://svelte.dev/e/effect_in_teardown");
}
function Yt() {
  throw new Error("https://svelte.dev/e/effect_in_unowned_derived");
}
function Gt(e) {
  throw new Error("https://svelte.dev/e/effect_orphan");
}
function Kt() {
  throw new Error("https://svelte.dev/e/effect_update_depth_exceeded");
}
function $t() {
  throw new Error("https://svelte.dev/e/state_descriptors_fixed");
}
function zt() {
  throw new Error("https://svelte.dev/e/state_prototype_fixed");
}
function Ht() {
  throw new Error("https://svelte.dev/e/state_unsafe_mutation");
}
function Wt() {
  throw new Error("https://svelte.dev/e/svelte_boundary_reset_onerror");
}
function Jt() {
  console.warn("https://svelte.dev/e/svelte_boundary_reset_noop");
}
function rt(e) {
  return e === this.v;
}
function Qt(e, t) {
  return e != e ? t == t : e !== t || e !== null && typeof e == "object" || typeof e == "function";
}
function Zt(e) {
  return !Qt(e, this.v);
}
let Le = !1, Xt = !1;
function Un() {
  Le = !0;
}
let S = null;
function le(e) {
  S = e;
}
function en(e, t = !1, n) {
  S = {
    p: S,
    i: !1,
    c: null,
    e: null,
    s: e,
    x: null,
    l: Le && !t ? { s: null, u: null, $: [] } : null
  };
}
function tn(e) {
  var t = (
    /** @type {ComponentContext} */
    S
  ), n = t.e;
  if (n !== null) {
    t.e = null;
    for (var r of n)
      wt(r);
  }
  return t.i = !0, S = t.p, /** @type {T} */
  {};
}
function ve() {
  return !Le || S !== null && S.l === null;
}
let fe = [];
function nn() {
  var e = fe;
  fe = [], Lt(e);
}
function Ve(e) {
  if (fe.length === 0) {
    var t = fe;
    queueMicrotask(() => {
      t === fe && nn();
    });
  }
  fe.push(e);
}
function it(e) {
  var t = v;
  if (t === null)
    return d.f |= z, e;
  if ((t.f & Ie) === 0) {
    if ((t.f & je) === 0)
      throw e;
    t.b.error(e);
  } else
    ue(e, t);
}
function ue(e, t) {
  for (; t !== null; ) {
    if ((t.f & je) !== 0)
      try {
        t.b.error(e);
        return;
      } catch (n) {
        e = n;
      }
    t = t.parent;
  }
  throw e;
}
const rn = -7169;
function w(e, t) {
  e.f = e.f & rn | t;
}
function Be(e) {
  (e.f & R) !== 0 || e.deps === null ? w(e, E) : w(e, Y);
}
function st(e) {
  if (e !== null)
    for (const t of e)
      (t.f & m) === 0 || (t.f & te) === 0 || (t.f ^= te, st(
        /** @type {Derived} */
        t.deps
      ));
}
function ft(e, t, n) {
  (e.f & b) !== 0 ? t.add(e) : (e.f & Y) !== 0 && n.add(e), st(e.deps), w(e, E);
}
const ge = /* @__PURE__ */ new Set();
let g = null, O = null, P = [], Ue = null, Pe = !1;
class C {
  committed = !1;
  /**
   * The current values of any sources that are updated in this batch
   * They keys of this map are identical to `this.#previous`
   * @type {Map<Source, any>}
   */
  current = /* @__PURE__ */ new Map();
  /**
   * The values of any sources that are updated in this batch _before_ those updates took place.
   * They keys of this map are identical to `this.#current`
   * @type {Map<Source, any>}
   */
  previous = /* @__PURE__ */ new Map();
  /**
   * When the batch is committed (and the DOM is updated), we need to remove old branches
   * and append new ones by calling the functions added inside (if/each/key/etc) blocks
   * @type {Set<() => void>}
   */
  #t = /* @__PURE__ */ new Set();
  /**
   * If a fork is discarded, we need to destroy any effects that are no longer needed
   * @type {Set<(batch: Batch) => void>}
   */
  #_ = /* @__PURE__ */ new Set();
  /**
   * The number of async effects that are currently in flight
   */
  #r = 0;
  /**
   * The number of async effects that are currently in flight, _not_ inside a pending boundary
   */
  #f = 0;
  /**
   * A deferred that resolves when the batch is committed, used with `settled()`
   * TODO replace with Promise.withResolvers once supported widely enough
   * @type {{ promise: Promise<void>, resolve: (value?: any) => void, reject: (reason: unknown) => void } | null}
   */
  #i = null;
  /**
   * Deferred effects (which run after async work has completed) that are DIRTY
   * @type {Set<Effect>}
   */
  #n = /* @__PURE__ */ new Set();
  /**
   * Deferred effects that are MAYBE_DIRTY
   * @type {Set<Effect>}
   */
  #e = /* @__PURE__ */ new Set();
  /**
   * A set of branches that still exist, but will be destroyed when this batch
   * is committed — we skip over these during `process`
   * @type {Set<Effect>}
   */
  skipped_effects = /* @__PURE__ */ new Set();
  is_fork = !1;
  is_deferred() {
    return this.is_fork || this.#f > 0;
  }
  /**
   *
   * @param {Effect[]} root_effects
   */
  process(t) {
    P = [], this.apply();
    var n = [], r = [];
    for (const i of t)
      this.#s(i, n, r);
    this.is_fork || this.#u(), this.is_deferred() ? (this.#l(r), this.#l(n)) : (g = null, We(r), We(n), this.#i?.resolve()), O = null;
  }
  /**
   * Traverse the effect tree, executing effects or stashing
   * them for later execution as appropriate
   * @param {Effect} root
   * @param {Effect[]} effects
   * @param {Effect[]} render_effects
   */
  #s(t, n, r) {
    t.f ^= E;
    for (var i = t.first, s = null; i !== null; ) {
      var l = i.f, u = (l & (U | re)) !== 0, f = u && (l & E) !== 0, a = f || (l & D) !== 0 || this.skipped_effects.has(i);
      if (!a && i.fn !== null) {
        u ? i.f ^= E : s !== null && (l & (me | Se | tt)) !== 0 ? s.b.defer_effect(i) : (l & me) !== 0 ? n.push(i) : pe(i) && ((l & B) !== 0 && this.#n.add(i), de(i));
        var o = i.first;
        if (o !== null) {
          i = o;
          continue;
        }
      }
      var h = i.parent;
      for (i = i.next; i === null && h !== null; )
        h === s && (s = null), i = h.next, h = h.parent;
    }
  }
  /**
   * @param {Effect[]} effects
   */
  #l(t) {
    for (var n = 0; n < t.length; n += 1)
      ft(t[n], this.#n, this.#e);
  }
  /**
   * Associate a change to a given source with the current
   * batch, noting its previous and current values
   * @param {Source} source
   * @param {any} value
   */
  capture(t, n) {
    n !== y && !this.previous.has(t) && this.previous.set(t, n), (t.f & z) === 0 && (this.current.set(t, t.v), O?.set(t, t.v));
  }
  activate() {
    g = this, this.apply();
  }
  deactivate() {
    g === this && (g = null, O = null);
  }
  flush() {
    if (this.activate(), P.length > 0) {
      if (sn(), g !== null && g !== this)
        return;
    } else this.#r === 0 && this.process([]);
    this.deactivate();
  }
  discard() {
    for (const t of this.#_) t(this);
    this.#_.clear();
  }
  #u() {
    if (this.#f === 0) {
      for (const t of this.#t) t();
      this.#t.clear();
    }
    this.#r === 0 && this.#a();
  }
  #a() {
    if (ge.size > 1) {
      this.previous.clear();
      var t = O, n = !0;
      for (const i of ge) {
        if (i === this) {
          n = !1;
          continue;
        }
        const s = [];
        for (const [u, f] of this.current) {
          if (i.current.has(u))
            if (n && f !== i.current.get(u))
              i.current.set(u, f);
            else
              continue;
          s.push(u);
        }
        if (s.length === 0)
          continue;
        const l = [...i.current.keys()].filter((u) => !this.current.has(u));
        if (l.length > 0) {
          var r = P;
          P = [];
          const u = /* @__PURE__ */ new Set(), f = /* @__PURE__ */ new Map();
          for (const a of s)
            lt(a, l, u, f);
          if (P.length > 0) {
            g = i, i.apply();
            for (const a of P)
              i.#s(a, [], []);
            i.deactivate();
          }
          P = r;
        }
      }
      g = null, O = t;
    }
    this.committed = !0, ge.delete(this);
  }
  /**
   *
   * @param {boolean} blocking
   */
  increment(t) {
    this.#r += 1, t && (this.#f += 1);
  }
  /**
   *
   * @param {boolean} blocking
   */
  decrement(t) {
    this.#r -= 1, t && (this.#f -= 1), this.revive();
  }
  revive() {
    for (const t of this.#n)
      this.#e.delete(t), w(t, b), V(t);
    for (const t of this.#e)
      w(t, Y), V(t);
    this.flush();
  }
  /** @param {() => void} fn */
  oncommit(t) {
    this.#t.add(t);
  }
  /** @param {(batch: Batch) => void} fn */
  ondiscard(t) {
    this.#_.add(t);
  }
  settled() {
    return (this.#i ??= et()).promise;
  }
  static ensure() {
    if (g === null) {
      const t = g = new C();
      ge.add(g), C.enqueue(() => {
        g === t && t.flush();
      });
    }
    return g;
  }
  /** @param {() => void} task */
  static enqueue(t) {
    Ve(t);
  }
  apply() {
  }
}
function sn() {
  var e = X;
  Pe = !0;
  var t = null;
  try {
    var n = 0;
    for (xe(!0); P.length > 0; ) {
      var r = C.ensure();
      if (n++ > 1e3) {
        var i, s;
        fn();
      }
      r.process(P), H.clear();
    }
  } finally {
    Pe = !1, xe(e), Ue = null;
  }
}
function fn() {
  try {
    Kt();
  } catch (e) {
    ue(e, Ue);
  }
}
let q = null;
function We(e) {
  var t = e.length;
  if (t !== 0) {
    for (var n = 0; n < t; ) {
      var r = e[n++];
      if ((r.f & ($ | D)) === 0 && pe(r) && (q = /* @__PURE__ */ new Set(), de(r), r.deps === null && r.first === null && r.nodes === null && (r.teardown === null && r.ac === null ? Et(r) : r.fn = null), q?.size > 0)) {
        H.clear();
        for (const i of q) {
          if ((i.f & ($ | D)) !== 0) continue;
          const s = [i];
          let l = i.parent;
          for (; l !== null; )
            q.has(l) && (q.delete(l), s.push(l)), l = l.parent;
          for (let u = s.length - 1; u >= 0; u--) {
            const f = s[u];
            (f.f & ($ | D)) === 0 && de(f);
          }
        }
        q.clear();
      }
    }
    q = null;
  }
}
function lt(e, t, n, r) {
  if (!n.has(e) && (n.add(e), e.reactions !== null))
    for (const i of e.reactions) {
      const s = i.f;
      (s & m) !== 0 ? lt(
        /** @type {Derived} */
        i,
        t,
        n,
        r
      ) : (s & (qe | B)) !== 0 && (s & b) === 0 && ut(i, t, r) && (w(i, b), V(
        /** @type {Effect} */
        i
      ));
    }
}
function ut(e, t, n) {
  const r = n.get(e);
  if (r !== void 0) return r;
  if (e.deps !== null)
    for (const i of e.deps) {
      if (t.includes(i))
        return !0;
      if ((i.f & m) !== 0 && ut(
        /** @type {Derived} */
        i,
        t,
        n
      ))
        return n.set(
          /** @type {Derived} */
          i,
          !0
        ), !0;
    }
  return n.set(e, !1), !1;
}
function V(e) {
  for (var t = Ue = e; t.parent !== null; ) {
    t = t.parent;
    var n = t.f;
    if (Pe && t === v && (n & B) !== 0 && (n & nt) === 0)
      return;
    if ((n & (re | U)) !== 0) {
      if ((n & E) === 0) return;
      t.f ^= E;
    }
  }
  P.push(t);
}
function ln(e) {
  let t = 0, n = Ae(0), r;
  return () => {
    Ke() && (Z(n), Tn(() => (t === 0 && (r = Nn(() => e(() => _e(n)))), t += 1, () => {
      Ve(() => {
        t -= 1, t === 0 && (r?.(), r = void 0, _e(n));
      });
    })));
  };
}
var un = he | ae | je;
function an(e, t, n) {
  new on(e, t, n);
}
class on {
  /** @type {Boundary | null} */
  parent;
  is_pending = !1;
  /** @type {TemplateNode} */
  #t;
  /** @type {TemplateNode | null} */
  #_ = null;
  /** @type {BoundaryProps} */
  #r;
  /** @type {((anchor: Node) => void)} */
  #f;
  /** @type {Effect} */
  #i;
  /** @type {Effect | null} */
  #n = null;
  /** @type {Effect | null} */
  #e = null;
  /** @type {Effect | null} */
  #s = null;
  /** @type {DocumentFragment | null} */
  #l = null;
  /** @type {TemplateNode | null} */
  #u = null;
  #a = 0;
  #o = 0;
  #h = !1;
  /** @type {Set<Effect>} */
  #d = /* @__PURE__ */ new Set();
  /** @type {Set<Effect>} */
  #v = /* @__PURE__ */ new Set();
  /**
   * A source containing the number of pending async deriveds/expressions.
   * Only created if `$effect.pending()` is used inside the boundary,
   * otherwise updating the source results in needless `Batch.ensure()`
   * calls followed by no-op flushes
   * @type {Source<number> | null}
   */
  #c = null;
  #m = ln(() => (this.#c = Ae(this.#a), () => {
    this.#c = null;
  }));
  /**
   * @param {TemplateNode} node
   * @param {BoundaryProps} props
   * @param {((anchor: Node) => void)} children
   */
  constructor(t, n, r) {
    this.#t = t, this.#r = n, this.#f = r, this.parent = /** @type {Effect} */
    v.b, this.is_pending = !!this.#r.pending, this.#i = Sn(() => {
      v.b = this;
      {
        var i = this.#w();
        try {
          this.#n = W(() => r(i));
        } catch (s) {
          this.error(s);
        }
        this.#o > 0 ? this.#g() : this.is_pending = !1;
      }
      return () => {
        this.#u?.remove();
      };
    }, un);
  }
  #E() {
    try {
      this.#n = W(() => this.#f(this.#t));
    } catch (t) {
      this.error(t);
    }
  }
  #b() {
    const t = this.#r.pending;
    t && (this.#e = W(() => t(this.#t)), C.enqueue(() => {
      var n = this.#w();
      this.#n = this.#p(() => (C.ensure(), W(() => this.#f(n)))), this.#o > 0 ? this.#g() : (ye(
        /** @type {Effect} */
        this.#e,
        () => {
          this.#e = null;
        }
      ), this.is_pending = !1);
    }));
  }
  #w() {
    var t = this.#t;
    return this.is_pending && (this.#u = vt(), this.#t.before(this.#u), t = this.#u), t;
  }
  /**
   * Defer an effect inside a pending boundary until the boundary resolves
   * @param {Effect} effect
   */
  defer_effect(t) {
    ft(t, this.#d, this.#v);
  }
  /**
   * Returns `false` if the effect exists inside a boundary whose pending snippet is shown
   * @returns {boolean}
   */
  is_rendered() {
    return !this.is_pending && (!this.parent || this.parent.is_rendered());
  }
  has_pending_snippet() {
    return !!this.#r.pending;
  }
  /**
   * @param {() => Effect | null} fn
   */
  #p(t) {
    var n = v, r = d, i = S;
    j(this.#i), T(this.#i), le(this.#i.ctx);
    try {
      return t();
    } catch (s) {
      return it(s), null;
    } finally {
      j(n), T(r), le(i);
    }
  }
  #g() {
    const t = (
      /** @type {(anchor: Node) => void} */
      this.#r.pending
    );
    this.#n !== null && (this.#l = document.createDocumentFragment(), this.#l.append(
      /** @type {TemplateNode} */
      this.#u
    ), Rn(this.#n, this.#l)), this.#e === null && (this.#e = W(() => t(this.#t)));
  }
  /**
   * Updates the pending count associated with the currently visible pending snippet,
   * if any, such that we can replace the snippet with content once work is done
   * @param {1 | -1} d
   */
  #y(t) {
    if (!this.has_pending_snippet()) {
      this.parent && this.parent.#y(t);
      return;
    }
    if (this.#o += t, this.#o === 0) {
      this.is_pending = !1;
      for (const n of this.#d)
        w(n, b), V(n);
      for (const n of this.#v)
        w(n, Y), V(n);
      this.#d.clear(), this.#v.clear(), this.#e && ye(this.#e, () => {
        this.#e = null;
      }), this.#l && (this.#t.before(this.#l), this.#l = null);
    }
  }
  /**
   * Update the source that powers `$effect.pending()` inside this boundary,
   * and controls when the current `pending` snippet (if any) is removed.
   * Do not call from inside the class
   * @param {1 | -1} d
   */
  update_pending_count(t) {
    this.#y(t), this.#a += t, this.#c && be(this.#c, this.#a);
  }
  get_effect_pending() {
    return this.#m(), Z(
      /** @type {Source<number>} */
      this.#c
    );
  }
  /** @param {unknown} error */
  error(t) {
    var n = this.#r.onerror;
    let r = this.#r.failed;
    if (this.#h || !n && !r)
      throw t;
    this.#n && (M(this.#n), this.#n = null), this.#e && (M(this.#e), this.#e = null), this.#s && (M(this.#s), this.#s = null);
    var i = !1, s = !1;
    const l = () => {
      if (i) {
        Jt();
        return;
      }
      i = !0, s && Wt(), C.ensure(), this.#a = 0, this.#s !== null && ye(this.#s, () => {
        this.#s = null;
      }), this.is_pending = this.has_pending_snippet(), this.#n = this.#p(() => (this.#h = !1, W(() => this.#f(this.#t)))), this.#o > 0 ? this.#g() : this.is_pending = !1;
    };
    var u = d;
    try {
      T(null), s = !0, n?.(t, l), s = !1;
    } catch (f) {
      ue(f, this.#i && this.#i.parent);
    } finally {
      T(u);
    }
    r && Ve(() => {
      this.#s = this.#p(() => {
        C.ensure(), this.#h = !0;
        try {
          return W(() => {
            r(
              this.#t,
              () => t,
              () => l
            );
          });
        } catch (f) {
          return ue(
            f,
            /** @type {Effect} */
            this.#i.parent
          ), null;
        } finally {
          this.#h = !1;
        }
      });
    });
  }
}
function cn(e, t, n, r) {
  const i = ve() ? Ye : dn;
  if (n.length === 0 && e.length === 0) {
    r(t.map(i));
    return;
  }
  var s = g, l = (
    /** @type {Effect} */
    v
  ), u = _n();
  function f() {
    Promise.all(n.map((a) => /* @__PURE__ */ hn(a))).then((a) => {
      u();
      try {
        r([...t.map(i), ...a]);
      } catch (o) {
        (l.f & $) === 0 && ue(o, l);
      }
      s?.deactivate(), Ee();
    }).catch((a) => {
      ue(a, l);
    });
  }
  e.length > 0 ? Promise.all(e).then(() => {
    u();
    try {
      return f();
    } finally {
      s?.deactivate(), Ee();
    }
  }) : f();
}
function _n() {
  var e = v, t = d, n = S, r = g;
  return function(s = !0) {
    j(e), T(t), le(n), s && r?.activate();
  };
}
function Ee() {
  j(null), T(null), le(null);
}
// @__NO_SIDE_EFFECTS__
function Ye(e) {
  var t = m | b, n = d !== null && (d.f & m) !== 0 ? (
    /** @type {Derived} */
    d
  ) : null;
  return v !== null && (v.f |= ae), {
    ctx: S,
    deps: null,
    effects: null,
    equals: rt,
    f: t,
    fn: e,
    reactions: null,
    rv: 0,
    v: (
      /** @type {V} */
      y
    ),
    wv: 0,
    parent: n ?? v,
    ac: null
  };
}
// @__NO_SIDE_EFFECTS__
function hn(e, t, n) {
  let r = (
    /** @type {Effect | null} */
    v
  );
  r === null && Bt();
  var i = (
    /** @type {Boundary} */
    r.b
  ), s = (
    /** @type {Promise<V>} */
    /** @type {unknown} */
    void 0
  ), l = Ae(
    /** @type {V} */
    y
  ), u = !d, f = /* @__PURE__ */ new Map();
  return xn(() => {
    var a = et();
    s = a.promise;
    try {
      Promise.resolve(e()).then(a.resolve, a.reject).then(() => {
        o === g && o.committed && o.deactivate(), Ee();
      });
    } catch (_) {
      a.reject(_), Ee();
    }
    var o = (
      /** @type {Batch} */
      g
    );
    if (u) {
      var h = i.is_rendered();
      i.update_pending_count(1), o.increment(h), f.get(o)?.reject(se), f.delete(o), f.set(o, a);
    }
    const c = (_, p = void 0) => {
      if (o.activate(), p)
        p !== se && (l.f |= z, be(l, p));
      else {
        (l.f & z) !== 0 && (l.f ^= z), be(l, _);
        for (const [N, I] of f) {
          if (f.delete(N), N === o) break;
          I.reject(se);
        }
      }
      u && (i.update_pending_count(-1), o.decrement(h));
    };
    a.promise.then(c, (_) => c(null, _ || "unknown"));
  }), En(() => {
    for (const a of f.values())
      a.reject(se);
  }), new Promise((a) => {
    function o(h) {
      function c() {
        h === s ? a(l) : o(s);
      }
      h.then(c, c);
    }
    o(s);
  });
}
// @__NO_SIDE_EFFECTS__
function Yn(e) {
  const t = /* @__PURE__ */ Ye(e);
  return Tt(t), t;
}
// @__NO_SIDE_EFFECTS__
function dn(e) {
  const t = /* @__PURE__ */ Ye(e);
  return t.equals = Zt, t;
}
function at(e) {
  var t = e.effects;
  if (t !== null) {
    e.effects = null;
    for (var n = 0; n < t.length; n += 1)
      M(
        /** @type {Effect} */
        t[n]
      );
  }
}
function vn(e) {
  for (var t = e.parent; t !== null; ) {
    if ((t.f & m) === 0)
      return (t.f & $) === 0 ? (
        /** @type {Effect} */
        t
      ) : null;
    t = t.parent;
  }
  return null;
}
function Ge(e) {
  var t, n = v;
  j(vn(e));
  try {
    e.f &= ~te, at(e), t = Rt(e);
  } finally {
    j(n);
  }
  return t;
}
function ot(e) {
  var t = Ge(e);
  if (!e.equals(t) && (e.wv = At(), (!g?.is_fork || e.deps === null) && (e.v = t, e.deps === null))) {
    w(e, E);
    return;
  }
  ne || (O !== null ? (Ke() || g?.is_fork) && O.set(e, t) : Be(e));
}
let Ce = /* @__PURE__ */ new Set();
const H = /* @__PURE__ */ new Map();
let ct = !1;
function Ae(e, t) {
  var n = {
    f: 0,
    // TODO ideally we could skip this altogether, but it causes type errors
    v: e,
    reactions: null,
    equals: rt,
    rv: 0,
    wv: 0
  };
  return n;
}
// @__NO_SIDE_EFFECTS__
function K(e, t) {
  const n = Ae(e);
  return Tt(n), n;
}
function J(e, t, n = !1) {
  d !== null && // since we are untracking the function inside `$inspect.with` we need to add this check
  // to ensure we error if state is set inside an inspect effect
  (!F || (d.f & He) !== 0) && ve() && (d.f & (m | B | qe | He)) !== 0 && !L?.includes(e) && Ht();
  let r = n ? oe(t) : t;
  return be(e, r);
}
function be(e, t) {
  if (!e.equals(t)) {
    var n = e.v;
    ne ? H.set(e, t) : H.set(e, n), e.v = t;
    var r = C.ensure();
    if (r.capture(e, n), (e.f & m) !== 0) {
      const i = (
        /** @type {Derived} */
        e
      );
      (e.f & b) !== 0 && Ge(i), Be(i);
    }
    e.wv = At(), _t(e, b), ve() && v !== null && (v.f & E) !== 0 && (v.f & (U | re)) === 0 && (k === null ? On([e]) : k.push(e)), !r.is_fork && Ce.size > 0 && !ct && pn();
  }
  return t;
}
function pn() {
  ct = !1;
  var e = X;
  xe(!0);
  const t = Array.from(Ce);
  try {
    for (const n of t)
      (n.f & E) !== 0 && w(n, Y), pe(n) && de(n);
  } finally {
    xe(e);
  }
  Ce.clear();
}
function _e(e) {
  J(e, e.v + 1);
}
function _t(e, t) {
  var n = e.reactions;
  if (n !== null)
    for (var r = ve(), i = n.length, s = 0; s < i; s++) {
      var l = n[s], u = l.f;
      if (!(!r && l === v)) {
        var f = (u & b) === 0;
        if (f && w(l, t), (u & m) !== 0) {
          var a = (
            /** @type {Derived} */
            l
          );
          O?.delete(a), (u & te) === 0 && (u & R && (l.f |= te), _t(a, Y));
        } else f && ((u & B) !== 0 && q !== null && q.add(
          /** @type {Effect} */
          l
        ), V(
          /** @type {Effect} */
          l
        ));
      }
    }
}
function oe(e) {
  if (typeof e != "object" || e === null || Oe in e)
    return e;
  const t = qt(e);
  if (t !== jt && t !== It)
    return e;
  var n = /* @__PURE__ */ new Map(), r = Pt(e), i = /* @__PURE__ */ K(0), s = ee, l = (u) => {
    if (ee === s)
      return u();
    var f = d, a = ee;
    T(null), Ze(s);
    var o = u();
    return T(f), Ze(a), o;
  };
  return r && n.set("length", /* @__PURE__ */ K(
    /** @type {any[]} */
    e.length
  )), new Proxy(
    /** @type {any} */
    e,
    {
      defineProperty(u, f, a) {
        (!("value" in a) || a.configurable === !1 || a.enumerable === !1 || a.writable === !1) && $t();
        var o = n.get(f);
        return o === void 0 ? o = l(() => {
          var h = /* @__PURE__ */ K(a.value);
          return n.set(f, h), h;
        }) : J(o, a.value, !0), !0;
      },
      deleteProperty(u, f) {
        var a = n.get(f);
        if (a === void 0) {
          if (f in u) {
            const o = l(() => /* @__PURE__ */ K(y));
            n.set(f, o), _e(i);
          }
        } else
          J(a, y), _e(i);
        return !0;
      },
      get(u, f, a) {
        if (f === Oe)
          return e;
        var o = n.get(f), h = f in u;
        if (o === void 0 && (!h || ce(u, f)?.writable) && (o = l(() => {
          var _ = oe(h ? u[f] : y), p = /* @__PURE__ */ K(_);
          return p;
        }), n.set(f, o)), o !== void 0) {
          var c = Z(o);
          return c === y ? void 0 : c;
        }
        return Reflect.get(u, f, a);
      },
      getOwnPropertyDescriptor(u, f) {
        var a = Reflect.getOwnPropertyDescriptor(u, f);
        if (a && "value" in a) {
          var o = n.get(f);
          o && (a.value = Z(o));
        } else if (a === void 0) {
          var h = n.get(f), c = h?.v;
          if (h !== void 0 && c !== y)
            return {
              enumerable: !0,
              configurable: !0,
              value: c,
              writable: !0
            };
        }
        return a;
      },
      has(u, f) {
        if (f === Oe)
          return !0;
        var a = n.get(f), o = a !== void 0 && a.v !== y || Reflect.has(u, f);
        if (a !== void 0 || v !== null && (!o || ce(u, f)?.writable)) {
          a === void 0 && (a = l(() => {
            var c = o ? oe(u[f]) : y, _ = /* @__PURE__ */ K(c);
            return _;
          }), n.set(f, a));
          var h = Z(a);
          if (h === y)
            return !1;
        }
        return o;
      },
      set(u, f, a, o) {
        var h = n.get(f), c = f in u;
        if (r && f === "length")
          for (var _ = a; _ < /** @type {Source<number>} */
          h.v; _ += 1) {
            var p = n.get(_ + "");
            p !== void 0 ? J(p, y) : _ in u && (p = l(() => /* @__PURE__ */ K(y)), n.set(_ + "", p));
          }
        if (h === void 0)
          (!c || ce(u, f)?.writable) && (h = l(() => /* @__PURE__ */ K(void 0)), J(h, oe(a)), n.set(f, h));
        else {
          c = h.v !== y;
          var N = l(() => oe(a));
          J(h, N);
        }
        var I = Reflect.getOwnPropertyDescriptor(u, f);
        if (I?.set && I.set.call(o, a), !c) {
          if (r && typeof f == "string") {
            var $e = (
              /** @type {Source<number>} */
              n.get("length")
            ), Re = Number(f);
            Number.isInteger(Re) && Re >= $e.v && J($e, Re + 1);
          }
          _e(i);
        }
        return !0;
      },
      ownKeys(u) {
        Z(i);
        var f = Reflect.ownKeys(u).filter((h) => {
          var c = n.get(h);
          return c === void 0 || c.v !== y;
        });
        for (var [a, o] of n)
          o.v !== y && !(a in u) && f.push(a);
        return f;
      },
      setPrototypeOf() {
        zt();
      }
    }
  );
}
var Je, gn, ht, dt;
function wn() {
  if (Je === void 0) {
    Je = window, gn = /Firefox/.test(navigator.userAgent);
    var e = Element.prototype, t = Node.prototype, n = Text.prototype;
    ht = ce(t, "firstChild").get, dt = ce(t, "nextSibling").get, ze(e) && (e.__click = void 0, e.__className = void 0, e.__attributes = null, e.__style = void 0, e.__e = void 0), ze(n) && (n.__t = void 0);
  }
}
function vt(e = "") {
  return document.createTextNode(e);
}
// @__NO_SIDE_EFFECTS__
function pt(e) {
  return (
    /** @type {TemplateNode | null} */
    ht.call(e)
  );
}
// @__NO_SIDE_EFFECTS__
function ke(e) {
  return (
    /** @type {TemplateNode | null} */
    dt.call(e)
  );
}
function Gn(e, t) {
  return /* @__PURE__ */ pt(e);
}
function Kn(e, t = !1) {
  {
    var n = /* @__PURE__ */ pt(e);
    return n instanceof Comment && n.data === "" ? /* @__PURE__ */ ke(n) : n;
  }
}
function $n(e, t = 1, n = !1) {
  let r = e;
  for (; t--; )
    r = /** @type {TemplateNode} */
    /* @__PURE__ */ ke(r);
  return r;
}
function zn() {
  return !1;
}
function gt(e) {
  var t = d, n = v;
  T(null), j(null);
  try {
    return e();
  } finally {
    T(t), j(n);
  }
}
function yn(e) {
  v === null && (d === null && Gt(), Yt()), ne && Ut();
}
function mn(e, t) {
  var n = t.last;
  n === null ? t.last = t.first = e : (n.next = e, e.prev = n, t.last = e);
}
function G(e, t, n) {
  var r = v;
  r !== null && (r.f & D) !== 0 && (e |= D);
  var i = {
    ctx: S,
    deps: null,
    nodes: null,
    f: e | b | R,
    first: null,
    fn: t,
    last: null,
    next: null,
    parent: r,
    b: r && r.b,
    prev: null,
    teardown: null,
    wv: 0,
    ac: null
  };
  if (n)
    try {
      de(i), i.f |= Ie;
    } catch (u) {
      throw M(i), u;
    }
  else t !== null && V(i);
  var s = i;
  if (n && s.deps === null && s.teardown === null && s.nodes === null && s.first === s.last && // either `null`, or a singular child
  (s.f & ae) === 0 && (s = s.first, (e & B) !== 0 && (e & he) !== 0 && s !== null && (s.f |= he)), s !== null && (s.parent = r, r !== null && mn(s, r), d !== null && (d.f & m) !== 0 && (e & re) === 0)) {
    var l = (
      /** @type {Derived} */
      d
    );
    (l.effects ??= []).push(s);
  }
  return i;
}
function Ke() {
  return d !== null && !F;
}
function En(e) {
  const t = G(Se, null, !1);
  return w(t, E), t.teardown = e, t;
}
function Hn(e) {
  yn();
  var t = (
    /** @type {Effect} */
    v.f
  ), n = !d && (t & U) !== 0 && (t & Ie) === 0;
  if (n) {
    var r = (
      /** @type {ComponentContext} */
      S
    );
    (r.e ??= []).push(e);
  } else
    return wt(e);
}
function wt(e) {
  return G(me | Vt, e, !1);
}
function bn(e) {
  C.ensure();
  const t = G(re | ae, e, !0);
  return (n = {}) => new Promise((r) => {
    n.outro ? ye(t, () => {
      M(t), r(void 0);
    }) : (M(t), r(void 0));
  });
}
function Wn(e) {
  return G(me, e, !1);
}
function xn(e) {
  return G(qe | ae, e, !0);
}
function Tn(e, t = 0) {
  return G(Se | t, e, !0);
}
function Jn(e, t = [], n = [], r = []) {
  cn(r, t, n, (i) => {
    G(Se, () => e(...i.map(Z)), !0);
  });
}
function Sn(e, t = 0) {
  var n = G(B | t, e, !0);
  return n;
}
function W(e) {
  return G(U | ae, e, !0);
}
function yt(e) {
  var t = e.teardown;
  if (t !== null) {
    const n = ne, r = d;
    Qe(!0), T(null);
    try {
      t.call(null);
    } finally {
      Qe(n), T(r);
    }
  }
}
function mt(e, t = !1) {
  var n = e.first;
  for (e.first = e.last = null; n !== null; ) {
    const i = n.ac;
    i !== null && gt(() => {
      i.abort(se);
    });
    var r = n.next;
    (n.f & re) !== 0 ? n.parent = null : M(n, t), n = r;
  }
}
function An(e) {
  for (var t = e.first; t !== null; ) {
    var n = t.next;
    (t.f & U) === 0 && M(t), t = n;
  }
}
function M(e, t = !0) {
  var n = !1;
  (t || (e.f & nt) !== 0) && e.nodes !== null && e.nodes.end !== null && (kn(
    e.nodes.start,
    /** @type {TemplateNode} */
    e.nodes.end
  ), n = !0), mt(e, t && !n), Te(e, 0), w(e, $);
  var r = e.nodes && e.nodes.t;
  if (r !== null)
    for (const s of r)
      s.stop();
  yt(e);
  var i = e.parent;
  i !== null && i.first !== null && Et(e), e.next = e.prev = e.teardown = e.ctx = e.deps = e.fn = e.nodes = e.ac = null;
}
function kn(e, t) {
  for (; e !== null; ) {
    var n = e === t ? null : /* @__PURE__ */ ke(e);
    e.remove(), e = n;
  }
}
function Et(e) {
  var t = e.parent, n = e.prev, r = e.next;
  n !== null && (n.next = r), r !== null && (r.prev = n), t !== null && (t.first === e && (t.first = r), t.last === e && (t.last = n));
}
function ye(e, t, n = !0) {
  var r = [];
  bt(e, r, !0);
  var i = () => {
    n && M(e), t && t();
  }, s = r.length;
  if (s > 0) {
    var l = () => --s || i();
    for (var u of r)
      u.out(l);
  } else
    i();
}
function bt(e, t, n) {
  if ((e.f & D) === 0) {
    e.f ^= D;
    var r = e.nodes && e.nodes.t;
    if (r !== null)
      for (const u of r)
        (u.is_global || n) && t.push(u);
    for (var i = e.first; i !== null; ) {
      var s = i.next, l = (i.f & he) !== 0 || // If this is a branch effect without a block effect parent,
      // it means the parent block effect was pruned. In that case,
      // transparency information was transferred to the branch effect.
      (i.f & U) !== 0 && (e.f & B) !== 0;
      bt(i, t, l ? n : !1), i = s;
    }
  }
}
function Qn(e) {
  xt(e, !0);
}
function xt(e, t) {
  if ((e.f & D) !== 0) {
    e.f ^= D, (e.f & E) === 0 && (w(e, b), V(e));
    for (var n = e.first; n !== null; ) {
      var r = n.next, i = (n.f & he) !== 0 || (n.f & U) !== 0;
      xt(n, i ? t : !1), n = r;
    }
    var s = e.nodes && e.nodes.t;
    if (s !== null)
      for (const l of s)
        (l.is_global || t) && l.in();
  }
}
function Rn(e, t) {
  if (e.nodes)
    for (var n = e.nodes.start, r = e.nodes.end; n !== null; ) {
      var i = n === r ? null : /* @__PURE__ */ ke(n);
      t.append(n), n = i;
    }
}
let X = !1;
function xe(e) {
  X = e;
}
let ne = !1;
function Qe(e) {
  ne = e;
}
let d = null, F = !1;
function T(e) {
  d = e;
}
let v = null;
function j(e) {
  v = e;
}
let L = null;
function Tt(e) {
  d !== null && (L === null ? L = [e] : L.push(e));
}
let x = null, A = 0, k = null;
function On(e) {
  k = e;
}
let St = 1, Q = 0, ee = Q;
function Ze(e) {
  ee = e;
}
function At() {
  return ++St;
}
function pe(e) {
  var t = e.f;
  if ((t & b) !== 0)
    return !0;
  if (t & m && (e.f &= ~te), (t & Y) !== 0) {
    for (var n = (
      /** @type {Value[]} */
      e.deps
    ), r = n.length, i = 0; i < r; i++) {
      var s = n[i];
      if (pe(
        /** @type {Derived} */
        s
      ) && ot(
        /** @type {Derived} */
        s
      ), s.wv > e.wv)
        return !0;
    }
    (t & R) !== 0 && // During time traveling we don't want to reset the status so that
    // traversal of the graph in the other batches still happens
    O === null && w(e, E);
  }
  return !1;
}
function kt(e, t, n = !0) {
  var r = e.reactions;
  if (r !== null && !L?.includes(e))
    for (var i = 0; i < r.length; i++) {
      var s = r[i];
      (s.f & m) !== 0 ? kt(
        /** @type {Derived} */
        s,
        t,
        !1
      ) : t === s && (n ? w(s, b) : (s.f & E) !== 0 && w(s, Y), V(
        /** @type {Effect} */
        s
      ));
    }
}
function Rt(e) {
  var t = x, n = A, r = k, i = d, s = L, l = S, u = F, f = ee, a = e.f;
  x = /** @type {null | Value[]} */
  null, A = 0, k = null, d = (a & (U | re)) === 0 ? e : null, L = null, le(e.ctx), F = !1, ee = ++Q, e.ac !== null && (gt(() => {
    e.ac.abort(se);
  }), e.ac = null);
  try {
    e.f |= Ne;
    var o = (
      /** @type {Function} */
      e.fn
    ), h = o(), c = e.deps;
    if (x !== null) {
      var _;
      if (Te(e, A), c !== null && A > 0)
        for (c.length = A + x.length, _ = 0; _ < x.length; _++)
          c[A + _] = x[_];
      else
        e.deps = c = x;
      if (Ke() && (e.f & R) !== 0)
        for (_ = A; _ < c.length; _++)
          (c[_].reactions ??= []).push(e);
    } else c !== null && A < c.length && (Te(e, A), c.length = A);
    if (ve() && k !== null && !F && c !== null && (e.f & (m | Y | b)) === 0)
      for (_ = 0; _ < /** @type {Source[]} */
      k.length; _++)
        kt(
          k[_],
          /** @type {Effect} */
          e
        );
    if (i !== null && i !== e) {
      if (Q++, i.deps !== null)
        for (let p = 0; p < n; p += 1)
          i.deps[p].rv = Q;
      if (t !== null)
        for (const p of t)
          p.rv = Q;
      k !== null && (r === null ? r = k : r.push(.../** @type {Source[]} */
      k));
    }
    return (e.f & z) !== 0 && (e.f ^= z), h;
  } catch (p) {
    return it(p);
  } finally {
    e.f ^= Ne, x = t, A = n, k = r, d = i, L = s, le(l), F = u, ee = f;
  }
}
function Fn(e, t) {
  let n = t.reactions;
  if (n !== null) {
    var r = Ct.call(n, e);
    if (r !== -1) {
      var i = n.length - 1;
      i === 0 ? n = t.reactions = null : (n[r] = n[i], n.pop());
    }
  }
  if (n === null && (t.f & m) !== 0 && // Destroying a child effect while updating a parent effect can cause a dependency to appear
  // to be unused, when in fact it is used by the currently-updating parent. Checking `new_deps`
  // allows us to skip the expensive work of disconnecting and immediately reconnecting it
  (x === null || !x.includes(t))) {
    var s = (
      /** @type {Derived} */
      t
    );
    (s.f & R) !== 0 && (s.f ^= R, s.f &= ~te), Be(s), at(s), Te(s, 0);
  }
}
function Te(e, t) {
  var n = e.deps;
  if (n !== null)
    for (var r = t; r < n.length; r++)
      Fn(e, n[r]);
}
function de(e) {
  var t = e.f;
  if ((t & $) === 0) {
    w(e, E);
    var n = v, r = X;
    v = e, X = !0;
    try {
      (t & (B | tt)) !== 0 ? An(e) : mt(e), yt(e);
      var i = Rt(e);
      e.teardown = typeof i == "function" ? i : null, e.wv = St;
      var s;
      Fe && Xt && (e.f & b) !== 0 && e.deps;
    } finally {
      X = r, v = n;
    }
  }
}
function Z(e) {
  var t = e.f, n = (t & m) !== 0;
  if (d !== null && !F) {
    var r = v !== null && (v.f & $) !== 0;
    if (!r && !L?.includes(e)) {
      var i = d.deps;
      if ((d.f & Ne) !== 0)
        e.rv < Q && (e.rv = Q, x === null && i !== null && i[A] === e ? A++ : x === null ? x = [e] : x.push(e));
      else {
        (d.deps ??= []).push(e);
        var s = e.reactions;
        s === null ? e.reactions = [d] : s.includes(d) || s.push(d);
      }
    }
  }
  if (ne && H.has(e))
    return H.get(e);
  if (n) {
    var l = (
      /** @type {Derived} */
      e
    );
    if (ne) {
      var u = l.v;
      return ((l.f & E) === 0 && l.reactions !== null || Ft(l)) && (u = Ge(l)), H.set(l, u), u;
    }
    var f = (l.f & R) === 0 && !F && d !== null && (X || (d.f & R) !== 0), a = l.deps === null;
    pe(l) && (f && (l.f |= R), ot(l)), f && !a && Ot(l);
  }
  if (O?.has(e))
    return O.get(e);
  if ((e.f & z) !== 0)
    throw e.v;
  return e.v;
}
function Ot(e) {
  if (e.deps !== null) {
    e.f |= R;
    for (const t of e.deps)
      (t.reactions ??= []).push(e), (t.f & m) !== 0 && (t.f & R) === 0 && Ot(
        /** @type {Derived} */
        t
      );
  }
}
function Ft(e) {
  if (e.v === y) return !0;
  if (e.deps === null) return !1;
  for (const t of e.deps)
    if (H.has(t) || (t.f & m) !== 0 && Ft(
      /** @type {Derived} */
      t
    ))
      return !0;
  return !1;
}
function Nn(e) {
  var t = F;
  try {
    return F = !0, e();
  } finally {
    F = t;
  }
}
const Pn = ["touchstart", "touchmove"];
function Cn(e) {
  return Pn.includes(e);
}
const Nt = /* @__PURE__ */ new Set(), De = /* @__PURE__ */ new Set();
function Zn(e) {
  for (var t = 0; t < e.length; t++)
    Nt.add(e[t]);
  for (var n of De)
    n(e);
}
let Xe = null;
function we(e) {
  var t = this, n = (
    /** @type {Node} */
    t.ownerDocument
  ), r = e.type, i = e.composedPath?.() || [], s = (
    /** @type {null | Element} */
    i[0] || e.target
  );
  Xe = e;
  var l = 0, u = Xe === e && e.__root;
  if (u) {
    var f = i.indexOf(u);
    if (f !== -1 && (t === document || t === /** @type {any} */
    window)) {
      e.__root = t;
      return;
    }
    var a = i.indexOf(t);
    if (a === -1)
      return;
    f <= a && (l = f);
  }
  if (s = /** @type {Element} */
  i[l] || e.target, s !== t) {
    Mt(e, "currentTarget", {
      configurable: !0,
      get() {
        return s || n;
      }
    });
    var o = d, h = v;
    T(null), j(null);
    try {
      for (var c, _ = []; s !== null; ) {
        var p = s.assignedSlot || s.parentNode || /** @type {any} */
        s.host || null;
        try {
          var N = s["__" + r];
          N != null && (!/** @type {any} */
          s.disabled || // DOM could've been updated already by the time this is reached, so we check this as well
          // -> the target could not have been disabled because it emits the event in the first place
          e.target === s) && N.call(s, e);
        } catch (I) {
          c ? _.push(I) : c = I;
        }
        if (e.cancelBubble || p === t || p === null)
          break;
        s = p;
      }
      if (c) {
        for (let I of _)
          queueMicrotask(() => {
            throw I;
          });
        throw c;
      }
    } finally {
      e.__root = t, delete e.currentTarget, T(o), j(h);
    }
  }
}
function Xn(e, t) {
  var n = t == null ? "" : typeof t == "object" ? t + "" : t;
  n !== (e.__t ??= e.nodeValue) && (e.__t = n, e.nodeValue = n + "");
}
function er(e, t) {
  return Dn(e, t);
}
const ie = /* @__PURE__ */ new Map();
function Dn(e, { target: t, anchor: n, props: r = {}, events: i, context: s, intro: l = !0 }) {
  wn();
  var u = /* @__PURE__ */ new Set(), f = (h) => {
    for (var c = 0; c < h.length; c++) {
      var _ = h[c];
      if (!u.has(_)) {
        u.add(_);
        var p = Cn(_);
        t.addEventListener(_, we, { passive: p });
        var N = ie.get(_);
        N === void 0 ? (document.addEventListener(_, we, { passive: p }), ie.set(_, 1)) : ie.set(_, N + 1);
      }
    }
  };
  f(Dt(Nt)), De.add(f);
  var a = void 0, o = bn(() => {
    var h = n ?? t.appendChild(vt());
    return an(
      /** @type {TemplateNode} */
      h,
      {
        pending: () => {
        }
      },
      (c) => {
        if (s) {
          en({});
          var _ = (
            /** @type {ComponentContext} */
            S
          );
          _.c = s;
        }
        i && (r.$$events = i), a = e(c, r) || {}, s && tn();
      }
    ), () => {
      for (var c of u) {
        t.removeEventListener(c, we);
        var _ = (
          /** @type {number} */
          ie.get(c)
        );
        --_ === 0 ? (document.removeEventListener(c, we), ie.delete(c)) : ie.set(c, _);
      }
      De.delete(f), h !== n && h.parentNode?.removeChild(h);
    };
  });
  return Me.set(a, o), a;
}
let Me = /* @__PURE__ */ new WeakMap();
function tr(e, t) {
  const n = Me.get(e);
  return n ? (Me.delete(e), n(t)) : Promise.resolve();
}
export {
  Zn as A,
  Jn as B,
  Z as C,
  Gn as D,
  he as E,
  $n as F,
  Yn as G,
  Xn as H,
  Kn as I,
  Ke as J,
  ln as K,
  Vn as L,
  K as M,
  In as N,
  oe as O,
  J as P,
  tn as Q,
  en as R,
  Oe as S,
  Mn as T,
  er as U,
  tr as V,
  pt as a,
  gn as b,
  jn as c,
  v as d,
  vt as e,
  g as f,
  qt as g,
  M as h,
  Pt as i,
  W as j,
  Sn as k,
  qn as l,
  Rn as m,
  Wn as n,
  jt as o,
  ye as p,
  Tn as q,
  Qn as r,
  zn as s,
  Ve as t,
  Nn as u,
  Ln as v,
  Un as w,
  S as x,
  Le as y,
  Hn as z
};
