const Ln = 1, jn = 2, y = /* @__PURE__ */ Symbol(), In = "http://www.w3.org/1999/xhtml", Ne = !1;
var Ct = Array.isArray, Dt = Array.prototype.indexOf, Mt = Array.from, Lt = Object.defineProperty, _e = Object.getOwnPropertyDescriptor, qn = Object.getOwnPropertyDescriptors, jt = Object.prototype, It = Array.prototype, qt = Object.getPrototypeOf, We = Object.isExtensible;
const Bn = () => {
};
function Bt(e) {
  for (var t = 0; t < e.length; t++)
    e[t]();
}
function tt() {
  var e, t, n = new Promise((r, i) => {
    e = r, t = i;
  });
  return { promise: n, resolve: e, reject: t };
}
const E = 2, Ee = 4, Se = 8, nt = 1 << 24, V = 16, U = 32, re = 64, je = 128, R = 512, b = 1024, m = 2048, Y = 4096, D = 8192, $ = 16384, Ie = 32768, de = 65536, ze = 1 << 17, rt = 1 << 18, ae = 1 << 19, Vt = 1 << 20, te = 32768, Pe = 1 << 21, qe = 1 << 22, H = 1 << 23, Fe = /* @__PURE__ */ Symbol("$state"), Vn = /* @__PURE__ */ Symbol(""), se = new class extends Error {
  name = "StaleReactionError";
  message = "The reaction that called `getAbortSignal()` was re-run or destroyed";
}();
function Ut() {
  throw new Error("https://svelte.dev/e/async_derived_orphan");
}
function Yt(e) {
  throw new Error("https://svelte.dev/e/effect_in_teardown");
}
function Gt() {
  throw new Error("https://svelte.dev/e/effect_in_unowned_derived");
}
function Kt(e) {
  throw new Error("https://svelte.dev/e/effect_orphan");
}
function $t() {
  throw new Error("https://svelte.dev/e/effect_update_depth_exceeded");
}
function Ht() {
  throw new Error("https://svelte.dev/e/state_descriptors_fixed");
}
function Wt() {
  throw new Error("https://svelte.dev/e/state_prototype_fixed");
}
function zt() {
  throw new Error("https://svelte.dev/e/state_unsafe_mutation");
}
function Jt() {
  throw new Error("https://svelte.dev/e/svelte_boundary_reset_onerror");
}
function Qt() {
  console.warn("https://svelte.dev/e/svelte_boundary_reset_noop");
}
function it(e) {
  return e === this.v;
}
function Zt(e, t) {
  return e != e ? t == t : e !== t || e !== null && typeof e == "object" || typeof e == "function";
}
function Xt(e) {
  return !Zt(e, this.v);
}
let Be = !1, en = !1;
function Yn() {
  Be = !0;
}
let S = null;
function le(e) {
  S = e;
}
function tn(e, t = !1, n) {
  S = {
    p: S,
    i: !1,
    c: null,
    e: null,
    s: e,
    x: null,
    l: Be && !t ? { s: null, u: null, $: [] } : null
  };
}
function nn(e) {
  var t = (
    /** @type {ComponentContext} */
    S
  ), n = t.e;
  if (n !== null) {
    t.e = null;
    for (var r of n)
      yt(r);
  }
  return t.i = !0, S = t.p, /** @type {T} */
  {};
}
function pe() {
  return !Be || S !== null && S.l === null;
}
let fe = [];
function rn() {
  var e = fe;
  fe = [], Bt(e);
}
function Ae(e) {
  if (fe.length === 0) {
    var t = fe;
    queueMicrotask(() => {
      t === fe && rn();
    });
  }
  fe.push(e);
}
function st(e) {
  var t = v;
  if (t === null)
    return d.f |= H, e;
  if ((t.f & Ie) === 0) {
    if ((t.f & je) === 0)
      throw e;
    t.b.error(e);
  } else
    ue(e, t);
}
function ue(e, t) {
  for (; t !== null; ) {
    if ((t.f & je) !== 0)
      try {
        t.b.error(e);
        return;
      } catch (n) {
        e = n;
      }
    t = t.parent;
  }
  throw e;
}
const sn = -7169;
function w(e, t) {
  e.f = e.f & sn | t;
}
function Ve(e) {
  (e.f & R) !== 0 || e.deps === null ? w(e, b) : w(e, Y);
}
function ft(e) {
  if (e !== null)
    for (const t of e)
      (t.f & E) === 0 || (t.f & te) === 0 || (t.f ^= te, ft(
        /** @type {Derived} */
        t.deps
      ));
}
function lt(e, t, n) {
  (e.f & m) !== 0 ? t.add(e) : (e.f & Y) !== 0 && n.add(e), ft(e.deps), w(e, b);
}
const we = /* @__PURE__ */ new Set();
let g = null, O = null, P = [], Ue = null, Ce = !1;
class C {
  committed = !1;
  /**
   * The current values of any sources that are updated in this batch
   * They keys of this map are identical to `this.#previous`
   * @type {Map<Source, any>}
   */
  current = /* @__PURE__ */ new Map();
  /**
   * The values of any sources that are updated in this batch _before_ those updates took place.
   * They keys of this map are identical to `this.#current`
   * @type {Map<Source, any>}
   */
  previous = /* @__PURE__ */ new Map();
  /**
   * When the batch is committed (and the DOM is updated), we need to remove old branches
   * and append new ones by calling the functions added inside (if/each/key/etc) blocks
   * @type {Set<() => void>}
   */
  #t = /* @__PURE__ */ new Set();
  /**
   * If a fork is discarded, we need to destroy any effects that are no longer needed
   * @type {Set<(batch: Batch) => void>}
   */
  #_ = /* @__PURE__ */ new Set();
  /**
   * The number of async effects that are currently in flight
   */
  #r = 0;
  /**
   * The number of async effects that are currently in flight, _not_ inside a pending boundary
   */
  #f = 0;
  /**
   * A deferred that resolves when the batch is committed, used with `settled()`
   * TODO replace with Promise.withResolvers once supported widely enough
   * @type {{ promise: Promise<void>, resolve: (value?: any) => void, reject: (reason: unknown) => void } | null}
   */
  #i = null;
  /**
   * Deferred effects (which run after async work has completed) that are DIRTY
   * @type {Set<Effect>}
   */
  #n = /* @__PURE__ */ new Set();
  /**
   * Deferred effects that are MAYBE_DIRTY
   * @type {Set<Effect>}
   */
  #e = /* @__PURE__ */ new Set();
  /**
   * A set of branches that still exist, but will be destroyed when this batch
   * is committed — we skip over these during `process`
   * @type {Set<Effect>}
   */
  skipped_effects = /* @__PURE__ */ new Set();
  is_fork = !1;
  is_deferred() {
    return this.is_fork || this.#f > 0;
  }
  /**
   *
   * @param {Effect[]} root_effects
   */
  process(t) {
    P = [], this.apply();
    var n = [], r = [];
    for (const i of t)
      this.#s(i, n, r);
    this.is_fork || this.#u(), this.is_deferred() ? (this.#l(r), this.#l(n)) : (g = null, Je(r), Je(n), this.#i?.resolve()), O = null;
  }
  /**
   * Traverse the effect tree, executing effects or stashing
   * them for later execution as appropriate
   * @param {Effect} root
   * @param {Effect[]} effects
   * @param {Effect[]} render_effects
   */
  #s(t, n, r) {
    t.f ^= b;
    for (var i = t.first, s = null; i !== null; ) {
      var l = i.f, u = (l & (U | re)) !== 0, f = u && (l & b) !== 0, a = f || (l & D) !== 0 || this.skipped_effects.has(i);
      if (!a && i.fn !== null) {
        u ? i.f ^= b : s !== null && (l & (Ee | Se | nt)) !== 0 ? s.b.defer_effect(i) : (l & Ee) !== 0 ? n.push(i) : ge(i) && ((l & V) !== 0 && this.#n.add(i), ve(i));
        var o = i.first;
        if (o !== null) {
          i = o;
          continue;
        }
      }
      var h = i.parent;
      for (i = i.next; i === null && h !== null; )
        h === s && (s = null), i = h.next, h = h.parent;
    }
  }
  /**
   * @param {Effect[]} effects
   */
  #l(t) {
    for (var n = 0; n < t.length; n += 1)
      lt(t[n], this.#n, this.#e);
  }
  /**
   * Associate a change to a given source with the current
   * batch, noting its previous and current values
   * @param {Source} source
   * @param {any} value
   */
  capture(t, n) {
    n !== y && !this.previous.has(t) && this.previous.set(t, n), (t.f & H) === 0 && (this.current.set(t, t.v), O?.set(t, t.v));
  }
  activate() {
    g = this, this.apply();
  }
  deactivate() {
    g === this && (g = null, O = null);
  }
  flush() {
    if (this.activate(), P.length > 0) {
      if (fn(), g !== null && g !== this)
        return;
    } else this.#r === 0 && this.process([]);
    this.deactivate();
  }
  discard() {
    for (const t of this.#_) t(this);
    this.#_.clear();
  }
  #u() {
    if (this.#f === 0) {
      for (const t of this.#t) t();
      this.#t.clear();
    }
    this.#r === 0 && this.#a();
  }
  #a() {
    if (we.size > 1) {
      this.previous.clear();
      var t = O, n = !0;
      for (const i of we) {
        if (i === this) {
          n = !1;
          continue;
        }
        const s = [];
        for (const [u, f] of this.current) {
          if (i.current.has(u))
            if (n && f !== i.current.get(u))
              i.current.set(u, f);
            else
              continue;
          s.push(u);
        }
        if (s.length === 0)
          continue;
        const l = [...i.current.keys()].filter((u) => !this.current.has(u));
        if (l.length > 0) {
          var r = P;
          P = [];
          const u = /* @__PURE__ */ new Set(), f = /* @__PURE__ */ new Map();
          for (const a of s)
            ut(a, l, u, f);
          if (P.length > 0) {
            g = i, i.apply();
            for (const a of P)
              i.#s(a, [], []);
            i.deactivate();
          }
          P = r;
        }
      }
      g = null, O = t;
    }
    this.committed = !0, we.delete(this);
  }
  /**
   *
   * @param {boolean} blocking
   */
  increment(t) {
    this.#r += 1, t && (this.#f += 1);
  }
  /**
   *
   * @param {boolean} blocking
   */
  decrement(t) {
    this.#r -= 1, t && (this.#f -= 1), this.revive();
  }
  revive() {
    for (const t of this.#n)
      this.#e.delete(t), w(t, m), B(t);
    for (const t of this.#e)
      w(t, Y), B(t);
    this.flush();
  }
  /** @param {() => void} fn */
  oncommit(t) {
    this.#t.add(t);
  }
  /** @param {(batch: Batch) => void} fn */
  ondiscard(t) {
    this.#_.add(t);
  }
  settled() {
    return (this.#i ??= tt()).promise;
  }
  static ensure() {
    if (g === null) {
      const t = g = new C();
      we.add(g), C.enqueue(() => {
        g === t && t.flush();
      });
    }
    return g;
  }
  /** @param {() => void} task */
  static enqueue(t) {
    Ae(t);
  }
  apply() {
  }
}
function fn() {
  var e = X;
  Ce = !0;
  var t = null;
  try {
    var n = 0;
    for (xe(!0); P.length > 0; ) {
      var r = C.ensure();
      if (n++ > 1e3) {
        var i, s;
        ln();
      }
      r.process(P), W.clear();
    }
  } finally {
    Ce = !1, xe(e), Ue = null;
  }
}
function ln() {
  try {
    $t();
  } catch (e) {
    ue(e, Ue);
  }
}
let I = null;
function Je(e) {
  var t = e.length;
  if (t !== 0) {
    for (var n = 0; n < t; ) {
      var r = e[n++];
      if ((r.f & ($ | D)) === 0 && ge(r) && (I = /* @__PURE__ */ new Set(), ve(r), r.deps === null && r.first === null && r.nodes === null && (r.teardown === null && r.ac === null ? mt(r) : r.fn = null), I?.size > 0)) {
        W.clear();
        for (const i of I) {
          if ((i.f & ($ | D)) !== 0) continue;
          const s = [i];
          let l = i.parent;
          for (; l !== null; )
            I.has(l) && (I.delete(l), s.push(l)), l = l.parent;
          for (let u = s.length - 1; u >= 0; u--) {
            const f = s[u];
            (f.f & ($ | D)) === 0 && ve(f);
          }
        }
        I.clear();
      }
    }
    I = null;
  }
}
function ut(e, t, n, r) {
  if (!n.has(e) && (n.add(e), e.reactions !== null))
    for (const i of e.reactions) {
      const s = i.f;
      (s & E) !== 0 ? ut(
        /** @type {Derived} */
        i,
        t,
        n,
        r
      ) : (s & (qe | V)) !== 0 && (s & m) === 0 && at(i, t, r) && (w(i, m), B(
        /** @type {Effect} */
        i
      ));
    }
}
function at(e, t, n) {
  const r = n.get(e);
  if (r !== void 0) return r;
  if (e.deps !== null)
    for (const i of e.deps) {
      if (t.includes(i))
        return !0;
      if ((i.f & E) !== 0 && at(
        /** @type {Derived} */
        i,
        t,
        n
      ))
        return n.set(
          /** @type {Derived} */
          i,
          !0
        ), !0;
    }
  return n.set(e, !1), !1;
}
function B(e) {
  for (var t = Ue = e; t.parent !== null; ) {
    t = t.parent;
    var n = t.f;
    if (Ce && t === v && (n & V) !== 0 && (n & rt) === 0)
      return;
    if ((n & (re | U)) !== 0) {
      if ((n & b) === 0) return;
      t.f ^= b;
    }
  }
  P.push(t);
}
function un(e) {
  let t = 0, n = ke(0), r;
  return () => {
    $e() && (Z(n), Tn(() => (t === 0 && (r = Nn(() => e(() => he(n)))), t += 1, () => {
      Ae(() => {
        t -= 1, t === 0 && (r?.(), r = void 0, he(n));
      });
    })));
  };
}
var an = de | ae | je;
function on(e, t, n) {
  new cn(e, t, n);
}
class cn {
  /** @type {Boundary | null} */
  parent;
  is_pending = !1;
  /** @type {TemplateNode} */
  #t;
  /** @type {TemplateNode | null} */
  #_ = null;
  /** @type {BoundaryProps} */
  #r;
  /** @type {((anchor: Node) => void)} */
  #f;
  /** @type {Effect} */
  #i;
  /** @type {Effect | null} */
  #n = null;
  /** @type {Effect | null} */
  #e = null;
  /** @type {Effect | null} */
  #s = null;
  /** @type {DocumentFragment | null} */
  #l = null;
  /** @type {TemplateNode | null} */
  #u = null;
  #a = 0;
  #o = 0;
  #h = !1;
  /** @type {Set<Effect>} */
  #d = /* @__PURE__ */ new Set();
  /** @type {Set<Effect>} */
  #v = /* @__PURE__ */ new Set();
  /**
   * A source containing the number of pending async deriveds/expressions.
   * Only created if `$effect.pending()` is used inside the boundary,
   * otherwise updating the source results in needless `Batch.ensure()`
   * calls followed by no-op flushes
   * @type {Source<number> | null}
   */
  #c = null;
  #E = un(() => (this.#c = ke(this.#a), () => {
    this.#c = null;
  }));
  /**
   * @param {TemplateNode} node
   * @param {BoundaryProps} props
   * @param {((anchor: Node) => void)} children
   */
  constructor(t, n, r) {
    this.#t = t, this.#r = n, this.#f = r, this.parent = /** @type {Effect} */
    v.b, this.is_pending = !!this.#r.pending, this.#i = Sn(() => {
      v.b = this;
      {
        var i = this.#w();
        try {
          this.#n = z(() => r(i));
        } catch (s) {
          this.error(s);
        }
        this.#o > 0 ? this.#g() : this.is_pending = !1;
      }
      return () => {
        this.#u?.remove();
      };
    }, an);
  }
  #b() {
    try {
      this.#n = z(() => this.#f(this.#t));
    } catch (t) {
      this.error(t);
    }
  }
  #m() {
    const t = this.#r.pending;
    t && (this.#e = z(() => t(this.#t)), C.enqueue(() => {
      var n = this.#w();
      this.#n = this.#p(() => (C.ensure(), z(() => this.#f(n)))), this.#o > 0 ? this.#g() : (ye(
        /** @type {Effect} */
        this.#e,
        () => {
          this.#e = null;
        }
      ), this.is_pending = !1);
    }));
  }
  #w() {
    var t = this.#t;
    return this.is_pending && (this.#u = pt(), this.#t.before(this.#u), t = this.#u), t;
  }
  /**
   * Defer an effect inside a pending boundary until the boundary resolves
   * @param {Effect} effect
   */
  defer_effect(t) {
    lt(t, this.#d, this.#v);
  }
  /**
   * Returns `false` if the effect exists inside a boundary whose pending snippet is shown
   * @returns {boolean}
   */
  is_rendered() {
    return !this.is_pending && (!this.parent || this.parent.is_rendered());
  }
  has_pending_snippet() {
    return !!this.#r.pending;
  }
  /**
   * @param {() => Effect | null} fn
   */
  #p(t) {
    var n = v, r = d, i = S;
    L(this.#i), T(this.#i), le(this.#i.ctx);
    try {
      return t();
    } catch (s) {
      return st(s), null;
    } finally {
      L(n), T(r), le(i);
    }
  }
  #g() {
    const t = (
      /** @type {(anchor: Node) => void} */
      this.#r.pending
    );
    this.#n !== null && (this.#l = document.createDocumentFragment(), this.#l.append(
      /** @type {TemplateNode} */
      this.#u
    ), Rn(this.#n, this.#l)), this.#e === null && (this.#e = z(() => t(this.#t)));
  }
  /**
   * Updates the pending count associated with the currently visible pending snippet,
   * if any, such that we can replace the snippet with content once work is done
   * @param {1 | -1} d
   */
  #y(t) {
    if (!this.has_pending_snippet()) {
      this.parent && this.parent.#y(t);
      return;
    }
    if (this.#o += t, this.#o === 0) {
      this.is_pending = !1;
      for (const n of this.#d)
        w(n, m), B(n);
      for (const n of this.#v)
        w(n, Y), B(n);
      this.#d.clear(), this.#v.clear(), this.#e && ye(this.#e, () => {
        this.#e = null;
      }), this.#l && (this.#t.before(this.#l), this.#l = null);
    }
  }
  /**
   * Update the source that powers `$effect.pending()` inside this boundary,
   * and controls when the current `pending` snippet (if any) is removed.
   * Do not call from inside the class
   * @param {1 | -1} d
   */
  update_pending_count(t) {
    this.#y(t), this.#a += t, this.#c && me(this.#c, this.#a);
  }
  get_effect_pending() {
    return this.#E(), Z(
      /** @type {Source<number>} */
      this.#c
    );
  }
  /** @param {unknown} error */
  error(t) {
    var n = this.#r.onerror;
    let r = this.#r.failed;
    if (this.#h || !n && !r)
      throw t;
    this.#n && (M(this.#n), this.#n = null), this.#e && (M(this.#e), this.#e = null), this.#s && (M(this.#s), this.#s = null);
    var i = !1, s = !1;
    const l = () => {
      if (i) {
        Qt();
        return;
      }
      i = !0, s && Jt(), C.ensure(), this.#a = 0, this.#s !== null && ye(this.#s, () => {
        this.#s = null;
      }), this.is_pending = this.has_pending_snippet(), this.#n = this.#p(() => (this.#h = !1, z(() => this.#f(this.#t)))), this.#o > 0 ? this.#g() : this.is_pending = !1;
    };
    var u = d;
    try {
      T(null), s = !0, n?.(t, l), s = !1;
    } catch (f) {
      ue(f, this.#i && this.#i.parent);
    } finally {
      T(u);
    }
    r && Ae(() => {
      this.#s = this.#p(() => {
        C.ensure(), this.#h = !0;
        try {
          return z(() => {
            r(
              this.#t,
              () => t,
              () => l
            );
          });
        } catch (f) {
          return ue(
            f,
            /** @type {Effect} */
            this.#i.parent
          ), null;
        } finally {
          this.#h = !1;
        }
      });
    });
  }
}
function _n(e, t, n, r) {
  const i = pe() ? Ye : vn;
  if (n.length === 0 && e.length === 0) {
    r(t.map(i));
    return;
  }
  var s = g, l = (
    /** @type {Effect} */
    v
  ), u = hn();
  function f() {
    Promise.all(n.map((a) => /* @__PURE__ */ dn(a))).then((a) => {
      u();
      try {
        r([...t.map(i), ...a]);
      } catch (o) {
        (l.f & $) === 0 && ue(o, l);
      }
      s?.deactivate(), be();
    }).catch((a) => {
      ue(a, l);
    });
  }
  e.length > 0 ? Promise.all(e).then(() => {
    u();
    try {
      return f();
    } finally {
      s?.deactivate(), be();
    }
  }) : f();
}
function hn() {
  var e = v, t = d, n = S, r = g;
  return function(s = !0) {
    L(e), T(t), le(n), s && r?.activate();
  };
}
function be() {
  L(null), T(null), le(null);
}
// @__NO_SIDE_EFFECTS__
function Ye(e) {
  var t = E | m, n = d !== null && (d.f & E) !== 0 ? (
    /** @type {Derived} */
    d
  ) : null;
  return v !== null && (v.f |= ae), {
    ctx: S,
    deps: null,
    effects: null,
    equals: it,
    f: t,
    fn: e,
    reactions: null,
    rv: 0,
    v: (
      /** @type {V} */
      y
    ),
    wv: 0,
    parent: n ?? v,
    ac: null
  };
}
// @__NO_SIDE_EFFECTS__
function dn(e, t, n) {
  let r = (
    /** @type {Effect | null} */
    v
  );
  r === null && Ut();
  var i = (
    /** @type {Boundary} */
    r.b
  ), s = (
    /** @type {Promise<V>} */
    /** @type {unknown} */
    void 0
  ), l = ke(
    /** @type {V} */
    y
  ), u = !d, f = /* @__PURE__ */ new Map();
  return xn(() => {
    var a = tt();
    s = a.promise;
    try {
      Promise.resolve(e()).then(a.resolve, a.reject).then(() => {
        o === g && o.committed && o.deactivate(), be();
      });
    } catch (_) {
      a.reject(_), be();
    }
    var o = (
      /** @type {Batch} */
      g
    );
    if (u) {
      var h = i.is_rendered();
      i.update_pending_count(1), o.increment(h), f.get(o)?.reject(se), f.delete(o), f.set(o, a);
    }
    const c = (_, p = void 0) => {
      if (o.activate(), p)
        p !== se && (l.f |= H, me(l, p));
      else {
        (l.f & H) !== 0 && (l.f ^= H), me(l, _);
        for (const [N, j] of f) {
          if (f.delete(N), N === o) break;
          j.reject(se);
        }
      }
      u && (i.update_pending_count(-1), o.decrement(h));
    };
    a.promise.then(c, (_) => c(null, _ || "unknown"));
  }), wt(() => {
    for (const a of f.values())
      a.reject(se);
  }), new Promise((a) => {
    function o(h) {
      function c() {
        h === s ? a(l) : o(s);
      }
      h.then(c, c);
    }
    o(s);
  });
}
// @__NO_SIDE_EFFECTS__
function Gn(e) {
  const t = /* @__PURE__ */ Ye(e);
  return St(t), t;
}
// @__NO_SIDE_EFFECTS__
function vn(e) {
  const t = /* @__PURE__ */ Ye(e);
  return t.equals = Xt, t;
}
function ot(e) {
  var t = e.effects;
  if (t !== null) {
    e.effects = null;
    for (var n = 0; n < t.length; n += 1)
      M(
        /** @type {Effect} */
        t[n]
      );
  }
}
function pn(e) {
  for (var t = e.parent; t !== null; ) {
    if ((t.f & E) === 0)
      return (t.f & $) === 0 ? (
        /** @type {Effect} */
        t
      ) : null;
    t = t.parent;
  }
  return null;
}
function Ge(e) {
  var t, n = v;
  L(pn(e));
  try {
    e.f &= ~te, ot(e), t = Ot(e);
  } finally {
    L(n);
  }
  return t;
}
function ct(e) {
  var t = Ge(e);
  if (!e.equals(t) && (e.wv = kt(), (!g?.is_fork || e.deps === null) && (e.v = t, e.deps === null))) {
    w(e, b);
    return;
  }
  ne || (O !== null ? ($e() || g?.is_fork) && O.set(e, t) : Ve(e));
}
let De = /* @__PURE__ */ new Set();
const W = /* @__PURE__ */ new Map();
let _t = !1;
function ke(e, t) {
  var n = {
    f: 0,
    // TODO ideally we could skip this altogether, but it causes type errors
    v: e,
    reactions: null,
    equals: it,
    rv: 0,
    wv: 0
  };
  return n;
}
// @__NO_SIDE_EFFECTS__
function K(e, t) {
  const n = ke(e);
  return St(n), n;
}
function J(e, t, n = !1) {
  d !== null && // since we are untracking the function inside `$inspect.with` we need to add this check
  // to ensure we error if state is set inside an inspect effect
  (!F || (d.f & ze) !== 0) && pe() && (d.f & (E | V | qe | ze)) !== 0 && !q?.includes(e) && zt();
  let r = n ? oe(t) : t;
  return me(e, r);
}
function me(e, t) {
  if (!e.equals(t)) {
    var n = e.v;
    ne ? W.set(e, t) : W.set(e, n), e.v = t;
    var r = C.ensure();
    if (r.capture(e, n), (e.f & E) !== 0) {
      const i = (
        /** @type {Derived} */
        e
      );
      (e.f & m) !== 0 && Ge(i), Ve(i);
    }
    e.wv = kt(), ht(e, m), pe() && v !== null && (v.f & b) !== 0 && (v.f & (U | re)) === 0 && (k === null ? On([e]) : k.push(e)), !r.is_fork && De.size > 0 && !_t && gn();
  }
  return t;
}
function gn() {
  _t = !1;
  var e = X;
  xe(!0);
  const t = Array.from(De);
  try {
    for (const n of t)
      (n.f & b) !== 0 && w(n, Y), ge(n) && ve(n);
  } finally {
    xe(e);
  }
  De.clear();
}
function he(e) {
  J(e, e.v + 1);
}
function ht(e, t) {
  var n = e.reactions;
  if (n !== null)
    for (var r = pe(), i = n.length, s = 0; s < i; s++) {
      var l = n[s], u = l.f;
      if (!(!r && l === v)) {
        var f = (u & m) === 0;
        if (f && w(l, t), (u & E) !== 0) {
          var a = (
            /** @type {Derived} */
            l
          );
          O?.delete(a), (u & te) === 0 && (u & R && (l.f |= te), ht(a, Y));
        } else f && ((u & V) !== 0 && I !== null && I.add(
          /** @type {Effect} */
          l
        ), B(
          /** @type {Effect} */
          l
        ));
      }
    }
}
function oe(e) {
  if (typeof e != "object" || e === null || Fe in e)
    return e;
  const t = qt(e);
  if (t !== jt && t !== It)
    return e;
  var n = /* @__PURE__ */ new Map(), r = Ct(e), i = /* @__PURE__ */ K(0), s = ee, l = (u) => {
    if (ee === s)
      return u();
    var f = d, a = ee;
    T(null), Xe(s);
    var o = u();
    return T(f), Xe(a), o;
  };
  return r && n.set("length", /* @__PURE__ */ K(
    /** @type {any[]} */
    e.length
  )), new Proxy(
    /** @type {any} */
    e,
    {
      defineProperty(u, f, a) {
        (!("value" in a) || a.configurable === !1 || a.enumerable === !1 || a.writable === !1) && Ht();
        var o = n.get(f);
        return o === void 0 ? o = l(() => {
          var h = /* @__PURE__ */ K(a.value);
          return n.set(f, h), h;
        }) : J(o, a.value, !0), !0;
      },
      deleteProperty(u, f) {
        var a = n.get(f);
        if (a === void 0) {
          if (f in u) {
            const o = l(() => /* @__PURE__ */ K(y));
            n.set(f, o), he(i);
          }
        } else
          J(a, y), he(i);
        return !0;
      },
      get(u, f, a) {
        if (f === Fe)
          return e;
        var o = n.get(f), h = f in u;
        if (o === void 0 && (!h || _e(u, f)?.writable) && (o = l(() => {
          var _ = oe(h ? u[f] : y), p = /* @__PURE__ */ K(_);
          return p;
        }), n.set(f, o)), o !== void 0) {
          var c = Z(o);
          return c === y ? void 0 : c;
        }
        return Reflect.get(u, f, a);
      },
      getOwnPropertyDescriptor(u, f) {
        var a = Reflect.getOwnPropertyDescriptor(u, f);
        if (a && "value" in a) {
          var o = n.get(f);
          o && (a.value = Z(o));
        } else if (a === void 0) {
          var h = n.get(f), c = h?.v;
          if (h !== void 0 && c !== y)
            return {
              enumerable: !0,
              configurable: !0,
              value: c,
              writable: !0
            };
        }
        return a;
      },
      has(u, f) {
        if (f === Fe)
          return !0;
        var a = n.get(f), o = a !== void 0 && a.v !== y || Reflect.has(u, f);
        if (a !== void 0 || v !== null && (!o || _e(u, f)?.writable)) {
          a === void 0 && (a = l(() => {
            var c = o ? oe(u[f]) : y, _ = /* @__PURE__ */ K(c);
            return _;
          }), n.set(f, a));
          var h = Z(a);
          if (h === y)
            return !1;
        }
        return o;
      },
      set(u, f, a, o) {
        var h = n.get(f), c = f in u;
        if (r && f === "length")
          for (var _ = a; _ < /** @type {Source<number>} */
          h.v; _ += 1) {
            var p = n.get(_ + "");
            p !== void 0 ? J(p, y) : _ in u && (p = l(() => /* @__PURE__ */ K(y)), n.set(_ + "", p));
          }
        if (h === void 0)
          (!c || _e(u, f)?.writable) && (h = l(() => /* @__PURE__ */ K(void 0)), J(h, oe(a)), n.set(f, h));
        else {
          c = h.v !== y;
          var N = l(() => oe(a));
          J(h, N);
        }
        var j = Reflect.getOwnPropertyDescriptor(u, f);
        if (j?.set && j.set.call(o, a), !c) {
          if (r && typeof f == "string") {
            var He = (
              /** @type {Source<number>} */
              n.get("length")
            ), Oe = Number(f);
            Number.isInteger(Oe) && Oe >= He.v && J(He, Oe + 1);
          }
          he(i);
        }
        return !0;
      },
      ownKeys(u) {
        Z(i);
        var f = Reflect.ownKeys(u).filter((h) => {
          var c = n.get(h);
          return c === void 0 || c.v !== y;
        });
        for (var [a, o] of n)
          o.v !== y && !(a in u) && f.push(a);
        return f;
      },
      setPrototypeOf() {
        Wt();
      }
    }
  );
}
var Qe, wn, dt, vt;
function yn() {
  if (Qe === void 0) {
    Qe = window, wn = /Firefox/.test(navigator.userAgent);
    var e = Element.prototype, t = Node.prototype, n = Text.prototype;
    dt = _e(t, "firstChild").get, vt = _e(t, "nextSibling").get, We(e) && (e.__click = void 0, e.__className = void 0, e.__attributes = null, e.__style = void 0, e.__e = void 0), We(n) && (n.__t = void 0);
  }
}
function pt(e = "") {
  return document.createTextNode(e);
}
// @__NO_SIDE_EFFECTS__
function gt(e) {
  return (
    /** @type {TemplateNode | null} */
    dt.call(e)
  );
}
// @__NO_SIDE_EFFECTS__
function Re(e) {
  return (
    /** @type {TemplateNode | null} */
    vt.call(e)
  );
}
function Kn(e, t) {
  return /* @__PURE__ */ gt(e);
}
function $n(e, t = !1) {
  {
    var n = /* @__PURE__ */ gt(e);
    return n instanceof Comment && n.data === "" ? /* @__PURE__ */ Re(n) : n;
  }
}
function Hn(e, t = 1, n = !1) {
  let r = e;
  for (; t--; )
    r = /** @type {TemplateNode} */
    /* @__PURE__ */ Re(r);
  return r;
}
function Wn() {
  return !1;
}
function Ke(e) {
  var t = d, n = v;
  T(null), L(null);
  try {
    return e();
  } finally {
    T(t), L(n);
  }
}
function En(e) {
  v === null && (d === null && Kt(), Gt()), ne && Yt();
}
function bn(e, t) {
  var n = t.last;
  n === null ? t.last = t.first = e : (n.next = e, e.prev = n, t.last = e);
}
function G(e, t, n) {
  var r = v;
  r !== null && (r.f & D) !== 0 && (e |= D);
  var i = {
    ctx: S,
    deps: null,
    nodes: null,
    f: e | m | R,
    first: null,
    fn: t,
    last: null,
    next: null,
    parent: r,
    b: r && r.b,
    prev: null,
    teardown: null,
    wv: 0,
    ac: null
  };
  if (n)
    try {
      ve(i), i.f |= Ie;
    } catch (u) {
      throw M(i), u;
    }
  else t !== null && B(i);
  var s = i;
  if (n && s.deps === null && s.teardown === null && s.nodes === null && s.first === s.last && // either `null`, or a singular child
  (s.f & ae) === 0 && (s = s.first, (e & V) !== 0 && (e & de) !== 0 && s !== null && (s.f |= de)), s !== null && (s.parent = r, r !== null && bn(s, r), d !== null && (d.f & E) !== 0 && (e & re) === 0)) {
    var l = (
      /** @type {Derived} */
      d
    );
    (l.effects ??= []).push(s);
  }
  return i;
}
function $e() {
  return d !== null && !F;
}
function wt(e) {
  const t = G(Se, null, !1);
  return w(t, b), t.teardown = e, t;
}
function zn(e) {
  En();
  var t = (
    /** @type {Effect} */
    v.f
  ), n = !d && (t & U) !== 0 && (t & Ie) === 0;
  if (n) {
    var r = (
      /** @type {ComponentContext} */
      S
    );
    (r.e ??= []).push(e);
  } else
    return yt(e);
}
function yt(e) {
  return G(Ee | Vt, e, !1);
}
function mn(e) {
  C.ensure();
  const t = G(re | ae, e, !0);
  return (n = {}) => new Promise((r) => {
    n.outro ? ye(t, () => {
      M(t), r(void 0);
    }) : (M(t), r(void 0));
  });
}
function Jn(e) {
  return G(Ee, e, !1);
}
function xn(e) {
  return G(qe | ae, e, !0);
}
function Tn(e, t = 0) {
  return G(Se | t, e, !0);
}
function Qn(e, t = [], n = [], r = []) {
  _n(r, t, n, (i) => {
    G(Se, () => e(...i.map(Z)), !0);
  });
}
function Sn(e, t = 0) {
  var n = G(V | t, e, !0);
  return n;
}
function z(e) {
  return G(U | ae, e, !0);
}
function Et(e) {
  var t = e.teardown;
  if (t !== null) {
    const n = ne, r = d;
    Ze(!0), T(null);
    try {
      t.call(null);
    } finally {
      Ze(n), T(r);
    }
  }
}
function bt(e, t = !1) {
  var n = e.first;
  for (e.first = e.last = null; n !== null; ) {
    const i = n.ac;
    i !== null && Ke(() => {
      i.abort(se);
    });
    var r = n.next;
    (n.f & re) !== 0 ? n.parent = null : M(n, t), n = r;
  }
}
function An(e) {
  for (var t = e.first; t !== null; ) {
    var n = t.next;
    (t.f & U) === 0 && M(t), t = n;
  }
}
function M(e, t = !0) {
  var n = !1;
  (t || (e.f & rt) !== 0) && e.nodes !== null && e.nodes.end !== null && (kn(
    e.nodes.start,
    /** @type {TemplateNode} */
    e.nodes.end
  ), n = !0), bt(e, t && !n), Te(e, 0), w(e, $);
  var r = e.nodes && e.nodes.t;
  if (r !== null)
    for (const s of r)
      s.stop();
  Et(e);
  var i = e.parent;
  i !== null && i.first !== null && mt(e), e.next = e.prev = e.teardown = e.ctx = e.deps = e.fn = e.nodes = e.ac = null;
}
function kn(e, t) {
  for (; e !== null; ) {
    var n = e === t ? null : /* @__PURE__ */ Re(e);
    e.remove(), e = n;
  }
}
function mt(e) {
  var t = e.parent, n = e.prev, r = e.next;
  n !== null && (n.next = r), r !== null && (r.prev = n), t !== null && (t.first === e && (t.first = r), t.last === e && (t.last = n));
}
function ye(e, t, n = !0) {
  var r = [];
  xt(e, r, !0);
  var i = () => {
    n && M(e), t && t();
  }, s = r.length;
  if (s > 0) {
    var l = () => --s || i();
    for (var u of r)
      u.out(l);
  } else
    i();
}
function xt(e, t, n) {
  if ((e.f & D) === 0) {
    e.f ^= D;
    var r = e.nodes && e.nodes.t;
    if (r !== null)
      for (const u of r)
        (u.is_global || n) && t.push(u);
    for (var i = e.first; i !== null; ) {
      var s = i.next, l = (i.f & de) !== 0 || // If this is a branch effect without a block effect parent,
      // it means the parent block effect was pruned. In that case,
      // transparency information was transferred to the branch effect.
      (i.f & U) !== 0 && (e.f & V) !== 0;
      xt(i, t, l ? n : !1), i = s;
    }
  }
}
function Zn(e) {
  Tt(e, !0);
}
function Tt(e, t) {
  if ((e.f & D) !== 0) {
    e.f ^= D, (e.f & b) === 0 && (w(e, m), B(e));
    for (var n = e.first; n !== null; ) {
      var r = n.next, i = (n.f & de) !== 0 || (n.f & U) !== 0;
      Tt(n, i ? t : !1), n = r;
    }
    var s = e.nodes && e.nodes.t;
    if (s !== null)
      for (const l of s)
        (l.is_global || t) && l.in();
  }
}
function Rn(e, t) {
  if (e.nodes)
    for (var n = e.nodes.start, r = e.nodes.end; n !== null; ) {
      var i = n === r ? null : /* @__PURE__ */ Re(n);
      t.append(n), n = i;
    }
}
let X = !1;
function xe(e) {
  X = e;
}
let ne = !1;
function Ze(e) {
  ne = e;
}
let d = null, F = !1;
function T(e) {
  d = e;
}
let v = null;
function L(e) {
  v = e;
}
let q = null;
function St(e) {
  d !== null && (q === null ? q = [e] : q.push(e));
}
let x = null, A = 0, k = null;
function On(e) {
  k = e;
}
let At = 1, Q = 0, ee = Q;
function Xe(e) {
  ee = e;
}
function kt() {
  return ++At;
}
function ge(e) {
  var t = e.f;
  if ((t & m) !== 0)
    return !0;
  if (t & E && (e.f &= ~te), (t & Y) !== 0) {
    for (var n = (
      /** @type {Value[]} */
      e.deps
    ), r = n.length, i = 0; i < r; i++) {
      var s = n[i];
      if (ge(
        /** @type {Derived} */
        s
      ) && ct(
        /** @type {Derived} */
        s
      ), s.wv > e.wv)
        return !0;
    }
    (t & R) !== 0 && // During time traveling we don't want to reset the status so that
    // traversal of the graph in the other batches still happens
    O === null && w(e, b);
  }
  return !1;
}
function Rt(e, t, n = !0) {
  var r = e.reactions;
  if (r !== null && !q?.includes(e))
    for (var i = 0; i < r.length; i++) {
      var s = r[i];
      (s.f & E) !== 0 ? Rt(
        /** @type {Derived} */
        s,
        t,
        !1
      ) : t === s && (n ? w(s, m) : (s.f & b) !== 0 && w(s, Y), B(
        /** @type {Effect} */
        s
      ));
    }
}
function Ot(e) {
  var t = x, n = A, r = k, i = d, s = q, l = S, u = F, f = ee, a = e.f;
  x = /** @type {null | Value[]} */
  null, A = 0, k = null, d = (a & (U | re)) === 0 ? e : null, q = null, le(e.ctx), F = !1, ee = ++Q, e.ac !== null && (Ke(() => {
    e.ac.abort(se);
  }), e.ac = null);
  try {
    e.f |= Pe;
    var o = (
      /** @type {Function} */
      e.fn
    ), h = o(), c = e.deps;
    if (x !== null) {
      var _;
      if (Te(e, A), c !== null && A > 0)
        for (c.length = A + x.length, _ = 0; _ < x.length; _++)
          c[A + _] = x[_];
      else
        e.deps = c = x;
      if ($e() && (e.f & R) !== 0)
        for (_ = A; _ < c.length; _++)
          (c[_].reactions ??= []).push(e);
    } else c !== null && A < c.length && (Te(e, A), c.length = A);
    if (pe() && k !== null && !F && c !== null && (e.f & (E | Y | m)) === 0)
      for (_ = 0; _ < /** @type {Source[]} */
      k.length; _++)
        Rt(
          k[_],
          /** @type {Effect} */
          e
        );
    if (i !== null && i !== e) {
      if (Q++, i.deps !== null)
        for (let p = 0; p < n; p += 1)
          i.deps[p].rv = Q;
      if (t !== null)
        for (const p of t)
          p.rv = Q;
      k !== null && (r === null ? r = k : r.push(.../** @type {Source[]} */
      k));
    }
    return (e.f & H) !== 0 && (e.f ^= H), h;
  } catch (p) {
    return st(p);
  } finally {
    e.f ^= Pe, x = t, A = n, k = r, d = i, q = s, le(l), F = u, ee = f;
  }
}
function Fn(e, t) {
  let n = t.reactions;
  if (n !== null) {
    var r = Dt.call(n, e);
    if (r !== -1) {
      var i = n.length - 1;
      i === 0 ? n = t.reactions = null : (n[r] = n[i], n.pop());
    }
  }
  if (n === null && (t.f & E) !== 0 && // Destroying a child effect while updating a parent effect can cause a dependency to appear
  // to be unused, when in fact it is used by the currently-updating parent. Checking `new_deps`
  // allows us to skip the expensive work of disconnecting and immediately reconnecting it
  (x === null || !x.includes(t))) {
    var s = (
      /** @type {Derived} */
      t
    );
    (s.f & R) !== 0 && (s.f ^= R, s.f &= ~te), Ve(s), ot(s), Te(s, 0);
  }
}
function Te(e, t) {
  var n = e.deps;
  if (n !== null)
    for (var r = t; r < n.length; r++)
      Fn(e, n[r]);
}
function ve(e) {
  var t = e.f;
  if ((t & $) === 0) {
    w(e, b);
    var n = v, r = X;
    v = e, X = !0;
    try {
      (t & (V | nt)) !== 0 ? An(e) : bt(e), Et(e);
      var i = Ot(e);
      e.teardown = typeof i == "function" ? i : null, e.wv = At;
      var s;
      Ne && en && (e.f & m) !== 0 && e.deps;
    } finally {
      X = r, v = n;
    }
  }
}
function Z(e) {
  var t = e.f, n = (t & E) !== 0;
  if (d !== null && !F) {
    var r = v !== null && (v.f & $) !== 0;
    if (!r && !q?.includes(e)) {
      var i = d.deps;
      if ((d.f & Pe) !== 0)
        e.rv < Q && (e.rv = Q, x === null && i !== null && i[A] === e ? A++ : x === null ? x = [e] : x.push(e));
      else {
        (d.deps ??= []).push(e);
        var s = e.reactions;
        s === null ? e.reactions = [d] : s.includes(d) || s.push(d);
      }
    }
  }
  if (ne && W.has(e))
    return W.get(e);
  if (n) {
    var l = (
      /** @type {Derived} */
      e
    );
    if (ne) {
      var u = l.v;
      return ((l.f & b) === 0 && l.reactions !== null || Nt(l)) && (u = Ge(l)), W.set(l, u), u;
    }
    var f = (l.f & R) === 0 && !F && d !== null && (X || (d.f & R) !== 0), a = l.deps === null;
    ge(l) && (f && (l.f |= R), ct(l)), f && !a && Ft(l);
  }
  if (O?.has(e))
    return O.get(e);
  if ((e.f & H) !== 0)
    throw e.v;
  return e.v;
}
function Ft(e) {
  if (e.deps !== null) {
    e.f |= R;
    for (const t of e.deps)
      (t.reactions ??= []).push(e), (t.f & E) !== 0 && (t.f & R) === 0 && Ft(
        /** @type {Derived} */
        t
      );
  }
}
function Nt(e) {
  if (e.v === y) return !0;
  if (e.deps === null) return !1;
  for (const t of e.deps)
    if (W.has(t) || (t.f & E) !== 0 && Nt(
      /** @type {Derived} */
      t
    ))
      return !0;
  return !1;
}
function Nn(e) {
  var t = F;
  try {
    return F = !0, e();
  } finally {
    F = t;
  }
}
const Pn = ["touchstart", "touchmove"];
function Cn(e) {
  return Pn.includes(e);
}
const Pt = /* @__PURE__ */ new Set(), Me = /* @__PURE__ */ new Set();
function Dn(e, t, n, r = {}) {
  function i(s) {
    if (r.capture || ce.call(t, s), !s.cancelBubble)
      return Ke(() => n?.call(this, s));
  }
  return e.startsWith("pointer") || e.startsWith("touch") || e === "wheel" ? Ae(() => {
    t.addEventListener(e, i, r);
  }) : t.addEventListener(e, i, r), i;
}
function Xn(e, t, n, r, i) {
  var s = { capture: r, passive: i }, l = Dn(e, t, n, s);
  (t === document.body || // @ts-ignore
  t === window || // @ts-ignore
  t === document || // Firefox has quirky behavior, it can happen that we still get "canplay" events when the element is already removed
  t instanceof HTMLMediaElement) && wt(() => {
    t.removeEventListener(e, l, s);
  });
}
function er(e) {
  for (var t = 0; t < e.length; t++)
    Pt.add(e[t]);
  for (var n of Me)
    n(e);
}
let et = null;
function ce(e) {
  var t = this, n = (
    /** @type {Node} */
    t.ownerDocument
  ), r = e.type, i = e.composedPath?.() || [], s = (
    /** @type {null | Element} */
    i[0] || e.target
  );
  et = e;
  var l = 0, u = et === e && e.__root;
  if (u) {
    var f = i.indexOf(u);
    if (f !== -1 && (t === document || t === /** @type {any} */
    window)) {
      e.__root = t;
      return;
    }
    var a = i.indexOf(t);
    if (a === -1)
      return;
    f <= a && (l = f);
  }
  if (s = /** @type {Element} */
  i[l] || e.target, s !== t) {
    Lt(e, "currentTarget", {
      configurable: !0,
      get() {
        return s || n;
      }
    });
    var o = d, h = v;
    T(null), L(null);
    try {
      for (var c, _ = []; s !== null; ) {
        var p = s.assignedSlot || s.parentNode || /** @type {any} */
        s.host || null;
        try {
          var N = s["__" + r];
          N != null && (!/** @type {any} */
          s.disabled || // DOM could've been updated already by the time this is reached, so we check this as well
          // -> the target could not have been disabled because it emits the event in the first place
          e.target === s) && N.call(s, e);
        } catch (j) {
          c ? _.push(j) : c = j;
        }
        if (e.cancelBubble || p === t || p === null)
          break;
        s = p;
      }
      if (c) {
        for (let j of _)
          queueMicrotask(() => {
            throw j;
          });
        throw c;
      }
    } finally {
      e.__root = t, delete e.currentTarget, T(o), L(h);
    }
  }
}
function tr(e, t) {
  var n = t == null ? "" : typeof t == "object" ? t + "" : t;
  n !== (e.__t ??= e.nodeValue) && (e.__t = n, e.nodeValue = n + "");
}
function nr(e, t) {
  return Mn(e, t);
}
const ie = /* @__PURE__ */ new Map();
function Mn(e, { target: t, anchor: n, props: r = {}, events: i, context: s, intro: l = !0 }) {
  yn();
  var u = /* @__PURE__ */ new Set(), f = (h) => {
    for (var c = 0; c < h.length; c++) {
      var _ = h[c];
      if (!u.has(_)) {
        u.add(_);
        var p = Cn(_);
        t.addEventListener(_, ce, { passive: p });
        var N = ie.get(_);
        N === void 0 ? (document.addEventListener(_, ce, { passive: p }), ie.set(_, 1)) : ie.set(_, N + 1);
      }
    }
  };
  f(Mt(Pt)), Me.add(f);
  var a = void 0, o = mn(() => {
    var h = n ?? t.appendChild(pt());
    return on(
      /** @type {TemplateNode} */
      h,
      {
        pending: () => {
        }
      },
      (c) => {
        if (s) {
          tn({});
          var _ = (
            /** @type {ComponentContext} */
            S
          );
          _.c = s;
        }
        i && (r.$$events = i), a = e(c, r) || {}, s && nn();
      }
    ), () => {
      for (var c of u) {
        t.removeEventListener(c, ce);
        var _ = (
          /** @type {number} */
          ie.get(c)
        );
        --_ === 0 ? (document.removeEventListener(c, ce), ie.delete(c)) : ie.set(c, _);
      }
      Me.delete(f), h !== n && h.parentNode?.removeChild(h);
    };
  });
  return Le.set(a, o), a;
}
let Le = /* @__PURE__ */ new WeakMap();
function rr(e, t) {
  const n = Le.get(e);
  return n ? (Le.delete(e), n(t)) : Promise.resolve();
}
export {
  Qe as $,
  er as A,
  Qn as B,
  Z as C,
  Kn as D,
  de as E,
  Hn as F,
  Gn as G,
  tr as H,
  $n as I,
  $e as J,
  un as K,
  Vn as L,
  K as M,
  In as N,
  oe as O,
  J as P,
  Xn as Q,
  nn as R,
  Fe as S,
  Ln as T,
  tn as U,
  nr as V,
  rr as W,
  gt as a,
  wn as b,
  jn as c,
  v as d,
  pt as e,
  g as f,
  qt as g,
  M as h,
  Ct as i,
  z as j,
  Sn as k,
  qn as l,
  Rn as m,
  Jn as n,
  jt as o,
  ye as p,
  Tn as q,
  Zn as r,
  Wn as s,
  Ae as t,
  Nn as u,
  Bn as v,
  Yn as w,
  S as x,
  Be as y,
  zn as z
};
