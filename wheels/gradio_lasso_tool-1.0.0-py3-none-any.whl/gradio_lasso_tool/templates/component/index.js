import { i as de, g as se, o as pe, a as it, b as ge, T as ye, c as me, d as _e, e as ct, f as Mt, r as xe, h as lt, p as be, j as It, m as ve, s as Ee, k as vt, E as Et, L as we, N as Se, l as ke, n as Me, q as Ie, u as Q, t as Re, S as Pe, v as Le, w as Ae, x as J, y as Ne, z as D, A as re, B as ut, C as M, D as Z, F as Rt, G as dt, H as Oe, I as Te, J as Ce, K as Be, M as q, O as Pt, P as X, Q as ze, R as $e, U as je, $ as Fe } from "./render-D7UyhFse.js";
function oe(s) {
  throw new Error("https://svelte.dev/e/lifecycle_outside_component");
}
const Ge = [];
function De(s, t = !1, e = !1) {
  return tt(s, /* @__PURE__ */ new Map(), "", Ge, null, e);
}
function tt(s, t, e, n, i = null, r = !1) {
  if (typeof s == "object" && s !== null) {
    var o = t.get(s);
    if (o !== void 0) return o;
    if (s instanceof Map) return (
      /** @type {Snapshot<T>} */
      new Map(s)
    );
    if (s instanceof Set) return (
      /** @type {Snapshot<T>} */
      new Set(s)
    );
    if (de(s)) {
      var l = (
        /** @type {Snapshot<any>} */
        Array(s.length)
      );
      t.set(s, l), i !== null && t.set(i, l);
      for (var h = 0; h < s.length; h += 1) {
        var f = s[h];
        h in s && (l[h] = tt(f, t, e, n, null, r));
      }
      return l;
    }
    if (se(s) === pe) {
      l = {}, t.set(s, l), i !== null && t.set(i, l);
      for (var d in s)
        l[d] = tt(
          // @ts-expect-error
          s[d],
          t,
          e,
          n,
          null,
          r
        );
      return l;
    }
    if (s instanceof Date)
      return (
        /** @type {Snapshot<T>} */
        structuredClone(s)
      );
    if (typeof /** @type {T & { toJSON?: any } } */
    s.toJSON == "function" && !r)
      return tt(
        /** @type {T & { toJSON(): any } } */
        s.toJSON(),
        t,
        e,
        n,
        // Associate the instance with the toJSON clone
        s
      );
  }
  if (s instanceof EventTarget)
    return (
      /** @type {Snapshot<T>} */
      s
    );
  try {
    return (
      /** @type {Snapshot<T>} */
      structuredClone(s)
    );
  } catch {
    return (
      /** @type {Snapshot<T>} */
      s
    );
  }
}
function le(s) {
  var t = document.createElement("template");
  return t.innerHTML = s.replaceAll("<!>", "<!---->"), t.content;
}
function st(s, t) {
  var e = (
    /** @type {Effect} */
    _e
  );
  e.nodes === null && (e.nodes = { start: s, end: t, a: null, t: null });
}
// @__NO_SIDE_EFFECTS__
function wt(s, t) {
  var e = (t & ye) !== 0, n = (t & me) !== 0, i, r = !s.startsWith("<!>");
  return () => {
    i === void 0 && (i = le(r ? s : "<!>" + s), e || (i = /** @type {TemplateNode} */
    it(i)));
    var o = (
      /** @type {TemplateNode} */
      n || ge ? document.importNode(i, !0) : i.cloneNode(!0)
    );
    if (e) {
      var l = (
        /** @type {TemplateNode} */
        it(o)
      ), h = (
        /** @type {TemplateNode} */
        o.lastChild
      );
      st(l, h);
    } else
      st(o, o);
    return o;
  };
}
// @__NO_SIDE_EFFECTS__
function Ye(s, t, e = "svg") {
  var n = !s.startsWith("<!>"), i = `<${e}>${n ? s : "<!>" + s}</${e}>`, r;
  return () => {
    if (!r) {
      var o = (
        /** @type {DocumentFragment} */
        le(i)
      ), l = (
        /** @type {Element} */
        it(o)
      );
      r = /** @type {Element} */
      it(l);
    }
    var h = (
      /** @type {TemplateNode} */
      r.cloneNode(!0)
    );
    return st(h, h), h;
  };
}
// @__NO_SIDE_EFFECTS__
function Ue(s, t) {
  return /* @__PURE__ */ Ye(s, t, "svg");
}
function He() {
  var s = document.createDocumentFragment(), t = document.createComment(""), e = ct();
  return s.append(t, e), st(t, e), s;
}
function W(s, t) {
  s !== null && s.before(
    /** @type {Node} */
    t
  );
}
class St {
  /** @type {TemplateNode} */
  anchor;
  /** @type {Map<Batch, Key>} */
  #t = /* @__PURE__ */ new Map();
  /**
   * Map of keys to effects that are currently rendered in the DOM.
   * These effects are visible and actively part of the document tree.
   * Example:
   * ```
   * {#if condition}
   * 	foo
   * {:else}
   * 	bar
   * {/if}
   * ```
   * Can result in the entries `true->Effect` and `false->Effect`
   * @type {Map<Key, Effect>}
   */
  #e = /* @__PURE__ */ new Map();
  /**
   * Similar to #onscreen with respect to the keys, but contains branches that are not yet
   * in the DOM, because their insertion is deferred.
   * @type {Map<Key, Branch>}
   */
  #n = /* @__PURE__ */ new Map();
  /**
   * Keys of effects that are currently outroing
   * @type {Set<Key>}
   */
  #h = /* @__PURE__ */ new Set();
  /**
   * Whether to pause (i.e. outro) on change, or destroy immediately.
   * This is necessary for `<svelte:element>`
   */
  #f = !0;
  /**
   * @param {TemplateNode} anchor
   * @param {boolean} transition
   */
  constructor(t, e = !0) {
    this.anchor = t, this.#f = e;
  }
  #c = () => {
    var t = (
      /** @type {Batch} */
      Mt
    );
    if (this.#t.has(t)) {
      var e = (
        /** @type {Key} */
        this.#t.get(t)
      ), n = this.#e.get(e);
      if (n)
        xe(n), this.#h.delete(e);
      else {
        var i = this.#n.get(e);
        i && (this.#e.set(e, i.effect), this.#n.delete(e), i.fragment.lastChild.remove(), this.anchor.before(i.fragment), n = i.effect);
      }
      for (const [r, o] of this.#t) {
        if (this.#t.delete(r), r === t)
          break;
        const l = this.#n.get(o);
        l && (lt(l.effect), this.#n.delete(o));
      }
      for (const [r, o] of this.#e) {
        if (r === e || this.#h.has(r)) continue;
        const l = () => {
          if (Array.from(this.#t.values()).includes(r)) {
            var f = document.createDocumentFragment();
            ve(o, f), f.append(ct()), this.#n.set(r, { effect: o, fragment: f });
          } else
            lt(o);
          this.#h.delete(r), this.#e.delete(r);
        };
        this.#f || !n ? (this.#h.add(r), be(o, l, !1)) : l();
      }
    }
  };
  /**
   * @param {Batch} batch
   */
  #u = (t) => {
    this.#t.delete(t);
    const e = Array.from(this.#t.values());
    for (const [n, i] of this.#n)
      e.includes(n) || (lt(i.effect), this.#n.delete(n));
  };
  /**
   *
   * @param {any} key
   * @param {null | ((target: TemplateNode) => void)} fn
   */
  ensure(t, e) {
    var n = (
      /** @type {Batch} */
      Mt
    ), i = Ee();
    if (e && !this.#e.has(t) && !this.#n.has(t))
      if (i) {
        var r = document.createDocumentFragment(), o = ct();
        r.append(o), this.#n.set(t, {
          effect: It(() => e(o)),
          fragment: r
        });
      } else
        this.#e.set(
          t,
          It(() => e(this.anchor))
        );
    if (this.#t.set(n, t), i) {
      for (const [l, h] of this.#e)
        l === t ? n.skipped_effects.delete(h) : n.skipped_effects.add(h);
      for (const [l, h] of this.#n)
        l === t ? n.skipped_effects.delete(h.effect) : n.skipped_effects.add(h.effect);
      n.oncommit(this.#c), n.ondiscard(this.#u);
    } else
      this.#c();
  }
}
function Lt(s, t, e = !1) {
  var n = new St(s), i = e ? Et : 0;
  function r(o, l) {
    n.ensure(o, l);
  }
  vt(() => {
    var o = !1;
    t((l, h = !0) => {
      o = !0, r(h, l);
    }), o || r(!1, null);
  }, i);
}
function qe(s, t, ...e) {
  var n = new St(s);
  vt(() => {
    const i = t() ?? null;
    n.ensure(i, i && ((r) => i(r, ...e)));
  }, Et);
}
function Xe(s, t, e) {
  var n = new St(s);
  vt(() => {
    var i = t() ?? null;
    n.ensure(i, i && ((r) => e(r, i)));
  }, Et);
}
const At = [...` 	
\r\f \v\uFEFF`];
function We(s, t, e) {
  var n = s == null ? "" : "" + s;
  if (e) {
    for (var i in e)
      if (e[i])
        n = n ? n + " " + i : i;
      else if (n.length)
        for (var r = i.length, o = 0; (o = n.indexOf(i, o)) >= 0; ) {
          var l = o + r;
          (o === 0 || At.includes(n[o - 1])) && (l === n.length || At.includes(n[l])) ? n = (o === 0 ? "" : n.substring(0, o)) + n.substring(l + 1) : o = l;
        }
  }
  return n === "" ? null : n;
}
function Nt(s, t = !1) {
  var e = t ? " !important;" : ";", n = "";
  for (var i in s) {
    var r = s[i];
    r != null && r !== "" && (n += " " + i + ": " + r + e);
  }
  return n;
}
function Ke(s, t) {
  if (t) {
    var e = "", n, i;
    return Array.isArray(t) ? (n = t[0], i = t[1]) : n = t, n && (e += Nt(n)), i && (e += Nt(i, !0)), e = e.trim(), e === "" ? null : e;
  }
  return String(s);
}
function Ot(s, t, e, n, i, r) {
  var o = s.__className;
  if (o !== e || o === void 0) {
    var l = We(e, n, r);
    l == null ? s.removeAttribute("class") : s.className = l, s.__className = e;
  } else if (r && i !== r)
    for (var h in r) {
      var f = !!r[h];
      (i == null || f !== !!i[h]) && s.classList.toggle(h, f);
    }
  return r;
}
function ht(s, t = {}, e, n) {
  for (var i in e) {
    var r = e[i];
    t[i] !== r && (e[i] == null ? s.style.removeProperty(i) : s.style.setProperty(i, r, n));
  }
}
function Qe(s, t, e, n) {
  var i = s.__style;
  if (i !== t) {
    var r = Ke(t, n);
    r == null ? s.removeAttribute("style") : s.style.cssText = r, s.__style = t;
  } else n && (Array.isArray(n) ? (ht(s, e?.[0], n[0]), ht(s, e?.[1], n[1], "important")) : ht(s, e, n));
  return n;
}
const Ve = /* @__PURE__ */ Symbol("is custom element"), Je = /* @__PURE__ */ Symbol("is html");
function et(s, t, e, n) {
  var i = Ze(s);
  i[t] !== (i[t] = e) && (t === "loading" && (s[we] = e), e == null ? s.removeAttribute(t) : typeof e != "string" && tn(s).includes(t) ? s[t] = e : s.setAttribute(t, e));
}
function Ze(s) {
  return (
    /** @type {Record<string | symbol, unknown>} **/
    // @ts-expect-error
    s.__attributes ??= {
      [Ve]: s.nodeName.includes("-"),
      [Je]: s.namespaceURI === Se
    }
  );
}
var Tt = /* @__PURE__ */ new Map();
function tn(s) {
  var t = s.getAttribute("is") || s.nodeName, e = Tt.get(t);
  if (e) return e;
  Tt.set(t, e = []);
  for (var n, i = s, r = Element.prototype; r !== i; ) {
    n = ke(i);
    for (var o in n)
      n[o].set && e.push(o);
    i = se(i);
  }
  return e;
}
function Ct(s, t) {
  return s === t || s?.[Pe] === t;
}
function en(s = {}, t, e, n) {
  return Me(() => {
    var i, r;
    return Ie(() => {
      i = r, r = [], Q(() => {
        s !== e(...r) && (t(s, ...r), i && Ct(e(...i), s) && t(null, ...i));
      });
    }), () => {
      Re(() => {
        r && Ct(e(...r), s) && t(null, ...r);
      });
    };
  }), s;
}
function nn(s, t, e) {
  if (s == null)
    return t(void 0), Le;
  const n = Q(
    () => s.subscribe(
      t,
      // @ts-expect-error
      e
    )
  );
  return n.unsubscribe ? () => n.unsubscribe() : n;
}
function sn(s) {
  let t;
  return nn(s, (e) => t = e)(), t;
}
const rn = {
  get(s, t) {
    if (!s.exclude.includes(t))
      return s.props[t];
  },
  set(s, t) {
    return !1;
  },
  getOwnPropertyDescriptor(s, t) {
    if (!s.exclude.includes(t) && t in s.props)
      return {
        enumerable: !0,
        configurable: !0,
        value: s.props[t]
      };
  },
  has(s, t) {
    return s.exclude.includes(t) ? !1 : t in s.props;
  },
  ownKeys(s) {
    return Reflect.ownKeys(s.props).filter((t) => !s.exclude.includes(t));
  }
};
// @__NO_SIDE_EFFECTS__
function on(s, t, e) {
  return new Proxy(
    { props: s, exclude: t },
    rn
  );
}
function A(s, t, e, n) {
  var i = (
    /** @type {V} */
    n
  ), r = !0, o = () => (r && (r = !1, i = /** @type {V} */
  n), i), l;
  l = /** @type {V} */
  s[t], l === void 0 && n !== void 0 && (l = o());
  var h;
  return h = () => {
    var f = (
      /** @type {V} */
      s[t]
    );
    return f === void 0 ? o() : (r = !0, f);
  }, h;
}
Ae();
function he(s) {
  J === null && oe(), Ne && J.l !== null ? hn(J).m.push(s) : D(() => {
    const t = Q(s);
    if (typeof t == "function") return (
      /** @type {() => void} */
      t
    );
  });
}
function ln(s) {
  J === null && oe(), he(() => () => Q(s));
}
function hn(s) {
  var t = (
    /** @type {ComponentContextLegacy} */
    s.l
  );
  return t.u ??= { a: [], b: [], m: [] };
}
var an = /* @__PURE__ */ wt('<span class="svelte-12hu46v"> </span>'), fn = /* @__PURE__ */ wt("<button><!> <div><!> <!></div></button>");
function cn(s, t) {
  let e = A(t, "label", 3, ""), n = A(t, "show_label", 3, !1), i = A(t, "pending", 3, !1), r = A(t, "size", 3, "small"), o = A(t, "padded", 3, !0), l = A(t, "highlight", 3, !1), h = A(t, "disabled", 3, !1), f = A(t, "hasPopup", 3, !1), d = A(t, "color", 3, "var(--block-label-text-color)"), a = A(t, "transparent", 3, !1), c = A(t, "background", 3, "var(--block-background-fill)"), u = A(t, "border", 3, "transparent"), y = dt(() => l() ? "var(--color-accent)" : d());
  var g = fn();
  let _;
  g.__click = function(...v) {
    t.onclick?.apply(this, v);
  };
  let m;
  var p = Z(g);
  {
    var x = (v) => {
      var S = an(), R = Z(S);
      ut(() => Oe(R, e())), W(v, S);
    };
    Lt(p, (v) => {
      n() && v(x);
    });
  }
  var b = Rt(p, 2);
  let E;
  var w = Z(b);
  Xe(w, () => t.Icon, (v, S) => {
    S(v, {});
  });
  var L = Rt(w, 2);
  {
    var k = (v) => {
      var S = He(), R = Te(S);
      qe(R, () => t.children), W(v, S);
    };
    Lt(L, (v) => {
      t.children && v(k);
    });
  }
  ut(() => {
    _ = Ot(g, 1, "icon-button svelte-12hu46v", null, _, {
      pending: i(),
      padded: o(),
      highlight: l(),
      transparent: a()
    }), g.disabled = h(), et(g, "aria-label", e()), et(g, "aria-haspopup", f()), et(g, "title", e()), m = Qe(g, "", m, {
      "--border-color": u(),
      color: !h() && M(y) ? M(y) : "var(--block-label-text-color)",
      "--bg-color": h() ? "auto" : c()
    }), E = Ot(b, 1, "svelte-12hu46v", null, E, {
      "x-small": r() === "x-small",
      small: r() === "small",
      large: r() === "large",
      medium: r() === "medium"
    });
  }), W(s, g);
}
re(["click"]);
const un = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], Bt = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
un.reduce((s, { color: t, primary: e, secondary: n }) => ({
  ...s,
  [t]: {
    primary: Bt[t][e],
    secondary: Bt[t][n]
  }
}), {});
function dn(s) {
  let t;
  const e = Be((i) => {
    let r = !1;
    const o = s.subscribe((l) => {
      t = l, r && i();
    });
    return r = !0, o;
  });
  function n() {
    return Ce() ? (e(), t) : sn(s);
  }
  return "set" in s ? {
    get current() {
      return n();
    },
    set current(i) {
      s.set(i);
    }
  } : {
    get current() {
      return n();
    }
  };
}
const pn = "__i18n__", gn = [
  "label",
  "info",
  "placeholder",
  "description",
  "title",
  "value"
], yn = [
  "elem_id",
  "elem_classes",
  "visible",
  "interactive",
  "server_fns",
  "server",
  "id",
  "target",
  "theme_mode",
  "version",
  "root",
  "autoscroll",
  "max_file_size",
  "formatter",
  "client",
  "load_component",
  "scale",
  "min_width",
  "theme",
  "padding",
  "loading_status",
  "label",
  "show_label",
  "validation_error",
  "show_progress",
  "api_prefix",
  "container",
  "attached_events",
  "register_component",
  "dispatcher"
];
function mn(s) {
  return typeof s == "string" && s.includes(pn);
}
class _n {
  load_component;
  #t = q(Pt({}));
  get shared() {
    return M(this.#t);
  }
  set shared(t) {
    X(this.#t, t, !0);
  }
  #e = q(Pt({}));
  get props() {
    return M(this.#e);
  }
  set props(t) {
    X(this.#e, t, !0);
  }
  #n = q((t) => t);
  get i18n() {
    return M(this.#n);
  }
  set i18n(t) {
    X(this.#n, t, !0);
  }
  i18n_store;
  _i18n_from_store;
  translatable_props = {};
  dispatcher;
  last_update = null;
  shared_props = yn;
  mounted = !1;
  old_value;
  register_component;
  constructor(t, e) {
    for (const n in t.shared_props)
      this.shared[n] = t.shared_props[n];
    for (const n in t.props)
      n !== "i18n_store" && (this.props[n] = t.props[n]);
    if (e)
      for (const n in e)
        this.props[n] === void 0 && (this.props[n] = e[n]);
    this.i18n = this.props.i18n ?? ((n) => n), this.i18n_store = t.props.i18n_store, this._i18n_from_store = this.i18n_store ? dn(this.i18n_store) : void 0;
    for (const n of gn)
      this.shared[n] = this._translate_and_store(
        "shared",
        n,
        // @ts-ignore
        t.shared_props[n]
      ), this.props[n] = this._translate_and_store(
        "props",
        n,
        // @ts-ignore
        t.props[n]
      );
    this.load_component = this.shared.load_component, this.register_component = this.shared.register_component || (() => {
    }), this.dispatcher = this.shared.dispatcher || (() => {
    }), this.register_component(
      t.shared_props.id,
      // @ts-ignore
      this.set_data.bind(this),
      this.get_data.bind(this)
    ), D(() => {
      for (const n in t.shared_props)
        this._is_i18n_managed(`shared.${n}`, t.shared_props[n]) || (this.shared[n] = t.shared_props[n]);
      for (const n in t.props)
        n !== "i18n_store" && (this._is_i18n_managed(`props.${n}`, t.props[n]) || (this.props[n] = t.props[n]));
      this.register_component(
        t.shared_props.id,
        // @ts-ignore
        this.set_data.bind(this),
        this.get_data.bind(this)
      ), Q(() => {
        this.shared.id = t.shared_props.id;
      });
    }), D(() => this.i18n_store ? this.i18n_store.subscribe(() => {
      for (const [i, r] of Object.entries(this.translatable_props)) {
        const [o, l] = i.split("."), h = this.i18n(r);
        o === "shared" ? this.shared[l] = h : this.props[l] = h;
      }
    }) : void 0);
  }
  // check if props are translatable
  _is_i18n_managed(t, e) {
    const n = this.translatable_props[t];
    return n ? e === n ? !0 : (delete this.translatable_props[t], !1) : !1;
  }
  _translate_and_store(t, e, n) {
    if (typeof n != "string") return n;
    const i = this.i18n(n);
    return i !== n && (this.translatable_props[`${t}.${e}`] = n), i;
  }
  // Reactive variant of `i18n`. Reading it inside a derived or template
  // subscribes to the live locale store (via Svelte's createSubscriber), so
  // the caller re-runs when the locale changes at runtime. The store is only
  // the reactivity trigger; translation always goes through `this.i18n` so a
  // custom formatter passed via props keeps taking effect.
  live_i18n = (t) => (this._i18n_from_store?.current, this.i18n(t));
  dispatch(t, e) {
    this.dispatcher(this.shared.id, t, e);
  }
  async get_data() {
    return De(this.props);
  }
  update(t) {
    this.set_data(t);
  }
  set_data(t) {
    for (const e in t) {
      const n = t[e], i = mn(n) ? this._translate_and_store(this.shared_props.includes(e) ? "shared" : "props", e, n) : n;
      if (this.shared_props.includes(e)) {
        const r = e;
        this.shared[r] = i;
        continue;
      }
      this.props[e] = i;
    }
  }
  watch_for_change() {
    D(() => {
      this.mounted || (this.old_value = this.props.value, this.mounted = !0), this.old_value != this.props.value && (this.old_value = this.props.value, this.dispatch("change"));
    });
  }
}
re(["click"]);
const zt = "canvas-host", xn = "canvas-host-request";
function bn(s, t) {
  const e = (n) => {
    const i = n.detail;
    i.id === s && t(i);
  };
  return window.addEventListener(zt, e), window.dispatchEvent(
    new CustomEvent(xn, { detail: { canvas_id: s, resolve: t } })
  ), () => window.removeEventListener(zt, e);
}
var vn = /* @__PURE__ */ Ue('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3.704 14.467a10 8 0 1 1 3.115 2.375"></path><path d="M7 22a5 5 0 0 1-2-3.994"></path><circle cx="5" cy="16" r="2"></circle></svg>');
function En(s) {
  var t = vn();
  W(s, t);
}
class F {
  constructor(t, e) {
    this.next = null, this.key = t, this.data = e, this.left = null, this.right = null;
  }
}
function wn(s, t) {
  return s > t ? 1 : s < t ? -1 : 0;
}
function z(s, t, e) {
  const n = new F(null, null);
  let i = n, r = n;
  for (; ; ) {
    const o = e(s, t.key);
    if (o < 0) {
      if (t.left === null) break;
      if (e(s, t.left.key) < 0) {
        const l = t.left;
        if (t.left = l.right, l.right = t, t = l, t.left === null) break;
      }
      r.left = t, r = t, t = t.left;
    } else if (o > 0) {
      if (t.right === null) break;
      if (e(s, t.right.key) > 0) {
        const l = t.right;
        if (t.right = l.left, l.left = t, t = l, t.right === null) break;
      }
      i.right = t, i = t, t = t.right;
    } else break;
  }
  return i.right = t.left, r.left = t.right, t.left = n.right, t.right = n.left, t;
}
function at(s, t, e, n) {
  const i = new F(s, t);
  if (e === null)
    return i.left = i.right = null, i;
  e = z(s, e, n);
  const r = n(s, e.key);
  return r < 0 ? (i.left = e.left, i.right = e, e.left = null) : r >= 0 && (i.right = e.right, i.left = e, e.right = null), i;
}
function $t(s, t, e) {
  let n = null, i = null;
  if (t) {
    t = z(s, t, e);
    const r = e(t.key, s);
    r === 0 ? (n = t.left, i = t.right) : r < 0 ? (i = t.right, t.right = null, n = t) : (n = t.left, t.left = null, i = t);
  }
  return { left: n, right: i };
}
function Sn(s, t, e) {
  return t === null ? s : (s === null || (t = z(s.key, t, e), t.left = s), t);
}
function pt(s, t, e, n, i) {
  if (s) {
    n(`${t}${e ? "└── " : "├── "}${i(s)}
`);
    const r = t + (e ? "    " : "│   ");
    s.left && pt(s.left, r, !1, n, i), s.right && pt(s.right, r, !0, n, i);
  }
}
class kt {
  constructor(t = wn) {
    this._root = null, this._size = 0, this._comparator = t;
  }
  /**
   * Inserts a key, allows duplicates
   */
  insert(t, e) {
    return this._size++, this._root = at(t, e, this._root, this._comparator);
  }
  /**
   * Adds a key, if it is not present in the tree
   */
  add(t, e) {
    const n = new F(t, e);
    this._root === null && (n.left = n.right = null, this._size++, this._root = n);
    const i = this._comparator, r = z(t, this._root, i), o = i(t, r.key);
    return o === 0 ? this._root = r : (o < 0 ? (n.left = r.left, n.right = r, r.left = null) : o > 0 && (n.right = r.right, n.left = r, r.right = null), this._size++, this._root = n), this._root;
  }
  /**
   * @param  {Key} key
   * @return {Node|null}
   */
  remove(t) {
    this._root = this._remove(t, this._root, this._comparator);
  }
  /**
   * Deletes i from the tree if it's there
   */
  _remove(t, e, n) {
    let i;
    return e === null ? null : (e = z(t, e, n), n(t, e.key) === 0 ? (e.left === null ? i = e.right : (i = z(t, e.left, n), i.right = e.right), this._size--, i) : e);
  }
  /**
   * Removes and returns the node with smallest key
   */
  pop() {
    let t = this._root;
    if (t) {
      for (; t.left; ) t = t.left;
      return this._root = z(t.key, this._root, this._comparator), this._root = this._remove(t.key, this._root, this._comparator), { key: t.key, data: t.data };
    }
    return null;
  }
  /**
   * Find without splaying
   */
  findStatic(t) {
    let e = this._root;
    const n = this._comparator;
    for (; e; ) {
      const i = n(t, e.key);
      if (i === 0) return e;
      i < 0 ? e = e.left : e = e.right;
    }
    return null;
  }
  find(t) {
    return this._root && (this._root = z(t, this._root, this._comparator), this._comparator(t, this._root.key) !== 0) ? null : this._root;
  }
  contains(t) {
    let e = this._root;
    const n = this._comparator;
    for (; e; ) {
      const i = n(t, e.key);
      if (i === 0) return !0;
      i < 0 ? e = e.left : e = e.right;
    }
    return !1;
  }
  forEach(t, e) {
    let n = this._root;
    const i = [];
    let r = !1;
    for (; !r; )
      n !== null ? (i.push(n), n = n.left) : i.length !== 0 ? (n = i.pop(), t.call(e, n), n = n.right) : r = !0;
    return this;
  }
  /**
   * Walk key range from `low` to `high`. Stops if `fn` returns a value.
   */
  range(t, e, n, i) {
    const r = [], o = this._comparator;
    let l = this._root, h;
    for (; r.length !== 0 || l; )
      if (l)
        r.push(l), l = l.left;
      else {
        if (l = r.pop(), h = o(l.key, e), h > 0)
          break;
        if (o(l.key, t) >= 0 && n.call(i, l))
          return this;
        l = l.right;
      }
    return this;
  }
  /**
   * Returns array of keys
   */
  keys() {
    const t = [];
    return this.forEach(({ key: e }) => {
      t.push(e);
    }), t;
  }
  /**
   * Returns array of all the data in the nodes
   */
  values() {
    const t = [];
    return this.forEach(({ data: e }) => {
      t.push(e);
    }), t;
  }
  min() {
    return this._root ? this.minNode(this._root).key : null;
  }
  max() {
    return this._root ? this.maxNode(this._root).key : null;
  }
  minNode(t = this._root) {
    if (t) for (; t.left; ) t = t.left;
    return t;
  }
  maxNode(t = this._root) {
    if (t) for (; t.right; ) t = t.right;
    return t;
  }
  /**
   * Returns node at given index
   */
  at(t) {
    let e = this._root, n = !1, i = 0;
    const r = [];
    for (; !n; )
      if (e)
        r.push(e), e = e.left;
      else if (r.length > 0) {
        if (e = r.pop(), i === t) return e;
        i++, e = e.right;
      } else n = !0;
    return null;
  }
  next(t) {
    let e = this._root, n = null;
    if (t.right) {
      for (n = t.right; n.left; ) n = n.left;
      return n;
    }
    const i = this._comparator;
    for (; e; ) {
      const r = i(t.key, e.key);
      if (r === 0) break;
      r < 0 ? (n = e, e = e.left) : e = e.right;
    }
    return n;
  }
  prev(t) {
    let e = this._root, n = null;
    if (t.left !== null) {
      for (n = t.left; n.right; ) n = n.right;
      return n;
    }
    const i = this._comparator;
    for (; e; ) {
      const r = i(t.key, e.key);
      if (r === 0) break;
      r < 0 ? e = e.left : (n = e, e = e.right);
    }
    return n;
  }
  clear() {
    return this._root = null, this._size = 0, this;
  }
  toList() {
    return Mn(this._root);
  }
  /**
   * Bulk-load items. Both array have to be same size
   */
  load(t, e = [], n = !1) {
    let i = t.length;
    const r = this._comparator;
    if (n && mt(t, e, 0, i - 1, r), this._root === null)
      this._root = gt(t, e, 0, i), this._size = i;
    else {
      const o = In(
        this.toList(),
        kn(t, e),
        r
      );
      i = this._size + i, this._root = yt({ head: o }, 0, i);
    }
    return this;
  }
  isEmpty() {
    return this._root === null;
  }
  get size() {
    return this._size;
  }
  get root() {
    return this._root;
  }
  toString(t = (e) => String(e.key)) {
    const e = [];
    return pt(this._root, "", !0, (n) => e.push(n), t), e.join("");
  }
  update(t, e, n) {
    const i = this._comparator;
    let { left: r, right: o } = $t(t, this._root, i);
    i(t, e) < 0 ? o = at(e, n, o, i) : r = at(e, n, r, i), this._root = Sn(r, o, i);
  }
  split(t) {
    return $t(t, this._root, this._comparator);
  }
  *[Symbol.iterator]() {
    let t = this._root;
    const e = [];
    let n = !1;
    for (; !n; )
      t !== null ? (e.push(t), t = t.left) : e.length !== 0 ? (t = e.pop(), yield t, t = t.right) : n = !0;
  }
}
function gt(s, t, e, n) {
  const i = n - e;
  if (i > 0) {
    const r = e + Math.floor(i / 2), o = s[r], l = t[r], h = new F(o, l);
    return h.left = gt(s, t, e, r), h.right = gt(s, t, r + 1, n), h;
  }
  return null;
}
function kn(s, t) {
  const e = new F(null, null);
  let n = e;
  for (let i = 0; i < s.length; i++)
    n = n.next = new F(s[i], t[i]);
  return n.next = null, e.next;
}
function Mn(s) {
  let t = s;
  const e = [];
  let n = !1;
  const i = new F(null, null);
  let r = i;
  for (; !n; )
    t ? (e.push(t), t = t.left) : e.length > 0 ? (t = r = r.next = e.pop(), t = t.right) : n = !0;
  return r.next = null, i.next;
}
function yt(s, t, e) {
  const n = e - t;
  if (n > 0) {
    const i = t + Math.floor(n / 2), r = yt(s, t, i), o = s.head;
    return o.left = r, s.head = s.head.next, o.right = yt(s, i + 1, e), o;
  }
  return null;
}
function In(s, t, e) {
  const n = new F(null, null);
  let i = n, r = s, o = t;
  for (; r !== null && o !== null; )
    e(r.key, o.key) < 0 ? (i.next = r, r = r.next) : (i.next = o, o = o.next), i = i.next;
  return r !== null ? i.next = r : o !== null && (i.next = o), n.next;
}
function mt(s, t, e, n, i) {
  if (e >= n) return;
  const r = s[e + n >> 1];
  let o = e - 1, l = n + 1;
  for (; ; ) {
    do
      o++;
    while (i(s[o], r) < 0);
    do
      l--;
    while (i(s[l], r) > 0);
    if (o >= l) break;
    let h = s[o];
    s[o] = s[l], s[l] = h, h = t[o], t[o] = t[l], t[l] = h;
  }
  mt(s, t, e, l, i), mt(s, t, l + 1, n, i);
}
const B = 11102230246251565e-32, I = 134217729, Rn = (3 + 8 * B) * B;
function ft(s, t, e, n, i) {
  let r, o, l, h, f = t[0], d = n[0], a = 0, c = 0;
  d > f == d > -f ? (r = f, f = t[++a]) : (r = d, d = n[++c]);
  let u = 0;
  if (a < s && c < e)
    for (d > f == d > -f ? (o = f + r, l = r - (o - f), f = t[++a]) : (o = d + r, l = r - (o - d), d = n[++c]), r = o, l !== 0 && (i[u++] = l); a < s && c < e; )
      d > f == d > -f ? (o = r + f, h = o - r, l = r - (o - h) + (f - h), f = t[++a]) : (o = r + d, h = o - r, l = r - (o - h) + (d - h), d = n[++c]), r = o, l !== 0 && (i[u++] = l);
  for (; a < s; )
    o = r + f, h = o - r, l = r - (o - h) + (f - h), f = t[++a], r = o, l !== 0 && (i[u++] = l);
  for (; c < e; )
    o = r + d, h = o - r, l = r - (o - h) + (d - h), d = n[++c], r = o, l !== 0 && (i[u++] = l);
  return (r !== 0 || u === 0) && (i[u++] = r), u;
}
function Pn(s, t) {
  let e = t[0];
  for (let n = 1; n < s; n++) e += t[n];
  return e;
}
function V(s) {
  return new Float64Array(s);
}
const Ln = (3 + 16 * B) * B, An = (2 + 12 * B) * B, Nn = (9 + 64 * B) * B * B, G = V(4), jt = V(8), Ft = V(12), Gt = V(16), P = V(4);
function On(s, t, e, n, i, r, o) {
  let l, h, f, d, a, c, u, y, g, _, m, p, x, b, E, w, L, k;
  const v = s - i, S = e - i, R = t - r, O = n - r;
  b = v * O, c = I * v, u = c - (c - v), y = v - u, c = I * O, g = c - (c - O), _ = O - g, E = y * _ - (b - u * g - y * g - u * _), w = R * S, c = I * R, u = c - (c - R), y = R - u, c = I * S, g = c - (c - S), _ = S - g, L = y * _ - (w - u * g - y * g - u * _), m = E - L, a = E - m, G[0] = E - (m + a) + (a - L), p = b + m, a = p - b, x = b - (p - a) + (m - a), m = x - w, a = x - m, G[1] = x - (m + a) + (a - w), k = p + m, a = k - p, G[2] = p - (k - a) + (m - a), G[3] = k;
  let C = Pn(4, G), Y = An * o;
  if (C >= Y || -C >= Y || (a = s - v, l = s - (v + a) + (a - i), a = e - S, f = e - (S + a) + (a - i), a = t - R, h = t - (R + a) + (a - r), a = n - O, d = n - (O + a) + (a - r), l === 0 && h === 0 && f === 0 && d === 0) || (Y = Nn * o + Rn * Math.abs(C), C += v * d + O * l - (R * f + S * h), C >= Y || -C >= Y)) return C;
  b = l * O, c = I * l, u = c - (c - l), y = l - u, c = I * O, g = c - (c - O), _ = O - g, E = y * _ - (b - u * g - y * g - u * _), w = h * S, c = I * h, u = c - (c - h), y = h - u, c = I * S, g = c - (c - S), _ = S - g, L = y * _ - (w - u * g - y * g - u * _), m = E - L, a = E - m, P[0] = E - (m + a) + (a - L), p = b + m, a = p - b, x = b - (p - a) + (m - a), m = x - w, a = x - m, P[1] = x - (m + a) + (a - w), k = p + m, a = k - p, P[2] = p - (k - a) + (m - a), P[3] = k;
  const fe = ft(4, G, 4, P, jt);
  b = v * d, c = I * v, u = c - (c - v), y = v - u, c = I * d, g = c - (c - d), _ = d - g, E = y * _ - (b - u * g - y * g - u * _), w = R * f, c = I * R, u = c - (c - R), y = R - u, c = I * f, g = c - (c - f), _ = f - g, L = y * _ - (w - u * g - y * g - u * _), m = E - L, a = E - m, P[0] = E - (m + a) + (a - L), p = b + m, a = p - b, x = b - (p - a) + (m - a), m = x - w, a = x - m, P[1] = x - (m + a) + (a - w), k = p + m, a = k - p, P[2] = p - (k - a) + (m - a), P[3] = k;
  const ce = ft(fe, jt, 4, P, Ft);
  b = l * d, c = I * l, u = c - (c - l), y = l - u, c = I * d, g = c - (c - d), _ = d - g, E = y * _ - (b - u * g - y * g - u * _), w = h * f, c = I * h, u = c - (c - h), y = h - u, c = I * f, g = c - (c - f), _ = f - g, L = y * _ - (w - u * g - y * g - u * _), m = E - L, a = E - m, P[0] = E - (m + a) + (a - L), p = b + m, a = p - b, x = b - (p - a) + (m - a), m = x - w, a = x - m, P[1] = x - (m + a) + (a - w), k = p + m, a = k - p, P[2] = p - (k - a) + (m - a), P[3] = k;
  const ue = ft(ce, Ft, 4, P, Gt);
  return Gt[ue - 1];
}
function Tn(s, t, e, n, i, r) {
  const o = (t - r) * (e - i), l = (s - i) * (n - r), h = o - l, f = Math.abs(o + l);
  return Math.abs(h) >= Ln * f ? h : -On(s, t, e, n, i, r, f);
}
const U = (s, t) => s.ll.x <= t.x && t.x <= s.ur.x && s.ll.y <= t.y && t.y <= s.ur.y, _t = (s, t) => {
  if (t.ur.x < s.ll.x || s.ur.x < t.ll.x || t.ur.y < s.ll.y || s.ur.y < t.ll.y) return null;
  const e = s.ll.x < t.ll.x ? t.ll.x : s.ll.x, n = s.ur.x < t.ur.x ? s.ur.x : t.ur.x, i = s.ll.y < t.ll.y ? t.ll.y : s.ll.y, r = s.ur.y < t.ur.y ? s.ur.y : t.ur.y;
  return {
    ll: {
      x: e,
      y: i
    },
    ur: {
      x: n,
      y: r
    }
  };
};
let $ = Number.EPSILON;
$ === void 0 && ($ = Math.pow(2, -52));
const Cn = $ * $, Dt = (s, t) => {
  if (-$ < s && s < $ && -$ < t && t < $)
    return 0;
  const e = s - t;
  return e * e < Cn * s * t ? 0 : s < t ? -1 : 1;
};
class Bn {
  constructor() {
    this.reset();
  }
  reset() {
    this.xRounder = new Yt(), this.yRounder = new Yt();
  }
  round(t, e) {
    return {
      x: this.xRounder.round(t),
      y: this.yRounder.round(e)
    };
  }
}
class Yt {
  constructor() {
    this.tree = new kt(), this.round(0);
  }
  // Note: this can rounds input values backwards or forwards.
  //       You might ask, why not restrict this to just rounding
  //       forwards? Wouldn't that allow left endpoints to always
  //       remain left endpoints during splitting (never change to
  //       right). No - it wouldn't, because we snap intersections
  //       to endpoints (to establish independence from the segment
  //       angle for t-intersections).
  round(t) {
    const e = this.tree.add(t), n = this.tree.prev(e);
    if (n !== null && Dt(e.key, n.key) === 0)
      return this.tree.remove(t), n.key;
    const i = this.tree.next(e);
    return i !== null && Dt(e.key, i.key) === 0 ? (this.tree.remove(t), i.key) : t;
  }
}
const K = new Bn(), nt = (s, t) => s.x * t.y - s.y * t.x, ae = (s, t) => s.x * t.x + s.y * t.y, Ut = (s, t, e) => {
  const n = Tn(s.x, s.y, t.x, t.y, e.x, e.y);
  return n > 0 ? -1 : n < 0 ? 1 : 0;
}, rt = (s) => Math.sqrt(ae(s, s)), zn = (s, t, e) => {
  const n = {
    x: t.x - s.x,
    y: t.y - s.y
  }, i = {
    x: e.x - s.x,
    y: e.y - s.y
  };
  return nt(i, n) / rt(i) / rt(n);
}, $n = (s, t, e) => {
  const n = {
    x: t.x - s.x,
    y: t.y - s.y
  }, i = {
    x: e.x - s.x,
    y: e.y - s.y
  };
  return ae(i, n) / rt(i) / rt(n);
}, Ht = (s, t, e) => t.y === 0 ? null : {
  x: s.x + t.x / t.y * (e - s.y),
  y: e
}, qt = (s, t, e) => t.x === 0 ? null : {
  x: e,
  y: s.y + t.y / t.x * (e - s.x)
}, jn = (s, t, e, n) => {
  if (t.x === 0) return qt(e, n, s.x);
  if (n.x === 0) return qt(s, t, e.x);
  if (t.y === 0) return Ht(e, n, s.y);
  if (n.y === 0) return Ht(s, t, e.y);
  const i = nt(t, n);
  if (i == 0) return null;
  const r = {
    x: e.x - s.x,
    y: e.y - s.y
  }, o = nt(r, t) / i, l = nt(r, n) / i, h = s.x + l * t.x, f = e.x + o * n.x, d = s.y + l * t.y, a = e.y + o * n.y, c = (h + f) / 2, u = (d + a) / 2;
  return {
    x: c,
    y: u
  };
};
class N {
  // for ordering sweep events in the sweep event queue
  static compare(t, e) {
    const n = N.comparePoints(t.point, e.point);
    return n !== 0 ? n : (t.point !== e.point && t.link(e), t.isLeft !== e.isLeft ? t.isLeft ? 1 : -1 : j.compare(t.segment, e.segment));
  }
  // for ordering points in sweep line order
  static comparePoints(t, e) {
    return t.x < e.x ? -1 : t.x > e.x ? 1 : t.y < e.y ? -1 : t.y > e.y ? 1 : 0;
  }
  // Warning: 'point' input will be modified and re-used (for performance)
  constructor(t, e) {
    t.events === void 0 ? t.events = [this] : t.events.push(this), this.point = t, this.isLeft = e;
  }
  link(t) {
    if (t.point === this.point)
      throw new Error("Tried to link already linked events");
    const e = t.point.events;
    for (let n = 0, i = e.length; n < i; n++) {
      const r = e[n];
      this.point.events.push(r), r.point = this.point;
    }
    this.checkForConsuming();
  }
  /* Do a pass over our linked events and check to see if any pair
   * of segments match, and should be consumed. */
  checkForConsuming() {
    const t = this.point.events.length;
    for (let e = 0; e < t; e++) {
      const n = this.point.events[e];
      if (n.segment.consumedBy === void 0)
        for (let i = e + 1; i < t; i++) {
          const r = this.point.events[i];
          r.consumedBy === void 0 && n.otherSE.point.events === r.otherSE.point.events && n.segment.consume(r.segment);
        }
    }
  }
  getAvailableLinkedEvents() {
    const t = [];
    for (let e = 0, n = this.point.events.length; e < n; e++) {
      const i = this.point.events[e];
      i !== this && !i.segment.ringOut && i.segment.isInResult() && t.push(i);
    }
    return t;
  }
  /**
   * Returns a comparator function for sorting linked events that will
   * favor the event that will give us the smallest left-side angle.
   * All ring construction starts as low as possible heading to the right,
   * so by always turning left as sharp as possible we'll get polygons
   * without uncessary loops & holes.
   *
   * The comparator function has a compute cache such that it avoids
   * re-computing already-computed values.
   */
  getLeftmostComparator(t) {
    const e = /* @__PURE__ */ new Map(), n = (i) => {
      const r = i.otherSE;
      e.set(i, {
        sine: zn(this.point, t.point, r.point),
        cosine: $n(this.point, t.point, r.point)
      });
    };
    return (i, r) => {
      e.has(i) || n(i), e.has(r) || n(r);
      const {
        sine: o,
        cosine: l
      } = e.get(i), {
        sine: h,
        cosine: f
      } = e.get(r);
      return o >= 0 && h >= 0 ? l < f ? 1 : l > f ? -1 : 0 : o < 0 && h < 0 ? l < f ? -1 : l > f ? 1 : 0 : h < o ? -1 : h > o ? 1 : 0;
    };
  }
}
let Fn = 0;
class j {
  /* This compare() function is for ordering segments in the sweep
   * line tree, and does so according to the following criteria:
   *
   * Consider the vertical line that lies an infinestimal step to the
   * right of the right-more of the two left endpoints of the input
   * segments. Imagine slowly moving a point up from negative infinity
   * in the increasing y direction. Which of the two segments will that
   * point intersect first? That segment comes 'before' the other one.
   *
   * If neither segment would be intersected by such a line, (if one
   * or more of the segments are vertical) then the line to be considered
   * is directly on the right-more of the two left inputs.
   */
  static compare(t, e) {
    const n = t.leftSE.point.x, i = e.leftSE.point.x, r = t.rightSE.point.x, o = e.rightSE.point.x;
    if (o < n) return 1;
    if (r < i) return -1;
    const l = t.leftSE.point.y, h = e.leftSE.point.y, f = t.rightSE.point.y, d = e.rightSE.point.y;
    if (n < i) {
      if (h < l && h < f) return 1;
      if (h > l && h > f) return -1;
      const a = t.comparePoint(e.leftSE.point);
      if (a < 0) return 1;
      if (a > 0) return -1;
      const c = e.comparePoint(t.rightSE.point);
      return c !== 0 ? c : -1;
    }
    if (n > i) {
      if (l < h && l < d) return -1;
      if (l > h && l > d) return 1;
      const a = e.comparePoint(t.leftSE.point);
      if (a !== 0) return a;
      const c = t.comparePoint(e.rightSE.point);
      return c < 0 ? 1 : c > 0 ? -1 : 1;
    }
    if (l < h) return -1;
    if (l > h) return 1;
    if (r < o) {
      const a = e.comparePoint(t.rightSE.point);
      if (a !== 0) return a;
    }
    if (r > o) {
      const a = t.comparePoint(e.rightSE.point);
      if (a < 0) return 1;
      if (a > 0) return -1;
    }
    if (r !== o) {
      const a = f - l, c = r - n, u = d - h, y = o - i;
      if (a > c && u < y) return 1;
      if (a < c && u > y) return -1;
    }
    return r > o ? 1 : r < o || f < d ? -1 : f > d ? 1 : t.id < e.id ? -1 : t.id > e.id ? 1 : 0;
  }
  /* Warning: a reference to ringWindings input will be stored,
   *  and possibly will be later modified */
  constructor(t, e, n, i) {
    this.id = ++Fn, this.leftSE = t, t.segment = this, t.otherSE = e, this.rightSE = e, e.segment = this, e.otherSE = t, this.rings = n, this.windings = i;
  }
  static fromRing(t, e, n) {
    let i, r, o;
    const l = N.comparePoints(t, e);
    if (l < 0)
      i = t, r = e, o = 1;
    else if (l > 0)
      i = e, r = t, o = -1;
    else throw new Error(`Tried to create degenerate segment at [${t.x}, ${t.y}]`);
    const h = new N(i, !0), f = new N(r, !1);
    return new j(h, f, [n], [o]);
  }
  /* When a segment is split, the rightSE is replaced with a new sweep event */
  replaceRightSE(t) {
    this.rightSE = t, this.rightSE.segment = this, this.rightSE.otherSE = this.leftSE, this.leftSE.otherSE = this.rightSE;
  }
  bbox() {
    const t = this.leftSE.point.y, e = this.rightSE.point.y;
    return {
      ll: {
        x: this.leftSE.point.x,
        y: t < e ? t : e
      },
      ur: {
        x: this.rightSE.point.x,
        y: t > e ? t : e
      }
    };
  }
  /* A vector from the left point to the right */
  vector() {
    return {
      x: this.rightSE.point.x - this.leftSE.point.x,
      y: this.rightSE.point.y - this.leftSE.point.y
    };
  }
  isAnEndpoint(t) {
    return t.x === this.leftSE.point.x && t.y === this.leftSE.point.y || t.x === this.rightSE.point.x && t.y === this.rightSE.point.y;
  }
  /* Compare this segment with a point.
   *
   * A point P is considered to be colinear to a segment if there
   * exists a distance D such that if we travel along the segment
   * from one * endpoint towards the other a distance D, we find
   * ourselves at point P.
   *
   * Return value indicates:
   *
   *   1: point lies above the segment (to the left of vertical)
   *   0: point is colinear to segment
   *  -1: point lies below the segment (to the right of vertical)
   */
  comparePoint(t) {
    if (this.isAnEndpoint(t)) return 0;
    const e = this.leftSE.point, n = this.rightSE.point, i = this.vector();
    if (e.x === n.x)
      return t.x === e.x ? 0 : t.x < e.x ? 1 : -1;
    const r = (t.y - e.y) / i.y, o = e.x + r * i.x;
    if (t.x === o) return 0;
    const l = (t.x - e.x) / i.x, h = e.y + l * i.y;
    return t.y === h ? 0 : t.y < h ? -1 : 1;
  }
  /**
   * Given another segment, returns the first non-trivial intersection
   * between the two segments (in terms of sweep line ordering), if it exists.
   *
   * A 'non-trivial' intersection is one that will cause one or both of the
   * segments to be split(). As such, 'trivial' vs. 'non-trivial' intersection:
   *
   *   * endpoint of segA with endpoint of segB --> trivial
   *   * endpoint of segA with point along segB --> non-trivial
   *   * endpoint of segB with point along segA --> non-trivial
   *   * point along segA with point along segB --> non-trivial
   *
   * If no non-trivial intersection exists, return null
   * Else, return null.
   */
  getIntersection(t) {
    const e = this.bbox(), n = t.bbox(), i = _t(e, n);
    if (i === null) return null;
    const r = this.leftSE.point, o = this.rightSE.point, l = t.leftSE.point, h = t.rightSE.point, f = U(e, l) && this.comparePoint(l) === 0, d = U(n, r) && t.comparePoint(r) === 0, a = U(e, h) && this.comparePoint(h) === 0, c = U(n, o) && t.comparePoint(o) === 0;
    if (d && f)
      return c && !a ? o : !c && a ? h : null;
    if (d)
      return a && r.x === h.x && r.y === h.y ? null : r;
    if (f)
      return c && o.x === l.x && o.y === l.y ? null : l;
    if (c && a) return null;
    if (c) return o;
    if (a) return h;
    const u = jn(r, this.vector(), l, t.vector());
    return u === null || !U(i, u) ? null : K.round(u.x, u.y);
  }
  /**
   * Split the given segment into multiple segments on the given points.
   *  * Each existing segment will retain its leftSE and a new rightSE will be
   *    generated for it.
   *  * A new segment will be generated which will adopt the original segment's
   *    rightSE, and a new leftSE will be generated for it.
   *  * If there are more than two points given to split on, new segments
   *    in the middle will be generated with new leftSE and rightSE's.
   *  * An array of the newly generated SweepEvents will be returned.
   *
   * Warning: input array of points is modified
   */
  split(t) {
    const e = [], n = t.events !== void 0, i = new N(t, !0), r = new N(t, !1), o = this.rightSE;
    this.replaceRightSE(r), e.push(r), e.push(i);
    const l = new j(i, o, this.rings.slice(), this.windings.slice());
    return N.comparePoints(l.leftSE.point, l.rightSE.point) > 0 && l.swapEvents(), N.comparePoints(this.leftSE.point, this.rightSE.point) > 0 && this.swapEvents(), n && (i.checkForConsuming(), r.checkForConsuming()), e;
  }
  /* Swap which event is left and right */
  swapEvents() {
    const t = this.rightSE;
    this.rightSE = this.leftSE, this.leftSE = t, this.leftSE.isLeft = !0, this.rightSE.isLeft = !1;
    for (let e = 0, n = this.windings.length; e < n; e++)
      this.windings[e] *= -1;
  }
  /* Consume another segment. We take their rings under our wing
   * and mark them as consumed. Use for perfectly overlapping segments */
  consume(t) {
    let e = this, n = t;
    for (; e.consumedBy; ) e = e.consumedBy;
    for (; n.consumedBy; ) n = n.consumedBy;
    const i = j.compare(e, n);
    if (i !== 0) {
      if (i > 0) {
        const r = e;
        e = n, n = r;
      }
      if (e.prev === n) {
        const r = e;
        e = n, n = r;
      }
      for (let r = 0, o = n.rings.length; r < o; r++) {
        const l = n.rings[r], h = n.windings[r], f = e.rings.indexOf(l);
        f === -1 ? (e.rings.push(l), e.windings.push(h)) : e.windings[f] += h;
      }
      n.rings = null, n.windings = null, n.consumedBy = e, n.leftSE.consumedBy = e.leftSE, n.rightSE.consumedBy = e.rightSE;
    }
  }
  /* The first segment previous segment chain that is in the result */
  prevInResult() {
    return this._prevInResult !== void 0 ? this._prevInResult : (this.prev ? this.prev.isInResult() ? this._prevInResult = this.prev : this._prevInResult = this.prev.prevInResult() : this._prevInResult = null, this._prevInResult);
  }
  beforeState() {
    if (this._beforeState !== void 0) return this._beforeState;
    if (!this.prev) this._beforeState = {
      rings: [],
      windings: [],
      multiPolys: []
    };
    else {
      const t = this.prev.consumedBy || this.prev;
      this._beforeState = t.afterState();
    }
    return this._beforeState;
  }
  afterState() {
    if (this._afterState !== void 0) return this._afterState;
    const t = this.beforeState();
    this._afterState = {
      rings: t.rings.slice(0),
      windings: t.windings.slice(0),
      multiPolys: []
    };
    const e = this._afterState.rings, n = this._afterState.windings, i = this._afterState.multiPolys;
    for (let l = 0, h = this.rings.length; l < h; l++) {
      const f = this.rings[l], d = this.windings[l], a = e.indexOf(f);
      a === -1 ? (e.push(f), n.push(d)) : n[a] += d;
    }
    const r = [], o = [];
    for (let l = 0, h = e.length; l < h; l++) {
      if (n[l] === 0) continue;
      const f = e[l], d = f.poly;
      if (o.indexOf(d) === -1)
        if (f.isExterior) r.push(d);
        else {
          o.indexOf(d) === -1 && o.push(d);
          const a = r.indexOf(f.poly);
          a !== -1 && r.splice(a, 1);
        }
    }
    for (let l = 0, h = r.length; l < h; l++) {
      const f = r[l].multiPoly;
      i.indexOf(f) === -1 && i.push(f);
    }
    return this._afterState;
  }
  /* Is this segment part of the final result? */
  isInResult() {
    if (this.consumedBy) return !1;
    if (this._isInResult !== void 0) return this._isInResult;
    const t = this.beforeState().multiPolys, e = this.afterState().multiPolys;
    switch (T.type) {
      case "union": {
        const n = t.length === 0, i = e.length === 0;
        this._isInResult = n !== i;
        break;
      }
      case "intersection": {
        let n, i;
        t.length < e.length ? (n = t.length, i = e.length) : (n = e.length, i = t.length), this._isInResult = i === T.numMultiPolys && n < i;
        break;
      }
      case "xor": {
        const n = Math.abs(t.length - e.length);
        this._isInResult = n % 2 === 1;
        break;
      }
      case "difference": {
        const n = (i) => i.length === 1 && i[0].isSubject;
        this._isInResult = n(t) !== n(e);
        break;
      }
      default:
        throw new Error(`Unrecognized operation type found ${T.type}`);
    }
    return this._isInResult;
  }
}
class Xt {
  constructor(t, e, n) {
    if (!Array.isArray(t) || t.length === 0)
      throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
    if (this.poly = e, this.isExterior = n, this.segments = [], typeof t[0][0] != "number" || typeof t[0][1] != "number")
      throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
    const i = K.round(t[0][0], t[0][1]);
    this.bbox = {
      ll: {
        x: i.x,
        y: i.y
      },
      ur: {
        x: i.x,
        y: i.y
      }
    };
    let r = i;
    for (let o = 1, l = t.length; o < l; o++) {
      if (typeof t[o][0] != "number" || typeof t[o][1] != "number")
        throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
      let h = K.round(t[o][0], t[o][1]);
      h.x === r.x && h.y === r.y || (this.segments.push(j.fromRing(r, h, this)), h.x < this.bbox.ll.x && (this.bbox.ll.x = h.x), h.y < this.bbox.ll.y && (this.bbox.ll.y = h.y), h.x > this.bbox.ur.x && (this.bbox.ur.x = h.x), h.y > this.bbox.ur.y && (this.bbox.ur.y = h.y), r = h);
    }
    (i.x !== r.x || i.y !== r.y) && this.segments.push(j.fromRing(r, i, this));
  }
  getSweepEvents() {
    const t = [];
    for (let e = 0, n = this.segments.length; e < n; e++) {
      const i = this.segments[e];
      t.push(i.leftSE), t.push(i.rightSE);
    }
    return t;
  }
}
class Gn {
  constructor(t, e) {
    if (!Array.isArray(t))
      throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
    this.exteriorRing = new Xt(t[0], this, !0), this.bbox = {
      ll: {
        x: this.exteriorRing.bbox.ll.x,
        y: this.exteriorRing.bbox.ll.y
      },
      ur: {
        x: this.exteriorRing.bbox.ur.x,
        y: this.exteriorRing.bbox.ur.y
      }
    }, this.interiorRings = [];
    for (let n = 1, i = t.length; n < i; n++) {
      const r = new Xt(t[n], this, !1);
      r.bbox.ll.x < this.bbox.ll.x && (this.bbox.ll.x = r.bbox.ll.x), r.bbox.ll.y < this.bbox.ll.y && (this.bbox.ll.y = r.bbox.ll.y), r.bbox.ur.x > this.bbox.ur.x && (this.bbox.ur.x = r.bbox.ur.x), r.bbox.ur.y > this.bbox.ur.y && (this.bbox.ur.y = r.bbox.ur.y), this.interiorRings.push(r);
    }
    this.multiPoly = e;
  }
  getSweepEvents() {
    const t = this.exteriorRing.getSweepEvents();
    for (let e = 0, n = this.interiorRings.length; e < n; e++) {
      const i = this.interiorRings[e].getSweepEvents();
      for (let r = 0, o = i.length; r < o; r++)
        t.push(i[r]);
    }
    return t;
  }
}
class Wt {
  constructor(t, e) {
    if (!Array.isArray(t))
      throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
    try {
      typeof t[0][0][0] == "number" && (t = [t]);
    } catch {
    }
    this.polys = [], this.bbox = {
      ll: {
        x: Number.POSITIVE_INFINITY,
        y: Number.POSITIVE_INFINITY
      },
      ur: {
        x: Number.NEGATIVE_INFINITY,
        y: Number.NEGATIVE_INFINITY
      }
    };
    for (let n = 0, i = t.length; n < i; n++) {
      const r = new Gn(t[n], this);
      r.bbox.ll.x < this.bbox.ll.x && (this.bbox.ll.x = r.bbox.ll.x), r.bbox.ll.y < this.bbox.ll.y && (this.bbox.ll.y = r.bbox.ll.y), r.bbox.ur.x > this.bbox.ur.x && (this.bbox.ur.x = r.bbox.ur.x), r.bbox.ur.y > this.bbox.ur.y && (this.bbox.ur.y = r.bbox.ur.y), this.polys.push(r);
    }
    this.isSubject = e;
  }
  getSweepEvents() {
    const t = [];
    for (let e = 0, n = this.polys.length; e < n; e++) {
      const i = this.polys[e].getSweepEvents();
      for (let r = 0, o = i.length; r < o; r++)
        t.push(i[r]);
    }
    return t;
  }
}
class ot {
  /* Given the segments from the sweep line pass, compute & return a series
   * of closed rings from all the segments marked to be part of the result */
  static factory(t) {
    const e = [];
    for (let n = 0, i = t.length; n < i; n++) {
      const r = t[n];
      if (!r.isInResult() || r.ringOut) continue;
      let o = null, l = r.leftSE, h = r.rightSE;
      const f = [l], d = l.point, a = [];
      for (; o = l, l = h, f.push(l), l.point !== d; )
        for (; ; ) {
          const c = l.getAvailableLinkedEvents();
          if (c.length === 0) {
            const g = f[0].point, _ = f[f.length - 1].point;
            throw new Error(`Unable to complete output ring starting at [${g.x}, ${g.y}]. Last matching segment found ends at [${_.x}, ${_.y}].`);
          }
          if (c.length === 1) {
            h = c[0].otherSE;
            break;
          }
          let u = null;
          for (let g = 0, _ = a.length; g < _; g++)
            if (a[g].point === l.point) {
              u = g;
              break;
            }
          if (u !== null) {
            const g = a.splice(u)[0], _ = f.splice(g.index);
            _.unshift(_[0].otherSE), e.push(new ot(_.reverse()));
            continue;
          }
          a.push({
            index: f.length,
            point: l.point
          });
          const y = l.getLeftmostComparator(o);
          h = c.sort(y)[0].otherSE;
          break;
        }
      e.push(new ot(f));
    }
    return e;
  }
  constructor(t) {
    this.events = t;
    for (let e = 0, n = t.length; e < n; e++)
      t[e].segment.ringOut = this;
    this.poly = null;
  }
  getGeom() {
    let t = this.events[0].point;
    const e = [t];
    for (let f = 1, d = this.events.length - 1; f < d; f++) {
      const a = this.events[f].point, c = this.events[f + 1].point;
      Ut(a, t, c) !== 0 && (e.push(a), t = a);
    }
    if (e.length === 1) return null;
    const n = e[0], i = e[1];
    Ut(n, t, i) === 0 && e.shift(), e.push(e[0]);
    const r = this.isExteriorRing() ? 1 : -1, o = this.isExteriorRing() ? 0 : e.length - 1, l = this.isExteriorRing() ? e.length : -1, h = [];
    for (let f = o; f != l; f += r) h.push([e[f].x, e[f].y]);
    return h;
  }
  isExteriorRing() {
    if (this._isExteriorRing === void 0) {
      const t = this.enclosingRing();
      this._isExteriorRing = t ? !t.isExteriorRing() : !0;
    }
    return this._isExteriorRing;
  }
  enclosingRing() {
    return this._enclosingRing === void 0 && (this._enclosingRing = this._calcEnclosingRing()), this._enclosingRing;
  }
  /* Returns the ring that encloses this one, if any */
  _calcEnclosingRing() {
    let t = this.events[0];
    for (let i = 1, r = this.events.length; i < r; i++) {
      const o = this.events[i];
      N.compare(t, o) > 0 && (t = o);
    }
    let e = t.segment.prevInResult(), n = e ? e.prevInResult() : null;
    for (; ; ) {
      if (!e) return null;
      if (!n) return e.ringOut;
      if (n.ringOut !== e.ringOut)
        return n.ringOut.enclosingRing() !== e.ringOut ? e.ringOut : e.ringOut.enclosingRing();
      e = n.prevInResult(), n = e ? e.prevInResult() : null;
    }
  }
}
class Kt {
  constructor(t) {
    this.exteriorRing = t, t.poly = this, this.interiorRings = [];
  }
  addInterior(t) {
    this.interiorRings.push(t), t.poly = this;
  }
  getGeom() {
    const t = [this.exteriorRing.getGeom()];
    if (t[0] === null) return null;
    for (let e = 0, n = this.interiorRings.length; e < n; e++) {
      const i = this.interiorRings[e].getGeom();
      i !== null && t.push(i);
    }
    return t;
  }
}
class Dn {
  constructor(t) {
    this.rings = t, this.polys = this._composePolys(t);
  }
  getGeom() {
    const t = [];
    for (let e = 0, n = this.polys.length; e < n; e++) {
      const i = this.polys[e].getGeom();
      i !== null && t.push(i);
    }
    return t;
  }
  _composePolys(t) {
    const e = [];
    for (let n = 0, i = t.length; n < i; n++) {
      const r = t[n];
      if (!r.poly)
        if (r.isExteriorRing()) e.push(new Kt(r));
        else {
          const o = r.enclosingRing();
          o.poly || e.push(new Kt(o)), o.poly.addInterior(r);
        }
    }
    return e;
  }
}
class Yn {
  constructor(t) {
    let e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : j.compare;
    this.queue = t, this.tree = new kt(e), this.segments = [];
  }
  process(t) {
    const e = t.segment, n = [];
    if (t.consumedBy)
      return t.isLeft ? this.queue.remove(t.otherSE) : this.tree.remove(e), n;
    const i = t.isLeft ? this.tree.add(e) : this.tree.find(e);
    if (!i) throw new Error(`Unable to find segment #${e.id} [${e.leftSE.point.x}, ${e.leftSE.point.y}] -> [${e.rightSE.point.x}, ${e.rightSE.point.y}] in SweepLine tree.`);
    let r = i, o = i, l, h;
    for (; l === void 0; )
      r = this.tree.prev(r), r === null ? l = null : r.key.consumedBy === void 0 && (l = r.key);
    for (; h === void 0; )
      o = this.tree.next(o), o === null ? h = null : o.key.consumedBy === void 0 && (h = o.key);
    if (t.isLeft) {
      let f = null;
      if (l) {
        const a = l.getIntersection(e);
        if (a !== null && (e.isAnEndpoint(a) || (f = a), !l.isAnEndpoint(a))) {
          const c = this._splitSafely(l, a);
          for (let u = 0, y = c.length; u < y; u++)
            n.push(c[u]);
        }
      }
      let d = null;
      if (h) {
        const a = h.getIntersection(e);
        if (a !== null && (e.isAnEndpoint(a) || (d = a), !h.isAnEndpoint(a))) {
          const c = this._splitSafely(h, a);
          for (let u = 0, y = c.length; u < y; u++)
            n.push(c[u]);
        }
      }
      if (f !== null || d !== null) {
        let a = null;
        f === null ? a = d : d === null ? a = f : a = N.comparePoints(f, d) <= 0 ? f : d, this.queue.remove(e.rightSE), n.push(e.rightSE);
        const c = e.split(a);
        for (let u = 0, y = c.length; u < y; u++)
          n.push(c[u]);
      }
      n.length > 0 ? (this.tree.remove(e), n.push(t)) : (this.segments.push(e), e.prev = l);
    } else {
      if (l && h) {
        const f = l.getIntersection(h);
        if (f !== null) {
          if (!l.isAnEndpoint(f)) {
            const d = this._splitSafely(l, f);
            for (let a = 0, c = d.length; a < c; a++)
              n.push(d[a]);
          }
          if (!h.isAnEndpoint(f)) {
            const d = this._splitSafely(h, f);
            for (let a = 0, c = d.length; a < c; a++)
              n.push(d[a]);
          }
        }
      }
      this.tree.remove(e);
    }
    return n;
  }
  /* Safely split a segment that is currently in the datastructures
   * IE - a segment other than the one that is currently being processed. */
  _splitSafely(t, e) {
    this.tree.remove(t);
    const n = t.rightSE;
    this.queue.remove(n);
    const i = t.split(e);
    return i.push(n), t.consumedBy === void 0 && this.tree.add(t), i;
  }
}
const Qt = typeof process < "u" && process.env.POLYGON_CLIPPING_MAX_QUEUE_SIZE || 1e6, Un = typeof process < "u" && process.env.POLYGON_CLIPPING_MAX_SWEEPLINE_SEGMENTS || 1e6;
class Hn {
  run(t, e, n) {
    T.type = t, K.reset();
    const i = [new Wt(e, !0)];
    for (let a = 0, c = n.length; a < c; a++)
      i.push(new Wt(n[a], !1));
    if (T.numMultiPolys = i.length, T.type === "difference") {
      const a = i[0];
      let c = 1;
      for (; c < i.length; )
        _t(i[c].bbox, a.bbox) !== null ? c++ : i.splice(c, 1);
    }
    if (T.type === "intersection")
      for (let a = 0, c = i.length; a < c; a++) {
        const u = i[a];
        for (let y = a + 1, g = i.length; y < g; y++)
          if (_t(u.bbox, i[y].bbox) === null) return [];
      }
    const r = new kt(N.compare);
    for (let a = 0, c = i.length; a < c; a++) {
      const u = i[a].getSweepEvents();
      for (let y = 0, g = u.length; y < g; y++)
        if (r.insert(u[y]), r.size > Qt)
          throw new Error("Infinite loop when putting segment endpoints in a priority queue (queue size too big).");
    }
    const o = new Yn(r);
    let l = r.size, h = r.pop();
    for (; h; ) {
      const a = h.key;
      if (r.size === l) {
        const u = a.segment;
        throw new Error(`Unable to pop() ${a.isLeft ? "left" : "right"} SweepEvent [${a.point.x}, ${a.point.y}] from segment #${u.id} [${u.leftSE.point.x}, ${u.leftSE.point.y}] -> [${u.rightSE.point.x}, ${u.rightSE.point.y}] from queue.`);
      }
      if (r.size > Qt)
        throw new Error("Infinite loop when passing sweep line over endpoints (queue size too big).");
      if (o.segments.length > Un)
        throw new Error("Infinite loop when passing sweep line over endpoints (too many sweep line segments).");
      const c = o.process(a);
      for (let u = 0, y = c.length; u < y; u++) {
        const g = c[u];
        g.consumedBy === void 0 && r.insert(g);
      }
      l = r.size, h = r.pop();
    }
    K.reset();
    const f = ot.factory(o.segments);
    return new Dn(f).getGeom();
  }
}
const T = new Hn(), qn = function(s) {
  for (var t = arguments.length, e = new Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++)
    e[n - 1] = arguments[n];
  return T.run("union", s, e);
}, Xn = function(s) {
  for (var t = arguments.length, e = new Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++)
    e[n - 1] = arguments[n];
  return T.run("intersection", s, e);
}, Wn = function(s) {
  for (var t = arguments.length, e = new Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++)
    e[n - 1] = arguments[n];
  return T.run("xor", s, e);
}, Kn = function(s) {
  for (var t = arguments.length, e = new Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++)
    e[n - 1] = arguments[n];
  return T.run("difference", s, e);
};
var Vt = {
  union: qn,
  intersection: Xn,
  xor: Wn,
  difference: Kn
};
const Jt = 3, Qn = 10, Vn = 1, Jn = '<path d="M3.704 14.467a10 8 0 1 1 3.115 2.375"/><path d="M7 22a5 5 0 0 1-2-3.994"/><circle cx="5" cy="16" r="2"/>', Zn = '<path d="M22 26h8M26 22v8"/>', ti = '<path d="M22 26h8"/>';
function xt(s = "") {
  const t = Jn + s, e = s ? 24 : 16, n = e * 1.5, i = `<svg xmlns="http://www.w3.org/2000/svg" width="${e}" height="${e}" viewBox="0 0 ${n} ${n}" fill="none" stroke-linecap="round" stroke-linejoin="round"><g stroke="white" stroke-width="4">${t}</g><g stroke="black" stroke-width="2">${t}</g></svg>`;
  return `url("data:image/svg+xml,${encodeURIComponent(i)}") 5 15, crosshair`;
}
const ei = xt(), ni = {
  add: xt(Zn),
  subtract: xt(ti)
}, ii = `
	:host {
		position: absolute;
		display: none;
		z-index: 1;
		cursor: ${ei};
		touch-action: none;
		user-select: none;
	}

	:host([hidden]) {
		display: none !important;
	}

	:host([disabled]) {
		pointer-events: none;
	}

	svg {
		position: absolute;
		inset: 0;
		width: 100%;
		height: 100%;
		overflow: visible;
		pointer-events: none;
	}

	polyline,
	polygon {
		display: none;
		fill: none;
		stroke-width: 1px;
	}

	#draft {
		stroke: var(--lasso-tool-color, var(--color-accent, #f97316));
	}

	/* Marching ants: black dashes over a white line. */
	#lasso {
		stroke: white;
	}

	#ants {
		stroke: black;
		stroke-dasharray: 4 4;
		animation: march 0.6s linear infinite;
	}

	:host([static]) #ants {
		animation: none;
	}

	@keyframes march {
		to {
			stroke-dashoffset: -8;
		}
	}
`;
class si extends HTMLElement {
  #t = null;
  /** As drawn, kept intact while browsing images. */
  #e = null;
  /** Resolution of the image lasso was drawn over. */
  #n = null;
  #h;
  #f;
  #c;
  /** Last emitted value, as JSON, to emit only changes. */
  #u = "null";
  /**
   * Element lasso is drawn within, e.g. the canvas: a drawing leaving it
   * is in fact a drag of image to another element.
   */
  area = null;
  /** Neighbors each vertex is averaged with on each side, to smooth the hand's jitter. */
  smoothing = 1;
  #v = ["", ""];
  #i = null;
  /** What lasso being drawn does to the current one, if not replace it. */
  #a = null;
  /** Operation of the shortcut held while pointer is over overlay, if any. */
  #m = null;
  /** Where user pressed, in client pixels, to tell a click from a move. */
  #E = null;
  /** Lasso as it was when user pressed, back if user cancels. */
  #_ = null;
  /** Lasso being drawn, applied to the current one on release. */
  #r = null;
  /** Element outside overlay that pointer is over, while user drags image. */
  #s = null;
  /** Whether drop target accepts displayed image. */
  #x = !1;
  #d = null;
  #M = new ResizeObserver(() => this.#w());
  #I = () => this.#w();
  /** Escape cancels the lasso being drawn, and only that. */
  #R = (t) => {
    t.key === "Escape" && (t.preventDefault(), t.stopPropagation(), this.#N());
  };
  /** Tell what a drag would do, as user presses or releases a shortcut. */
  #b = (t) => {
    if (!this.matches(":hover")) {
      this.#L();
      return;
    }
    t.key === "Alt" && t.preventDefault(), this.#k(t);
  };
  constructor() {
    super();
    const t = this.attachShadow({ mode: "open" }), e = document.createElement("style");
    e.textContent = ii;
    const n = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    n.innerHTML = '<polygon id="lasso"></polygon><polygon id="ants"></polygon><polyline id="draft"></polyline>', this.#h = n.querySelector("#draft"), this.#f = n.querySelector("#lasso"), this.#c = n.querySelector("#ants"), t.append(e, n), this.addEventListener("pointerenter", (i) => this.#T(i)), this.addEventListener("pointerleave", () => this.#L()), this.addEventListener("pointerdown", (i) => this.#C(i)), this.addEventListener("pointermove", (i) => this.#B(i)), this.addEventListener("pointerup", () => this.#z()), this.addEventListener("pointercancel", () => this.#$());
  }
  /**
   * Image to draw the lasso over. Lasso persists when another image is
   * displayed, scaled to its resolution, so user finds it back while
   * browsing images.
   */
  get target() {
    return this.#t;
  }
  set target(t) {
    this.#t !== t && (this.#t && (this.#M.unobserve(this.#t), this.#t.removeEventListener("load", this.#I)), this.#t = t, this.#l(), t && (this.#M.observe(t), t.addEventListener("load", this.#I))), this.#w();
  }
  /**
   * Tooltips shown over the image: while no lasso is drawn, e.g. to tell
   * how to draw one, then once drawn, e.g. to tell how to clear it.
   */
  get tooltips() {
    return this.#v;
  }
  set tooltips(t) {
    this.#v = t, this.#o();
  }
  /**
   * Lasso in pixels of the displayed image, scaled to it.
   * Setting it emits no event.
   */
  get value() {
    return this.#p();
  }
  set value(t) {
    this.#e = t && t.map(([e, n]) => [e, n]), this.#n = H(this.#t) ?? this.#n, this.#u = JSON.stringify(ne(this.#p())), this.#l(), this.#o();
  }
  clear() {
    this.#e = null, this.#l(), this.#o(), this.#S();
  }
  /** Cover image content, letterbox bands excluded. */
  sync() {
    const t = this.#t, e = this.parentElement;
    if (!t?.isConnected || !e || !t.naturalWidth || !t.naturalHeight) {
      this.style.display = "none";
      return;
    }
    const n = t.getBoundingClientRect(), i = e.getBoundingClientRect(), r = Math.min(
      n.width / t.naturalWidth,
      n.height / t.naturalHeight
    ), o = t.naturalWidth * r, l = t.naturalHeight * r;
    if (o <= 0 || l <= 0) {
      this.style.display = "none";
      return;
    }
    const h = n.left - i.left - e.clientLeft + (n.width - o) / 2, f = n.top - i.top - e.clientTop + (n.height - l) / 2;
    this.style.display = "block", this.style.left = `${h}px`, this.style.top = `${f}px`, this.style.width = `${o}px`, this.style.height = `${l}px`;
  }
  /** Follow displayed image, which may be another one or resized. */
  #w() {
    this.#n ??= H(this.#t), this.sync(), this.#o(), this.#S();
  }
  /**
   * Lasso scaled to displayed image, whose resolution may differ from the
   * drawn one, so it surrounds the same region.
   */
  #p() {
    const t = this.#e, e = H(this.#t);
    if (!t || !e || !this.#n) return t;
    const n = e.width / this.#n.width, i = e.height / this.#n.height;
    return t.map(([r, o]) => [r * n, o * i]);
  }
  #P(t) {
    const e = this.#t, n = this.getBoundingClientRect(), i = ie(t.clientX - n.left, 0, n.width), r = ie(t.clientY - n.top, 0, n.height);
    return [
      i / n.width * e.naturalWidth,
      r / n.height * e.naturalHeight
    ];
  }
  #o() {
    const t = this.#t, e = !!H(t), n = e ? this.#p() : null, i = e && this.#i === "draw" && this.#r ? Zt(this.#r, this.#A()) : null;
    this.title = this.#v[n ? 1 : 0];
    for (const [r, o] of [
      [this.#h, i],
      [this.#f, n],
      [this.#c, n]
    ])
      r.style.display = o ? "inline" : "none", o && r.setAttribute("points", this.#O(o, t));
  }
  /** SVG points of vertices, in overlay pixels. */
  #O(t, e) {
    const n = this.clientWidth / e.naturalWidth, i = this.clientHeight / e.naturalHeight;
    return t.map(([r, o]) => `${r * n},${o * i}`).join(" ");
  }
  /** Emit value, if changed. */
  #S() {
    const t = ne(this.#p()), e = JSON.stringify(t);
    e !== this.#u && (this.#u = e, this.dispatchEvent(new CustomEvent("lasso-change", { detail: t })));
  }
  #T(t) {
    window.addEventListener("keydown", this.#b, !0), window.addEventListener("keyup", this.#b, !0), this.#k(t);
  }
  #L() {
    window.removeEventListener("keydown", this.#b, !0), window.removeEventListener("keyup", this.#b, !0), this.#m = null, this.#g();
  }
  #k(t) {
    const e = te(t);
    e !== this.#m && (this.#m = e, this.#g());
  }
  /**
   * A click clears the lasso, and a drag draws a new one, which replaces
   * the current one at once and closes on release, or adds to it with Shift
   * held, or subtracts from it with Alt held. User may as well drag displayed
   * image to another element, e.g. a prompt left of the canvas: leaving the
   * area (canvas) turns the drawing into a drop.
   */
  #C(t) {
    !this.#t || t.button !== 0 || (t.preventDefault(), t.stopPropagation(), this.#l(), this.#e = this.#p(), this.#n = H(this.#t), this.#_ = this.#e, this.#i = "press", this.#a = te(t), this.#E = [t.clientX, t.clientY], this.#r = [this.#P(t)], this.#g(), this.setPointerCapture(t.pointerId), window.addEventListener("keydown", this.#R, !0));
  }
  #B(t) {
    if (this.#k(t), !this.#t || !this.#i) return;
    if (this.#i === "press") {
      const [o, l] = this.#E;
      if (Math.hypot(t.clientX - o, t.clientY - l) <= Qn)
        return;
      this.#i = "draw", this.#a || (this.#e = null);
    }
    if (this.#i === "draw" && this.#F(t) && (this.#i = "drop", this.#e = this.#_, this.#r = null, this.#o()), this.#i === "drop") {
      this.#G(t);
      return;
    }
    const e = this.#P(t), n = this.#r, [i, r] = n[n.length - 1];
    Math.hypot(e[0] - i, e[1] - r) < Vn || (n.push(e), this.#o());
  }
  #z() {
    const t = this.#i;
    t === "press" ? this.#a ? this.#l() : this.clear() : t === "drop" ? (this.#x && (this.#y(this.#s, "drop"), this.#s = null), this.#l()) : t === "draw" && this.#j();
  }
  #$() {
    this.#i && this.#N();
  }
  /** Close lasso as drawn, unless it encloses nothing, and apply it. */
  #j() {
    const t = this.#r && Zt(this.#r, this.#A()), e = this.#a, n = this.#e;
    if (this.#l(), e)
      t && t.length >= Jt && (n ? this.#e = ri(n, t, e) ?? n : this.#e = e === "add" ? t : null);
    else {
      if (!t || t.length < Jt) {
        this.clear();
        return;
      }
      this.#e = t;
    }
    this.#o(), this.#S();
  }
  #A() {
    return Math.max(0, Math.floor(this.smoothing)) || 0;
  }
  /** Back to lasso as it was before user pressed. */
  #N() {
    this.#e = this.#_, this.#l(), this.#o();
  }
  /** Forget ongoing gesture, if any. */
  #l() {
    this.#s && this.#y(this.#s, "dragleave"), window.removeEventListener("keydown", this.#R, !0), this.#i = null, this.#a = null, this.#E = null, this.#_ = null, this.#r = null, this.#s = null, this.#x = !1, this.#d = null, this.#g();
  }
  /** Cursor of ongoing drop, if any, else of what a drag would do. */
  #g() {
    let t = "";
    if (this.#i === "drop")
      t = this.#x ? "copy" : "grabbing";
    else {
      const e = this.#i ? this.#a : this.#m;
      e && (t = ni[e]);
    }
    this.style.cursor = t;
  }
  /** Whether pointer left the area lasso is drawn within. */
  #F(t) {
    const e = (this.area ?? this).getBoundingClientRect();
    return t.clientX < e.left || t.clientX > e.right || t.clientY < e.top || t.clientY > e.bottom;
  }
  /**
   * Drag displayed image over the element pointer is over, outside overlay,
   * as browser would do. Overlay can't let browser drag the image itself:
   * it would take any drag over it, those drawing the lasso included.
   */
  #G(t) {
    const e = document.elementFromPoint(t.clientX, t.clientY), n = e === this ? null : e;
    n !== this.#s && (n && this.#y(n, "dragenter"), this.#s && this.#y(this.#s, "dragleave"), this.#s = n), this.#x = !!n && !this.#y(n, "dragover"), this.#g();
  }
  /** Returns false if canceled. */
  #y(t, e) {
    return this.#d || (this.#d = new DataTransfer(), this.#d.setData("text/uri-list", this.#t.currentSrc)), t.dispatchEvent(
      new DragEvent(e, {
        bubbles: !0,
        cancelable: !0,
        composed: !0,
        dataTransfer: this.#d
      })
    );
  }
}
function Zt(s, t) {
  const e = s.length;
  return t === 0 ? s : s.map((n, i) => {
    const r = Math.min(t, i, e - 1 - i);
    let [o, l] = [0, 0];
    for (let f = i - r; f <= i + r; f++)
      o += s[f][0], l += s[f][1];
    const h = 2 * r + 1;
    return [o / h, l / h];
  });
}
function te(s) {
  return s.shiftKey ? "add" : s.altKey ? "subtract" : null;
}
function ri(s, t, e) {
  let n;
  try {
    n = e === "add" ? Vt.union([s], [t]) : Vt.difference([s], [t]);
  } catch (o) {
    return console.warn("Lasso tool couldn't combine lassos:", o), null;
  }
  const i = n.map((o) => o[0]);
  return i.length ? i.reduce((o, l) => ee(l) > ee(o) ? l : o).slice(0, -1).map(([o, l]) => [o, l]) : null;
}
function ee(s) {
  let t = 0;
  for (let e = 0; e < s.length; e++) {
    const [n, i] = s[e], [r, o] = s[(e + 1) % s.length];
    t += n * o - r * i;
  }
  return Math.abs(t) / 2;
}
function H(s) {
  return s?.naturalWidth && s.naturalHeight ? { width: s.naturalWidth, height: s.naturalHeight } : null;
}
function ne(s) {
  return s && s.map(([t, e]) => [Math.round(t), Math.round(e)]);
}
function ie(s, t, e) {
  return Math.max(t, Math.min(e, s));
}
const bt = "lasso-tool-overlay";
customElements.get(bt) || customElements.define(bt, si);
var oi = /* @__PURE__ */ wt("<div><!></div>");
function hi(s, t) {
  je(t, !0);
  const e = /* @__PURE__ */ on(t, ["$$slots", "$$events", "$$legacy"]), n = new _n(e), i = document.createElement(bt);
  let r, o = n.props.value ?? null;
  i.value = o;
  let l = q(null), h = q(!1), f = null;
  function d(p, x) {
    return JSON.stringify(p ?? null) === JSON.stringify(x ?? null);
  }
  function a(p, x) {
    !p && x ? n.dispatch("drawn") : p && !x && n.dispatch("cleared");
  }
  function c(p) {
    if (M(l)) return;
    X(l, p, !0), p.stage.append(i), p.add_tool(n.shared.id, r), i.area = p.area, i.target = p.image;
    const x = () => {
      X(h, p.tool === n.shared.id);
    };
    p.addEventListener("tool-change", x), x();
  }
  function u() {
    M(l) && (M(l).tool = M(h) ? null : n.shared.id);
  }
  function y(p) {
    return p instanceof HTMLElement && (p.isContentEditable || ["INPUT", "TEXTAREA", "SELECT"].includes(p.tagName));
  }
  function g(p) {
    !M(l) || M(h) || n.shared.visible === !1 || n.shared.interactive === !1 || p.key.toLowerCase() !== "l" || p.defaultPrevented || p.altKey || p.ctrlKey || p.metaKey || y(p.target) && !M(l).area.matches(":hover") || (p.preventDefault(), M(l).tool = n.shared.id);
  }
  he(() => {
    r.parentElement && (r.parentElement.hidden = !0), i.addEventListener("lasso-change", (x) => {
      const b = x.detail;
      a(o, b), o = b, n.props.value = b, n.dispatch("input"), n.dispatch("change");
    });
    const p = n.props.canvas_id;
    p !== null && (f = bn(p, c));
  }), ln(() => {
    f?.(), i.target = null, i.remove();
  }), D(() => {
    const p = n.props.value ?? null;
    d(p, o) || (a(o, p), o = p, i.value = p, n.dispatch("change"));
  }), D(() => {
    i.toggleAttribute("disabled", !M(h) || n.shared.interactive === !1), i.toggleAttribute("hidden", n.shared.visible === !1), i.toggleAttribute("static", n.props.marching_ants === !1), i.smoothing = n.props.smoothing ?? 1, i.tooltips = [
      n.props.draw_tooltip ?? "",
      n.props.clear_tooltip ?? ""
    ];
  });
  var _ = oi();
  ze("keydown", Fe, g);
  var m = Z(_);
  {
    let p = dt(() => (M(h) ? n.props.disable_tooltip : n.props.enable_tooltip) ?? ""), x = dt(() => n.shared.interactive === !1);
    cn(m, {
      get Icon() {
        return En;
      },
      get label() {
        return M(p);
      },
      get disabled() {
        return M(x);
      },
      onclick: u
    });
  }
  en(_, (p) => r = p, () => r), ut(() => et(_, "hidden", !M(l) || n.shared.visible === !1)), W(s, _), $e();
}
export {
  hi as default
};
