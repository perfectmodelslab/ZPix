import { i as ue, g as ie, o as de, a as it, b as pe, T as ge, c as ye, d as me, e as ut, f as It, r as _e, h as lt, p as xe, j as Rt, m as be, s as ve, k as Et, E as wt, L as Ee, N as we, l as Se, n as ke, q as Me, u as Q, t as Ie, S as Re, v as Pe, w as Le, x as J, y as Ae, z as D, A as se, B as dt, C as M, D as Z, F as Pt, G as pt, H as Ne, I as Oe, J as Te, K as Ce, M as q, O as Lt, P as X, Q as Be, R as ze, U as $e, $ as je } from "./render-D7UyhFse.js";
function re(r) {
  throw new Error("https://svelte.dev/e/lifecycle_outside_component");
}
const Fe = [];
function Ge(r, t = !1, e = !1) {
  return tt(r, /* @__PURE__ */ new Map(), "", Fe, null, e);
}
function tt(r, t, e, n, i = null, s = !1) {
  if (typeof r == "object" && r !== null) {
    var l = t.get(r);
    if (l !== void 0) return l;
    if (r instanceof Map) return (
      /** @type {Snapshot<T>} */
      new Map(r)
    );
    if (r instanceof Set) return (
      /** @type {Snapshot<T>} */
      new Set(r)
    );
    if (ue(r)) {
      var o = (
        /** @type {Snapshot<any>} */
        Array(r.length)
      );
      t.set(r, o), i !== null && t.set(i, o);
      for (var h = 0; h < r.length; h += 1) {
        var f = r[h];
        h in r && (o[h] = tt(f, t, e, n, null, s));
      }
      return o;
    }
    if (ie(r) === de) {
      o = {}, t.set(r, o), i !== null && t.set(i, o);
      for (var d in r)
        o[d] = tt(
          // @ts-expect-error
          r[d],
          t,
          e,
          n,
          null,
          s
        );
      return o;
    }
    if (r instanceof Date)
      return (
        /** @type {Snapshot<T>} */
        structuredClone(r)
      );
    if (typeof /** @type {T & { toJSON?: any } } */
    r.toJSON == "function" && !s)
      return tt(
        /** @type {T & { toJSON(): any } } */
        r.toJSON(),
        t,
        e,
        n,
        // Associate the instance with the toJSON clone
        r
      );
  }
  if (r instanceof EventTarget)
    return (
      /** @type {Snapshot<T>} */
      r
    );
  try {
    return (
      /** @type {Snapshot<T>} */
      structuredClone(r)
    );
  } catch {
    return (
      /** @type {Snapshot<T>} */
      r
    );
  }
}
function oe(r) {
  var t = document.createElement("template");
  return t.innerHTML = r.replaceAll("<!>", "<!---->"), t.content;
}
function st(r, t) {
  var e = (
    /** @type {Effect} */
    me
  );
  e.nodes === null && (e.nodes = { start: r, end: t, a: null, t: null });
}
// @__NO_SIDE_EFFECTS__
function St(r, t) {
  var e = (t & ge) !== 0, n = (t & ye) !== 0, i, s = !r.startsWith("<!>");
  return () => {
    i === void 0 && (i = oe(s ? r : "<!>" + r), e || (i = /** @type {TemplateNode} */
    it(i)));
    var l = (
      /** @type {TemplateNode} */
      n || pe ? document.importNode(i, !0) : i.cloneNode(!0)
    );
    if (e) {
      var o = (
        /** @type {TemplateNode} */
        it(l)
      ), h = (
        /** @type {TemplateNode} */
        l.lastChild
      );
      st(o, h);
    } else
      st(l, l);
    return l;
  };
}
// @__NO_SIDE_EFFECTS__
function De(r, t, e = "svg") {
  var n = !r.startsWith("<!>"), i = `<${e}>${n ? r : "<!>" + r}</${e}>`, s;
  return () => {
    if (!s) {
      var l = (
        /** @type {DocumentFragment} */
        oe(i)
      ), o = (
        /** @type {Element} */
        it(l)
      );
      s = /** @type {Element} */
      it(o);
    }
    var h = (
      /** @type {TemplateNode} */
      s.cloneNode(!0)
    );
    return st(h, h), h;
  };
}
// @__NO_SIDE_EFFECTS__
function Ye(r, t) {
  return /* @__PURE__ */ De(r, t, "svg");
}
function Ue() {
  var r = document.createDocumentFragment(), t = document.createComment(""), e = ut();
  return r.append(t, e), st(t, e), r;
}
function W(r, t) {
  r !== null && r.before(
    /** @type {Node} */
    t
  );
}
class kt {
  /** @type {TemplateNode} */
  anchor;
  /** @type {Map<Batch, Key>} */
  #t = /* @__PURE__ */ new Map();
  /**
   * Map of keys to effects that are currently rendered in the DOM.
   * These effects are visible and actively part of the document tree.
   * Example:
   * ```
   * {#if condition}
   * 	foo
   * {:else}
   * 	bar
   * {/if}
   * ```
   * Can result in the entries `true->Effect` and `false->Effect`
   * @type {Map<Key, Effect>}
   */
  #e = /* @__PURE__ */ new Map();
  /**
   * Similar to #onscreen with respect to the keys, but contains branches that are not yet
   * in the DOM, because their insertion is deferred.
   * @type {Map<Key, Branch>}
   */
  #n = /* @__PURE__ */ new Map();
  /**
   * Keys of effects that are currently outroing
   * @type {Set<Key>}
   */
  #r = /* @__PURE__ */ new Set();
  /**
   * Whether to pause (i.e. outro) on change, or destroy immediately.
   * This is necessary for `<svelte:element>`
   */
  #f = !0;
  /**
   * @param {TemplateNode} anchor
   * @param {boolean} transition
   */
  constructor(t, e = !0) {
    this.anchor = t, this.#f = e;
  }
  #c = () => {
    var t = (
      /** @type {Batch} */
      It
    );
    if (this.#t.has(t)) {
      var e = (
        /** @type {Key} */
        this.#t.get(t)
      ), n = this.#e.get(e);
      if (n)
        _e(n), this.#r.delete(e);
      else {
        var i = this.#n.get(e);
        i && (this.#e.set(e, i.effect), this.#n.delete(e), i.fragment.lastChild.remove(), this.anchor.before(i.fragment), n = i.effect);
      }
      for (const [s, l] of this.#t) {
        if (this.#t.delete(s), s === t)
          break;
        const o = this.#n.get(l);
        o && (lt(o.effect), this.#n.delete(l));
      }
      for (const [s, l] of this.#e) {
        if (s === e || this.#r.has(s)) continue;
        const o = () => {
          if (Array.from(this.#t.values()).includes(s)) {
            var f = document.createDocumentFragment();
            be(l, f), f.append(ut()), this.#n.set(s, { effect: l, fragment: f });
          } else
            lt(l);
          this.#r.delete(s), this.#e.delete(s);
        };
        this.#f || !n ? (this.#r.add(s), xe(l, o, !1)) : o();
      }
    }
  };
  /**
   * @param {Batch} batch
   */
  #u = (t) => {
    this.#t.delete(t);
    const e = Array.from(this.#t.values());
    for (const [n, i] of this.#n)
      e.includes(n) || (lt(i.effect), this.#n.delete(n));
  };
  /**
   *
   * @param {any} key
   * @param {null | ((target: TemplateNode) => void)} fn
   */
  ensure(t, e) {
    var n = (
      /** @type {Batch} */
      It
    ), i = ve();
    if (e && !this.#e.has(t) && !this.#n.has(t))
      if (i) {
        var s = document.createDocumentFragment(), l = ut();
        s.append(l), this.#n.set(t, {
          effect: Rt(() => e(l)),
          fragment: s
        });
      } else
        this.#e.set(
          t,
          Rt(() => e(this.anchor))
        );
    if (this.#t.set(n, t), i) {
      for (const [o, h] of this.#e)
        o === t ? n.skipped_effects.delete(h) : n.skipped_effects.add(h);
      for (const [o, h] of this.#n)
        o === t ? n.skipped_effects.delete(h.effect) : n.skipped_effects.add(h.effect);
      n.oncommit(this.#c), n.ondiscard(this.#u);
    } else
      this.#c();
  }
}
function At(r, t, e = !1) {
  var n = new kt(r), i = e ? wt : 0;
  function s(l, o) {
    n.ensure(l, o);
  }
  Et(() => {
    var l = !1;
    t((o, h = !0) => {
      l = !0, s(h, o);
    }), l || s(!1, null);
  }, i);
}
function He(r, t, ...e) {
  var n = new kt(r);
  Et(() => {
    const i = t() ?? null;
    n.ensure(i, i && ((s) => i(s, ...e)));
  }, wt);
}
function qe(r, t, e) {
  var n = new kt(r);
  Et(() => {
    var i = t() ?? null;
    n.ensure(i, i && ((s) => e(s, i)));
  }, wt);
}
const Nt = [...` 	
\r\f \v\uFEFF`];
function Xe(r, t, e) {
  var n = r == null ? "" : "" + r;
  if (e) {
    for (var i in e)
      if (e[i])
        n = n ? n + " " + i : i;
      else if (n.length)
        for (var s = i.length, l = 0; (l = n.indexOf(i, l)) >= 0; ) {
          var o = l + s;
          (l === 0 || Nt.includes(n[l - 1])) && (o === n.length || Nt.includes(n[o])) ? n = (l === 0 ? "" : n.substring(0, l)) + n.substring(o + 1) : l = o;
        }
  }
  return n === "" ? null : n;
}
function Ot(r, t = !1) {
  var e = t ? " !important;" : ";", n = "";
  for (var i in r) {
    var s = r[i];
    s != null && s !== "" && (n += " " + i + ": " + s + e);
  }
  return n;
}
function We(r, t) {
  if (t) {
    var e = "", n, i;
    return Array.isArray(t) ? (n = t[0], i = t[1]) : n = t, n && (e += Ot(n)), i && (e += Ot(i, !0)), e = e.trim(), e === "" ? null : e;
  }
  return String(r);
}
function Tt(r, t, e, n, i, s) {
  var l = r.__className;
  if (l !== e || l === void 0) {
    var o = Xe(e, n, s);
    o == null ? r.removeAttribute("class") : r.className = o, r.__className = e;
  } else if (s && i !== s)
    for (var h in s) {
      var f = !!s[h];
      (i == null || f !== !!i[h]) && r.classList.toggle(h, f);
    }
  return s;
}
function ht(r, t = {}, e, n) {
  for (var i in e) {
    var s = e[i];
    t[i] !== s && (e[i] == null ? r.style.removeProperty(i) : r.style.setProperty(i, s, n));
  }
}
function Ke(r, t, e, n) {
  var i = r.__style;
  if (i !== t) {
    var s = We(t, n);
    s == null ? r.removeAttribute("style") : r.style.cssText = s, r.__style = t;
  } else n && (Array.isArray(n) ? (ht(r, e?.[0], n[0]), ht(r, e?.[1], n[1], "important")) : ht(r, e, n));
  return n;
}
const Qe = /* @__PURE__ */ Symbol("is custom element"), Ve = /* @__PURE__ */ Symbol("is html");
function et(r, t, e, n) {
  var i = Je(r);
  i[t] !== (i[t] = e) && (t === "loading" && (r[Ee] = e), e == null ? r.removeAttribute(t) : typeof e != "string" && Ze(r).includes(t) ? r[t] = e : r.setAttribute(t, e));
}
function Je(r) {
  return (
    /** @type {Record<string | symbol, unknown>} **/
    // @ts-expect-error
    r.__attributes ??= {
      [Qe]: r.nodeName.includes("-"),
      [Ve]: r.namespaceURI === we
    }
  );
}
var Ct = /* @__PURE__ */ new Map();
function Ze(r) {
  var t = r.getAttribute("is") || r.nodeName, e = Ct.get(t);
  if (e) return e;
  Ct.set(t, e = []);
  for (var n, i = r, s = Element.prototype; s !== i; ) {
    n = Se(i);
    for (var l in n)
      n[l].set && e.push(l);
    i = ie(i);
  }
  return e;
}
function Bt(r, t) {
  return r === t || r?.[Re] === t;
}
function tn(r = {}, t, e, n) {
  return ke(() => {
    var i, s;
    return Me(() => {
      i = s, s = [], Q(() => {
        r !== e(...s) && (t(r, ...s), i && Bt(e(...i), r) && t(null, ...i));
      });
    }), () => {
      Ie(() => {
        s && Bt(e(...s), r) && t(null, ...s);
      });
    };
  }), r;
}
function en(r, t, e) {
  if (r == null)
    return t(void 0), Pe;
  const n = Q(
    () => r.subscribe(
      t,
      // @ts-expect-error
      e
    )
  );
  return n.unsubscribe ? () => n.unsubscribe() : n;
}
function nn(r) {
  let t;
  return en(r, (e) => t = e)(), t;
}
const sn = {
  get(r, t) {
    if (!r.exclude.includes(t))
      return r.props[t];
  },
  set(r, t) {
    return !1;
  },
  getOwnPropertyDescriptor(r, t) {
    if (!r.exclude.includes(t) && t in r.props)
      return {
        enumerable: !0,
        configurable: !0,
        value: r.props[t]
      };
  },
  has(r, t) {
    return r.exclude.includes(t) ? !1 : t in r.props;
  },
  ownKeys(r) {
    return Reflect.ownKeys(r.props).filter((t) => !r.exclude.includes(t));
  }
};
// @__NO_SIDE_EFFECTS__
function rn(r, t, e) {
  return new Proxy(
    { props: r, exclude: t },
    sn
  );
}
function A(r, t, e, n) {
  var i = (
    /** @type {V} */
    n
  ), s = !0, l = () => (s && (s = !1, i = /** @type {V} */
  n), i), o;
  o = /** @type {V} */
  r[t], o === void 0 && n !== void 0 && (o = l());
  var h;
  return h = () => {
    var f = (
      /** @type {V} */
      r[t]
    );
    return f === void 0 ? l() : (s = !0, f);
  }, h;
}
Le();
function le(r) {
  J === null && re(), Ae && J.l !== null ? ln(J).m.push(r) : D(() => {
    const t = Q(r);
    if (typeof t == "function") return (
      /** @type {() => void} */
      t
    );
  });
}
function on(r) {
  J === null && re(), le(() => () => Q(r));
}
function ln(r) {
  var t = (
    /** @type {ComponentContextLegacy} */
    r.l
  );
  return t.u ??= { a: [], b: [], m: [] };
}
var hn = /* @__PURE__ */ St('<span class="svelte-12hu46v"> </span>'), an = /* @__PURE__ */ St("<button><!> <div><!> <!></div></button>");
function fn(r, t) {
  let e = A(t, "label", 3, ""), n = A(t, "show_label", 3, !1), i = A(t, "pending", 3, !1), s = A(t, "size", 3, "small"), l = A(t, "padded", 3, !0), o = A(t, "highlight", 3, !1), h = A(t, "disabled", 3, !1), f = A(t, "hasPopup", 3, !1), d = A(t, "color", 3, "var(--block-label-text-color)"), a = A(t, "transparent", 3, !1), c = A(t, "background", 3, "var(--block-background-fill)"), u = A(t, "border", 3, "transparent"), y = pt(() => o() ? "var(--color-accent)" : d());
  var g = an();
  let _;
  g.__click = function(...v) {
    t.onclick?.apply(this, v);
  };
  let m;
  var p = Z(g);
  {
    var x = (v) => {
      var S = hn(), R = Z(S);
      dt(() => Ne(R, e())), W(v, S);
    };
    At(p, (v) => {
      n() && v(x);
    });
  }
  var b = Pt(p, 2);
  let E;
  var w = Z(b);
  qe(w, () => t.Icon, (v, S) => {
    S(v, {});
  });
  var L = Pt(w, 2);
  {
    var k = (v) => {
      var S = Ue(), R = Oe(S);
      He(R, () => t.children), W(v, S);
    };
    At(L, (v) => {
      t.children && v(k);
    });
  }
  dt(() => {
    _ = Tt(g, 1, "icon-button svelte-12hu46v", null, _, {
      pending: i(),
      padded: l(),
      highlight: o(),
      transparent: a()
    }), g.disabled = h(), et(g, "aria-label", e()), et(g, "aria-haspopup", f()), et(g, "title", e()), m = Ke(g, "", m, {
      "--border-color": u(),
      color: !h() && M(y) ? M(y) : "var(--block-label-text-color)",
      "--bg-color": h() ? "auto" : c()
    }), E = Tt(b, 1, "svelte-12hu46v", null, E, {
      "x-small": s() === "x-small",
      small: s() === "small",
      large: s() === "large",
      medium: s() === "medium"
    });
  }), W(r, g);
}
se(["click"]);
const cn = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], zt = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
cn.reduce((r, { color: t, primary: e, secondary: n }) => ({
  ...r,
  [t]: {
    primary: zt[t][e],
    secondary: zt[t][n]
  }
}), {});
function un(r) {
  let t;
  const e = Ce((i) => {
    let s = !1;
    const l = r.subscribe((o) => {
      t = o, s && i();
    });
    return s = !0, l;
  });
  function n() {
    return Te() ? (e(), t) : nn(r);
  }
  return "set" in r ? {
    get current() {
      return n();
    },
    set current(i) {
      r.set(i);
    }
  } : {
    get current() {
      return n();
    }
  };
}
const dn = "__i18n__", pn = [
  "label",
  "info",
  "placeholder",
  "description",
  "title",
  "value"
], gn = [
  "elem_id",
  "elem_classes",
  "visible",
  "interactive",
  "server_fns",
  "server",
  "id",
  "target",
  "theme_mode",
  "version",
  "root",
  "autoscroll",
  "max_file_size",
  "formatter",
  "client",
  "load_component",
  "scale",
  "min_width",
  "theme",
  "padding",
  "loading_status",
  "label",
  "show_label",
  "validation_error",
  "show_progress",
  "api_prefix",
  "container",
  "attached_events",
  "register_component",
  "dispatcher"
];
function yn(r) {
  return typeof r == "string" && r.includes(dn);
}
class mn {
  load_component;
  #t = q(Lt({}));
  get shared() {
    return M(this.#t);
  }
  set shared(t) {
    X(this.#t, t, !0);
  }
  #e = q(Lt({}));
  get props() {
    return M(this.#e);
  }
  set props(t) {
    X(this.#e, t, !0);
  }
  #n = q((t) => t);
  get i18n() {
    return M(this.#n);
  }
  set i18n(t) {
    X(this.#n, t, !0);
  }
  i18n_store;
  _i18n_from_store;
  translatable_props = {};
  dispatcher;
  last_update = null;
  shared_props = gn;
  mounted = !1;
  old_value;
  register_component;
  constructor(t, e) {
    for (const n in t.shared_props)
      this.shared[n] = t.shared_props[n];
    for (const n in t.props)
      n !== "i18n_store" && (this.props[n] = t.props[n]);
    if (e)
      for (const n in e)
        this.props[n] === void 0 && (this.props[n] = e[n]);
    this.i18n = this.props.i18n ?? ((n) => n), this.i18n_store = t.props.i18n_store, this._i18n_from_store = this.i18n_store ? un(this.i18n_store) : void 0;
    for (const n of pn)
      this.shared[n] = this._translate_and_store(
        "shared",
        n,
        // @ts-ignore
        t.shared_props[n]
      ), this.props[n] = this._translate_and_store(
        "props",
        n,
        // @ts-ignore
        t.props[n]
      );
    this.load_component = this.shared.load_component, this.register_component = this.shared.register_component || (() => {
    }), this.dispatcher = this.shared.dispatcher || (() => {
    }), this.register_component(
      t.shared_props.id,
      // @ts-ignore
      this.set_data.bind(this),
      this.get_data.bind(this)
    ), D(() => {
      for (const n in t.shared_props)
        this._is_i18n_managed(`shared.${n}`, t.shared_props[n]) || (this.shared[n] = t.shared_props[n]);
      for (const n in t.props)
        n !== "i18n_store" && (this._is_i18n_managed(`props.${n}`, t.props[n]) || (this.props[n] = t.props[n]));
      this.register_component(
        t.shared_props.id,
        // @ts-ignore
        this.set_data.bind(this),
        this.get_data.bind(this)
      ), Q(() => {
        this.shared.id = t.shared_props.id;
      });
    }), D(() => this.i18n_store ? this.i18n_store.subscribe(() => {
      for (const [i, s] of Object.entries(this.translatable_props)) {
        const [l, o] = i.split("."), h = this.i18n(s);
        l === "shared" ? this.shared[o] = h : this.props[o] = h;
      }
    }) : void 0);
  }
  // check if props are translatable
  _is_i18n_managed(t, e) {
    const n = this.translatable_props[t];
    return n ? e === n ? !0 : (delete this.translatable_props[t], !1) : !1;
  }
  _translate_and_store(t, e, n) {
    if (typeof n != "string") return n;
    const i = this.i18n(n);
    return i !== n && (this.translatable_props[`${t}.${e}`] = n), i;
  }
  // Reactive variant of `i18n`. Reading it inside a derived or template
  // subscribes to the live locale store (via Svelte's createSubscriber), so
  // the caller re-runs when the locale changes at runtime. The store is only
  // the reactivity trigger; translation always goes through `this.i18n` so a
  // custom formatter passed via props keeps taking effect.
  live_i18n = (t) => (this._i18n_from_store?.current, this.i18n(t));
  dispatch(t, e) {
    this.dispatcher(this.shared.id, t, e);
  }
  async get_data() {
    return Ge(this.props);
  }
  update(t) {
    this.set_data(t);
  }
  set_data(t) {
    for (const e in t) {
      const n = t[e], i = yn(n) ? this._translate_and_store(this.shared_props.includes(e) ? "shared" : "props", e, n) : n;
      if (this.shared_props.includes(e)) {
        const s = e;
        this.shared[s] = i;
        continue;
      }
      this.props[e] = i;
    }
  }
  watch_for_change() {
    D(() => {
      this.mounted || (this.old_value = this.props.value, this.mounted = !0), this.old_value != this.props.value && (this.old_value = this.props.value, this.dispatch("change"));
    });
  }
}
se(["click"]);
const $t = "canvas-host", _n = "canvas-host-request";
function xn(r, t) {
  const e = (n) => {
    const i = n.detail;
    i.id === r && t(i);
  };
  return window.addEventListener($t, e), window.dispatchEvent(
    new CustomEvent(_n, { detail: { canvas_id: r, resolve: t } })
  ), () => window.removeEventListener($t, e);
}
var bn = /* @__PURE__ */ Ye('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3.704 14.467a10 8 0 1 1 3.115 2.375"></path><path d="M7 22a5 5 0 0 1-2-3.994"></path><circle cx="5" cy="16" r="2"></circle></svg>');
function vn(r) {
  var t = bn();
  W(r, t);
}
class F {
  constructor(t, e) {
    this.next = null, this.key = t, this.data = e, this.left = null, this.right = null;
  }
}
function En(r, t) {
  return r > t ? 1 : r < t ? -1 : 0;
}
function z(r, t, e) {
  const n = new F(null, null);
  let i = n, s = n;
  for (; ; ) {
    const l = e(r, t.key);
    if (l < 0) {
      if (t.left === null) break;
      if (e(r, t.left.key) < 0) {
        const o = t.left;
        if (t.left = o.right, o.right = t, t = o, t.left === null) break;
      }
      s.left = t, s = t, t = t.left;
    } else if (l > 0) {
      if (t.right === null) break;
      if (e(r, t.right.key) > 0) {
        const o = t.right;
        if (t.right = o.left, o.left = t, t = o, t.right === null) break;
      }
      i.right = t, i = t, t = t.right;
    } else break;
  }
  return i.right = t.left, s.left = t.right, t.left = n.right, t.right = n.left, t;
}
function at(r, t, e, n) {
  const i = new F(r, t);
  if (e === null)
    return i.left = i.right = null, i;
  e = z(r, e, n);
  const s = n(r, e.key);
  return s < 0 ? (i.left = e.left, i.right = e, e.left = null) : s >= 0 && (i.right = e.right, i.left = e, e.right = null), i;
}
function jt(r, t, e) {
  let n = null, i = null;
  if (t) {
    t = z(r, t, e);
    const s = e(t.key, r);
    s === 0 ? (n = t.left, i = t.right) : s < 0 ? (i = t.right, t.right = null, n = t) : (n = t.left, t.left = null, i = t);
  }
  return { left: n, right: i };
}
function wn(r, t, e) {
  return t === null ? r : (r === null || (t = z(r.key, t, e), t.left = r), t);
}
function gt(r, t, e, n, i) {
  if (r) {
    n(`${t}${e ? "└── " : "├── "}${i(r)}
`);
    const s = t + (e ? "    " : "│   ");
    r.left && gt(r.left, s, !1, n, i), r.right && gt(r.right, s, !0, n, i);
  }
}
class Mt {
  constructor(t = En) {
    this._root = null, this._size = 0, this._comparator = t;
  }
  /**
   * Inserts a key, allows duplicates
   */
  insert(t, e) {
    return this._size++, this._root = at(t, e, this._root, this._comparator);
  }
  /**
   * Adds a key, if it is not present in the tree
   */
  add(t, e) {
    const n = new F(t, e);
    this._root === null && (n.left = n.right = null, this._size++, this._root = n);
    const i = this._comparator, s = z(t, this._root, i), l = i(t, s.key);
    return l === 0 ? this._root = s : (l < 0 ? (n.left = s.left, n.right = s, s.left = null) : l > 0 && (n.right = s.right, n.left = s, s.right = null), this._size++, this._root = n), this._root;
  }
  /**
   * @param  {Key} key
   * @return {Node|null}
   */
  remove(t) {
    this._root = this._remove(t, this._root, this._comparator);
  }
  /**
   * Deletes i from the tree if it's there
   */
  _remove(t, e, n) {
    let i;
    return e === null ? null : (e = z(t, e, n), n(t, e.key) === 0 ? (e.left === null ? i = e.right : (i = z(t, e.left, n), i.right = e.right), this._size--, i) : e);
  }
  /**
   * Removes and returns the node with smallest key
   */
  pop() {
    let t = this._root;
    if (t) {
      for (; t.left; ) t = t.left;
      return this._root = z(t.key, this._root, this._comparator), this._root = this._remove(t.key, this._root, this._comparator), { key: t.key, data: t.data };
    }
    return null;
  }
  /**
   * Find without splaying
   */
  findStatic(t) {
    let e = this._root;
    const n = this._comparator;
    for (; e; ) {
      const i = n(t, e.key);
      if (i === 0) return e;
      i < 0 ? e = e.left : e = e.right;
    }
    return null;
  }
  find(t) {
    return this._root && (this._root = z(t, this._root, this._comparator), this._comparator(t, this._root.key) !== 0) ? null : this._root;
  }
  contains(t) {
    let e = this._root;
    const n = this._comparator;
    for (; e; ) {
      const i = n(t, e.key);
      if (i === 0) return !0;
      i < 0 ? e = e.left : e = e.right;
    }
    return !1;
  }
  forEach(t, e) {
    let n = this._root;
    const i = [];
    let s = !1;
    for (; !s; )
      n !== null ? (i.push(n), n = n.left) : i.length !== 0 ? (n = i.pop(), t.call(e, n), n = n.right) : s = !0;
    return this;
  }
  /**
   * Walk key range from `low` to `high`. Stops if `fn` returns a value.
   */
  range(t, e, n, i) {
    const s = [], l = this._comparator;
    let o = this._root, h;
    for (; s.length !== 0 || o; )
      if (o)
        s.push(o), o = o.left;
      else {
        if (o = s.pop(), h = l(o.key, e), h > 0)
          break;
        if (l(o.key, t) >= 0 && n.call(i, o))
          return this;
        o = o.right;
      }
    return this;
  }
  /**
   * Returns array of keys
   */
  keys() {
    const t = [];
    return this.forEach(({ key: e }) => {
      t.push(e);
    }), t;
  }
  /**
   * Returns array of all the data in the nodes
   */
  values() {
    const t = [];
    return this.forEach(({ data: e }) => {
      t.push(e);
    }), t;
  }
  min() {
    return this._root ? this.minNode(this._root).key : null;
  }
  max() {
    return this._root ? this.maxNode(this._root).key : null;
  }
  minNode(t = this._root) {
    if (t) for (; t.left; ) t = t.left;
    return t;
  }
  maxNode(t = this._root) {
    if (t) for (; t.right; ) t = t.right;
    return t;
  }
  /**
   * Returns node at given index
   */
  at(t) {
    let e = this._root, n = !1, i = 0;
    const s = [];
    for (; !n; )
      if (e)
        s.push(e), e = e.left;
      else if (s.length > 0) {
        if (e = s.pop(), i === t) return e;
        i++, e = e.right;
      } else n = !0;
    return null;
  }
  next(t) {
    let e = this._root, n = null;
    if (t.right) {
      for (n = t.right; n.left; ) n = n.left;
      return n;
    }
    const i = this._comparator;
    for (; e; ) {
      const s = i(t.key, e.key);
      if (s === 0) break;
      s < 0 ? (n = e, e = e.left) : e = e.right;
    }
    return n;
  }
  prev(t) {
    let e = this._root, n = null;
    if (t.left !== null) {
      for (n = t.left; n.right; ) n = n.right;
      return n;
    }
    const i = this._comparator;
    for (; e; ) {
      const s = i(t.key, e.key);
      if (s === 0) break;
      s < 0 ? e = e.left : (n = e, e = e.right);
    }
    return n;
  }
  clear() {
    return this._root = null, this._size = 0, this;
  }
  toList() {
    return kn(this._root);
  }
  /**
   * Bulk-load items. Both array have to be same size
   */
  load(t, e = [], n = !1) {
    let i = t.length;
    const s = this._comparator;
    if (n && _t(t, e, 0, i - 1, s), this._root === null)
      this._root = yt(t, e, 0, i), this._size = i;
    else {
      const l = Mn(
        this.toList(),
        Sn(t, e),
        s
      );
      i = this._size + i, this._root = mt({ head: l }, 0, i);
    }
    return this;
  }
  isEmpty() {
    return this._root === null;
  }
  get size() {
    return this._size;
  }
  get root() {
    return this._root;
  }
  toString(t = (e) => String(e.key)) {
    const e = [];
    return gt(this._root, "", !0, (n) => e.push(n), t), e.join("");
  }
  update(t, e, n) {
    const i = this._comparator;
    let { left: s, right: l } = jt(t, this._root, i);
    i(t, e) < 0 ? l = at(e, n, l, i) : s = at(e, n, s, i), this._root = wn(s, l, i);
  }
  split(t) {
    return jt(t, this._root, this._comparator);
  }
  *[Symbol.iterator]() {
    let t = this._root;
    const e = [];
    let n = !1;
    for (; !n; )
      t !== null ? (e.push(t), t = t.left) : e.length !== 0 ? (t = e.pop(), yield t, t = t.right) : n = !0;
  }
}
function yt(r, t, e, n) {
  const i = n - e;
  if (i > 0) {
    const s = e + Math.floor(i / 2), l = r[s], o = t[s], h = new F(l, o);
    return h.left = yt(r, t, e, s), h.right = yt(r, t, s + 1, n), h;
  }
  return null;
}
function Sn(r, t) {
  const e = new F(null, null);
  let n = e;
  for (let i = 0; i < r.length; i++)
    n = n.next = new F(r[i], t[i]);
  return n.next = null, e.next;
}
function kn(r) {
  let t = r;
  const e = [];
  let n = !1;
  const i = new F(null, null);
  let s = i;
  for (; !n; )
    t ? (e.push(t), t = t.left) : e.length > 0 ? (t = s = s.next = e.pop(), t = t.right) : n = !0;
  return s.next = null, i.next;
}
function mt(r, t, e) {
  const n = e - t;
  if (n > 0) {
    const i = t + Math.floor(n / 2), s = mt(r, t, i), l = r.head;
    return l.left = s, r.head = r.head.next, l.right = mt(r, i + 1, e), l;
  }
  return null;
}
function Mn(r, t, e) {
  const n = new F(null, null);
  let i = n, s = r, l = t;
  for (; s !== null && l !== null; )
    e(s.key, l.key) < 0 ? (i.next = s, s = s.next) : (i.next = l, l = l.next), i = i.next;
  return s !== null ? i.next = s : l !== null && (i.next = l), n.next;
}
function _t(r, t, e, n, i) {
  if (e >= n) return;
  const s = r[e + n >> 1];
  let l = e - 1, o = n + 1;
  for (; ; ) {
    do
      l++;
    while (i(r[l], s) < 0);
    do
      o--;
    while (i(r[o], s) > 0);
    if (l >= o) break;
    let h = r[l];
    r[l] = r[o], r[o] = h, h = t[l], t[l] = t[o], t[o] = h;
  }
  _t(r, t, e, o, i), _t(r, t, o + 1, n, i);
}
const B = 11102230246251565e-32, I = 134217729, In = (3 + 8 * B) * B;
function ft(r, t, e, n, i) {
  let s, l, o, h, f = t[0], d = n[0], a = 0, c = 0;
  d > f == d > -f ? (s = f, f = t[++a]) : (s = d, d = n[++c]);
  let u = 0;
  if (a < r && c < e)
    for (d > f == d > -f ? (l = f + s, o = s - (l - f), f = t[++a]) : (l = d + s, o = s - (l - d), d = n[++c]), s = l, o !== 0 && (i[u++] = o); a < r && c < e; )
      d > f == d > -f ? (l = s + f, h = l - s, o = s - (l - h) + (f - h), f = t[++a]) : (l = s + d, h = l - s, o = s - (l - h) + (d - h), d = n[++c]), s = l, o !== 0 && (i[u++] = o);
  for (; a < r; )
    l = s + f, h = l - s, o = s - (l - h) + (f - h), f = t[++a], s = l, o !== 0 && (i[u++] = o);
  for (; c < e; )
    l = s + d, h = l - s, o = s - (l - h) + (d - h), d = n[++c], s = l, o !== 0 && (i[u++] = o);
  return (s !== 0 || u === 0) && (i[u++] = s), u;
}
function Rn(r, t) {
  let e = t[0];
  for (let n = 1; n < r; n++) e += t[n];
  return e;
}
function V(r) {
  return new Float64Array(r);
}
const Pn = (3 + 16 * B) * B, Ln = (2 + 12 * B) * B, An = (9 + 64 * B) * B * B, G = V(4), Ft = V(8), Gt = V(12), Dt = V(16), P = V(4);
function Nn(r, t, e, n, i, s, l) {
  let o, h, f, d, a, c, u, y, g, _, m, p, x, b, E, w, L, k;
  const v = r - i, S = e - i, R = t - s, O = n - s;
  b = v * O, c = I * v, u = c - (c - v), y = v - u, c = I * O, g = c - (c - O), _ = O - g, E = y * _ - (b - u * g - y * g - u * _), w = R * S, c = I * R, u = c - (c - R), y = R - u, c = I * S, g = c - (c - S), _ = S - g, L = y * _ - (w - u * g - y * g - u * _), m = E - L, a = E - m, G[0] = E - (m + a) + (a - L), p = b + m, a = p - b, x = b - (p - a) + (m - a), m = x - w, a = x - m, G[1] = x - (m + a) + (a - w), k = p + m, a = k - p, G[2] = p - (k - a) + (m - a), G[3] = k;
  let C = Rn(4, G), Y = Ln * l;
  if (C >= Y || -C >= Y || (a = r - v, o = r - (v + a) + (a - i), a = e - S, f = e - (S + a) + (a - i), a = t - R, h = t - (R + a) + (a - s), a = n - O, d = n - (O + a) + (a - s), o === 0 && h === 0 && f === 0 && d === 0) || (Y = An * l + In * Math.abs(C), C += v * d + O * o - (R * f + S * h), C >= Y || -C >= Y)) return C;
  b = o * O, c = I * o, u = c - (c - o), y = o - u, c = I * O, g = c - (c - O), _ = O - g, E = y * _ - (b - u * g - y * g - u * _), w = h * S, c = I * h, u = c - (c - h), y = h - u, c = I * S, g = c - (c - S), _ = S - g, L = y * _ - (w - u * g - y * g - u * _), m = E - L, a = E - m, P[0] = E - (m + a) + (a - L), p = b + m, a = p - b, x = b - (p - a) + (m - a), m = x - w, a = x - m, P[1] = x - (m + a) + (a - w), k = p + m, a = k - p, P[2] = p - (k - a) + (m - a), P[3] = k;
  const ae = ft(4, G, 4, P, Ft);
  b = v * d, c = I * v, u = c - (c - v), y = v - u, c = I * d, g = c - (c - d), _ = d - g, E = y * _ - (b - u * g - y * g - u * _), w = R * f, c = I * R, u = c - (c - R), y = R - u, c = I * f, g = c - (c - f), _ = f - g, L = y * _ - (w - u * g - y * g - u * _), m = E - L, a = E - m, P[0] = E - (m + a) + (a - L), p = b + m, a = p - b, x = b - (p - a) + (m - a), m = x - w, a = x - m, P[1] = x - (m + a) + (a - w), k = p + m, a = k - p, P[2] = p - (k - a) + (m - a), P[3] = k;
  const fe = ft(ae, Ft, 4, P, Gt);
  b = o * d, c = I * o, u = c - (c - o), y = o - u, c = I * d, g = c - (c - d), _ = d - g, E = y * _ - (b - u * g - y * g - u * _), w = h * f, c = I * h, u = c - (c - h), y = h - u, c = I * f, g = c - (c - f), _ = f - g, L = y * _ - (w - u * g - y * g - u * _), m = E - L, a = E - m, P[0] = E - (m + a) + (a - L), p = b + m, a = p - b, x = b - (p - a) + (m - a), m = x - w, a = x - m, P[1] = x - (m + a) + (a - w), k = p + m, a = k - p, P[2] = p - (k - a) + (m - a), P[3] = k;
  const ce = ft(fe, Gt, 4, P, Dt);
  return Dt[ce - 1];
}
function On(r, t, e, n, i, s) {
  const l = (t - s) * (e - i), o = (r - i) * (n - s), h = l - o, f = Math.abs(l + o);
  return Math.abs(h) >= Pn * f ? h : -Nn(r, t, e, n, i, s, f);
}
const U = (r, t) => r.ll.x <= t.x && t.x <= r.ur.x && r.ll.y <= t.y && t.y <= r.ur.y, xt = (r, t) => {
  if (t.ur.x < r.ll.x || r.ur.x < t.ll.x || t.ur.y < r.ll.y || r.ur.y < t.ll.y) return null;
  const e = r.ll.x < t.ll.x ? t.ll.x : r.ll.x, n = r.ur.x < t.ur.x ? r.ur.x : t.ur.x, i = r.ll.y < t.ll.y ? t.ll.y : r.ll.y, s = r.ur.y < t.ur.y ? r.ur.y : t.ur.y;
  return {
    ll: {
      x: e,
      y: i
    },
    ur: {
      x: n,
      y: s
    }
  };
};
let $ = Number.EPSILON;
$ === void 0 && ($ = Math.pow(2, -52));
const Tn = $ * $, Yt = (r, t) => {
  if (-$ < r && r < $ && -$ < t && t < $)
    return 0;
  const e = r - t;
  return e * e < Tn * r * t ? 0 : r < t ? -1 : 1;
};
class Cn {
  constructor() {
    this.reset();
  }
  reset() {
    this.xRounder = new Ut(), this.yRounder = new Ut();
  }
  round(t, e) {
    return {
      x: this.xRounder.round(t),
      y: this.yRounder.round(e)
    };
  }
}
class Ut {
  constructor() {
    this.tree = new Mt(), this.round(0);
  }
  // Note: this can rounds input values backwards or forwards.
  //       You might ask, why not restrict this to just rounding
  //       forwards? Wouldn't that allow left endpoints to always
  //       remain left endpoints during splitting (never change to
  //       right). No - it wouldn't, because we snap intersections
  //       to endpoints (to establish independence from the segment
  //       angle for t-intersections).
  round(t) {
    const e = this.tree.add(t), n = this.tree.prev(e);
    if (n !== null && Yt(e.key, n.key) === 0)
      return this.tree.remove(t), n.key;
    const i = this.tree.next(e);
    return i !== null && Yt(e.key, i.key) === 0 ? (this.tree.remove(t), i.key) : t;
  }
}
const K = new Cn(), nt = (r, t) => r.x * t.y - r.y * t.x, he = (r, t) => r.x * t.x + r.y * t.y, Ht = (r, t, e) => {
  const n = On(r.x, r.y, t.x, t.y, e.x, e.y);
  return n > 0 ? -1 : n < 0 ? 1 : 0;
}, rt = (r) => Math.sqrt(he(r, r)), Bn = (r, t, e) => {
  const n = {
    x: t.x - r.x,
    y: t.y - r.y
  }, i = {
    x: e.x - r.x,
    y: e.y - r.y
  };
  return nt(i, n) / rt(i) / rt(n);
}, zn = (r, t, e) => {
  const n = {
    x: t.x - r.x,
    y: t.y - r.y
  }, i = {
    x: e.x - r.x,
    y: e.y - r.y
  };
  return he(i, n) / rt(i) / rt(n);
}, qt = (r, t, e) => t.y === 0 ? null : {
  x: r.x + t.x / t.y * (e - r.y),
  y: e
}, Xt = (r, t, e) => t.x === 0 ? null : {
  x: e,
  y: r.y + t.y / t.x * (e - r.x)
}, $n = (r, t, e, n) => {
  if (t.x === 0) return Xt(e, n, r.x);
  if (n.x === 0) return Xt(r, t, e.x);
  if (t.y === 0) return qt(e, n, r.y);
  if (n.y === 0) return qt(r, t, e.y);
  const i = nt(t, n);
  if (i == 0) return null;
  const s = {
    x: e.x - r.x,
    y: e.y - r.y
  }, l = nt(s, t) / i, o = nt(s, n) / i, h = r.x + o * t.x, f = e.x + l * n.x, d = r.y + o * t.y, a = e.y + l * n.y, c = (h + f) / 2, u = (d + a) / 2;
  return {
    x: c,
    y: u
  };
};
class N {
  // for ordering sweep events in the sweep event queue
  static compare(t, e) {
    const n = N.comparePoints(t.point, e.point);
    return n !== 0 ? n : (t.point !== e.point && t.link(e), t.isLeft !== e.isLeft ? t.isLeft ? 1 : -1 : j.compare(t.segment, e.segment));
  }
  // for ordering points in sweep line order
  static comparePoints(t, e) {
    return t.x < e.x ? -1 : t.x > e.x ? 1 : t.y < e.y ? -1 : t.y > e.y ? 1 : 0;
  }
  // Warning: 'point' input will be modified and re-used (for performance)
  constructor(t, e) {
    t.events === void 0 ? t.events = [this] : t.events.push(this), this.point = t, this.isLeft = e;
  }
  link(t) {
    if (t.point === this.point)
      throw new Error("Tried to link already linked events");
    const e = t.point.events;
    for (let n = 0, i = e.length; n < i; n++) {
      const s = e[n];
      this.point.events.push(s), s.point = this.point;
    }
    this.checkForConsuming();
  }
  /* Do a pass over our linked events and check to see if any pair
   * of segments match, and should be consumed. */
  checkForConsuming() {
    const t = this.point.events.length;
    for (let e = 0; e < t; e++) {
      const n = this.point.events[e];
      if (n.segment.consumedBy === void 0)
        for (let i = e + 1; i < t; i++) {
          const s = this.point.events[i];
          s.consumedBy === void 0 && n.otherSE.point.events === s.otherSE.point.events && n.segment.consume(s.segment);
        }
    }
  }
  getAvailableLinkedEvents() {
    const t = [];
    for (let e = 0, n = this.point.events.length; e < n; e++) {
      const i = this.point.events[e];
      i !== this && !i.segment.ringOut && i.segment.isInResult() && t.push(i);
    }
    return t;
  }
  /**
   * Returns a comparator function for sorting linked events that will
   * favor the event that will give us the smallest left-side angle.
   * All ring construction starts as low as possible heading to the right,
   * so by always turning left as sharp as possible we'll get polygons
   * without uncessary loops & holes.
   *
   * The comparator function has a compute cache such that it avoids
   * re-computing already-computed values.
   */
  getLeftmostComparator(t) {
    const e = /* @__PURE__ */ new Map(), n = (i) => {
      const s = i.otherSE;
      e.set(i, {
        sine: Bn(this.point, t.point, s.point),
        cosine: zn(this.point, t.point, s.point)
      });
    };
    return (i, s) => {
      e.has(i) || n(i), e.has(s) || n(s);
      const {
        sine: l,
        cosine: o
      } = e.get(i), {
        sine: h,
        cosine: f
      } = e.get(s);
      return l >= 0 && h >= 0 ? o < f ? 1 : o > f ? -1 : 0 : l < 0 && h < 0 ? o < f ? -1 : o > f ? 1 : 0 : h < l ? -1 : h > l ? 1 : 0;
    };
  }
}
let jn = 0;
class j {
  /* This compare() function is for ordering segments in the sweep
   * line tree, and does so according to the following criteria:
   *
   * Consider the vertical line that lies an infinestimal step to the
   * right of the right-more of the two left endpoints of the input
   * segments. Imagine slowly moving a point up from negative infinity
   * in the increasing y direction. Which of the two segments will that
   * point intersect first? That segment comes 'before' the other one.
   *
   * If neither segment would be intersected by such a line, (if one
   * or more of the segments are vertical) then the line to be considered
   * is directly on the right-more of the two left inputs.
   */
  static compare(t, e) {
    const n = t.leftSE.point.x, i = e.leftSE.point.x, s = t.rightSE.point.x, l = e.rightSE.point.x;
    if (l < n) return 1;
    if (s < i) return -1;
    const o = t.leftSE.point.y, h = e.leftSE.point.y, f = t.rightSE.point.y, d = e.rightSE.point.y;
    if (n < i) {
      if (h < o && h < f) return 1;
      if (h > o && h > f) return -1;
      const a = t.comparePoint(e.leftSE.point);
      if (a < 0) return 1;
      if (a > 0) return -1;
      const c = e.comparePoint(t.rightSE.point);
      return c !== 0 ? c : -1;
    }
    if (n > i) {
      if (o < h && o < d) return -1;
      if (o > h && o > d) return 1;
      const a = e.comparePoint(t.leftSE.point);
      if (a !== 0) return a;
      const c = t.comparePoint(e.rightSE.point);
      return c < 0 ? 1 : c > 0 ? -1 : 1;
    }
    if (o < h) return -1;
    if (o > h) return 1;
    if (s < l) {
      const a = e.comparePoint(t.rightSE.point);
      if (a !== 0) return a;
    }
    if (s > l) {
      const a = t.comparePoint(e.rightSE.point);
      if (a < 0) return 1;
      if (a > 0) return -1;
    }
    if (s !== l) {
      const a = f - o, c = s - n, u = d - h, y = l - i;
      if (a > c && u < y) return 1;
      if (a < c && u > y) return -1;
    }
    return s > l ? 1 : s < l || f < d ? -1 : f > d ? 1 : t.id < e.id ? -1 : t.id > e.id ? 1 : 0;
  }
  /* Warning: a reference to ringWindings input will be stored,
   *  and possibly will be later modified */
  constructor(t, e, n, i) {
    this.id = ++jn, this.leftSE = t, t.segment = this, t.otherSE = e, this.rightSE = e, e.segment = this, e.otherSE = t, this.rings = n, this.windings = i;
  }
  static fromRing(t, e, n) {
    let i, s, l;
    const o = N.comparePoints(t, e);
    if (o < 0)
      i = t, s = e, l = 1;
    else if (o > 0)
      i = e, s = t, l = -1;
    else throw new Error(`Tried to create degenerate segment at [${t.x}, ${t.y}]`);
    const h = new N(i, !0), f = new N(s, !1);
    return new j(h, f, [n], [l]);
  }
  /* When a segment is split, the rightSE is replaced with a new sweep event */
  replaceRightSE(t) {
    this.rightSE = t, this.rightSE.segment = this, this.rightSE.otherSE = this.leftSE, this.leftSE.otherSE = this.rightSE;
  }
  bbox() {
    const t = this.leftSE.point.y, e = this.rightSE.point.y;
    return {
      ll: {
        x: this.leftSE.point.x,
        y: t < e ? t : e
      },
      ur: {
        x: this.rightSE.point.x,
        y: t > e ? t : e
      }
    };
  }
  /* A vector from the left point to the right */
  vector() {
    return {
      x: this.rightSE.point.x - this.leftSE.point.x,
      y: this.rightSE.point.y - this.leftSE.point.y
    };
  }
  isAnEndpoint(t) {
    return t.x === this.leftSE.point.x && t.y === this.leftSE.point.y || t.x === this.rightSE.point.x && t.y === this.rightSE.point.y;
  }
  /* Compare this segment with a point.
   *
   * A point P is considered to be colinear to a segment if there
   * exists a distance D such that if we travel along the segment
   * from one * endpoint towards the other a distance D, we find
   * ourselves at point P.
   *
   * Return value indicates:
   *
   *   1: point lies above the segment (to the left of vertical)
   *   0: point is colinear to segment
   *  -1: point lies below the segment (to the right of vertical)
   */
  comparePoint(t) {
    if (this.isAnEndpoint(t)) return 0;
    const e = this.leftSE.point, n = this.rightSE.point, i = this.vector();
    if (e.x === n.x)
      return t.x === e.x ? 0 : t.x < e.x ? 1 : -1;
    const s = (t.y - e.y) / i.y, l = e.x + s * i.x;
    if (t.x === l) return 0;
    const o = (t.x - e.x) / i.x, h = e.y + o * i.y;
    return t.y === h ? 0 : t.y < h ? -1 : 1;
  }
  /**
   * Given another segment, returns the first non-trivial intersection
   * between the two segments (in terms of sweep line ordering), if it exists.
   *
   * A 'non-trivial' intersection is one that will cause one or both of the
   * segments to be split(). As such, 'trivial' vs. 'non-trivial' intersection:
   *
   *   * endpoint of segA with endpoint of segB --> trivial
   *   * endpoint of segA with point along segB --> non-trivial
   *   * endpoint of segB with point along segA --> non-trivial
   *   * point along segA with point along segB --> non-trivial
   *
   * If no non-trivial intersection exists, return null
   * Else, return null.
   */
  getIntersection(t) {
    const e = this.bbox(), n = t.bbox(), i = xt(e, n);
    if (i === null) return null;
    const s = this.leftSE.point, l = this.rightSE.point, o = t.leftSE.point, h = t.rightSE.point, f = U(e, o) && this.comparePoint(o) === 0, d = U(n, s) && t.comparePoint(s) === 0, a = U(e, h) && this.comparePoint(h) === 0, c = U(n, l) && t.comparePoint(l) === 0;
    if (d && f)
      return c && !a ? l : !c && a ? h : null;
    if (d)
      return a && s.x === h.x && s.y === h.y ? null : s;
    if (f)
      return c && l.x === o.x && l.y === o.y ? null : o;
    if (c && a) return null;
    if (c) return l;
    if (a) return h;
    const u = $n(s, this.vector(), o, t.vector());
    return u === null || !U(i, u) ? null : K.round(u.x, u.y);
  }
  /**
   * Split the given segment into multiple segments on the given points.
   *  * Each existing segment will retain its leftSE and a new rightSE will be
   *    generated for it.
   *  * A new segment will be generated which will adopt the original segment's
   *    rightSE, and a new leftSE will be generated for it.
   *  * If there are more than two points given to split on, new segments
   *    in the middle will be generated with new leftSE and rightSE's.
   *  * An array of the newly generated SweepEvents will be returned.
   *
   * Warning: input array of points is modified
   */
  split(t) {
    const e = [], n = t.events !== void 0, i = new N(t, !0), s = new N(t, !1), l = this.rightSE;
    this.replaceRightSE(s), e.push(s), e.push(i);
    const o = new j(i, l, this.rings.slice(), this.windings.slice());
    return N.comparePoints(o.leftSE.point, o.rightSE.point) > 0 && o.swapEvents(), N.comparePoints(this.leftSE.point, this.rightSE.point) > 0 && this.swapEvents(), n && (i.checkForConsuming(), s.checkForConsuming()), e;
  }
  /* Swap which event is left and right */
  swapEvents() {
    const t = this.rightSE;
    this.rightSE = this.leftSE, this.leftSE = t, this.leftSE.isLeft = !0, this.rightSE.isLeft = !1;
    for (let e = 0, n = this.windings.length; e < n; e++)
      this.windings[e] *= -1;
  }
  /* Consume another segment. We take their rings under our wing
   * and mark them as consumed. Use for perfectly overlapping segments */
  consume(t) {
    let e = this, n = t;
    for (; e.consumedBy; ) e = e.consumedBy;
    for (; n.consumedBy; ) n = n.consumedBy;
    const i = j.compare(e, n);
    if (i !== 0) {
      if (i > 0) {
        const s = e;
        e = n, n = s;
      }
      if (e.prev === n) {
        const s = e;
        e = n, n = s;
      }
      for (let s = 0, l = n.rings.length; s < l; s++) {
        const o = n.rings[s], h = n.windings[s], f = e.rings.indexOf(o);
        f === -1 ? (e.rings.push(o), e.windings.push(h)) : e.windings[f] += h;
      }
      n.rings = null, n.windings = null, n.consumedBy = e, n.leftSE.consumedBy = e.leftSE, n.rightSE.consumedBy = e.rightSE;
    }
  }
  /* The first segment previous segment chain that is in the result */
  prevInResult() {
    return this._prevInResult !== void 0 ? this._prevInResult : (this.prev ? this.prev.isInResult() ? this._prevInResult = this.prev : this._prevInResult = this.prev.prevInResult() : this._prevInResult = null, this._prevInResult);
  }
  beforeState() {
    if (this._beforeState !== void 0) return this._beforeState;
    if (!this.prev) this._beforeState = {
      rings: [],
      windings: [],
      multiPolys: []
    };
    else {
      const t = this.prev.consumedBy || this.prev;
      this._beforeState = t.afterState();
    }
    return this._beforeState;
  }
  afterState() {
    if (this._afterState !== void 0) return this._afterState;
    const t = this.beforeState();
    this._afterState = {
      rings: t.rings.slice(0),
      windings: t.windings.slice(0),
      multiPolys: []
    };
    const e = this._afterState.rings, n = this._afterState.windings, i = this._afterState.multiPolys;
    for (let o = 0, h = this.rings.length; o < h; o++) {
      const f = this.rings[o], d = this.windings[o], a = e.indexOf(f);
      a === -1 ? (e.push(f), n.push(d)) : n[a] += d;
    }
    const s = [], l = [];
    for (let o = 0, h = e.length; o < h; o++) {
      if (n[o] === 0) continue;
      const f = e[o], d = f.poly;
      if (l.indexOf(d) === -1)
        if (f.isExterior) s.push(d);
        else {
          l.indexOf(d) === -1 && l.push(d);
          const a = s.indexOf(f.poly);
          a !== -1 && s.splice(a, 1);
        }
    }
    for (let o = 0, h = s.length; o < h; o++) {
      const f = s[o].multiPoly;
      i.indexOf(f) === -1 && i.push(f);
    }
    return this._afterState;
  }
  /* Is this segment part of the final result? */
  isInResult() {
    if (this.consumedBy) return !1;
    if (this._isInResult !== void 0) return this._isInResult;
    const t = this.beforeState().multiPolys, e = this.afterState().multiPolys;
    switch (T.type) {
      case "union": {
        const n = t.length === 0, i = e.length === 0;
        this._isInResult = n !== i;
        break;
      }
      case "intersection": {
        let n, i;
        t.length < e.length ? (n = t.length, i = e.length) : (n = e.length, i = t.length), this._isInResult = i === T.numMultiPolys && n < i;
        break;
      }
      case "xor": {
        const n = Math.abs(t.length - e.length);
        this._isInResult = n % 2 === 1;
        break;
      }
      case "difference": {
        const n = (i) => i.length === 1 && i[0].isSubject;
        this._isInResult = n(t) !== n(e);
        break;
      }
      default:
        throw new Error(`Unrecognized operation type found ${T.type}`);
    }
    return this._isInResult;
  }
}
class Wt {
  constructor(t, e, n) {
    if (!Array.isArray(t) || t.length === 0)
      throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
    if (this.poly = e, this.isExterior = n, this.segments = [], typeof t[0][0] != "number" || typeof t[0][1] != "number")
      throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
    const i = K.round(t[0][0], t[0][1]);
    this.bbox = {
      ll: {
        x: i.x,
        y: i.y
      },
      ur: {
        x: i.x,
        y: i.y
      }
    };
    let s = i;
    for (let l = 1, o = t.length; l < o; l++) {
      if (typeof t[l][0] != "number" || typeof t[l][1] != "number")
        throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
      let h = K.round(t[l][0], t[l][1]);
      h.x === s.x && h.y === s.y || (this.segments.push(j.fromRing(s, h, this)), h.x < this.bbox.ll.x && (this.bbox.ll.x = h.x), h.y < this.bbox.ll.y && (this.bbox.ll.y = h.y), h.x > this.bbox.ur.x && (this.bbox.ur.x = h.x), h.y > this.bbox.ur.y && (this.bbox.ur.y = h.y), s = h);
    }
    (i.x !== s.x || i.y !== s.y) && this.segments.push(j.fromRing(s, i, this));
  }
  getSweepEvents() {
    const t = [];
    for (let e = 0, n = this.segments.length; e < n; e++) {
      const i = this.segments[e];
      t.push(i.leftSE), t.push(i.rightSE);
    }
    return t;
  }
}
class Fn {
  constructor(t, e) {
    if (!Array.isArray(t))
      throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
    this.exteriorRing = new Wt(t[0], this, !0), this.bbox = {
      ll: {
        x: this.exteriorRing.bbox.ll.x,
        y: this.exteriorRing.bbox.ll.y
      },
      ur: {
        x: this.exteriorRing.bbox.ur.x,
        y: this.exteriorRing.bbox.ur.y
      }
    }, this.interiorRings = [];
    for (let n = 1, i = t.length; n < i; n++) {
      const s = new Wt(t[n], this, !1);
      s.bbox.ll.x < this.bbox.ll.x && (this.bbox.ll.x = s.bbox.ll.x), s.bbox.ll.y < this.bbox.ll.y && (this.bbox.ll.y = s.bbox.ll.y), s.bbox.ur.x > this.bbox.ur.x && (this.bbox.ur.x = s.bbox.ur.x), s.bbox.ur.y > this.bbox.ur.y && (this.bbox.ur.y = s.bbox.ur.y), this.interiorRings.push(s);
    }
    this.multiPoly = e;
  }
  getSweepEvents() {
    const t = this.exteriorRing.getSweepEvents();
    for (let e = 0, n = this.interiorRings.length; e < n; e++) {
      const i = this.interiorRings[e].getSweepEvents();
      for (let s = 0, l = i.length; s < l; s++)
        t.push(i[s]);
    }
    return t;
  }
}
class Kt {
  constructor(t, e) {
    if (!Array.isArray(t))
      throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
    try {
      typeof t[0][0][0] == "number" && (t = [t]);
    } catch {
    }
    this.polys = [], this.bbox = {
      ll: {
        x: Number.POSITIVE_INFINITY,
        y: Number.POSITIVE_INFINITY
      },
      ur: {
        x: Number.NEGATIVE_INFINITY,
        y: Number.NEGATIVE_INFINITY
      }
    };
    for (let n = 0, i = t.length; n < i; n++) {
      const s = new Fn(t[n], this);
      s.bbox.ll.x < this.bbox.ll.x && (this.bbox.ll.x = s.bbox.ll.x), s.bbox.ll.y < this.bbox.ll.y && (this.bbox.ll.y = s.bbox.ll.y), s.bbox.ur.x > this.bbox.ur.x && (this.bbox.ur.x = s.bbox.ur.x), s.bbox.ur.y > this.bbox.ur.y && (this.bbox.ur.y = s.bbox.ur.y), this.polys.push(s);
    }
    this.isSubject = e;
  }
  getSweepEvents() {
    const t = [];
    for (let e = 0, n = this.polys.length; e < n; e++) {
      const i = this.polys[e].getSweepEvents();
      for (let s = 0, l = i.length; s < l; s++)
        t.push(i[s]);
    }
    return t;
  }
}
class ot {
  /* Given the segments from the sweep line pass, compute & return a series
   * of closed rings from all the segments marked to be part of the result */
  static factory(t) {
    const e = [];
    for (let n = 0, i = t.length; n < i; n++) {
      const s = t[n];
      if (!s.isInResult() || s.ringOut) continue;
      let l = null, o = s.leftSE, h = s.rightSE;
      const f = [o], d = o.point, a = [];
      for (; l = o, o = h, f.push(o), o.point !== d; )
        for (; ; ) {
          const c = o.getAvailableLinkedEvents();
          if (c.length === 0) {
            const g = f[0].point, _ = f[f.length - 1].point;
            throw new Error(`Unable to complete output ring starting at [${g.x}, ${g.y}]. Last matching segment found ends at [${_.x}, ${_.y}].`);
          }
          if (c.length === 1) {
            h = c[0].otherSE;
            break;
          }
          let u = null;
          for (let g = 0, _ = a.length; g < _; g++)
            if (a[g].point === o.point) {
              u = g;
              break;
            }
          if (u !== null) {
            const g = a.splice(u)[0], _ = f.splice(g.index);
            _.unshift(_[0].otherSE), e.push(new ot(_.reverse()));
            continue;
          }
          a.push({
            index: f.length,
            point: o.point
          });
          const y = o.getLeftmostComparator(l);
          h = c.sort(y)[0].otherSE;
          break;
        }
      e.push(new ot(f));
    }
    return e;
  }
  constructor(t) {
    this.events = t;
    for (let e = 0, n = t.length; e < n; e++)
      t[e].segment.ringOut = this;
    this.poly = null;
  }
  getGeom() {
    let t = this.events[0].point;
    const e = [t];
    for (let f = 1, d = this.events.length - 1; f < d; f++) {
      const a = this.events[f].point, c = this.events[f + 1].point;
      Ht(a, t, c) !== 0 && (e.push(a), t = a);
    }
    if (e.length === 1) return null;
    const n = e[0], i = e[1];
    Ht(n, t, i) === 0 && e.shift(), e.push(e[0]);
    const s = this.isExteriorRing() ? 1 : -1, l = this.isExteriorRing() ? 0 : e.length - 1, o = this.isExteriorRing() ? e.length : -1, h = [];
    for (let f = l; f != o; f += s) h.push([e[f].x, e[f].y]);
    return h;
  }
  isExteriorRing() {
    if (this._isExteriorRing === void 0) {
      const t = this.enclosingRing();
      this._isExteriorRing = t ? !t.isExteriorRing() : !0;
    }
    return this._isExteriorRing;
  }
  enclosingRing() {
    return this._enclosingRing === void 0 && (this._enclosingRing = this._calcEnclosingRing()), this._enclosingRing;
  }
  /* Returns the ring that encloses this one, if any */
  _calcEnclosingRing() {
    let t = this.events[0];
    for (let i = 1, s = this.events.length; i < s; i++) {
      const l = this.events[i];
      N.compare(t, l) > 0 && (t = l);
    }
    let e = t.segment.prevInResult(), n = e ? e.prevInResult() : null;
    for (; ; ) {
      if (!e) return null;
      if (!n) return e.ringOut;
      if (n.ringOut !== e.ringOut)
        return n.ringOut.enclosingRing() !== e.ringOut ? e.ringOut : e.ringOut.enclosingRing();
      e = n.prevInResult(), n = e ? e.prevInResult() : null;
    }
  }
}
class Qt {
  constructor(t) {
    this.exteriorRing = t, t.poly = this, this.interiorRings = [];
  }
  addInterior(t) {
    this.interiorRings.push(t), t.poly = this;
  }
  getGeom() {
    const t = [this.exteriorRing.getGeom()];
    if (t[0] === null) return null;
    for (let e = 0, n = this.interiorRings.length; e < n; e++) {
      const i = this.interiorRings[e].getGeom();
      i !== null && t.push(i);
    }
    return t;
  }
}
class Gn {
  constructor(t) {
    this.rings = t, this.polys = this._composePolys(t);
  }
  getGeom() {
    const t = [];
    for (let e = 0, n = this.polys.length; e < n; e++) {
      const i = this.polys[e].getGeom();
      i !== null && t.push(i);
    }
    return t;
  }
  _composePolys(t) {
    const e = [];
    for (let n = 0, i = t.length; n < i; n++) {
      const s = t[n];
      if (!s.poly)
        if (s.isExteriorRing()) e.push(new Qt(s));
        else {
          const l = s.enclosingRing();
          l.poly || e.push(new Qt(l)), l.poly.addInterior(s);
        }
    }
    return e;
  }
}
class Dn {
  constructor(t) {
    let e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : j.compare;
    this.queue = t, this.tree = new Mt(e), this.segments = [];
  }
  process(t) {
    const e = t.segment, n = [];
    if (t.consumedBy)
      return t.isLeft ? this.queue.remove(t.otherSE) : this.tree.remove(e), n;
    const i = t.isLeft ? this.tree.add(e) : this.tree.find(e);
    if (!i) throw new Error(`Unable to find segment #${e.id} [${e.leftSE.point.x}, ${e.leftSE.point.y}] -> [${e.rightSE.point.x}, ${e.rightSE.point.y}] in SweepLine tree.`);
    let s = i, l = i, o, h;
    for (; o === void 0; )
      s = this.tree.prev(s), s === null ? o = null : s.key.consumedBy === void 0 && (o = s.key);
    for (; h === void 0; )
      l = this.tree.next(l), l === null ? h = null : l.key.consumedBy === void 0 && (h = l.key);
    if (t.isLeft) {
      let f = null;
      if (o) {
        const a = o.getIntersection(e);
        if (a !== null && (e.isAnEndpoint(a) || (f = a), !o.isAnEndpoint(a))) {
          const c = this._splitSafely(o, a);
          for (let u = 0, y = c.length; u < y; u++)
            n.push(c[u]);
        }
      }
      let d = null;
      if (h) {
        const a = h.getIntersection(e);
        if (a !== null && (e.isAnEndpoint(a) || (d = a), !h.isAnEndpoint(a))) {
          const c = this._splitSafely(h, a);
          for (let u = 0, y = c.length; u < y; u++)
            n.push(c[u]);
        }
      }
      if (f !== null || d !== null) {
        let a = null;
        f === null ? a = d : d === null ? a = f : a = N.comparePoints(f, d) <= 0 ? f : d, this.queue.remove(e.rightSE), n.push(e.rightSE);
        const c = e.split(a);
        for (let u = 0, y = c.length; u < y; u++)
          n.push(c[u]);
      }
      n.length > 0 ? (this.tree.remove(e), n.push(t)) : (this.segments.push(e), e.prev = o);
    } else {
      if (o && h) {
        const f = o.getIntersection(h);
        if (f !== null) {
          if (!o.isAnEndpoint(f)) {
            const d = this._splitSafely(o, f);
            for (let a = 0, c = d.length; a < c; a++)
              n.push(d[a]);
          }
          if (!h.isAnEndpoint(f)) {
            const d = this._splitSafely(h, f);
            for (let a = 0, c = d.length; a < c; a++)
              n.push(d[a]);
          }
        }
      }
      this.tree.remove(e);
    }
    return n;
  }
  /* Safely split a segment that is currently in the datastructures
   * IE - a segment other than the one that is currently being processed. */
  _splitSafely(t, e) {
    this.tree.remove(t);
    const n = t.rightSE;
    this.queue.remove(n);
    const i = t.split(e);
    return i.push(n), t.consumedBy === void 0 && this.tree.add(t), i;
  }
}
const Vt = typeof process < "u" && process.env.POLYGON_CLIPPING_MAX_QUEUE_SIZE || 1e6, Yn = typeof process < "u" && process.env.POLYGON_CLIPPING_MAX_SWEEPLINE_SEGMENTS || 1e6;
class Un {
  run(t, e, n) {
    T.type = t, K.reset();
    const i = [new Kt(e, !0)];
    for (let a = 0, c = n.length; a < c; a++)
      i.push(new Kt(n[a], !1));
    if (T.numMultiPolys = i.length, T.type === "difference") {
      const a = i[0];
      let c = 1;
      for (; c < i.length; )
        xt(i[c].bbox, a.bbox) !== null ? c++ : i.splice(c, 1);
    }
    if (T.type === "intersection")
      for (let a = 0, c = i.length; a < c; a++) {
        const u = i[a];
        for (let y = a + 1, g = i.length; y < g; y++)
          if (xt(u.bbox, i[y].bbox) === null) return [];
      }
    const s = new Mt(N.compare);
    for (let a = 0, c = i.length; a < c; a++) {
      const u = i[a].getSweepEvents();
      for (let y = 0, g = u.length; y < g; y++)
        if (s.insert(u[y]), s.size > Vt)
          throw new Error("Infinite loop when putting segment endpoints in a priority queue (queue size too big).");
    }
    const l = new Dn(s);
    let o = s.size, h = s.pop();
    for (; h; ) {
      const a = h.key;
      if (s.size === o) {
        const u = a.segment;
        throw new Error(`Unable to pop() ${a.isLeft ? "left" : "right"} SweepEvent [${a.point.x}, ${a.point.y}] from segment #${u.id} [${u.leftSE.point.x}, ${u.leftSE.point.y}] -> [${u.rightSE.point.x}, ${u.rightSE.point.y}] from queue.`);
      }
      if (s.size > Vt)
        throw new Error("Infinite loop when passing sweep line over endpoints (queue size too big).");
      if (l.segments.length > Yn)
        throw new Error("Infinite loop when passing sweep line over endpoints (too many sweep line segments).");
      const c = l.process(a);
      for (let u = 0, y = c.length; u < y; u++) {
        const g = c[u];
        g.consumedBy === void 0 && s.insert(g);
      }
      o = s.size, h = s.pop();
    }
    K.reset();
    const f = ot.factory(l.segments);
    return new Gn(f).getGeom();
  }
}
const T = new Un(), Hn = function(r) {
  for (var t = arguments.length, e = new Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++)
    e[n - 1] = arguments[n];
  return T.run("union", r, e);
}, qn = function(r) {
  for (var t = arguments.length, e = new Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++)
    e[n - 1] = arguments[n];
  return T.run("intersection", r, e);
}, Xn = function(r) {
  for (var t = arguments.length, e = new Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++)
    e[n - 1] = arguments[n];
  return T.run("xor", r, e);
}, Wn = function(r) {
  for (var t = arguments.length, e = new Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++)
    e[n - 1] = arguments[n];
  return T.run("difference", r, e);
};
var ct = {
  union: Hn,
  intersection: qn,
  xor: Xn,
  difference: Wn
};
const Jt = 3, Kn = 10, Qn = 1, Vn = '<path d="M3.704 14.467a10 8 0 1 1 3.115 2.375"/><path d="M7 22a5 5 0 0 1-2-3.994"/><circle cx="5" cy="16" r="2"/>', Jn = '<path d="M22 26h8M26 22v8"/>', Zn = '<path d="M22 26h8"/>';
function bt(r = "") {
  const t = Vn + r, e = r ? 24 : 16, n = e * 1.5, i = `<svg xmlns="http://www.w3.org/2000/svg" width="${e}" height="${e}" viewBox="0 0 ${n} ${n}" fill="none" stroke-linecap="round" stroke-linejoin="round"><g stroke="white" stroke-width="4">${t}</g><g stroke="black" stroke-width="2">${t}</g></svg>`;
  return `url("data:image/svg+xml,${encodeURIComponent(i)}") 5 15, crosshair`;
}
const ti = bt(), ei = {
  add: bt(Jn),
  subtract: bt(Zn)
}, ni = `
	:host {
		position: absolute;
		display: none;
		z-index: 1;
		cursor: ${ti};
		touch-action: none;
		user-select: none;
	}

	:host([hidden]) {
		display: none !important;
	}

	:host([disabled]) {
		pointer-events: none;
	}

	svg {
		position: absolute;
		inset: 0;
		width: 100%;
		height: 100%;
		overflow: visible;
		pointer-events: none;
	}

	polyline,
	path {
		display: none;
		fill: none;
		stroke-width: 1px;
	}

	#draft {
		stroke: var(--lasso-tool-color, var(--color-accent, #f97316));
	}

	/* Marching ants: black dashes over a white line. */
	#lasso {
		stroke: white;
	}

	#ants {
		stroke: black;
		stroke-dasharray: 4 4;
		animation: march 0.6s linear infinite;
	}

	:host([static]) #ants {
		animation: none;
	}

	@keyframes march {
		to {
			stroke-dashoffset: -8;
		}
	}
`;
class ii extends HTMLElement {
  #t = null;
  /** As drawn, kept intact while browsing images. */
  #e = null;
  /** Resolution of the image lasso was drawn over. */
  #n = null;
  #r;
  #f;
  #c;
  /** Last emitted value, as JSON, to emit only changes. */
  #u = "null";
  /**
   * Element lasso is drawn within, e.g. the canvas: a drawing leaving it
   * is in fact a drag of image to another element.
   */
  area = null;
  /** Neighbors each vertex is averaged with on each side, to smooth the hand's jitter. */
  smoothing = 1;
  #v = ["", ""];
  #i = null;
  /** What lasso being drawn does to the current one, if not replace it. */
  #a = null;
  /** Operation of the shortcut held while pointer is over overlay, if any. */
  #m = null;
  /** Where user pressed, in client pixels, to tell a click from a move. */
  #E = null;
  /** Lasso as it was when user pressed, back if user cancels. */
  #_ = null;
  /** Lasso being drawn, applied to the current one on release. */
  #o = null;
  /** Element outside overlay that pointer is over, while user drags image. */
  #s = null;
  /** Whether drop target accepts displayed image. */
  #x = !1;
  #d = null;
  #M = new ResizeObserver(() => this.#w());
  #I = () => this.#w();
  /** Escape cancels the lasso being drawn, and only that. */
  #R = (t) => {
    t.key === "Escape" && (t.preventDefault(), t.stopPropagation(), this.#O());
  };
  /** Tell what a drag would do, as user presses or releases a shortcut. */
  #b = (t) => {
    if (!this.matches(":hover")) {
      this.#A();
      return;
    }
    t.key === "Alt" && t.preventDefault(), this.#k(t);
  };
  constructor() {
    super();
    const t = this.attachShadow({ mode: "open" }), e = document.createElement("style");
    e.textContent = ni;
    const n = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    n.innerHTML = '<path id="lasso"></path><path id="ants"></path><polyline id="draft"></polyline>', this.#r = n.querySelector("#draft"), this.#f = n.querySelector("#lasso"), this.#c = n.querySelector("#ants"), t.append(e, n), this.addEventListener("pointerenter", (i) => this.#T(i)), this.addEventListener("pointerleave", () => this.#A()), this.addEventListener("pointerdown", (i) => this.#C(i)), this.addEventListener("pointermove", (i) => this.#B(i)), this.addEventListener("pointerup", () => this.#z()), this.addEventListener("pointercancel", () => this.#$());
  }
  /**
   * Image to draw the lasso over. Lasso persists when another image is
   * displayed, scaled to its resolution, so user finds it back while
   * browsing images.
   */
  get target() {
    return this.#t;
  }
  set target(t) {
    this.#t !== t && (this.#t && (this.#M.unobserve(this.#t), this.#t.removeEventListener("load", this.#I)), this.#t = t, this.#h(), t && (this.#M.observe(t), t.addEventListener("load", this.#I))), this.#w();
  }
  /**
   * Tooltips shown over the image: while no lasso is drawn, e.g. to tell
   * how to draw one, then once drawn, e.g. to tell how to clear it.
   */
  get tooltips() {
    return this.#v;
  }
  set tooltips(t) {
    this.#v = t, this.#l();
  }
  /**
   * Lasso in pixels of the displayed image, scaled to it.
   * Setting it emits no event.
   */
  get value() {
    return this.#p();
  }
  set value(t) {
    this.#e = t && t.map((e) => e.map(([n, i]) => [n, i])), this.#n = H(this.#t) ?? this.#n, this.#u = JSON.stringify(ee(this.#p())), this.#h(), this.#l();
  }
  clear() {
    this.#e = null, this.#h(), this.#l(), this.#S();
  }
  /** Cover image content, letterbox bands excluded. */
  sync() {
    const t = this.#t, e = this.parentElement;
    if (!t?.isConnected || !e || !t.naturalWidth || !t.naturalHeight) {
      this.style.display = "none";
      return;
    }
    const n = t.getBoundingClientRect(), i = e.getBoundingClientRect(), s = Math.min(
      n.width / t.naturalWidth,
      n.height / t.naturalHeight
    ), l = t.naturalWidth * s, o = t.naturalHeight * s;
    if (l <= 0 || o <= 0) {
      this.style.display = "none";
      return;
    }
    const h = n.left - i.left - e.clientLeft + (n.width - l) / 2, f = n.top - i.top - e.clientTop + (n.height - o) / 2;
    this.style.display = "block", this.style.left = `${h}px`, this.style.top = `${f}px`, this.style.width = `${l}px`, this.style.height = `${o}px`;
  }
  /** Follow displayed image, which may be another one or resized. */
  #w() {
    this.#n ??= H(this.#t), this.sync(), this.#l(), this.#S();
  }
  /**
   * Lasso scaled to displayed image, whose resolution may differ from the
   * drawn one, so it surrounds the same region.
   */
  #p() {
    const t = this.#e, e = H(this.#t);
    if (!t || !e || !this.#n) return t;
    const n = e.width / this.#n.width, i = e.height / this.#n.height;
    return t.map(
      (s) => s.map(([l, o]) => [l * n, o * i])
    );
  }
  #P(t) {
    const e = this.#t, n = this.getBoundingClientRect(), i = ne(t.clientX - n.left, 0, n.width), s = ne(t.clientY - n.top, 0, n.height);
    return [
      i / n.width * e.naturalWidth,
      s / n.height * e.naturalHeight
    ];
  }
  #l() {
    const t = this.#t, e = !!H(t), n = e ? this.#p() : null, i = e && this.#i === "draw" && this.#o ? Zt(this.#o, this.#N()) : null;
    this.title = this.#v[n ? 1 : 0], this.#r.style.display = i ? "inline" : "none", i && this.#r.setAttribute("points", this.#L(i, t));
    for (const s of [this.#f, this.#c])
      s.style.display = n ? "inline" : "none", n && s.setAttribute(
        "d",
        n.map((l) => `M${this.#L(l, t)}Z`).join("")
      );
  }
  /** SVG points of vertices, in overlay pixels. */
  #L(t, e) {
    const n = this.clientWidth / e.naturalWidth, i = this.clientHeight / e.naturalHeight;
    return t.map(([s, l]) => `${s * n},${l * i}`).join(" ");
  }
  /** Emit value, if changed. */
  #S() {
    const t = ee(this.#p()), e = JSON.stringify(t);
    e !== this.#u && (this.#u = e, this.dispatchEvent(new CustomEvent("lasso-change", { detail: t })));
  }
  #T(t) {
    window.addEventListener("keydown", this.#b, !0), window.addEventListener("keyup", this.#b, !0), this.#k(t);
  }
  #A() {
    window.removeEventListener("keydown", this.#b, !0), window.removeEventListener("keyup", this.#b, !0), this.#m = null, this.#g();
  }
  #k(t) {
    const e = te(t);
    e !== this.#m && (this.#m = e, this.#g());
  }
  /**
   * A click clears the lasso, and a drag draws a new one, which replaces
   * the current one at once and closes on release, or adds a region to it
   * with Shift held, even apart from the others, or subtracts one from it
   * with Alt held. User may as well drag displayed
   * image to another element, e.g. a prompt left of the canvas: leaving the
   * area (canvas) turns the drawing into a drop.
   */
  #C(t) {
    !this.#t || t.button !== 0 || (t.preventDefault(), t.stopPropagation(), this.#h(), this.#e = this.#p(), this.#n = H(this.#t), this.#_ = this.#e, this.#i = "press", this.#a = te(t), this.#E = [t.clientX, t.clientY], this.#o = [this.#P(t)], this.#g(), this.setPointerCapture(t.pointerId), window.addEventListener("keydown", this.#R, !0));
  }
  #B(t) {
    if (this.#k(t), !this.#t || !this.#i) return;
    if (this.#i === "press") {
      const [l, o] = this.#E;
      if (Math.hypot(t.clientX - l, t.clientY - o) <= Kn)
        return;
      this.#i = "draw", this.#a || (this.#e = null);
    }
    if (this.#i === "draw" && this.#F(t) && (this.#i = "drop", this.#e = this.#_, this.#o = null, this.#l()), this.#i === "drop") {
      this.#G(t);
      return;
    }
    const e = this.#P(t), n = this.#o, [i, s] = n[n.length - 1];
    Math.hypot(e[0] - i, e[1] - s) < Qn || (n.push(e), this.#l());
  }
  #z() {
    const t = this.#i;
    t === "press" ? this.#a ? this.#h() : this.clear() : t === "drop" ? (this.#x && (this.#y(this.#s, "drop"), this.#s = null), this.#h()) : t === "draw" && this.#j();
  }
  #$() {
    this.#i && this.#O();
  }
  /** Close lasso as drawn, unless it encloses nothing, and apply it. */
  #j() {
    const t = this.#o && Zt(this.#o, this.#N()), e = this.#a, n = this.#e;
    if (this.#h(), e)
      t && t.length >= Jt && (n ? this.#e = si(n, t, e) ?? n : this.#e = e === "add" ? [t] : null);
    else {
      if (!t || t.length < Jt) {
        this.clear();
        return;
      }
      this.#e = [t];
    }
    this.#l(), this.#S();
  }
  #N() {
    return Math.max(0, Math.floor(this.smoothing)) || 0;
  }
  /** Back to lasso as it was before user pressed. */
  #O() {
    this.#e = this.#_, this.#h(), this.#l();
  }
  /** Forget ongoing gesture, if any. */
  #h() {
    this.#s && this.#y(this.#s, "dragleave"), window.removeEventListener("keydown", this.#R, !0), this.#i = null, this.#a = null, this.#E = null, this.#_ = null, this.#o = null, this.#s = null, this.#x = !1, this.#d = null, this.#g();
  }
  /** Cursor of ongoing drop, if any, else of what a drag would do. */
  #g() {
    let t = "";
    if (this.#i === "drop")
      t = this.#x ? "copy" : "grabbing";
    else {
      const e = this.#i ? this.#a : this.#m;
      e && (t = ei[e]);
    }
    this.style.cursor = t;
  }
  /** Whether pointer left the area lasso is drawn within. */
  #F(t) {
    const e = (this.area ?? this).getBoundingClientRect();
    return t.clientX < e.left || t.clientX > e.right || t.clientY < e.top || t.clientY > e.bottom;
  }
  /**
   * Drag displayed image over the element pointer is over, outside overlay,
   * as browser would do. Overlay can't let browser drag the image itself:
   * it would take any drag over it, those drawing the lasso included.
   */
  #G(t) {
    const e = document.elementFromPoint(t.clientX, t.clientY), n = e === this ? null : e;
    n !== this.#s && (n && this.#y(n, "dragenter"), this.#s && this.#y(this.#s, "dragleave"), this.#s = n), this.#x = !!n && !this.#y(n, "dragover"), this.#g();
  }
  /** Returns false if canceled. */
  #y(t, e) {
    return this.#d || (this.#d = new DataTransfer(), this.#d.setData("text/uri-list", this.#t.currentSrc)), t.dispatchEvent(
      new DragEvent(e, {
        bubbles: !0,
        cancelable: !0,
        composed: !0,
        dataTransfer: this.#d
      })
    );
  }
}
function Zt(r, t) {
  const e = r.length;
  return t === 0 ? r : r.map((n, i) => {
    const s = Math.min(t, i, e - 1 - i);
    let [l, o] = [0, 0];
    for (let f = i - s; f <= i + s; f++)
      l += r[f][0], o += r[f][1];
    const h = 2 * s + 1;
    return [l / h, o / h];
  });
}
function te(r) {
  return r.shiftKey ? "add" : r.altKey ? "subtract" : null;
}
function si(r, t, e) {
  let n;
  try {
    const [s, ...l] = r.map((h) => [h]), o = ct.xor(s, ...l);
    n = e === "add" ? ct.union(o, [t]) : ct.difference(o, [t]);
  } catch (s) {
    return console.warn("Lasso tool couldn't combine lassos:", s), null;
  }
  const i = n.flatMap(
    (s) => s.map((l) => l.slice(0, -1).map(([o, h]) => [o, h]))
  );
  return i.length ? i : null;
}
function H(r) {
  return r?.naturalWidth && r.naturalHeight ? { width: r.naturalWidth, height: r.naturalHeight } : null;
}
function ee(r) {
  return r && r.map((t) => t.map(([e, n]) => [Math.round(e), Math.round(n)]));
}
function ne(r, t, e) {
  return Math.max(t, Math.min(e, r));
}
const vt = "lasso-tool-overlay";
customElements.get(vt) || customElements.define(vt, ii);
var ri = /* @__PURE__ */ St("<div><!></div>");
function li(r, t) {
  $e(t, !0);
  const e = /* @__PURE__ */ rn(t, ["$$slots", "$$events", "$$legacy"]), n = new mn(e), i = document.createElement(vt);
  let s, l = n.props.value ?? null;
  i.value = l;
  let o = q(null), h = q(!1), f = null;
  function d(p, x) {
    return JSON.stringify(p ?? null) === JSON.stringify(x ?? null);
  }
  function a(p, x) {
    !p && x ? n.dispatch("drawn") : p && !x && n.dispatch("cleared");
  }
  function c(p) {
    if (M(o)) return;
    X(o, p, !0), p.stage.append(i), p.add_tool(n.shared.id, s), i.area = p.area, i.target = p.image;
    const x = () => {
      X(h, p.tool === n.shared.id);
    };
    p.addEventListener("tool-change", x), x();
  }
  function u() {
    M(o) && (M(o).tool = M(h) ? null : n.shared.id);
  }
  function y(p) {
    return p instanceof HTMLElement && (p.isContentEditable || ["INPUT", "TEXTAREA", "SELECT"].includes(p.tagName));
  }
  function g(p) {
    !M(o) || M(h) || n.shared.visible === !1 || n.shared.interactive === !1 || p.key.toLowerCase() !== "l" || p.defaultPrevented || p.altKey || p.ctrlKey || p.metaKey || y(p.target) && !M(o).area.matches(":hover") || (p.preventDefault(), M(o).tool = n.shared.id);
  }
  le(() => {
    s.parentElement && (s.parentElement.hidden = !0), i.addEventListener("lasso-change", (x) => {
      const b = x.detail;
      a(l, b), l = b, n.props.value = b, n.dispatch("input"), n.dispatch("change");
    });
    const p = n.props.canvas_id;
    p !== null && (f = xn(p, c));
  }), on(() => {
    f?.(), i.target = null, i.remove();
  }), D(() => {
    const p = n.props.value ?? null;
    d(p, l) || (a(l, p), l = p, i.value = p, n.dispatch("change"));
  }), D(() => {
    i.toggleAttribute("disabled", !M(h) || n.shared.interactive === !1), i.toggleAttribute("hidden", n.shared.visible === !1), i.toggleAttribute("static", n.props.marching_ants === !1), i.smoothing = n.props.smoothing ?? 1, i.tooltips = [
      n.props.draw_tooltip ?? "",
      n.props.clear_tooltip ?? ""
    ];
  });
  var _ = ri();
  Be("keydown", je, g);
  var m = Z(_);
  {
    let p = pt(() => (M(h) ? n.props.disable_tooltip : n.props.enable_tooltip) ?? ""), x = pt(() => n.shared.interactive === !1);
    fn(m, {
      get Icon() {
        return vn;
      },
      get label() {
        return M(p);
      },
      get disabled() {
        return M(x);
      },
      onclick: u
    });
  }
  tn(_, (p) => s = p, () => s), dt(() => et(_, "hidden", !M(o) || n.shared.visible === !1)), W(r, _), ze();
}
export {
  li as default
};
