import { i as A, g as C, o as R, n as N, u as b, c as M, a as d, e as H, b as T, s as g, p as k, d as m, f as y, h as P, j as I } from "./runtime-Du6aj1Oe.js";
function O(s) {
  throw new Error("https://svelte.dev/e/lifecycle_outside_component");
}
const D = [];
function z(s, t = !1, i = !1) {
  return _(s, /* @__PURE__ */ new Map(), "", D, null, i);
}
function _(s, t, i, e, n = null, r = !1) {
  if (typeof s == "object" && s !== null) {
    var a = t.get(s);
    if (a !== void 0) return a;
    if (s instanceof Map) return (
      /** @type {Snapshot<T>} */
      new Map(s)
    );
    if (s instanceof Set) return (
      /** @type {Snapshot<T>} */
      new Set(s)
    );
    if (A(s)) {
      var o = (
        /** @type {Snapshot<any>} */
        Array(s.length)
      );
      t.set(s, o), n !== null && t.set(n, o);
      for (var f = 0; f < s.length; f += 1) {
        var l = s[f];
        f in s && (o[f] = _(l, t, i, e, null, r));
      }
      return o;
    }
    if (C(s) === R) {
      o = {}, t.set(s, o), n !== null && t.set(n, o);
      for (var u in s)
        o[u] = _(
          // @ts-expect-error
          s[u],
          t,
          i,
          e,
          null,
          r
        );
      return o;
    }
    if (s instanceof Date)
      return (
        /** @type {Snapshot<T>} */
        structuredClone(s)
      );
    if (typeof /** @type {T & { toJSON?: any } } */
    s.toJSON == "function" && !r)
      return _(
        /** @type {T & { toJSON(): any } } */
        s.toJSON(),
        t,
        i,
        e,
        // Associate the instance with the toJSON clone
        s
      );
  }
  if (s instanceof EventTarget)
    return (
      /** @type {Snapshot<T>} */
      s
    );
  try {
    return (
      /** @type {Snapshot<T>} */
      structuredClone(s)
    );
  } catch {
    return (
      /** @type {Snapshot<T>} */
      s
    );
  }
}
function W(s, t, i) {
  if (s == null)
    return t(void 0), N;
  const e = b(
    () => s.subscribe(
      t,
      // @ts-expect-error
      i
    )
  );
  return e.unsubscribe ? () => e.unsubscribe() : e;
}
function Y(s) {
  let t;
  return W(s, (i) => t = i)(), t;
}
const B = {
  get(s, t) {
    if (!s.exclude.includes(t))
      return s.props[t];
  },
  set(s, t) {
    return !1;
  },
  getOwnPropertyDescriptor(s, t) {
    if (!s.exclude.includes(t) && t in s.props)
      return {
        enumerable: !0,
        configurable: !0,
        value: s.props[t]
      };
  },
  has(s, t) {
    return s.exclude.includes(t) ? !1 : t in s.props;
  },
  ownKeys(s) {
    return Reflect.ownKeys(s.props).filter((t) => !s.exclude.includes(t));
  }
};
// @__NO_SIDE_EFFECTS__
function J(s, t, i) {
  return new Proxy(
    { props: s, exclude: t },
    B
  );
}
const X = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], E = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
X.reduce((s, { color: t, primary: i, secondary: e }) => ({
  ...s,
  [t]: {
    primary: E[t][i],
    secondary: E[t][e]
  }
}), {});
function $(s) {
  M === null && O(), d(() => {
    const t = b(s);
    if (typeof t == "function") return (
      /** @type {() => void} */
      t
    );
  });
}
function j(s) {
  M === null && O(), $(() => () => b(s));
}
function q(s) {
  let t;
  const i = T((n) => {
    let r = !1;
    const a = s.subscribe((o) => {
      t = o, r && n();
    });
    return r = !0, a;
  });
  function e() {
    return H() ? (i(), t) : Y(s);
  }
  return "set" in s ? {
    get current() {
      return e();
    },
    set current(n) {
      s.set(n);
    }
  } : {
    get current() {
      return e();
    }
  };
}
const G = "__i18n__", K = [
  "label",
  "info",
  "placeholder",
  "description",
  "title",
  "value"
], V = [
  "elem_id",
  "elem_classes",
  "visible",
  "interactive",
  "server_fns",
  "server",
  "id",
  "target",
  "theme_mode",
  "version",
  "root",
  "autoscroll",
  "max_file_size",
  "formatter",
  "client",
  "load_component",
  "scale",
  "min_width",
  "theme",
  "padding",
  "loading_status",
  "label",
  "show_label",
  "validation_error",
  "show_progress",
  "api_prefix",
  "container",
  "attached_events",
  "register_component",
  "dispatcher"
];
function F(s) {
  return typeof s == "string" && s.includes(G);
}
class U {
  load_component;
  #t = g(k({}));
  get shared() {
    return m(this.#t);
  }
  set shared(t) {
    y(this.#t, t, !0);
  }
  #e = g(k({}));
  get props() {
    return m(this.#e);
  }
  set props(t) {
    y(this.#e, t, !0);
  }
  #i = g((t) => t);
  get i18n() {
    return m(this.#i);
  }
  set i18n(t) {
    y(this.#i, t, !0);
  }
  i18n_store;
  _i18n_from_store;
  translatable_props = {};
  dispatcher;
  last_update = null;
  shared_props = V;
  mounted = !1;
  old_value;
  register_component;
  constructor(t, i) {
    for (const e in t.shared_props)
      this.shared[e] = t.shared_props[e];
    for (const e in t.props)
      e !== "i18n_store" && (this.props[e] = t.props[e]);
    if (i)
      for (const e in i)
        this.props[e] === void 0 && (this.props[e] = i[e]);
    this.i18n = this.props.i18n ?? ((e) => e), this.i18n_store = t.props.i18n_store, this._i18n_from_store = this.i18n_store ? q(this.i18n_store) : void 0;
    for (const e of K)
      this.shared[e] = this._translate_and_store(
        "shared",
        e,
        // @ts-ignore
        t.shared_props[e]
      ), this.props[e] = this._translate_and_store(
        "props",
        e,
        // @ts-ignore
        t.props[e]
      );
    this.load_component = this.shared.load_component, this.register_component = this.shared.register_component || (() => {
    }), this.dispatcher = this.shared.dispatcher || (() => {
    }), this.register_component(
      t.shared_props.id,
      // @ts-ignore
      this.set_data.bind(this),
      this.get_data.bind(this)
    ), d(() => {
      for (const e in t.shared_props)
        this._is_i18n_managed(`shared.${e}`, t.shared_props[e]) || (this.shared[e] = t.shared_props[e]);
      for (const e in t.props)
        e !== "i18n_store" && (this._is_i18n_managed(`props.${e}`, t.props[e]) || (this.props[e] = t.props[e]));
      this.register_component(
        t.shared_props.id,
        // @ts-ignore
        this.set_data.bind(this),
        this.get_data.bind(this)
      ), b(() => {
        this.shared.id = t.shared_props.id;
      });
    }), d(() => this.i18n_store ? this.i18n_store.subscribe(() => {
      for (const [n, r] of Object.entries(this.translatable_props)) {
        const [a, o] = n.split("."), f = this.i18n(r);
        a === "shared" ? this.shared[o] = f : this.props[o] = f;
      }
    }) : void 0);
  }
  // check if props are translatable
  _is_i18n_managed(t, i) {
    const e = this.translatable_props[t];
    return e ? i === e ? !0 : (delete this.translatable_props[t], !1) : !1;
  }
  _translate_and_store(t, i, e) {
    if (typeof e != "string") return e;
    const n = this.i18n(e);
    return n !== e && (this.translatable_props[`${t}.${i}`] = e), n;
  }
  // Reactive variant of `i18n`. Reading it inside a derived or template
  // subscribes to the live locale store (via Svelte's createSubscriber), so
  // the caller re-runs when the locale changes at runtime. The store is only
  // the reactivity trigger; translation always goes through `this.i18n` so a
  // custom formatter passed via props keeps taking effect.
  live_i18n = (t) => (this._i18n_from_store?.current, this.i18n(t));
  dispatch(t, i) {
    this.dispatcher(this.shared.id, t, i);
  }
  async get_data() {
    return z(this.props);
  }
  update(t) {
    this.set_data(t);
  }
  set_data(t) {
    for (const i in t) {
      const e = t[i], n = F(e) ? this._translate_and_store(this.shared_props.includes(i) ? "shared" : "props", i, e) : e;
      if (this.shared_props.includes(i)) {
        const r = i;
        this.shared[r] = n;
        continue;
      }
      this.props[i] = n;
    }
  }
  watch_for_change() {
    d(() => {
      this.mounted || (this.old_value = this.props.value, this.mounted = !0), this.old_value != this.props.value && (this.old_value = this.props.value, this.dispatch("change"));
    });
  }
}
const Q = 3, Z = 10, tt = 1, S = '<path d="M3.704 14.467a10 8 0 1 1 3.115 2.375"/><path d="M7 22a5 5 0 0 1-2-3.994"/><circle cx="5" cy="16" r="2"/>', et = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke-linecap="round" stroke-linejoin="round"><g stroke="white" stroke-width="4">${S}</g><g stroke="black" stroke-width="2">${S}</g></svg>`, st = `url("data:image/svg+xml,${encodeURIComponent(et)}") 5 15, crosshair`, it = `
	:host {
		position: absolute;
		display: none;
		z-index: 1;
		cursor: ${st};
		touch-action: none;
		user-select: none;
	}

	:host([hidden]) {
		display: none !important;
	}

	:host([disabled]) {
		pointer-events: none;
	}

	svg {
		position: absolute;
		inset: 0;
		width: 100%;
		height: 100%;
		overflow: visible;
		pointer-events: none;
	}

	polyline,
	polygon {
		display: none;
		fill: none;
		stroke-width: 1px;
	}

	#draft {
		stroke: var(--lasso-tool-color, var(--color-accent, #f97316));
	}

	/* Marching ants: black dashes over a white line. */
	#lasso {
		stroke: white;
	}

	#ants {
		stroke: black;
		stroke-dasharray: 4 4;
		animation: march 0.6s linear infinite;
	}

	:host([static]) #ants {
		animation: none;
	}

	@keyframes march {
		to {
			stroke-dashoffset: -8;
		}
	}
`;
class nt extends HTMLElement {
  #t = null;
  /** As drawn, kept intact while browsing images. */
  #e = null;
  /** Resolution of the image lasso was drawn over. */
  #i = null;
  #m;
  #y;
  #w;
  /** Last emitted value, as JSON, to emit only changes. */
  #u = "null";
  /**
   * Element lasso is drawn within, e.g. the gallery: a drawing leaving it
   * is in fact a drag of image to another element.
   */
  area = null;
  #p = ["", ""];
  #s = null;
  /** Where user pressed, in client pixels, to tell a click from a move. */
  #_ = null;
  /** Lasso as it was when user pressed, back if user cancels. */
  #l = null;
  /** Lasso being drawn, which replaces the current one on release. */
  #o = null;
  /** Element outside overlay that pointer is over, while user drags image. */
  #n = null;
  /** Whether drop target accepts displayed image. */
  #d = !1;
  #c = null;
  #v = new ResizeObserver(() => this.#b());
  #k = () => this.#b();
  /** Escape cancels the lasso being drawn, and only that. */
  #E = (t) => {
    t.key === "Escape" && (t.preventDefault(), t.stopPropagation(), this.#x());
  };
  constructor() {
    super();
    const t = this.attachShadow({ mode: "open" }), i = document.createElement("style");
    i.textContent = it;
    const e = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    e.innerHTML = '<polyline id="draft"></polyline><polygon id="lasso"></polygon><polygon id="ants"></polygon>', this.#m = e.querySelector("#draft"), this.#y = e.querySelector("#lasso"), this.#w = e.querySelector("#ants"), t.append(i, e), this.addEventListener("pointerdown", (n) => this.#O(n)), this.addEventListener("pointermove", (n) => this.#$(n)), this.addEventListener("pointerup", () => this.#A()), this.addEventListener("pointercancel", () => this.#C()), this.addEventListener("click", (n) => n.stopPropagation());
  }
  /**
   * Image to draw the lasso over. Lasso persists when another image is
   * displayed, scaled to its resolution, so user finds it back while
   * browsing images.
   */
  get target() {
    return this.#t;
  }
  set target(t) {
    this.#t !== t && (this.#t && (this.#v.unobserve(this.#t), this.#t.removeEventListener("load", this.#k)), this.#t = t, this.#a(), t && (this.#v.observe(t), t.addEventListener("load", this.#k))), this.#b();
  }
  /**
   * Tooltips shown over the image: while no lasso is drawn, e.g. to tell
   * how to draw one, then once drawn, e.g. to tell how to clear it.
   */
  get tooltips() {
    return this.#p;
  }
  set tooltips(t) {
    this.#p = t, this.#r();
  }
  /**
   * Lasso in pixels of the displayed image, scaled to it.
   * Setting it emits no event.
   */
  get value() {
    return this.#h();
  }
  set value(t) {
    this.#e = t && t.map(([i, e]) => [i, e]), this.#i = p(this.#t) ?? this.#i, this.#u = JSON.stringify(x(this.#h())), this.#a(), this.#r();
  }
  clear() {
    this.#e = null, this.#a(), this.#r(), this.#g();
  }
  /** Cover image content, letterbox bands excluded. */
  sync() {
    const t = this.#t, i = this.parentElement;
    if (!t?.isConnected || !i || !t.naturalWidth || !t.naturalHeight) {
      this.style.display = "none";
      return;
    }
    const e = t.getBoundingClientRect(), n = i.getBoundingClientRect(), r = Math.min(
      e.width / t.naturalWidth,
      e.height / t.naturalHeight
    ), a = t.naturalWidth * r, o = t.naturalHeight * r;
    if (a <= 0 || o <= 0) {
      this.style.display = "none";
      return;
    }
    const f = e.left - n.left - i.clientLeft + (e.width - a) / 2, l = e.top - n.top - i.clientTop + (e.height - o) / 2;
    this.style.display = "block", this.style.left = `${f}px`, this.style.top = `${l}px`, this.style.width = `${a}px`, this.style.height = `${o}px`;
  }
  /** Follow displayed image, which may be another one or resized. */
  #b() {
    this.#i ??= p(this.#t), this.sync(), this.#r(), this.#g();
  }
  /**
   * Lasso scaled to displayed image, whose resolution may differ from the
   * drawn one, so it surrounds the same region.
   */
  #h() {
    const t = this.#e, i = p(this.#t);
    if (!t || !i || !this.#i) return t;
    const e = i.width / this.#i.width, n = i.height / this.#i.height;
    return t.map(([r, a]) => [r * e, a * n]);
  }
  #S(t) {
    const i = this.#t, e = this.getBoundingClientRect(), n = L(t.clientX - e.left, 0, e.width), r = L(t.clientY - e.top, 0, e.height);
    return [
      n / e.width * i.naturalWidth,
      r / e.height * i.naturalHeight
    ];
  }
  #r() {
    const t = this.#t, i = !!p(t), e = i ? this.#h() : null, n = i && this.#s === "draw" ? this.#o : null;
    this.title = this.#p[e ? 1 : 0];
    for (const [r, a] of [
      [this.#m, n],
      [this.#y, e],
      [this.#w, e]
    ])
      r.style.display = a ? "inline" : "none", a && r.setAttribute("points", this.#M(a, t));
  }
  /** SVG points of vertices, in overlay pixels. */
  #M(t, i) {
    const e = this.clientWidth / i.naturalWidth, n = this.clientHeight / i.naturalHeight;
    return t.map(([r, a]) => `${r * e},${a * n}`).join(" ");
  }
  /** Emit value, if changed. */
  #g() {
    const t = x(this.#h()), i = JSON.stringify(t);
    i !== this.#u && (this.#u = i, this.dispatchEvent(new CustomEvent("lasso-change", { detail: t })));
  }
  /**
   * A click clears the lasso, and a drag draws a new one, which replaces
   * the current one at once and closes on release. User may as well drag
   * displayed image to another element, e.g. a prompt left of the gallery:
   * leaving the area (gallery) turns the drawing into a drop.
   */
  #O(t) {
    !this.#t || t.button !== 0 || (t.preventDefault(), t.stopPropagation(), this.#a(), this.#e = this.#h(), this.#i = p(this.#t), this.#l = this.#e, this.#s = "press", this.#_ = [t.clientX, t.clientY], this.#o = [this.#S(t)], this.setPointerCapture(t.pointerId), window.addEventListener("keydown", this.#E, !0));
  }
  #$(t) {
    if (!this.#t || !this.#s) return;
    if (this.#s === "press") {
      const [a, o] = this.#_;
      if (Math.hypot(t.clientX - a, t.clientY - o) <= Z)
        return;
      this.#s = "draw", this.#e = null;
    }
    if (this.#s === "draw" && this.#N(t) && (this.#s = "drop", this.#e = this.#l, this.#o = null, this.#r()), this.#s === "drop") {
      this.#H(t);
      return;
    }
    const i = this.#S(t), e = this.#o, [n, r] = e[e.length - 1];
    Math.hypot(i[0] - n, i[1] - r) < tt || (e.push(i), this.#r());
  }
  #A() {
    const t = this.#s;
    t === "press" ? this.clear() : t === "drop" ? (this.#d && (this.#f(this.#n, "drop"), this.#n = null), this.#a()) : t === "draw" && this.#R();
  }
  #C() {
    this.#s && this.#x();
  }
  /** Close lasso as user drew it, unless it encloses nothing. */
  #R() {
    const t = this.#o;
    if (this.#a(), !t || t.length < Q) {
      this.clear();
      return;
    }
    this.#e = t, this.#r(), this.#g();
  }
  /** Back to lasso as it was before user pressed. */
  #x() {
    this.#e = this.#l, this.#a(), this.#r();
  }
  /** Forget ongoing gesture, if any. */
  #a() {
    this.#n && this.#f(this.#n, "dragleave"), window.removeEventListener("keydown", this.#E, !0), this.#s = null, this.#_ = null, this.#l = null, this.#o = null, this.#n = null, this.#d = !1, this.#c = null, this.#L(null);
  }
  /** Cursor of ongoing gesture, if any, in place of the lasso. */
  #L(t) {
    this.style.cursor = t ?? "";
  }
  /** Whether pointer left the area lasso is drawn within. */
  #N(t) {
    const i = (this.area ?? this).getBoundingClientRect();
    return t.clientX < i.left || t.clientX > i.right || t.clientY < i.top || t.clientY > i.bottom;
  }
  /**
   * Drag displayed image over the element pointer is over, outside overlay,
   * as browser would do. Overlay can't let browser drag the image itself:
   * it would take any drag over it, those drawing the lasso included.
   */
  #H(t) {
    const i = document.elementFromPoint(t.clientX, t.clientY), e = i === this ? null : i;
    e !== this.#n && (e && this.#f(e, "dragenter"), this.#n && this.#f(this.#n, "dragleave"), this.#n = e), this.#d = !!e && !this.#f(e, "dragover"), this.#L(this.#d ? "copy" : "grabbing");
  }
  /** Returns false if canceled. */
  #f(t, i) {
    return this.#c || (this.#c = new DataTransfer(), this.#c.setData("text/uri-list", this.#t.currentSrc)), t.dispatchEvent(
      new DragEvent(i, {
        bubbles: !0,
        cancelable: !0,
        composed: !0,
        dataTransfer: this.#c
      })
    );
  }
}
function p(s) {
  return s?.naturalWidth && s.naturalHeight ? { width: s.naturalWidth, height: s.naturalHeight } : null;
}
function x(s) {
  return s && s.map(([t, i]) => [Math.round(t), Math.round(i)]);
}
function L(s, t, i) {
  return Math.max(t, Math.min(i, s));
}
const w = "lasso-tool-overlay";
customElements.get(w) || customElements.define(w, nt);
function at(s, t) {
  I(t, !0);
  const i = /* @__PURE__ */ J(t, ["$$slots", "$$events", "$$legacy"]), e = new U(i), n = document.createElement(w);
  let r = e.props.value ?? null;
  n.value = r;
  let a = null;
  function o(c, h) {
    return JSON.stringify(c ?? null) === JSON.stringify(h ?? null);
  }
  function f(c, h) {
    !c && h ? e.dispatch("drawn") : c && !h && e.dispatch("cleared");
  }
  function l(c) {
    const h = c.querySelector('.media-button img[data-testid="detailed-image"]');
    if (!h) {
      n.target = null, n.remove();
      return;
    }
    const v = h.parentElement;
    n.parentElement !== v && v.append(n), n.area = c, n.target = h;
  }
  function u() {
    const c = e.props.gallery_elem_id, h = c ? document.getElementById(c) : null;
    if (a?.disconnect(), !h) {
      if (!c) return;
      a = new MutationObserver(u), a.observe(document.body, { childList: !0, subtree: !0 });
      return;
    }
    a = new MutationObserver(() => l(h)), a.observe(h, {
      childList: !0,
      subtree: !0,
      attributes: !0,
      attributeFilter: ["src"]
    }), l(h);
  }
  $(() => {
    n.addEventListener("lasso-change", (c) => {
      const h = c.detail;
      f(r, h), r = h, e.props.value = h, e.dispatch("input"), e.dispatch("change");
    }), u();
  }), j(() => {
    a?.disconnect(), n.target = null, n.remove();
  }), d(() => {
    const c = e.props.value ?? null;
    o(c, r) || (f(r, c), r = c, n.value = c, e.dispatch("change"));
  }), d(() => {
    n.toggleAttribute("disabled", e.shared.interactive === !1), n.toggleAttribute("hidden", e.shared.visible === !1), n.toggleAttribute("static", e.props.marching_ants === !1), n.tooltips = [
      e.props.draw_tooltip ?? "",
      e.props.clear_tooltip ?? ""
    ];
  }), P();
}
export {
  at as default
};
