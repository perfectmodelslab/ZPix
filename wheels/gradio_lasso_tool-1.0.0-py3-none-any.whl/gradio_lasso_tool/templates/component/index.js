import { i as de, g as se, o as pe, a as it, b as ge, T as ye, c as me, d as xe, e as ct, f as Mt, r as _e, h as lt, p as be, j as It, m as ve, s as Ee, k as vt, E as Et, L as we, N as Se, l as ke, n as Me, q as Ie, u as V, t as Re, S as Pe, v as Le, w as Ae, x as K, y as Ne, z as D, A as re, B as ut, C as L, D as Z, F as Rt, G as dt, H as Oe, I as Te, J as Ce, K as Be, M as q, O as Pt, P as X, Q as ze, R as $e } from "./render-BKVekDVV.js";
function oe(s) {
  throw new Error("https://svelte.dev/e/lifecycle_outside_component");
}
const je = [];
function Fe(s, t = !1, e = !1) {
  return tt(s, /* @__PURE__ */ new Map(), "", je, null, e);
}
function tt(s, t, e, n, i = null, r = !1) {
  if (typeof s == "object" && s !== null) {
    var o = t.get(s);
    if (o !== void 0) return o;
    if (s instanceof Map) return (
      /** @type {Snapshot<T>} */
      new Map(s)
    );
    if (s instanceof Set) return (
      /** @type {Snapshot<T>} */
      new Set(s)
    );
    if (de(s)) {
      var l = (
        /** @type {Snapshot<any>} */
        Array(s.length)
      );
      t.set(s, l), i !== null && t.set(i, l);
      for (var a = 0; a < s.length; a += 1) {
        var f = s[a];
        a in s && (l[a] = tt(f, t, e, n, null, r));
      }
      return l;
    }
    if (se(s) === pe) {
      l = {}, t.set(s, l), i !== null && t.set(i, l);
      for (var d in s)
        l[d] = tt(
          // @ts-expect-error
          s[d],
          t,
          e,
          n,
          null,
          r
        );
      return l;
    }
    if (s instanceof Date)
      return (
        /** @type {Snapshot<T>} */
        structuredClone(s)
      );
    if (typeof /** @type {T & { toJSON?: any } } */
    s.toJSON == "function" && !r)
      return tt(
        /** @type {T & { toJSON(): any } } */
        s.toJSON(),
        t,
        e,
        n,
        // Associate the instance with the toJSON clone
        s
      );
  }
  if (s instanceof EventTarget)
    return (
      /** @type {Snapshot<T>} */
      s
    );
  try {
    return (
      /** @type {Snapshot<T>} */
      structuredClone(s)
    );
  } catch {
    return (
      /** @type {Snapshot<T>} */
      s
    );
  }
}
function le(s) {
  var t = document.createElement("template");
  return t.innerHTML = s.replaceAll("<!>", "<!---->"), t.content;
}
function st(s, t) {
  var e = (
    /** @type {Effect} */
    xe
  );
  e.nodes === null && (e.nodes = { start: s, end: t, a: null, t: null });
}
// @__NO_SIDE_EFFECTS__
function wt(s, t) {
  var e = (t & ye) !== 0, n = (t & me) !== 0, i, r = !s.startsWith("<!>");
  return () => {
    i === void 0 && (i = le(r ? s : "<!>" + s), e || (i = /** @type {TemplateNode} */
    it(i)));
    var o = (
      /** @type {TemplateNode} */
      n || ge ? document.importNode(i, !0) : i.cloneNode(!0)
    );
    if (e) {
      var l = (
        /** @type {TemplateNode} */
        it(o)
      ), a = (
        /** @type {TemplateNode} */
        o.lastChild
      );
      st(l, a);
    } else
      st(o, o);
    return o;
  };
}
// @__NO_SIDE_EFFECTS__
function Ge(s, t, e = "svg") {
  var n = !s.startsWith("<!>"), i = `<${e}>${n ? s : "<!>" + s}</${e}>`, r;
  return () => {
    if (!r) {
      var o = (
        /** @type {DocumentFragment} */
        le(i)
      ), l = (
        /** @type {Element} */
        it(o)
      );
      r = /** @type {Element} */
      it(l);
    }
    var a = (
      /** @type {TemplateNode} */
      r.cloneNode(!0)
    );
    return st(a, a), a;
  };
}
// @__NO_SIDE_EFFECTS__
function De(s, t) {
  return /* @__PURE__ */ Ge(s, t, "svg");
}
function Ye() {
  var s = document.createDocumentFragment(), t = document.createComment(""), e = ct();
  return s.append(t, e), st(t, e), s;
}
function W(s, t) {
  s !== null && s.before(
    /** @type {Node} */
    t
  );
}
class St {
  /** @type {TemplateNode} */
  anchor;
  /** @type {Map<Batch, Key>} */
  #t = /* @__PURE__ */ new Map();
  /**
   * Map of keys to effects that are currently rendered in the DOM.
   * These effects are visible and actively part of the document tree.
   * Example:
   * ```
   * {#if condition}
   * 	foo
   * {:else}
   * 	bar
   * {/if}
   * ```
   * Can result in the entries `true->Effect` and `false->Effect`
   * @type {Map<Key, Effect>}
   */
  #e = /* @__PURE__ */ new Map();
  /**
   * Similar to #onscreen with respect to the keys, but contains branches that are not yet
   * in the DOM, because their insertion is deferred.
   * @type {Map<Key, Branch>}
   */
  #n = /* @__PURE__ */ new Map();
  /**
   * Keys of effects that are currently outroing
   * @type {Set<Key>}
   */
  #h = /* @__PURE__ */ new Set();
  /**
   * Whether to pause (i.e. outro) on change, or destroy immediately.
   * This is necessary for `<svelte:element>`
   */
  #f = !0;
  /**
   * @param {TemplateNode} anchor
   * @param {boolean} transition
   */
  constructor(t, e = !0) {
    this.anchor = t, this.#f = e;
  }
  #c = () => {
    var t = (
      /** @type {Batch} */
      Mt
    );
    if (this.#t.has(t)) {
      var e = (
        /** @type {Key} */
        this.#t.get(t)
      ), n = this.#e.get(e);
      if (n)
        _e(n), this.#h.delete(e);
      else {
        var i = this.#n.get(e);
        i && (this.#e.set(e, i.effect), this.#n.delete(e), i.fragment.lastChild.remove(), this.anchor.before(i.fragment), n = i.effect);
      }
      for (const [r, o] of this.#t) {
        if (this.#t.delete(r), r === t)
          break;
        const l = this.#n.get(o);
        l && (lt(l.effect), this.#n.delete(o));
      }
      for (const [r, o] of this.#e) {
        if (r === e || this.#h.has(r)) continue;
        const l = () => {
          if (Array.from(this.#t.values()).includes(r)) {
            var f = document.createDocumentFragment();
            ve(o, f), f.append(ct()), this.#n.set(r, { effect: o, fragment: f });
          } else
            lt(o);
          this.#h.delete(r), this.#e.delete(r);
        };
        this.#f || !n ? (this.#h.add(r), be(o, l, !1)) : l();
      }
    }
  };
  /**
   * @param {Batch} batch
   */
  #u = (t) => {
    this.#t.delete(t);
    const e = Array.from(this.#t.values());
    for (const [n, i] of this.#n)
      e.includes(n) || (lt(i.effect), this.#n.delete(n));
  };
  /**
   *
   * @param {any} key
   * @param {null | ((target: TemplateNode) => void)} fn
   */
  ensure(t, e) {
    var n = (
      /** @type {Batch} */
      Mt
    ), i = Ee();
    if (e && !this.#e.has(t) && !this.#n.has(t))
      if (i) {
        var r = document.createDocumentFragment(), o = ct();
        r.append(o), this.#n.set(t, {
          effect: It(() => e(o)),
          fragment: r
        });
      } else
        this.#e.set(
          t,
          It(() => e(this.anchor))
        );
    if (this.#t.set(n, t), i) {
      for (const [l, a] of this.#e)
        l === t ? n.skipped_effects.delete(a) : n.skipped_effects.add(a);
      for (const [l, a] of this.#n)
        l === t ? n.skipped_effects.delete(a.effect) : n.skipped_effects.add(a.effect);
      n.oncommit(this.#c), n.ondiscard(this.#u);
    } else
      this.#c();
  }
}
function Lt(s, t, e = !1) {
  var n = new St(s), i = e ? Et : 0;
  function r(o, l) {
    n.ensure(o, l);
  }
  vt(() => {
    var o = !1;
    t((l, a = !0) => {
      o = !0, r(a, l);
    }), o || r(!1, null);
  }, i);
}
function He(s, t, ...e) {
  var n = new St(s);
  vt(() => {
    const i = t() ?? null;
    n.ensure(i, i && ((r) => i(r, ...e)));
  }, Et);
}
function Ue(s, t, e) {
  var n = new St(s);
  vt(() => {
    var i = t() ?? null;
    n.ensure(i, i && ((r) => e(r, i)));
  }, Et);
}
const At = [...` 	
\r\f \v\uFEFF`];
function qe(s, t, e) {
  var n = s == null ? "" : "" + s;
  if (e) {
    for (var i in e)
      if (e[i])
        n = n ? n + " " + i : i;
      else if (n.length)
        for (var r = i.length, o = 0; (o = n.indexOf(i, o)) >= 0; ) {
          var l = o + r;
          (o === 0 || At.includes(n[o - 1])) && (l === n.length || At.includes(n[l])) ? n = (o === 0 ? "" : n.substring(0, o)) + n.substring(l + 1) : o = l;
        }
  }
  return n === "" ? null : n;
}
function Nt(s, t = !1) {
  var e = t ? " !important;" : ";", n = "";
  for (var i in s) {
    var r = s[i];
    r != null && r !== "" && (n += " " + i + ": " + r + e);
  }
  return n;
}
function Xe(s, t) {
  if (t) {
    var e = "", n, i;
    return Array.isArray(t) ? (n = t[0], i = t[1]) : n = t, n && (e += Nt(n)), i && (e += Nt(i, !0)), e = e.trim(), e === "" ? null : e;
  }
  return String(s);
}
function Ot(s, t, e, n, i, r) {
  var o = s.__className;
  if (o !== e || o === void 0) {
    var l = qe(e, n, r);
    l == null ? s.removeAttribute("class") : s.className = l, s.__className = e;
  } else if (r && i !== r)
    for (var a in r) {
      var f = !!r[a];
      (i == null || f !== !!i[a]) && s.classList.toggle(a, f);
    }
  return r;
}
function ht(s, t = {}, e, n) {
  for (var i in e) {
    var r = e[i];
    t[i] !== r && (e[i] == null ? s.style.removeProperty(i) : s.style.setProperty(i, r, n));
  }
}
function We(s, t, e, n) {
  var i = s.__style;
  if (i !== t) {
    var r = Xe(t, n);
    r == null ? s.removeAttribute("style") : s.style.cssText = r, s.__style = t;
  } else n && (Array.isArray(n) ? (ht(s, e?.[0], n[0]), ht(s, e?.[1], n[1], "important")) : ht(s, e, n));
  return n;
}
const Qe = /* @__PURE__ */ Symbol("is custom element"), Ve = /* @__PURE__ */ Symbol("is html");
function et(s, t, e, n) {
  var i = Je(s);
  i[t] !== (i[t] = e) && (t === "loading" && (s[we] = e), e == null ? s.removeAttribute(t) : typeof e != "string" && Ke(s).includes(t) ? s[t] = e : s.setAttribute(t, e));
}
function Je(s) {
  return (
    /** @type {Record<string | symbol, unknown>} **/
    // @ts-expect-error
    s.__attributes ??= {
      [Qe]: s.nodeName.includes("-"),
      [Ve]: s.namespaceURI === Se
    }
  );
}
var Tt = /* @__PURE__ */ new Map();
function Ke(s) {
  var t = s.getAttribute("is") || s.nodeName, e = Tt.get(t);
  if (e) return e;
  Tt.set(t, e = []);
  for (var n, i = s, r = Element.prototype; r !== i; ) {
    n = ke(i);
    for (var o in n)
      n[o].set && e.push(o);
    i = se(i);
  }
  return e;
}
function Ct(s, t) {
  return s === t || s?.[Pe] === t;
}
function Ze(s = {}, t, e, n) {
  return Me(() => {
    var i, r;
    return Ie(() => {
      i = r, r = [], V(() => {
        s !== e(...r) && (t(s, ...r), i && Ct(e(...i), s) && t(null, ...i));
      });
    }), () => {
      Re(() => {
        r && Ct(e(...r), s) && t(null, ...r);
      });
    };
  }), s;
}
function tn(s, t, e) {
  if (s == null)
    return t(void 0), Le;
  const n = V(
    () => s.subscribe(
      t,
      // @ts-expect-error
      e
    )
  );
  return n.unsubscribe ? () => n.unsubscribe() : n;
}
function en(s) {
  let t;
  return tn(s, (e) => t = e)(), t;
}
const nn = {
  get(s, t) {
    if (!s.exclude.includes(t))
      return s.props[t];
  },
  set(s, t) {
    return !1;
  },
  getOwnPropertyDescriptor(s, t) {
    if (!s.exclude.includes(t) && t in s.props)
      return {
        enumerable: !0,
        configurable: !0,
        value: s.props[t]
      };
  },
  has(s, t) {
    return s.exclude.includes(t) ? !1 : t in s.props;
  },
  ownKeys(s) {
    return Reflect.ownKeys(s.props).filter((t) => !s.exclude.includes(t));
  }
};
// @__NO_SIDE_EFFECTS__
function sn(s, t, e) {
  return new Proxy(
    { props: s, exclude: t },
    nn
  );
}
function A(s, t, e, n) {
  var i = (
    /** @type {V} */
    n
  ), r = !0, o = () => (r && (r = !1, i = /** @type {V} */
  n), i), l;
  l = /** @type {V} */
  s[t], l === void 0 && n !== void 0 && (l = o());
  var a;
  return a = () => {
    var f = (
      /** @type {V} */
      s[t]
    );
    return f === void 0 ? o() : (r = !0, f);
  }, a;
}
Ae();
function he(s) {
  K === null && oe(), Ne && K.l !== null ? on(K).m.push(s) : D(() => {
    const t = V(s);
    if (typeof t == "function") return (
      /** @type {() => void} */
      t
    );
  });
}
function rn(s) {
  K === null && oe(), he(() => () => V(s));
}
function on(s) {
  var t = (
    /** @type {ComponentContextLegacy} */
    s.l
  );
  return t.u ??= { a: [], b: [], m: [] };
}
var ln = /* @__PURE__ */ wt('<span class="svelte-12hu46v"> </span>'), hn = /* @__PURE__ */ wt("<button><!> <div><!> <!></div></button>");
function an(s, t) {
  let e = A(t, "label", 3, ""), n = A(t, "show_label", 3, !1), i = A(t, "pending", 3, !1), r = A(t, "size", 3, "small"), o = A(t, "padded", 3, !0), l = A(t, "highlight", 3, !1), a = A(t, "disabled", 3, !1), f = A(t, "hasPopup", 3, !1), d = A(t, "color", 3, "var(--block-label-text-color)"), h = A(t, "transparent", 3, !1), c = A(t, "background", 3, "var(--block-background-fill)"), u = A(t, "border", 3, "transparent"), m = dt(() => l() ? "var(--color-accent)" : d());
  var p = hn();
  let g;
  p.__click = function(...b) {
    t.onclick?.apply(this, b);
  };
  let y;
  var x = Z(p);
  {
    var S = (b) => {
      var w = ln(), I = Z(w);
      ut(() => Oe(I, e())), W(b, w);
    };
    Lt(x, (b) => {
      n() && b(S);
    });
  }
  var _ = Rt(x, 2);
  let v;
  var E = Z(_);
  Ue(E, () => t.Icon, (b, w) => {
    w(b, {});
  });
  var P = Rt(E, 2);
  {
    var k = (b) => {
      var w = Ye(), I = Te(w);
      He(I, () => t.children), W(b, w);
    };
    Lt(P, (b) => {
      t.children && b(k);
    });
  }
  ut(() => {
    g = Ot(p, 1, "icon-button svelte-12hu46v", null, g, {
      pending: i(),
      padded: o(),
      highlight: l(),
      transparent: h()
    }), p.disabled = a(), et(p, "aria-label", e()), et(p, "aria-haspopup", f()), et(p, "title", e()), y = We(p, "", y, {
      "--border-color": u(),
      color: !a() && L(m) ? L(m) : "var(--block-label-text-color)",
      "--bg-color": a() ? "auto" : c()
    }), v = Ot(_, 1, "svelte-12hu46v", null, v, {
      "x-small": r() === "x-small",
      small: r() === "small",
      large: r() === "large",
      medium: r() === "medium"
    });
  }), W(s, p);
}
re(["click"]);
const fn = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], Bt = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
fn.reduce((s, { color: t, primary: e, secondary: n }) => ({
  ...s,
  [t]: {
    primary: Bt[t][e],
    secondary: Bt[t][n]
  }
}), {});
function cn(s) {
  let t;
  const e = Be((i) => {
    let r = !1;
    const o = s.subscribe((l) => {
      t = l, r && i();
    });
    return r = !0, o;
  });
  function n() {
    return Ce() ? (e(), t) : en(s);
  }
  return "set" in s ? {
    get current() {
      return n();
    },
    set current(i) {
      s.set(i);
    }
  } : {
    get current() {
      return n();
    }
  };
}
const un = "__i18n__", dn = [
  "label",
  "info",
  "placeholder",
  "description",
  "title",
  "value"
], pn = [
  "elem_id",
  "elem_classes",
  "visible",
  "interactive",
  "server_fns",
  "server",
  "id",
  "target",
  "theme_mode",
  "version",
  "root",
  "autoscroll",
  "max_file_size",
  "formatter",
  "client",
  "load_component",
  "scale",
  "min_width",
  "theme",
  "padding",
  "loading_status",
  "label",
  "show_label",
  "validation_error",
  "show_progress",
  "api_prefix",
  "container",
  "attached_events",
  "register_component",
  "dispatcher"
];
function gn(s) {
  return typeof s == "string" && s.includes(un);
}
class yn {
  load_component;
  #t = q(Pt({}));
  get shared() {
    return L(this.#t);
  }
  set shared(t) {
    X(this.#t, t, !0);
  }
  #e = q(Pt({}));
  get props() {
    return L(this.#e);
  }
  set props(t) {
    X(this.#e, t, !0);
  }
  #n = q((t) => t);
  get i18n() {
    return L(this.#n);
  }
  set i18n(t) {
    X(this.#n, t, !0);
  }
  i18n_store;
  _i18n_from_store;
  translatable_props = {};
  dispatcher;
  last_update = null;
  shared_props = pn;
  mounted = !1;
  old_value;
  register_component;
  constructor(t, e) {
    for (const n in t.shared_props)
      this.shared[n] = t.shared_props[n];
    for (const n in t.props)
      n !== "i18n_store" && (this.props[n] = t.props[n]);
    if (e)
      for (const n in e)
        this.props[n] === void 0 && (this.props[n] = e[n]);
    this.i18n = this.props.i18n ?? ((n) => n), this.i18n_store = t.props.i18n_store, this._i18n_from_store = this.i18n_store ? cn(this.i18n_store) : void 0;
    for (const n of dn)
      this.shared[n] = this._translate_and_store(
        "shared",
        n,
        // @ts-ignore
        t.shared_props[n]
      ), this.props[n] = this._translate_and_store(
        "props",
        n,
        // @ts-ignore
        t.props[n]
      );
    this.load_component = this.shared.load_component, this.register_component = this.shared.register_component || (() => {
    }), this.dispatcher = this.shared.dispatcher || (() => {
    }), this.register_component(
      t.shared_props.id,
      // @ts-ignore
      this.set_data.bind(this),
      this.get_data.bind(this)
    ), D(() => {
      for (const n in t.shared_props)
        this._is_i18n_managed(`shared.${n}`, t.shared_props[n]) || (this.shared[n] = t.shared_props[n]);
      for (const n in t.props)
        n !== "i18n_store" && (this._is_i18n_managed(`props.${n}`, t.props[n]) || (this.props[n] = t.props[n]));
      this.register_component(
        t.shared_props.id,
        // @ts-ignore
        this.set_data.bind(this),
        this.get_data.bind(this)
      ), V(() => {
        this.shared.id = t.shared_props.id;
      });
    }), D(() => this.i18n_store ? this.i18n_store.subscribe(() => {
      for (const [i, r] of Object.entries(this.translatable_props)) {
        const [o, l] = i.split("."), a = this.i18n(r);
        o === "shared" ? this.shared[l] = a : this.props[l] = a;
      }
    }) : void 0);
  }
  // check if props are translatable
  _is_i18n_managed(t, e) {
    const n = this.translatable_props[t];
    return n ? e === n ? !0 : (delete this.translatable_props[t], !1) : !1;
  }
  _translate_and_store(t, e, n) {
    if (typeof n != "string") return n;
    const i = this.i18n(n);
    return i !== n && (this.translatable_props[`${t}.${e}`] = n), i;
  }
  // Reactive variant of `i18n`. Reading it inside a derived or template
  // subscribes to the live locale store (via Svelte's createSubscriber), so
  // the caller re-runs when the locale changes at runtime. The store is only
  // the reactivity trigger; translation always goes through `this.i18n` so a
  // custom formatter passed via props keeps taking effect.
  live_i18n = (t) => (this._i18n_from_store?.current, this.i18n(t));
  dispatch(t, e) {
    this.dispatcher(this.shared.id, t, e);
  }
  async get_data() {
    return Fe(this.props);
  }
  update(t) {
    this.set_data(t);
  }
  set_data(t) {
    for (const e in t) {
      const n = t[e], i = gn(n) ? this._translate_and_store(this.shared_props.includes(e) ? "shared" : "props", e, n) : n;
      if (this.shared_props.includes(e)) {
        const r = e;
        this.shared[r] = i;
        continue;
      }
      this.props[e] = i;
    }
  }
  watch_for_change() {
    D(() => {
      this.mounted || (this.old_value = this.props.value, this.mounted = !0), this.old_value != this.props.value && (this.old_value = this.props.value, this.dispatch("change"));
    });
  }
}
re(["click"]);
const zt = "canvas-host", mn = "canvas-host-request";
function xn(s, t) {
  const e = (n) => {
    const i = n.detail;
    i.id === s && t(i);
  };
  return window.addEventListener(zt, e), window.dispatchEvent(
    new CustomEvent(mn, { detail: { canvas_id: s, resolve: t } })
  ), () => window.removeEventListener(zt, e);
}
var _n = /* @__PURE__ */ De('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3.704 14.467a10 8 0 1 1 3.115 2.375"></path><path d="M7 22a5 5 0 0 1-2-3.994"></path><circle cx="5" cy="16" r="2"></circle></svg>');
function bn(s) {
  var t = _n();
  W(s, t);
}
class F {
  constructor(t, e) {
    this.next = null, this.key = t, this.data = e, this.left = null, this.right = null;
  }
}
function vn(s, t) {
  return s > t ? 1 : s < t ? -1 : 0;
}
function z(s, t, e) {
  const n = new F(null, null);
  let i = n, r = n;
  for (; ; ) {
    const o = e(s, t.key);
    if (o < 0) {
      if (t.left === null) break;
      if (e(s, t.left.key) < 0) {
        const l = t.left;
        if (t.left = l.right, l.right = t, t = l, t.left === null) break;
      }
      r.left = t, r = t, t = t.left;
    } else if (o > 0) {
      if (t.right === null) break;
      if (e(s, t.right.key) > 0) {
        const l = t.right;
        if (t.right = l.left, l.left = t, t = l, t.right === null) break;
      }
      i.right = t, i = t, t = t.right;
    } else break;
  }
  return i.right = t.left, r.left = t.right, t.left = n.right, t.right = n.left, t;
}
function at(s, t, e, n) {
  const i = new F(s, t);
  if (e === null)
    return i.left = i.right = null, i;
  e = z(s, e, n);
  const r = n(s, e.key);
  return r < 0 ? (i.left = e.left, i.right = e, e.left = null) : r >= 0 && (i.right = e.right, i.left = e, e.right = null), i;
}
function $t(s, t, e) {
  let n = null, i = null;
  if (t) {
    t = z(s, t, e);
    const r = e(t.key, s);
    r === 0 ? (n = t.left, i = t.right) : r < 0 ? (i = t.right, t.right = null, n = t) : (n = t.left, t.left = null, i = t);
  }
  return { left: n, right: i };
}
function En(s, t, e) {
  return t === null ? s : (s === null || (t = z(s.key, t, e), t.left = s), t);
}
function pt(s, t, e, n, i) {
  if (s) {
    n(`${t}${e ? "└── " : "├── "}${i(s)}
`);
    const r = t + (e ? "    " : "│   ");
    s.left && pt(s.left, r, !1, n, i), s.right && pt(s.right, r, !0, n, i);
  }
}
class kt {
  constructor(t = vn) {
    this._root = null, this._size = 0, this._comparator = t;
  }
  /**
   * Inserts a key, allows duplicates
   */
  insert(t, e) {
    return this._size++, this._root = at(t, e, this._root, this._comparator);
  }
  /**
   * Adds a key, if it is not present in the tree
   */
  add(t, e) {
    const n = new F(t, e);
    this._root === null && (n.left = n.right = null, this._size++, this._root = n);
    const i = this._comparator, r = z(t, this._root, i), o = i(t, r.key);
    return o === 0 ? this._root = r : (o < 0 ? (n.left = r.left, n.right = r, r.left = null) : o > 0 && (n.right = r.right, n.left = r, r.right = null), this._size++, this._root = n), this._root;
  }
  /**
   * @param  {Key} key
   * @return {Node|null}
   */
  remove(t) {
    this._root = this._remove(t, this._root, this._comparator);
  }
  /**
   * Deletes i from the tree if it's there
   */
  _remove(t, e, n) {
    let i;
    return e === null ? null : (e = z(t, e, n), n(t, e.key) === 0 ? (e.left === null ? i = e.right : (i = z(t, e.left, n), i.right = e.right), this._size--, i) : e);
  }
  /**
   * Removes and returns the node with smallest key
   */
  pop() {
    let t = this._root;
    if (t) {
      for (; t.left; ) t = t.left;
      return this._root = z(t.key, this._root, this._comparator), this._root = this._remove(t.key, this._root, this._comparator), { key: t.key, data: t.data };
    }
    return null;
  }
  /**
   * Find without splaying
   */
  findStatic(t) {
    let e = this._root;
    const n = this._comparator;
    for (; e; ) {
      const i = n(t, e.key);
      if (i === 0) return e;
      i < 0 ? e = e.left : e = e.right;
    }
    return null;
  }
  find(t) {
    return this._root && (this._root = z(t, this._root, this._comparator), this._comparator(t, this._root.key) !== 0) ? null : this._root;
  }
  contains(t) {
    let e = this._root;
    const n = this._comparator;
    for (; e; ) {
      const i = n(t, e.key);
      if (i === 0) return !0;
      i < 0 ? e = e.left : e = e.right;
    }
    return !1;
  }
  forEach(t, e) {
    let n = this._root;
    const i = [];
    let r = !1;
    for (; !r; )
      n !== null ? (i.push(n), n = n.left) : i.length !== 0 ? (n = i.pop(), t.call(e, n), n = n.right) : r = !0;
    return this;
  }
  /**
   * Walk key range from `low` to `high`. Stops if `fn` returns a value.
   */
  range(t, e, n, i) {
    const r = [], o = this._comparator;
    let l = this._root, a;
    for (; r.length !== 0 || l; )
      if (l)
        r.push(l), l = l.left;
      else {
        if (l = r.pop(), a = o(l.key, e), a > 0)
          break;
        if (o(l.key, t) >= 0 && n.call(i, l))
          return this;
        l = l.right;
      }
    return this;
  }
  /**
   * Returns array of keys
   */
  keys() {
    const t = [];
    return this.forEach(({ key: e }) => {
      t.push(e);
    }), t;
  }
  /**
   * Returns array of all the data in the nodes
   */
  values() {
    const t = [];
    return this.forEach(({ data: e }) => {
      t.push(e);
    }), t;
  }
  min() {
    return this._root ? this.minNode(this._root).key : null;
  }
  max() {
    return this._root ? this.maxNode(this._root).key : null;
  }
  minNode(t = this._root) {
    if (t) for (; t.left; ) t = t.left;
    return t;
  }
  maxNode(t = this._root) {
    if (t) for (; t.right; ) t = t.right;
    return t;
  }
  /**
   * Returns node at given index
   */
  at(t) {
    let e = this._root, n = !1, i = 0;
    const r = [];
    for (; !n; )
      if (e)
        r.push(e), e = e.left;
      else if (r.length > 0) {
        if (e = r.pop(), i === t) return e;
        i++, e = e.right;
      } else n = !0;
    return null;
  }
  next(t) {
    let e = this._root, n = null;
    if (t.right) {
      for (n = t.right; n.left; ) n = n.left;
      return n;
    }
    const i = this._comparator;
    for (; e; ) {
      const r = i(t.key, e.key);
      if (r === 0) break;
      r < 0 ? (n = e, e = e.left) : e = e.right;
    }
    return n;
  }
  prev(t) {
    let e = this._root, n = null;
    if (t.left !== null) {
      for (n = t.left; n.right; ) n = n.right;
      return n;
    }
    const i = this._comparator;
    for (; e; ) {
      const r = i(t.key, e.key);
      if (r === 0) break;
      r < 0 ? e = e.left : (n = e, e = e.right);
    }
    return n;
  }
  clear() {
    return this._root = null, this._size = 0, this;
  }
  toList() {
    return Sn(this._root);
  }
  /**
   * Bulk-load items. Both array have to be same size
   */
  load(t, e = [], n = !1) {
    let i = t.length;
    const r = this._comparator;
    if (n && mt(t, e, 0, i - 1, r), this._root === null)
      this._root = gt(t, e, 0, i), this._size = i;
    else {
      const o = kn(
        this.toList(),
        wn(t, e),
        r
      );
      i = this._size + i, this._root = yt({ head: o }, 0, i);
    }
    return this;
  }
  isEmpty() {
    return this._root === null;
  }
  get size() {
    return this._size;
  }
  get root() {
    return this._root;
  }
  toString(t = (e) => String(e.key)) {
    const e = [];
    return pt(this._root, "", !0, (n) => e.push(n), t), e.join("");
  }
  update(t, e, n) {
    const i = this._comparator;
    let { left: r, right: o } = $t(t, this._root, i);
    i(t, e) < 0 ? o = at(e, n, o, i) : r = at(e, n, r, i), this._root = En(r, o, i);
  }
  split(t) {
    return $t(t, this._root, this._comparator);
  }
  *[Symbol.iterator]() {
    let t = this._root;
    const e = [];
    let n = !1;
    for (; !n; )
      t !== null ? (e.push(t), t = t.left) : e.length !== 0 ? (t = e.pop(), yield t, t = t.right) : n = !0;
  }
}
function gt(s, t, e, n) {
  const i = n - e;
  if (i > 0) {
    const r = e + Math.floor(i / 2), o = s[r], l = t[r], a = new F(o, l);
    return a.left = gt(s, t, e, r), a.right = gt(s, t, r + 1, n), a;
  }
  return null;
}
function wn(s, t) {
  const e = new F(null, null);
  let n = e;
  for (let i = 0; i < s.length; i++)
    n = n.next = new F(s[i], t[i]);
  return n.next = null, e.next;
}
function Sn(s) {
  let t = s;
  const e = [];
  let n = !1;
  const i = new F(null, null);
  let r = i;
  for (; !n; )
    t ? (e.push(t), t = t.left) : e.length > 0 ? (t = r = r.next = e.pop(), t = t.right) : n = !0;
  return r.next = null, i.next;
}
function yt(s, t, e) {
  const n = e - t;
  if (n > 0) {
    const i = t + Math.floor(n / 2), r = yt(s, t, i), o = s.head;
    return o.left = r, s.head = s.head.next, o.right = yt(s, i + 1, e), o;
  }
  return null;
}
function kn(s, t, e) {
  const n = new F(null, null);
  let i = n, r = s, o = t;
  for (; r !== null && o !== null; )
    e(r.key, o.key) < 0 ? (i.next = r, r = r.next) : (i.next = o, o = o.next), i = i.next;
  return r !== null ? i.next = r : o !== null && (i.next = o), n.next;
}
function mt(s, t, e, n, i) {
  if (e >= n) return;
  const r = s[e + n >> 1];
  let o = e - 1, l = n + 1;
  for (; ; ) {
    do
      o++;
    while (i(s[o], r) < 0);
    do
      l--;
    while (i(s[l], r) > 0);
    if (o >= l) break;
    let a = s[o];
    s[o] = s[l], s[l] = a, a = t[o], t[o] = t[l], t[l] = a;
  }
  mt(s, t, e, l, i), mt(s, t, l + 1, n, i);
}
const B = 11102230246251565e-32, M = 134217729, Mn = (3 + 8 * B) * B;
function ft(s, t, e, n, i) {
  let r, o, l, a, f = t[0], d = n[0], h = 0, c = 0;
  d > f == d > -f ? (r = f, f = t[++h]) : (r = d, d = n[++c]);
  let u = 0;
  if (h < s && c < e)
    for (d > f == d > -f ? (o = f + r, l = r - (o - f), f = t[++h]) : (o = d + r, l = r - (o - d), d = n[++c]), r = o, l !== 0 && (i[u++] = l); h < s && c < e; )
      d > f == d > -f ? (o = r + f, a = o - r, l = r - (o - a) + (f - a), f = t[++h]) : (o = r + d, a = o - r, l = r - (o - a) + (d - a), d = n[++c]), r = o, l !== 0 && (i[u++] = l);
  for (; h < s; )
    o = r + f, a = o - r, l = r - (o - a) + (f - a), f = t[++h], r = o, l !== 0 && (i[u++] = l);
  for (; c < e; )
    o = r + d, a = o - r, l = r - (o - a) + (d - a), d = n[++c], r = o, l !== 0 && (i[u++] = l);
  return (r !== 0 || u === 0) && (i[u++] = r), u;
}
function In(s, t) {
  let e = t[0];
  for (let n = 1; n < s; n++) e += t[n];
  return e;
}
function J(s) {
  return new Float64Array(s);
}
const Rn = (3 + 16 * B) * B, Pn = (2 + 12 * B) * B, Ln = (9 + 64 * B) * B * B, G = J(4), jt = J(8), Ft = J(12), Gt = J(16), R = J(4);
function An(s, t, e, n, i, r, o) {
  let l, a, f, d, h, c, u, m, p, g, y, x, S, _, v, E, P, k;
  const b = s - i, w = e - i, I = t - r, O = n - r;
  _ = b * O, c = M * b, u = c - (c - b), m = b - u, c = M * O, p = c - (c - O), g = O - p, v = m * g - (_ - u * p - m * p - u * g), E = I * w, c = M * I, u = c - (c - I), m = I - u, c = M * w, p = c - (c - w), g = w - p, P = m * g - (E - u * p - m * p - u * g), y = v - P, h = v - y, G[0] = v - (y + h) + (h - P), x = _ + y, h = x - _, S = _ - (x - h) + (y - h), y = S - E, h = S - y, G[1] = S - (y + h) + (h - E), k = x + y, h = k - x, G[2] = x - (k - h) + (y - h), G[3] = k;
  let C = In(4, G), Y = Pn * o;
  if (C >= Y || -C >= Y || (h = s - b, l = s - (b + h) + (h - i), h = e - w, f = e - (w + h) + (h - i), h = t - I, a = t - (I + h) + (h - r), h = n - O, d = n - (O + h) + (h - r), l === 0 && a === 0 && f === 0 && d === 0) || (Y = Ln * o + Mn * Math.abs(C), C += b * d + O * l - (I * f + w * a), C >= Y || -C >= Y)) return C;
  _ = l * O, c = M * l, u = c - (c - l), m = l - u, c = M * O, p = c - (c - O), g = O - p, v = m * g - (_ - u * p - m * p - u * g), E = a * w, c = M * a, u = c - (c - a), m = a - u, c = M * w, p = c - (c - w), g = w - p, P = m * g - (E - u * p - m * p - u * g), y = v - P, h = v - y, R[0] = v - (y + h) + (h - P), x = _ + y, h = x - _, S = _ - (x - h) + (y - h), y = S - E, h = S - y, R[1] = S - (y + h) + (h - E), k = x + y, h = k - x, R[2] = x - (k - h) + (y - h), R[3] = k;
  const fe = ft(4, G, 4, R, jt);
  _ = b * d, c = M * b, u = c - (c - b), m = b - u, c = M * d, p = c - (c - d), g = d - p, v = m * g - (_ - u * p - m * p - u * g), E = I * f, c = M * I, u = c - (c - I), m = I - u, c = M * f, p = c - (c - f), g = f - p, P = m * g - (E - u * p - m * p - u * g), y = v - P, h = v - y, R[0] = v - (y + h) + (h - P), x = _ + y, h = x - _, S = _ - (x - h) + (y - h), y = S - E, h = S - y, R[1] = S - (y + h) + (h - E), k = x + y, h = k - x, R[2] = x - (k - h) + (y - h), R[3] = k;
  const ce = ft(fe, jt, 4, R, Ft);
  _ = l * d, c = M * l, u = c - (c - l), m = l - u, c = M * d, p = c - (c - d), g = d - p, v = m * g - (_ - u * p - m * p - u * g), E = a * f, c = M * a, u = c - (c - a), m = a - u, c = M * f, p = c - (c - f), g = f - p, P = m * g - (E - u * p - m * p - u * g), y = v - P, h = v - y, R[0] = v - (y + h) + (h - P), x = _ + y, h = x - _, S = _ - (x - h) + (y - h), y = S - E, h = S - y, R[1] = S - (y + h) + (h - E), k = x + y, h = k - x, R[2] = x - (k - h) + (y - h), R[3] = k;
  const ue = ft(ce, Ft, 4, R, Gt);
  return Gt[ue - 1];
}
function Nn(s, t, e, n, i, r) {
  const o = (t - r) * (e - i), l = (s - i) * (n - r), a = o - l, f = Math.abs(o + l);
  return Math.abs(a) >= Rn * f ? a : -An(s, t, e, n, i, r, f);
}
const H = (s, t) => s.ll.x <= t.x && t.x <= s.ur.x && s.ll.y <= t.y && t.y <= s.ur.y, xt = (s, t) => {
  if (t.ur.x < s.ll.x || s.ur.x < t.ll.x || t.ur.y < s.ll.y || s.ur.y < t.ll.y) return null;
  const e = s.ll.x < t.ll.x ? t.ll.x : s.ll.x, n = s.ur.x < t.ur.x ? s.ur.x : t.ur.x, i = s.ll.y < t.ll.y ? t.ll.y : s.ll.y, r = s.ur.y < t.ur.y ? s.ur.y : t.ur.y;
  return {
    ll: {
      x: e,
      y: i
    },
    ur: {
      x: n,
      y: r
    }
  };
};
let $ = Number.EPSILON;
$ === void 0 && ($ = Math.pow(2, -52));
const On = $ * $, Dt = (s, t) => {
  if (-$ < s && s < $ && -$ < t && t < $)
    return 0;
  const e = s - t;
  return e * e < On * s * t ? 0 : s < t ? -1 : 1;
};
class Tn {
  constructor() {
    this.reset();
  }
  reset() {
    this.xRounder = new Yt(), this.yRounder = new Yt();
  }
  round(t, e) {
    return {
      x: this.xRounder.round(t),
      y: this.yRounder.round(e)
    };
  }
}
class Yt {
  constructor() {
    this.tree = new kt(), this.round(0);
  }
  // Note: this can rounds input values backwards or forwards.
  //       You might ask, why not restrict this to just rounding
  //       forwards? Wouldn't that allow left endpoints to always
  //       remain left endpoints during splitting (never change to
  //       right). No - it wouldn't, because we snap intersections
  //       to endpoints (to establish independence from the segment
  //       angle for t-intersections).
  round(t) {
    const e = this.tree.add(t), n = this.tree.prev(e);
    if (n !== null && Dt(e.key, n.key) === 0)
      return this.tree.remove(t), n.key;
    const i = this.tree.next(e);
    return i !== null && Dt(e.key, i.key) === 0 ? (this.tree.remove(t), i.key) : t;
  }
}
const Q = new Tn(), nt = (s, t) => s.x * t.y - s.y * t.x, ae = (s, t) => s.x * t.x + s.y * t.y, Ht = (s, t, e) => {
  const n = Nn(s.x, s.y, t.x, t.y, e.x, e.y);
  return n > 0 ? -1 : n < 0 ? 1 : 0;
}, rt = (s) => Math.sqrt(ae(s, s)), Cn = (s, t, e) => {
  const n = {
    x: t.x - s.x,
    y: t.y - s.y
  }, i = {
    x: e.x - s.x,
    y: e.y - s.y
  };
  return nt(i, n) / rt(i) / rt(n);
}, Bn = (s, t, e) => {
  const n = {
    x: t.x - s.x,
    y: t.y - s.y
  }, i = {
    x: e.x - s.x,
    y: e.y - s.y
  };
  return ae(i, n) / rt(i) / rt(n);
}, Ut = (s, t, e) => t.y === 0 ? null : {
  x: s.x + t.x / t.y * (e - s.y),
  y: e
}, qt = (s, t, e) => t.x === 0 ? null : {
  x: e,
  y: s.y + t.y / t.x * (e - s.x)
}, zn = (s, t, e, n) => {
  if (t.x === 0) return qt(e, n, s.x);
  if (n.x === 0) return qt(s, t, e.x);
  if (t.y === 0) return Ut(e, n, s.y);
  if (n.y === 0) return Ut(s, t, e.y);
  const i = nt(t, n);
  if (i == 0) return null;
  const r = {
    x: e.x - s.x,
    y: e.y - s.y
  }, o = nt(r, t) / i, l = nt(r, n) / i, a = s.x + l * t.x, f = e.x + o * n.x, d = s.y + l * t.y, h = e.y + o * n.y, c = (a + f) / 2, u = (d + h) / 2;
  return {
    x: c,
    y: u
  };
};
class N {
  // for ordering sweep events in the sweep event queue
  static compare(t, e) {
    const n = N.comparePoints(t.point, e.point);
    return n !== 0 ? n : (t.point !== e.point && t.link(e), t.isLeft !== e.isLeft ? t.isLeft ? 1 : -1 : j.compare(t.segment, e.segment));
  }
  // for ordering points in sweep line order
  static comparePoints(t, e) {
    return t.x < e.x ? -1 : t.x > e.x ? 1 : t.y < e.y ? -1 : t.y > e.y ? 1 : 0;
  }
  // Warning: 'point' input will be modified and re-used (for performance)
  constructor(t, e) {
    t.events === void 0 ? t.events = [this] : t.events.push(this), this.point = t, this.isLeft = e;
  }
  link(t) {
    if (t.point === this.point)
      throw new Error("Tried to link already linked events");
    const e = t.point.events;
    for (let n = 0, i = e.length; n < i; n++) {
      const r = e[n];
      this.point.events.push(r), r.point = this.point;
    }
    this.checkForConsuming();
  }
  /* Do a pass over our linked events and check to see if any pair
   * of segments match, and should be consumed. */
  checkForConsuming() {
    const t = this.point.events.length;
    for (let e = 0; e < t; e++) {
      const n = this.point.events[e];
      if (n.segment.consumedBy === void 0)
        for (let i = e + 1; i < t; i++) {
          const r = this.point.events[i];
          r.consumedBy === void 0 && n.otherSE.point.events === r.otherSE.point.events && n.segment.consume(r.segment);
        }
    }
  }
  getAvailableLinkedEvents() {
    const t = [];
    for (let e = 0, n = this.point.events.length; e < n; e++) {
      const i = this.point.events[e];
      i !== this && !i.segment.ringOut && i.segment.isInResult() && t.push(i);
    }
    return t;
  }
  /**
   * Returns a comparator function for sorting linked events that will
   * favor the event that will give us the smallest left-side angle.
   * All ring construction starts as low as possible heading to the right,
   * so by always turning left as sharp as possible we'll get polygons
   * without uncessary loops & holes.
   *
   * The comparator function has a compute cache such that it avoids
   * re-computing already-computed values.
   */
  getLeftmostComparator(t) {
    const e = /* @__PURE__ */ new Map(), n = (i) => {
      const r = i.otherSE;
      e.set(i, {
        sine: Cn(this.point, t.point, r.point),
        cosine: Bn(this.point, t.point, r.point)
      });
    };
    return (i, r) => {
      e.has(i) || n(i), e.has(r) || n(r);
      const {
        sine: o,
        cosine: l
      } = e.get(i), {
        sine: a,
        cosine: f
      } = e.get(r);
      return o >= 0 && a >= 0 ? l < f ? 1 : l > f ? -1 : 0 : o < 0 && a < 0 ? l < f ? -1 : l > f ? 1 : 0 : a < o ? -1 : a > o ? 1 : 0;
    };
  }
}
let $n = 0;
class j {
  /* This compare() function is for ordering segments in the sweep
   * line tree, and does so according to the following criteria:
   *
   * Consider the vertical line that lies an infinestimal step to the
   * right of the right-more of the two left endpoints of the input
   * segments. Imagine slowly moving a point up from negative infinity
   * in the increasing y direction. Which of the two segments will that
   * point intersect first? That segment comes 'before' the other one.
   *
   * If neither segment would be intersected by such a line, (if one
   * or more of the segments are vertical) then the line to be considered
   * is directly on the right-more of the two left inputs.
   */
  static compare(t, e) {
    const n = t.leftSE.point.x, i = e.leftSE.point.x, r = t.rightSE.point.x, o = e.rightSE.point.x;
    if (o < n) return 1;
    if (r < i) return -1;
    const l = t.leftSE.point.y, a = e.leftSE.point.y, f = t.rightSE.point.y, d = e.rightSE.point.y;
    if (n < i) {
      if (a < l && a < f) return 1;
      if (a > l && a > f) return -1;
      const h = t.comparePoint(e.leftSE.point);
      if (h < 0) return 1;
      if (h > 0) return -1;
      const c = e.comparePoint(t.rightSE.point);
      return c !== 0 ? c : -1;
    }
    if (n > i) {
      if (l < a && l < d) return -1;
      if (l > a && l > d) return 1;
      const h = e.comparePoint(t.leftSE.point);
      if (h !== 0) return h;
      const c = t.comparePoint(e.rightSE.point);
      return c < 0 ? 1 : c > 0 ? -1 : 1;
    }
    if (l < a) return -1;
    if (l > a) return 1;
    if (r < o) {
      const h = e.comparePoint(t.rightSE.point);
      if (h !== 0) return h;
    }
    if (r > o) {
      const h = t.comparePoint(e.rightSE.point);
      if (h < 0) return 1;
      if (h > 0) return -1;
    }
    if (r !== o) {
      const h = f - l, c = r - n, u = d - a, m = o - i;
      if (h > c && u < m) return 1;
      if (h < c && u > m) return -1;
    }
    return r > o ? 1 : r < o || f < d ? -1 : f > d ? 1 : t.id < e.id ? -1 : t.id > e.id ? 1 : 0;
  }
  /* Warning: a reference to ringWindings input will be stored,
   *  and possibly will be later modified */
  constructor(t, e, n, i) {
    this.id = ++$n, this.leftSE = t, t.segment = this, t.otherSE = e, this.rightSE = e, e.segment = this, e.otherSE = t, this.rings = n, this.windings = i;
  }
  static fromRing(t, e, n) {
    let i, r, o;
    const l = N.comparePoints(t, e);
    if (l < 0)
      i = t, r = e, o = 1;
    else if (l > 0)
      i = e, r = t, o = -1;
    else throw new Error(`Tried to create degenerate segment at [${t.x}, ${t.y}]`);
    const a = new N(i, !0), f = new N(r, !1);
    return new j(a, f, [n], [o]);
  }
  /* When a segment is split, the rightSE is replaced with a new sweep event */
  replaceRightSE(t) {
    this.rightSE = t, this.rightSE.segment = this, this.rightSE.otherSE = this.leftSE, this.leftSE.otherSE = this.rightSE;
  }
  bbox() {
    const t = this.leftSE.point.y, e = this.rightSE.point.y;
    return {
      ll: {
        x: this.leftSE.point.x,
        y: t < e ? t : e
      },
      ur: {
        x: this.rightSE.point.x,
        y: t > e ? t : e
      }
    };
  }
  /* A vector from the left point to the right */
  vector() {
    return {
      x: this.rightSE.point.x - this.leftSE.point.x,
      y: this.rightSE.point.y - this.leftSE.point.y
    };
  }
  isAnEndpoint(t) {
    return t.x === this.leftSE.point.x && t.y === this.leftSE.point.y || t.x === this.rightSE.point.x && t.y === this.rightSE.point.y;
  }
  /* Compare this segment with a point.
   *
   * A point P is considered to be colinear to a segment if there
   * exists a distance D such that if we travel along the segment
   * from one * endpoint towards the other a distance D, we find
   * ourselves at point P.
   *
   * Return value indicates:
   *
   *   1: point lies above the segment (to the left of vertical)
   *   0: point is colinear to segment
   *  -1: point lies below the segment (to the right of vertical)
   */
  comparePoint(t) {
    if (this.isAnEndpoint(t)) return 0;
    const e = this.leftSE.point, n = this.rightSE.point, i = this.vector();
    if (e.x === n.x)
      return t.x === e.x ? 0 : t.x < e.x ? 1 : -1;
    const r = (t.y - e.y) / i.y, o = e.x + r * i.x;
    if (t.x === o) return 0;
    const l = (t.x - e.x) / i.x, a = e.y + l * i.y;
    return t.y === a ? 0 : t.y < a ? -1 : 1;
  }
  /**
   * Given another segment, returns the first non-trivial intersection
   * between the two segments (in terms of sweep line ordering), if it exists.
   *
   * A 'non-trivial' intersection is one that will cause one or both of the
   * segments to be split(). As such, 'trivial' vs. 'non-trivial' intersection:
   *
   *   * endpoint of segA with endpoint of segB --> trivial
   *   * endpoint of segA with point along segB --> non-trivial
   *   * endpoint of segB with point along segA --> non-trivial
   *   * point along segA with point along segB --> non-trivial
   *
   * If no non-trivial intersection exists, return null
   * Else, return null.
   */
  getIntersection(t) {
    const e = this.bbox(), n = t.bbox(), i = xt(e, n);
    if (i === null) return null;
    const r = this.leftSE.point, o = this.rightSE.point, l = t.leftSE.point, a = t.rightSE.point, f = H(e, l) && this.comparePoint(l) === 0, d = H(n, r) && t.comparePoint(r) === 0, h = H(e, a) && this.comparePoint(a) === 0, c = H(n, o) && t.comparePoint(o) === 0;
    if (d && f)
      return c && !h ? o : !c && h ? a : null;
    if (d)
      return h && r.x === a.x && r.y === a.y ? null : r;
    if (f)
      return c && o.x === l.x && o.y === l.y ? null : l;
    if (c && h) return null;
    if (c) return o;
    if (h) return a;
    const u = zn(r, this.vector(), l, t.vector());
    return u === null || !H(i, u) ? null : Q.round(u.x, u.y);
  }
  /**
   * Split the given segment into multiple segments on the given points.
   *  * Each existing segment will retain its leftSE and a new rightSE will be
   *    generated for it.
   *  * A new segment will be generated which will adopt the original segment's
   *    rightSE, and a new leftSE will be generated for it.
   *  * If there are more than two points given to split on, new segments
   *    in the middle will be generated with new leftSE and rightSE's.
   *  * An array of the newly generated SweepEvents will be returned.
   *
   * Warning: input array of points is modified
   */
  split(t) {
    const e = [], n = t.events !== void 0, i = new N(t, !0), r = new N(t, !1), o = this.rightSE;
    this.replaceRightSE(r), e.push(r), e.push(i);
    const l = new j(i, o, this.rings.slice(), this.windings.slice());
    return N.comparePoints(l.leftSE.point, l.rightSE.point) > 0 && l.swapEvents(), N.comparePoints(this.leftSE.point, this.rightSE.point) > 0 && this.swapEvents(), n && (i.checkForConsuming(), r.checkForConsuming()), e;
  }
  /* Swap which event is left and right */
  swapEvents() {
    const t = this.rightSE;
    this.rightSE = this.leftSE, this.leftSE = t, this.leftSE.isLeft = !0, this.rightSE.isLeft = !1;
    for (let e = 0, n = this.windings.length; e < n; e++)
      this.windings[e] *= -1;
  }
  /* Consume another segment. We take their rings under our wing
   * and mark them as consumed. Use for perfectly overlapping segments */
  consume(t) {
    let e = this, n = t;
    for (; e.consumedBy; ) e = e.consumedBy;
    for (; n.consumedBy; ) n = n.consumedBy;
    const i = j.compare(e, n);
    if (i !== 0) {
      if (i > 0) {
        const r = e;
        e = n, n = r;
      }
      if (e.prev === n) {
        const r = e;
        e = n, n = r;
      }
      for (let r = 0, o = n.rings.length; r < o; r++) {
        const l = n.rings[r], a = n.windings[r], f = e.rings.indexOf(l);
        f === -1 ? (e.rings.push(l), e.windings.push(a)) : e.windings[f] += a;
      }
      n.rings = null, n.windings = null, n.consumedBy = e, n.leftSE.consumedBy = e.leftSE, n.rightSE.consumedBy = e.rightSE;
    }
  }
  /* The first segment previous segment chain that is in the result */
  prevInResult() {
    return this._prevInResult !== void 0 ? this._prevInResult : (this.prev ? this.prev.isInResult() ? this._prevInResult = this.prev : this._prevInResult = this.prev.prevInResult() : this._prevInResult = null, this._prevInResult);
  }
  beforeState() {
    if (this._beforeState !== void 0) return this._beforeState;
    if (!this.prev) this._beforeState = {
      rings: [],
      windings: [],
      multiPolys: []
    };
    else {
      const t = this.prev.consumedBy || this.prev;
      this._beforeState = t.afterState();
    }
    return this._beforeState;
  }
  afterState() {
    if (this._afterState !== void 0) return this._afterState;
    const t = this.beforeState();
    this._afterState = {
      rings: t.rings.slice(0),
      windings: t.windings.slice(0),
      multiPolys: []
    };
    const e = this._afterState.rings, n = this._afterState.windings, i = this._afterState.multiPolys;
    for (let l = 0, a = this.rings.length; l < a; l++) {
      const f = this.rings[l], d = this.windings[l], h = e.indexOf(f);
      h === -1 ? (e.push(f), n.push(d)) : n[h] += d;
    }
    const r = [], o = [];
    for (let l = 0, a = e.length; l < a; l++) {
      if (n[l] === 0) continue;
      const f = e[l], d = f.poly;
      if (o.indexOf(d) === -1)
        if (f.isExterior) r.push(d);
        else {
          o.indexOf(d) === -1 && o.push(d);
          const h = r.indexOf(f.poly);
          h !== -1 && r.splice(h, 1);
        }
    }
    for (let l = 0, a = r.length; l < a; l++) {
      const f = r[l].multiPoly;
      i.indexOf(f) === -1 && i.push(f);
    }
    return this._afterState;
  }
  /* Is this segment part of the final result? */
  isInResult() {
    if (this.consumedBy) return !1;
    if (this._isInResult !== void 0) return this._isInResult;
    const t = this.beforeState().multiPolys, e = this.afterState().multiPolys;
    switch (T.type) {
      case "union": {
        const n = t.length === 0, i = e.length === 0;
        this._isInResult = n !== i;
        break;
      }
      case "intersection": {
        let n, i;
        t.length < e.length ? (n = t.length, i = e.length) : (n = e.length, i = t.length), this._isInResult = i === T.numMultiPolys && n < i;
        break;
      }
      case "xor": {
        const n = Math.abs(t.length - e.length);
        this._isInResult = n % 2 === 1;
        break;
      }
      case "difference": {
        const n = (i) => i.length === 1 && i[0].isSubject;
        this._isInResult = n(t) !== n(e);
        break;
      }
      default:
        throw new Error(`Unrecognized operation type found ${T.type}`);
    }
    return this._isInResult;
  }
}
class Xt {
  constructor(t, e, n) {
    if (!Array.isArray(t) || t.length === 0)
      throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
    if (this.poly = e, this.isExterior = n, this.segments = [], typeof t[0][0] != "number" || typeof t[0][1] != "number")
      throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
    const i = Q.round(t[0][0], t[0][1]);
    this.bbox = {
      ll: {
        x: i.x,
        y: i.y
      },
      ur: {
        x: i.x,
        y: i.y
      }
    };
    let r = i;
    for (let o = 1, l = t.length; o < l; o++) {
      if (typeof t[o][0] != "number" || typeof t[o][1] != "number")
        throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
      let a = Q.round(t[o][0], t[o][1]);
      a.x === r.x && a.y === r.y || (this.segments.push(j.fromRing(r, a, this)), a.x < this.bbox.ll.x && (this.bbox.ll.x = a.x), a.y < this.bbox.ll.y && (this.bbox.ll.y = a.y), a.x > this.bbox.ur.x && (this.bbox.ur.x = a.x), a.y > this.bbox.ur.y && (this.bbox.ur.y = a.y), r = a);
    }
    (i.x !== r.x || i.y !== r.y) && this.segments.push(j.fromRing(r, i, this));
  }
  getSweepEvents() {
    const t = [];
    for (let e = 0, n = this.segments.length; e < n; e++) {
      const i = this.segments[e];
      t.push(i.leftSE), t.push(i.rightSE);
    }
    return t;
  }
}
class jn {
  constructor(t, e) {
    if (!Array.isArray(t))
      throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
    this.exteriorRing = new Xt(t[0], this, !0), this.bbox = {
      ll: {
        x: this.exteriorRing.bbox.ll.x,
        y: this.exteriorRing.bbox.ll.y
      },
      ur: {
        x: this.exteriorRing.bbox.ur.x,
        y: this.exteriorRing.bbox.ur.y
      }
    }, this.interiorRings = [];
    for (let n = 1, i = t.length; n < i; n++) {
      const r = new Xt(t[n], this, !1);
      r.bbox.ll.x < this.bbox.ll.x && (this.bbox.ll.x = r.bbox.ll.x), r.bbox.ll.y < this.bbox.ll.y && (this.bbox.ll.y = r.bbox.ll.y), r.bbox.ur.x > this.bbox.ur.x && (this.bbox.ur.x = r.bbox.ur.x), r.bbox.ur.y > this.bbox.ur.y && (this.bbox.ur.y = r.bbox.ur.y), this.interiorRings.push(r);
    }
    this.multiPoly = e;
  }
  getSweepEvents() {
    const t = this.exteriorRing.getSweepEvents();
    for (let e = 0, n = this.interiorRings.length; e < n; e++) {
      const i = this.interiorRings[e].getSweepEvents();
      for (let r = 0, o = i.length; r < o; r++)
        t.push(i[r]);
    }
    return t;
  }
}
class Wt {
  constructor(t, e) {
    if (!Array.isArray(t))
      throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
    try {
      typeof t[0][0][0] == "number" && (t = [t]);
    } catch {
    }
    this.polys = [], this.bbox = {
      ll: {
        x: Number.POSITIVE_INFINITY,
        y: Number.POSITIVE_INFINITY
      },
      ur: {
        x: Number.NEGATIVE_INFINITY,
        y: Number.NEGATIVE_INFINITY
      }
    };
    for (let n = 0, i = t.length; n < i; n++) {
      const r = new jn(t[n], this);
      r.bbox.ll.x < this.bbox.ll.x && (this.bbox.ll.x = r.bbox.ll.x), r.bbox.ll.y < this.bbox.ll.y && (this.bbox.ll.y = r.bbox.ll.y), r.bbox.ur.x > this.bbox.ur.x && (this.bbox.ur.x = r.bbox.ur.x), r.bbox.ur.y > this.bbox.ur.y && (this.bbox.ur.y = r.bbox.ur.y), this.polys.push(r);
    }
    this.isSubject = e;
  }
  getSweepEvents() {
    const t = [];
    for (let e = 0, n = this.polys.length; e < n; e++) {
      const i = this.polys[e].getSweepEvents();
      for (let r = 0, o = i.length; r < o; r++)
        t.push(i[r]);
    }
    return t;
  }
}
class ot {
  /* Given the segments from the sweep line pass, compute & return a series
   * of closed rings from all the segments marked to be part of the result */
  static factory(t) {
    const e = [];
    for (let n = 0, i = t.length; n < i; n++) {
      const r = t[n];
      if (!r.isInResult() || r.ringOut) continue;
      let o = null, l = r.leftSE, a = r.rightSE;
      const f = [l], d = l.point, h = [];
      for (; o = l, l = a, f.push(l), l.point !== d; )
        for (; ; ) {
          const c = l.getAvailableLinkedEvents();
          if (c.length === 0) {
            const p = f[0].point, g = f[f.length - 1].point;
            throw new Error(`Unable to complete output ring starting at [${p.x}, ${p.y}]. Last matching segment found ends at [${g.x}, ${g.y}].`);
          }
          if (c.length === 1) {
            a = c[0].otherSE;
            break;
          }
          let u = null;
          for (let p = 0, g = h.length; p < g; p++)
            if (h[p].point === l.point) {
              u = p;
              break;
            }
          if (u !== null) {
            const p = h.splice(u)[0], g = f.splice(p.index);
            g.unshift(g[0].otherSE), e.push(new ot(g.reverse()));
            continue;
          }
          h.push({
            index: f.length,
            point: l.point
          });
          const m = l.getLeftmostComparator(o);
          a = c.sort(m)[0].otherSE;
          break;
        }
      e.push(new ot(f));
    }
    return e;
  }
  constructor(t) {
    this.events = t;
    for (let e = 0, n = t.length; e < n; e++)
      t[e].segment.ringOut = this;
    this.poly = null;
  }
  getGeom() {
    let t = this.events[0].point;
    const e = [t];
    for (let f = 1, d = this.events.length - 1; f < d; f++) {
      const h = this.events[f].point, c = this.events[f + 1].point;
      Ht(h, t, c) !== 0 && (e.push(h), t = h);
    }
    if (e.length === 1) return null;
    const n = e[0], i = e[1];
    Ht(n, t, i) === 0 && e.shift(), e.push(e[0]);
    const r = this.isExteriorRing() ? 1 : -1, o = this.isExteriorRing() ? 0 : e.length - 1, l = this.isExteriorRing() ? e.length : -1, a = [];
    for (let f = o; f != l; f += r) a.push([e[f].x, e[f].y]);
    return a;
  }
  isExteriorRing() {
    if (this._isExteriorRing === void 0) {
      const t = this.enclosingRing();
      this._isExteriorRing = t ? !t.isExteriorRing() : !0;
    }
    return this._isExteriorRing;
  }
  enclosingRing() {
    return this._enclosingRing === void 0 && (this._enclosingRing = this._calcEnclosingRing()), this._enclosingRing;
  }
  /* Returns the ring that encloses this one, if any */
  _calcEnclosingRing() {
    let t = this.events[0];
    for (let i = 1, r = this.events.length; i < r; i++) {
      const o = this.events[i];
      N.compare(t, o) > 0 && (t = o);
    }
    let e = t.segment.prevInResult(), n = e ? e.prevInResult() : null;
    for (; ; ) {
      if (!e) return null;
      if (!n) return e.ringOut;
      if (n.ringOut !== e.ringOut)
        return n.ringOut.enclosingRing() !== e.ringOut ? e.ringOut : e.ringOut.enclosingRing();
      e = n.prevInResult(), n = e ? e.prevInResult() : null;
    }
  }
}
class Qt {
  constructor(t) {
    this.exteriorRing = t, t.poly = this, this.interiorRings = [];
  }
  addInterior(t) {
    this.interiorRings.push(t), t.poly = this;
  }
  getGeom() {
    const t = [this.exteriorRing.getGeom()];
    if (t[0] === null) return null;
    for (let e = 0, n = this.interiorRings.length; e < n; e++) {
      const i = this.interiorRings[e].getGeom();
      i !== null && t.push(i);
    }
    return t;
  }
}
class Fn {
  constructor(t) {
    this.rings = t, this.polys = this._composePolys(t);
  }
  getGeom() {
    const t = [];
    for (let e = 0, n = this.polys.length; e < n; e++) {
      const i = this.polys[e].getGeom();
      i !== null && t.push(i);
    }
    return t;
  }
  _composePolys(t) {
    const e = [];
    for (let n = 0, i = t.length; n < i; n++) {
      const r = t[n];
      if (!r.poly)
        if (r.isExteriorRing()) e.push(new Qt(r));
        else {
          const o = r.enclosingRing();
          o.poly || e.push(new Qt(o)), o.poly.addInterior(r);
        }
    }
    return e;
  }
}
class Gn {
  constructor(t) {
    let e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : j.compare;
    this.queue = t, this.tree = new kt(e), this.segments = [];
  }
  process(t) {
    const e = t.segment, n = [];
    if (t.consumedBy)
      return t.isLeft ? this.queue.remove(t.otherSE) : this.tree.remove(e), n;
    const i = t.isLeft ? this.tree.add(e) : this.tree.find(e);
    if (!i) throw new Error(`Unable to find segment #${e.id} [${e.leftSE.point.x}, ${e.leftSE.point.y}] -> [${e.rightSE.point.x}, ${e.rightSE.point.y}] in SweepLine tree.`);
    let r = i, o = i, l, a;
    for (; l === void 0; )
      r = this.tree.prev(r), r === null ? l = null : r.key.consumedBy === void 0 && (l = r.key);
    for (; a === void 0; )
      o = this.tree.next(o), o === null ? a = null : o.key.consumedBy === void 0 && (a = o.key);
    if (t.isLeft) {
      let f = null;
      if (l) {
        const h = l.getIntersection(e);
        if (h !== null && (e.isAnEndpoint(h) || (f = h), !l.isAnEndpoint(h))) {
          const c = this._splitSafely(l, h);
          for (let u = 0, m = c.length; u < m; u++)
            n.push(c[u]);
        }
      }
      let d = null;
      if (a) {
        const h = a.getIntersection(e);
        if (h !== null && (e.isAnEndpoint(h) || (d = h), !a.isAnEndpoint(h))) {
          const c = this._splitSafely(a, h);
          for (let u = 0, m = c.length; u < m; u++)
            n.push(c[u]);
        }
      }
      if (f !== null || d !== null) {
        let h = null;
        f === null ? h = d : d === null ? h = f : h = N.comparePoints(f, d) <= 0 ? f : d, this.queue.remove(e.rightSE), n.push(e.rightSE);
        const c = e.split(h);
        for (let u = 0, m = c.length; u < m; u++)
          n.push(c[u]);
      }
      n.length > 0 ? (this.tree.remove(e), n.push(t)) : (this.segments.push(e), e.prev = l);
    } else {
      if (l && a) {
        const f = l.getIntersection(a);
        if (f !== null) {
          if (!l.isAnEndpoint(f)) {
            const d = this._splitSafely(l, f);
            for (let h = 0, c = d.length; h < c; h++)
              n.push(d[h]);
          }
          if (!a.isAnEndpoint(f)) {
            const d = this._splitSafely(a, f);
            for (let h = 0, c = d.length; h < c; h++)
              n.push(d[h]);
          }
        }
      }
      this.tree.remove(e);
    }
    return n;
  }
  /* Safely split a segment that is currently in the datastructures
   * IE - a segment other than the one that is currently being processed. */
  _splitSafely(t, e) {
    this.tree.remove(t);
    const n = t.rightSE;
    this.queue.remove(n);
    const i = t.split(e);
    return i.push(n), t.consumedBy === void 0 && this.tree.add(t), i;
  }
}
const Vt = typeof process < "u" && process.env.POLYGON_CLIPPING_MAX_QUEUE_SIZE || 1e6, Dn = typeof process < "u" && process.env.POLYGON_CLIPPING_MAX_SWEEPLINE_SEGMENTS || 1e6;
class Yn {
  run(t, e, n) {
    T.type = t, Q.reset();
    const i = [new Wt(e, !0)];
    for (let h = 0, c = n.length; h < c; h++)
      i.push(new Wt(n[h], !1));
    if (T.numMultiPolys = i.length, T.type === "difference") {
      const h = i[0];
      let c = 1;
      for (; c < i.length; )
        xt(i[c].bbox, h.bbox) !== null ? c++ : i.splice(c, 1);
    }
    if (T.type === "intersection")
      for (let h = 0, c = i.length; h < c; h++) {
        const u = i[h];
        for (let m = h + 1, p = i.length; m < p; m++)
          if (xt(u.bbox, i[m].bbox) === null) return [];
      }
    const r = new kt(N.compare);
    for (let h = 0, c = i.length; h < c; h++) {
      const u = i[h].getSweepEvents();
      for (let m = 0, p = u.length; m < p; m++)
        if (r.insert(u[m]), r.size > Vt)
          throw new Error("Infinite loop when putting segment endpoints in a priority queue (queue size too big).");
    }
    const o = new Gn(r);
    let l = r.size, a = r.pop();
    for (; a; ) {
      const h = a.key;
      if (r.size === l) {
        const u = h.segment;
        throw new Error(`Unable to pop() ${h.isLeft ? "left" : "right"} SweepEvent [${h.point.x}, ${h.point.y}] from segment #${u.id} [${u.leftSE.point.x}, ${u.leftSE.point.y}] -> [${u.rightSE.point.x}, ${u.rightSE.point.y}] from queue.`);
      }
      if (r.size > Vt)
        throw new Error("Infinite loop when passing sweep line over endpoints (queue size too big).");
      if (o.segments.length > Dn)
        throw new Error("Infinite loop when passing sweep line over endpoints (too many sweep line segments).");
      const c = o.process(h);
      for (let u = 0, m = c.length; u < m; u++) {
        const p = c[u];
        p.consumedBy === void 0 && r.insert(p);
      }
      l = r.size, a = r.pop();
    }
    Q.reset();
    const f = ot.factory(o.segments);
    return new Fn(f).getGeom();
  }
}
const T = new Yn(), Hn = function(s) {
  for (var t = arguments.length, e = new Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++)
    e[n - 1] = arguments[n];
  return T.run("union", s, e);
}, Un = function(s) {
  for (var t = arguments.length, e = new Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++)
    e[n - 1] = arguments[n];
  return T.run("intersection", s, e);
}, qn = function(s) {
  for (var t = arguments.length, e = new Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++)
    e[n - 1] = arguments[n];
  return T.run("xor", s, e);
}, Xn = function(s) {
  for (var t = arguments.length, e = new Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++)
    e[n - 1] = arguments[n];
  return T.run("difference", s, e);
};
var Jt = {
  union: Hn,
  intersection: Un,
  xor: qn,
  difference: Xn
};
const Kt = 3, Wn = 10, Qn = 1, Vn = '<path d="M3.704 14.467a10 8 0 1 1 3.115 2.375"/><path d="M7 22a5 5 0 0 1-2-3.994"/><circle cx="5" cy="16" r="2"/>', Jn = '<path d="M22 26h8M26 22v8"/>', Kn = '<path d="M22 26h8"/>';
function _t(s = "") {
  const t = Vn + s, e = s ? 24 : 16, n = e * 1.5, i = `<svg xmlns="http://www.w3.org/2000/svg" width="${e}" height="${e}" viewBox="0 0 ${n} ${n}" fill="none" stroke-linecap="round" stroke-linejoin="round"><g stroke="white" stroke-width="4">${t}</g><g stroke="black" stroke-width="2">${t}</g></svg>`;
  return `url("data:image/svg+xml,${encodeURIComponent(i)}") 5 15, crosshair`;
}
const Zn = _t(), ti = {
  add: _t(Jn),
  subtract: _t(Kn)
}, ei = `
	:host {
		position: absolute;
		display: none;
		z-index: 1;
		cursor: ${Zn};
		touch-action: none;
		user-select: none;
	}

	:host([hidden]) {
		display: none !important;
	}

	:host([disabled]) {
		pointer-events: none;
	}

	svg {
		position: absolute;
		inset: 0;
		width: 100%;
		height: 100%;
		overflow: visible;
		pointer-events: none;
	}

	polyline,
	polygon {
		display: none;
		fill: none;
		stroke-width: 1px;
	}

	#draft {
		stroke: var(--lasso-tool-color, var(--color-accent, #f97316));
	}

	/* Marching ants: black dashes over a white line. */
	#lasso {
		stroke: white;
	}

	#ants {
		stroke: black;
		stroke-dasharray: 4 4;
		animation: march 0.6s linear infinite;
	}

	:host([static]) #ants {
		animation: none;
	}

	@keyframes march {
		to {
			stroke-dashoffset: -8;
		}
	}
`;
class ni extends HTMLElement {
  #t = null;
  /** As drawn, kept intact while browsing images. */
  #e = null;
  /** Resolution of the image lasso was drawn over. */
  #n = null;
  #h;
  #f;
  #c;
  /** Last emitted value, as JSON, to emit only changes. */
  #u = "null";
  /**
   * Element lasso is drawn within, e.g. the canvas: a drawing leaving it
   * is in fact a drag of image to another element.
   */
  area = null;
  /** Neighbors each vertex is averaged with on each side, to smooth the hand's jitter. */
  smoothing = 1;
  #v = ["", ""];
  #i = null;
  /** What lasso being drawn does to the current one, if not replace it. */
  #a = null;
  /** Operation of the shortcut held while pointer is over overlay, if any. */
  #m = null;
  /** Where user pressed, in client pixels, to tell a click from a move. */
  #E = null;
  /** Lasso as it was when user pressed, back if user cancels. */
  #x = null;
  /** Lasso being drawn, applied to the current one on release. */
  #r = null;
  /** Element outside overlay that pointer is over, while user drags image. */
  #s = null;
  /** Whether drop target accepts displayed image. */
  #_ = !1;
  #d = null;
  #M = new ResizeObserver(() => this.#w());
  #I = () => this.#w();
  /** Escape cancels the lasso being drawn, and only that. */
  #R = (t) => {
    t.key === "Escape" && (t.preventDefault(), t.stopPropagation(), this.#N());
  };
  /** Tell what a drag would do, as user presses or releases a shortcut. */
  #b = (t) => {
    if (!this.matches(":hover")) {
      this.#L();
      return;
    }
    t.key === "Alt" && t.preventDefault(), this.#k(t);
  };
  constructor() {
    super();
    const t = this.attachShadow({ mode: "open" }), e = document.createElement("style");
    e.textContent = ei;
    const n = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    n.innerHTML = '<polygon id="lasso"></polygon><polygon id="ants"></polygon><polyline id="draft"></polyline>', this.#h = n.querySelector("#draft"), this.#f = n.querySelector("#lasso"), this.#c = n.querySelector("#ants"), t.append(e, n), this.addEventListener("pointerenter", (i) => this.#T(i)), this.addEventListener("pointerleave", () => this.#L()), this.addEventListener("pointerdown", (i) => this.#C(i)), this.addEventListener("pointermove", (i) => this.#B(i)), this.addEventListener("pointerup", () => this.#z()), this.addEventListener("pointercancel", () => this.#$());
  }
  /**
   * Image to draw the lasso over. Lasso persists when another image is
   * displayed, scaled to its resolution, so user finds it back while
   * browsing images.
   */
  get target() {
    return this.#t;
  }
  set target(t) {
    this.#t !== t && (this.#t && (this.#M.unobserve(this.#t), this.#t.removeEventListener("load", this.#I)), this.#t = t, this.#l(), t && (this.#M.observe(t), t.addEventListener("load", this.#I))), this.#w();
  }
  /**
   * Tooltips shown over the image: while no lasso is drawn, e.g. to tell
   * how to draw one, then once drawn, e.g. to tell how to clear it.
   */
  get tooltips() {
    return this.#v;
  }
  set tooltips(t) {
    this.#v = t, this.#o();
  }
  /**
   * Lasso in pixels of the displayed image, scaled to it.
   * Setting it emits no event.
   */
  get value() {
    return this.#p();
  }
  set value(t) {
    this.#e = t && t.map(([e, n]) => [e, n]), this.#n = U(this.#t) ?? this.#n, this.#u = JSON.stringify(ne(this.#p())), this.#l(), this.#o();
  }
  clear() {
    this.#e = null, this.#l(), this.#o(), this.#S();
  }
  /** Cover image content, letterbox bands excluded. */
  sync() {
    const t = this.#t, e = this.parentElement;
    if (!t?.isConnected || !e || !t.naturalWidth || !t.naturalHeight) {
      this.style.display = "none";
      return;
    }
    const n = t.getBoundingClientRect(), i = e.getBoundingClientRect(), r = Math.min(
      n.width / t.naturalWidth,
      n.height / t.naturalHeight
    ), o = t.naturalWidth * r, l = t.naturalHeight * r;
    if (o <= 0 || l <= 0) {
      this.style.display = "none";
      return;
    }
    const a = n.left - i.left - e.clientLeft + (n.width - o) / 2, f = n.top - i.top - e.clientTop + (n.height - l) / 2;
    this.style.display = "block", this.style.left = `${a}px`, this.style.top = `${f}px`, this.style.width = `${o}px`, this.style.height = `${l}px`;
  }
  /** Follow displayed image, which may be another one or resized. */
  #w() {
    this.#n ??= U(this.#t), this.sync(), this.#o(), this.#S();
  }
  /**
   * Lasso scaled to displayed image, whose resolution may differ from the
   * drawn one, so it surrounds the same region.
   */
  #p() {
    const t = this.#e, e = U(this.#t);
    if (!t || !e || !this.#n) return t;
    const n = e.width / this.#n.width, i = e.height / this.#n.height;
    return t.map(([r, o]) => [r * n, o * i]);
  }
  #P(t) {
    const e = this.#t, n = this.getBoundingClientRect(), i = ie(t.clientX - n.left, 0, n.width), r = ie(t.clientY - n.top, 0, n.height);
    return [
      i / n.width * e.naturalWidth,
      r / n.height * e.naturalHeight
    ];
  }
  #o() {
    const t = this.#t, e = !!U(t), n = e ? this.#p() : null, i = e && this.#i === "draw" && this.#r ? Zt(this.#r, this.#A()) : null;
    this.title = this.#v[n ? 1 : 0];
    for (const [r, o] of [
      [this.#h, i],
      [this.#f, n],
      [this.#c, n]
    ])
      r.style.display = o ? "inline" : "none", o && r.setAttribute("points", this.#O(o, t));
  }
  /** SVG points of vertices, in overlay pixels. */
  #O(t, e) {
    const n = this.clientWidth / e.naturalWidth, i = this.clientHeight / e.naturalHeight;
    return t.map(([r, o]) => `${r * n},${o * i}`).join(" ");
  }
  /** Emit value, if changed. */
  #S() {
    const t = ne(this.#p()), e = JSON.stringify(t);
    e !== this.#u && (this.#u = e, this.dispatchEvent(new CustomEvent("lasso-change", { detail: t })));
  }
  #T(t) {
    window.addEventListener("keydown", this.#b, !0), window.addEventListener("keyup", this.#b, !0), this.#k(t);
  }
  #L() {
    window.removeEventListener("keydown", this.#b, !0), window.removeEventListener("keyup", this.#b, !0), this.#m = null, this.#g();
  }
  #k(t) {
    const e = te(t);
    e !== this.#m && (this.#m = e, this.#g());
  }
  /**
   * A click clears the lasso, and a drag draws a new one, which replaces
   * the current one at once and closes on release, or adds to it with Shift
   * held, or subtracts from it with Alt held. User may as well drag displayed
   * image to another element, e.g. a prompt left of the canvas: leaving the
   * area (canvas) turns the drawing into a drop.
   */
  #C(t) {
    !this.#t || t.button !== 0 || (t.preventDefault(), t.stopPropagation(), this.#l(), this.#e = this.#p(), this.#n = U(this.#t), this.#x = this.#e, this.#i = "press", this.#a = te(t), this.#E = [t.clientX, t.clientY], this.#r = [this.#P(t)], this.#g(), this.setPointerCapture(t.pointerId), window.addEventListener("keydown", this.#R, !0));
  }
  #B(t) {
    if (this.#k(t), !this.#t || !this.#i) return;
    if (this.#i === "press") {
      const [o, l] = this.#E;
      if (Math.hypot(t.clientX - o, t.clientY - l) <= Wn)
        return;
      this.#i = "draw", this.#a || (this.#e = null);
    }
    if (this.#i === "draw" && this.#F(t) && (this.#i = "drop", this.#e = this.#x, this.#r = null, this.#o()), this.#i === "drop") {
      this.#G(t);
      return;
    }
    const e = this.#P(t), n = this.#r, [i, r] = n[n.length - 1];
    Math.hypot(e[0] - i, e[1] - r) < Qn || (n.push(e), this.#o());
  }
  #z() {
    const t = this.#i;
    t === "press" ? this.#a ? this.#l() : this.clear() : t === "drop" ? (this.#_ && (this.#y(this.#s, "drop"), this.#s = null), this.#l()) : t === "draw" && this.#j();
  }
  #$() {
    this.#i && this.#N();
  }
  /** Close lasso as drawn, unless it encloses nothing, and apply it. */
  #j() {
    const t = this.#r && Zt(this.#r, this.#A()), e = this.#a, n = this.#e;
    if (this.#l(), e)
      t && t.length >= Kt && (n ? this.#e = ii(n, t, e) ?? n : this.#e = e === "add" ? t : null);
    else {
      if (!t || t.length < Kt) {
        this.clear();
        return;
      }
      this.#e = t;
    }
    this.#o(), this.#S();
  }
  #A() {
    return Math.max(0, Math.floor(this.smoothing)) || 0;
  }
  /** Back to lasso as it was before user pressed. */
  #N() {
    this.#e = this.#x, this.#l(), this.#o();
  }
  /** Forget ongoing gesture, if any. */
  #l() {
    this.#s && this.#y(this.#s, "dragleave"), window.removeEventListener("keydown", this.#R, !0), this.#i = null, this.#a = null, this.#E = null, this.#x = null, this.#r = null, this.#s = null, this.#_ = !1, this.#d = null, this.#g();
  }
  /** Cursor of ongoing drop, if any, else of what a drag would do. */
  #g() {
    let t = "";
    if (this.#i === "drop")
      t = this.#_ ? "copy" : "grabbing";
    else {
      const e = this.#i ? this.#a : this.#m;
      e && (t = ti[e]);
    }
    this.style.cursor = t;
  }
  /** Whether pointer left the area lasso is drawn within. */
  #F(t) {
    const e = (this.area ?? this).getBoundingClientRect();
    return t.clientX < e.left || t.clientX > e.right || t.clientY < e.top || t.clientY > e.bottom;
  }
  /**
   * Drag displayed image over the element pointer is over, outside overlay,
   * as browser would do. Overlay can't let browser drag the image itself:
   * it would take any drag over it, those drawing the lasso included.
   */
  #G(t) {
    const e = document.elementFromPoint(t.clientX, t.clientY), n = e === this ? null : e;
    n !== this.#s && (n && this.#y(n, "dragenter"), this.#s && this.#y(this.#s, "dragleave"), this.#s = n), this.#_ = !!n && !this.#y(n, "dragover"), this.#g();
  }
  /** Returns false if canceled. */
  #y(t, e) {
    return this.#d || (this.#d = new DataTransfer(), this.#d.setData("text/uri-list", this.#t.currentSrc)), t.dispatchEvent(
      new DragEvent(e, {
        bubbles: !0,
        cancelable: !0,
        composed: !0,
        dataTransfer: this.#d
      })
    );
  }
}
function Zt(s, t) {
  const e = s.length;
  return t === 0 ? s : s.map((n, i) => {
    const r = Math.min(t, i, e - 1 - i);
    let [o, l] = [0, 0];
    for (let f = i - r; f <= i + r; f++)
      o += s[f][0], l += s[f][1];
    const a = 2 * r + 1;
    return [o / a, l / a];
  });
}
function te(s) {
  return s.shiftKey ? "add" : s.altKey ? "subtract" : null;
}
function ii(s, t, e) {
  let n;
  try {
    n = e === "add" ? Jt.union([s], [t]) : Jt.difference([s], [t]);
  } catch (o) {
    return console.warn("Lasso tool couldn't combine lassos:", o), null;
  }
  const i = n.map((o) => o[0]);
  return i.length ? i.reduce((o, l) => ee(l) > ee(o) ? l : o).slice(0, -1).map(([o, l]) => [o, l]) : null;
}
function ee(s) {
  let t = 0;
  for (let e = 0; e < s.length; e++) {
    const [n, i] = s[e], [r, o] = s[(e + 1) % s.length];
    t += n * o - r * i;
  }
  return Math.abs(t) / 2;
}
function U(s) {
  return s?.naturalWidth && s.naturalHeight ? { width: s.naturalWidth, height: s.naturalHeight } : null;
}
function ne(s) {
  return s && s.map(([t, e]) => [Math.round(t), Math.round(e)]);
}
function ie(s, t, e) {
  return Math.max(t, Math.min(e, s));
}
const bt = "lasso-tool-overlay";
customElements.get(bt) || customElements.define(bt, ni);
var si = /* @__PURE__ */ wt("<div><!></div>");
function oi(s, t) {
  $e(t, !0);
  const e = /* @__PURE__ */ sn(t, ["$$slots", "$$events", "$$legacy"]), n = new yn(e), i = document.createElement(bt);
  let r, o = n.props.value ?? null;
  i.value = o;
  let l = q(null), a = q(!1), f = null;
  function d(g, y) {
    return JSON.stringify(g ?? null) === JSON.stringify(y ?? null);
  }
  function h(g, y) {
    !g && y ? n.dispatch("drawn") : g && !y && n.dispatch("cleared");
  }
  function c(g) {
    if (L(l)) return;
    X(l, g, !0), g.stage.append(i), g.add_tool(n.shared.id, r), i.area = g.area, i.target = g.image;
    const y = () => {
      X(a, g.tool === n.shared.id);
    };
    g.addEventListener("tool-change", y), y();
  }
  function u() {
    L(l) && (L(l).tool = L(a) ? null : n.shared.id);
  }
  he(() => {
    r.parentElement && (r.parentElement.hidden = !0), i.addEventListener("lasso-change", (y) => {
      const x = y.detail;
      h(o, x), o = x, n.props.value = x, n.dispatch("input"), n.dispatch("change");
    });
    const g = n.props.canvas_id;
    g !== null && (f = xn(g, c));
  }), rn(() => {
    f?.(), i.target = null, i.remove();
  }), D(() => {
    const g = n.props.value ?? null;
    d(g, o) || (h(o, g), o = g, i.value = g, n.dispatch("change"));
  }), D(() => {
    i.toggleAttribute("disabled", !L(a) || n.shared.interactive === !1), i.toggleAttribute("hidden", n.shared.visible === !1), i.toggleAttribute("static", n.props.marching_ants === !1), i.smoothing = n.props.smoothing ?? 1, i.tooltips = [
      n.props.draw_tooltip ?? "",
      n.props.clear_tooltip ?? ""
    ];
  });
  var m = si(), p = Z(m);
  {
    let g = dt(() => (L(a) ? n.props.disable_tooltip : n.props.enable_tooltip) ?? ""), y = dt(() => n.shared.interactive === !1);
    an(p, {
      get Icon() {
        return bn;
      },
      get label() {
        return L(g);
      },
      get disabled() {
        return L(y);
      },
      onclick: u
    });
  }
  Ze(m, (g) => r = g, () => r), ut(() => et(m, "hidden", !L(l) || n.shared.visible === !1)), W(s, m), ze();
}
export {
  oi as default
};
