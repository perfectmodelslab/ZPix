import { i as jt, g as Gt, o as Yt, n as Ft, u as Q, c as At, a as G, e as Dt, b as qt, s as V, p as ct, d as K, f as Z, h as Ut, j as Xt } from "./runtime-Du6aj1Oe.js";
function Nt(r) {
  throw new Error("https://svelte.dev/e/lifecycle_outside_component");
}
const Ht = [];
function Wt(r, t = !1, e = !1) {
  return X(r, /* @__PURE__ */ new Map(), "", Ht, null, e);
}
function X(r, t, e, n, i = null, s = !1) {
  if (typeof r == "object" && r !== null) {
    var o = t.get(r);
    if (o !== void 0) return o;
    if (r instanceof Map) return (
      /** @type {Snapshot<T>} */
      new Map(r)
    );
    if (r instanceof Set) return (
      /** @type {Snapshot<T>} */
      new Set(r)
    );
    if (jt(r)) {
      var l = (
        /** @type {Snapshot<any>} */
        Array(r.length)
      );
      t.set(r, l), i !== null && t.set(i, l);
      for (var u = 0; u < r.length; u += 1) {
        var f = r[u];
        u in r && (l[u] = X(f, t, e, n, null, s));
      }
      return l;
    }
    if (Gt(r) === Yt) {
      l = {}, t.set(r, l), i !== null && t.set(i, l);
      for (var p in r)
        l[p] = X(
          // @ts-expect-error
          r[p],
          t,
          e,
          n,
          null,
          s
        );
      return l;
    }
    if (r instanceof Date)
      return (
        /** @type {Snapshot<T>} */
        structuredClone(r)
      );
    if (typeof /** @type {T & { toJSON?: any } } */
    r.toJSON == "function" && !s)
      return X(
        /** @type {T & { toJSON(): any } } */
        r.toJSON(),
        t,
        e,
        n,
        // Associate the instance with the toJSON clone
        r
      );
  }
  if (r instanceof EventTarget)
    return (
      /** @type {Snapshot<T>} */
      r
    );
  try {
    return (
      /** @type {Snapshot<T>} */
      structuredClone(r)
    );
  } catch {
    return (
      /** @type {Snapshot<T>} */
      r
    );
  }
}
function Jt(r, t, e) {
  if (r == null)
    return t(void 0), Ft;
  const n = Q(
    () => r.subscribe(
      t,
      // @ts-expect-error
      e
    )
  );
  return n.unsubscribe ? () => n.unsubscribe() : n;
}
function Qt(r) {
  let t;
  return Jt(r, (e) => t = e)(), t;
}
const Vt = {
  get(r, t) {
    if (!r.exclude.includes(t))
      return r.props[t];
  },
  set(r, t) {
    return !1;
  },
  getOwnPropertyDescriptor(r, t) {
    if (!r.exclude.includes(t) && t in r.props)
      return {
        enumerable: !0,
        configurable: !0,
        value: r.props[t]
      };
  },
  has(r, t) {
    return r.exclude.includes(t) ? !1 : t in r.props;
  },
  ownKeys(r) {
    return Reflect.ownKeys(r.props).filter((t) => !r.exclude.includes(t));
  }
};
// @__NO_SIDE_EFFECTS__
function Kt(r, t, e) {
  return new Proxy(
    { props: r, exclude: t },
    Vt
  );
}
const Zt = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], ft = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
Zt.reduce((r, { color: t, primary: e, secondary: n }) => ({
  ...r,
  [t]: {
    primary: ft[t][e],
    secondary: ft[t][n]
  }
}), {});
function $t(r) {
  At === null && Nt(), G(() => {
    const t = Q(r);
    if (typeof t == "function") return (
      /** @type {() => void} */
      t
    );
  });
}
function te(r) {
  At === null && Nt(), $t(() => () => Q(r));
}
function ee(r) {
  let t;
  const e = qt((i) => {
    let s = !1;
    const o = r.subscribe((l) => {
      t = l, s && i();
    });
    return s = !0, o;
  });
  function n() {
    return Dt() ? (e(), t) : Qt(r);
  }
  return "set" in r ? {
    get current() {
      return n();
    },
    set current(i) {
      r.set(i);
    }
  } : {
    get current() {
      return n();
    }
  };
}
const ne = "__i18n__", ie = [
  "label",
  "info",
  "placeholder",
  "description",
  "title",
  "value"
], se = [
  "elem_id",
  "elem_classes",
  "visible",
  "interactive",
  "server_fns",
  "server",
  "id",
  "target",
  "theme_mode",
  "version",
  "root",
  "autoscroll",
  "max_file_size",
  "formatter",
  "client",
  "load_component",
  "scale",
  "min_width",
  "theme",
  "padding",
  "loading_status",
  "label",
  "show_label",
  "validation_error",
  "show_progress",
  "api_prefix",
  "container",
  "attached_events",
  "register_component",
  "dispatcher"
];
function re(r) {
  return typeof r == "string" && r.includes(ne);
}
class oe {
  load_component;
  #t = V(ct({}));
  get shared() {
    return K(this.#t);
  }
  set shared(t) {
    Z(this.#t, t, !0);
  }
  #e = V(ct({}));
  get props() {
    return K(this.#e);
  }
  set props(t) {
    Z(this.#e, t, !0);
  }
  #i = V((t) => t);
  get i18n() {
    return K(this.#i);
  }
  set i18n(t) {
    Z(this.#i, t, !0);
  }
  i18n_store;
  _i18n_from_store;
  translatable_props = {};
  dispatcher;
  last_update = null;
  shared_props = se;
  mounted = !1;
  old_value;
  register_component;
  constructor(t, e) {
    for (const n in t.shared_props)
      this.shared[n] = t.shared_props[n];
    for (const n in t.props)
      n !== "i18n_store" && (this.props[n] = t.props[n]);
    if (e)
      for (const n in e)
        this.props[n] === void 0 && (this.props[n] = e[n]);
    this.i18n = this.props.i18n ?? ((n) => n), this.i18n_store = t.props.i18n_store, this._i18n_from_store = this.i18n_store ? ee(this.i18n_store) : void 0;
    for (const n of ie)
      this.shared[n] = this._translate_and_store(
        "shared",
        n,
        // @ts-ignore
        t.shared_props[n]
      ), this.props[n] = this._translate_and_store(
        "props",
        n,
        // @ts-ignore
        t.props[n]
      );
    this.load_component = this.shared.load_component, this.register_component = this.shared.register_component || (() => {
    }), this.dispatcher = this.shared.dispatcher || (() => {
    }), this.register_component(
      t.shared_props.id,
      // @ts-ignore
      this.set_data.bind(this),
      this.get_data.bind(this)
    ), G(() => {
      for (const n in t.shared_props)
        this._is_i18n_managed(`shared.${n}`, t.shared_props[n]) || (this.shared[n] = t.shared_props[n]);
      for (const n in t.props)
        n !== "i18n_store" && (this._is_i18n_managed(`props.${n}`, t.props[n]) || (this.props[n] = t.props[n]));
      this.register_component(
        t.shared_props.id,
        // @ts-ignore
        this.set_data.bind(this),
        this.get_data.bind(this)
      ), Q(() => {
        this.shared.id = t.shared_props.id;
      });
    }), G(() => this.i18n_store ? this.i18n_store.subscribe(() => {
      for (const [i, s] of Object.entries(this.translatable_props)) {
        const [o, l] = i.split("."), u = this.i18n(s);
        o === "shared" ? this.shared[l] = u : this.props[l] = u;
      }
    }) : void 0);
  }
  // check if props are translatable
  _is_i18n_managed(t, e) {
    const n = this.translatable_props[t];
    return n ? e === n ? !0 : (delete this.translatable_props[t], !1) : !1;
  }
  _translate_and_store(t, e, n) {
    if (typeof n != "string") return n;
    const i = this.i18n(n);
    return i !== n && (this.translatable_props[`${t}.${e}`] = n), i;
  }
  // Reactive variant of `i18n`. Reading it inside a derived or template
  // subscribes to the live locale store (via Svelte's createSubscriber), so
  // the caller re-runs when the locale changes at runtime. The store is only
  // the reactivity trigger; translation always goes through `this.i18n` so a
  // custom formatter passed via props keeps taking effect.
  live_i18n = (t) => (this._i18n_from_store?.current, this.i18n(t));
  dispatch(t, e) {
    this.dispatcher(this.shared.id, t, e);
  }
  async get_data() {
    return Wt(this.props);
  }
  update(t) {
    this.set_data(t);
  }
  set_data(t) {
    for (const e in t) {
      const n = t[e], i = re(n) ? this._translate_and_store(this.shared_props.includes(e) ? "shared" : "props", e, n) : n;
      if (this.shared_props.includes(e)) {
        const s = e;
        this.shared[s] = i;
        continue;
      }
      this.props[e] = i;
    }
  }
  watch_for_change() {
    G(() => {
      this.mounted || (this.old_value = this.props.value, this.mounted = !0), this.old_value != this.props.value && (this.old_value = this.props.value, this.dispatch("change"));
    });
  }
}
class T {
  constructor(t, e) {
    this.next = null, this.key = t, this.data = e, this.left = null, this.right = null;
  }
}
function le(r, t) {
  return r > t ? 1 : r < t ? -1 : 0;
}
function C(r, t, e) {
  const n = new T(null, null);
  let i = n, s = n;
  for (; ; ) {
    const o = e(r, t.key);
    if (o < 0) {
      if (t.left === null) break;
      if (e(r, t.left.key) < 0) {
        const l = t.left;
        if (t.left = l.right, l.right = t, t = l, t.left === null) break;
      }
      s.left = t, s = t, t = t.left;
    } else if (o > 0) {
      if (t.right === null) break;
      if (e(r, t.right.key) > 0) {
        const l = t.right;
        if (t.right = l.left, l.left = t, t = l, t.right === null) break;
      }
      i.right = t, i = t, t = t.right;
    } else break;
  }
  return i.right = t.left, s.left = t.right, t.left = n.right, t.right = n.left, t;
}
function tt(r, t, e, n) {
  const i = new T(r, t);
  if (e === null)
    return i.left = i.right = null, i;
  e = C(r, e, n);
  const s = n(r, e.key);
  return s < 0 ? (i.left = e.left, i.right = e, e.left = null) : s >= 0 && (i.right = e.right, i.left = e, e.right = null), i;
}
function at(r, t, e) {
  let n = null, i = null;
  if (t) {
    t = C(r, t, e);
    const s = e(t.key, r);
    s === 0 ? (n = t.left, i = t.right) : s < 0 ? (i = t.right, t.right = null, n = t) : (n = t.left, t.left = null, i = t);
  }
  return { left: n, right: i };
}
function he(r, t, e) {
  return t === null ? r : (r === null || (t = C(r.key, t, e), t.left = r), t);
}
function nt(r, t, e, n, i) {
  if (r) {
    n(`${t}${e ? "└── " : "├── "}${i(r)}
`);
    const s = t + (e ? "    " : "│   ");
    r.left && nt(r.left, s, !1, n, i), r.right && nt(r.right, s, !0, n, i);
  }
}
class ut {
  constructor(t = le) {
    this._root = null, this._size = 0, this._comparator = t;
  }
  /**
   * Inserts a key, allows duplicates
   */
  insert(t, e) {
    return this._size++, this._root = tt(t, e, this._root, this._comparator);
  }
  /**
   * Adds a key, if it is not present in the tree
   */
  add(t, e) {
    const n = new T(t, e);
    this._root === null && (n.left = n.right = null, this._size++, this._root = n);
    const i = this._comparator, s = C(t, this._root, i), o = i(t, s.key);
    return o === 0 ? this._root = s : (o < 0 ? (n.left = s.left, n.right = s, s.left = null) : o > 0 && (n.right = s.right, n.left = s, s.right = null), this._size++, this._root = n), this._root;
  }
  /**
   * @param  {Key} key
   * @return {Node|null}
   */
  remove(t) {
    this._root = this._remove(t, this._root, this._comparator);
  }
  /**
   * Deletes i from the tree if it's there
   */
  _remove(t, e, n) {
    let i;
    return e === null ? null : (e = C(t, e, n), n(t, e.key) === 0 ? (e.left === null ? i = e.right : (i = C(t, e.left, n), i.right = e.right), this._size--, i) : e);
  }
  /**
   * Removes and returns the node with smallest key
   */
  pop() {
    let t = this._root;
    if (t) {
      for (; t.left; ) t = t.left;
      return this._root = C(t.key, this._root, this._comparator), this._root = this._remove(t.key, this._root, this._comparator), { key: t.key, data: t.data };
    }
    return null;
  }
  /**
   * Find without splaying
   */
  findStatic(t) {
    let e = this._root;
    const n = this._comparator;
    for (; e; ) {
      const i = n(t, e.key);
      if (i === 0) return e;
      i < 0 ? e = e.left : e = e.right;
    }
    return null;
  }
  find(t) {
    return this._root && (this._root = C(t, this._root, this._comparator), this._comparator(t, this._root.key) !== 0) ? null : this._root;
  }
  contains(t) {
    let e = this._root;
    const n = this._comparator;
    for (; e; ) {
      const i = n(t, e.key);
      if (i === 0) return !0;
      i < 0 ? e = e.left : e = e.right;
    }
    return !1;
  }
  forEach(t, e) {
    let n = this._root;
    const i = [];
    let s = !1;
    for (; !s; )
      n !== null ? (i.push(n), n = n.left) : i.length !== 0 ? (n = i.pop(), t.call(e, n), n = n.right) : s = !0;
    return this;
  }
  /**
   * Walk key range from `low` to `high`. Stops if `fn` returns a value.
   */
  range(t, e, n, i) {
    const s = [], o = this._comparator;
    let l = this._root, u;
    for (; s.length !== 0 || l; )
      if (l)
        s.push(l), l = l.left;
      else {
        if (l = s.pop(), u = o(l.key, e), u > 0)
          break;
        if (o(l.key, t) >= 0 && n.call(i, l))
          return this;
        l = l.right;
      }
    return this;
  }
  /**
   * Returns array of keys
   */
  keys() {
    const t = [];
    return this.forEach(({ key: e }) => {
      t.push(e);
    }), t;
  }
  /**
   * Returns array of all the data in the nodes
   */
  values() {
    const t = [];
    return this.forEach(({ data: e }) => {
      t.push(e);
    }), t;
  }
  min() {
    return this._root ? this.minNode(this._root).key : null;
  }
  max() {
    return this._root ? this.maxNode(this._root).key : null;
  }
  minNode(t = this._root) {
    if (t) for (; t.left; ) t = t.left;
    return t;
  }
  maxNode(t = this._root) {
    if (t) for (; t.right; ) t = t.right;
    return t;
  }
  /**
   * Returns node at given index
   */
  at(t) {
    let e = this._root, n = !1, i = 0;
    const s = [];
    for (; !n; )
      if (e)
        s.push(e), e = e.left;
      else if (s.length > 0) {
        if (e = s.pop(), i === t) return e;
        i++, e = e.right;
      } else n = !0;
    return null;
  }
  next(t) {
    let e = this._root, n = null;
    if (t.right) {
      for (n = t.right; n.left; ) n = n.left;
      return n;
    }
    const i = this._comparator;
    for (; e; ) {
      const s = i(t.key, e.key);
      if (s === 0) break;
      s < 0 ? (n = e, e = e.left) : e = e.right;
    }
    return n;
  }
  prev(t) {
    let e = this._root, n = null;
    if (t.left !== null) {
      for (n = t.left; n.right; ) n = n.right;
      return n;
    }
    const i = this._comparator;
    for (; e; ) {
      const s = i(t.key, e.key);
      if (s === 0) break;
      s < 0 ? e = e.left : (n = e, e = e.right);
    }
    return n;
  }
  clear() {
    return this._root = null, this._size = 0, this;
  }
  toList() {
    return ce(this._root);
  }
  /**
   * Bulk-load items. Both array have to be same size
   */
  load(t, e = [], n = !1) {
    let i = t.length;
    const s = this._comparator;
    if (n && rt(t, e, 0, i - 1, s), this._root === null)
      this._root = it(t, e, 0, i), this._size = i;
    else {
      const o = fe(
        this.toList(),
        ue(t, e),
        s
      );
      i = this._size + i, this._root = st({ head: o }, 0, i);
    }
    return this;
  }
  isEmpty() {
    return this._root === null;
  }
  get size() {
    return this._size;
  }
  get root() {
    return this._root;
  }
  toString(t = (e) => String(e.key)) {
    const e = [];
    return nt(this._root, "", !0, (n) => e.push(n), t), e.join("");
  }
  update(t, e, n) {
    const i = this._comparator;
    let { left: s, right: o } = at(t, this._root, i);
    i(t, e) < 0 ? o = tt(e, n, o, i) : s = tt(e, n, s, i), this._root = he(s, o, i);
  }
  split(t) {
    return at(t, this._root, this._comparator);
  }
  *[Symbol.iterator]() {
    let t = this._root;
    const e = [];
    let n = !1;
    for (; !n; )
      t !== null ? (e.push(t), t = t.left) : e.length !== 0 ? (t = e.pop(), yield t, t = t.right) : n = !0;
  }
}
function it(r, t, e, n) {
  const i = n - e;
  if (i > 0) {
    const s = e + Math.floor(i / 2), o = r[s], l = t[s], u = new T(o, l);
    return u.left = it(r, t, e, s), u.right = it(r, t, s + 1, n), u;
  }
  return null;
}
function ue(r, t) {
  const e = new T(null, null);
  let n = e;
  for (let i = 0; i < r.length; i++)
    n = n.next = new T(r[i], t[i]);
  return n.next = null, e.next;
}
function ce(r) {
  let t = r;
  const e = [];
  let n = !1;
  const i = new T(null, null);
  let s = i;
  for (; !n; )
    t ? (e.push(t), t = t.left) : e.length > 0 ? (t = s = s.next = e.pop(), t = t.right) : n = !0;
  return s.next = null, i.next;
}
function st(r, t, e) {
  const n = e - t;
  if (n > 0) {
    const i = t + Math.floor(n / 2), s = st(r, t, i), o = r.head;
    return o.left = s, r.head = r.head.next, o.right = st(r, i + 1, e), o;
  }
  return null;
}
function fe(r, t, e) {
  const n = new T(null, null);
  let i = n, s = r, o = t;
  for (; s !== null && o !== null; )
    e(s.key, o.key) < 0 ? (i.next = s, s = s.next) : (i.next = o, o = o.next), i = i.next;
  return s !== null ? i.next = s : o !== null && (i.next = o), n.next;
}
function rt(r, t, e, n, i) {
  if (e >= n) return;
  const s = r[e + n >> 1];
  let o = e - 1, l = n + 1;
  for (; ; ) {
    do
      o++;
    while (i(r[o], s) < 0);
    do
      l--;
    while (i(r[l], s) > 0);
    if (o >= l) break;
    let u = r[o];
    r[o] = r[l], r[l] = u, u = t[o], t[o] = t[l], t[l] = u;
  }
  rt(r, t, e, l, i), rt(r, t, l + 1, n, i);
}
const $ = 11102230246251565e-32, v = 134217729, ae = (3 + 8 * $) * $;
function et(r, t, e, n, i) {
  let s, o, l, u, f = t[0], p = n[0], h = 0, c = 0;
  p > f == p > -f ? (s = f, f = t[++h]) : (s = p, p = n[++c]);
  let a = 0;
  if (h < r && c < e)
    for (p > f == p > -f ? (o = f + s, l = s - (o - f), f = t[++h]) : (o = p + s, l = s - (o - p), p = n[++c]), s = o, l !== 0 && (i[a++] = l); h < r && c < e; )
      p > f == p > -f ? (o = s + f, u = o - s, l = s - (o - u) + (f - u), f = t[++h]) : (o = s + p, u = o - s, l = s - (o - u) + (p - u), p = n[++c]), s = o, l !== 0 && (i[a++] = l);
  for (; h < r; )
    o = s + f, u = o - s, l = s - (o - u) + (f - u), f = t[++h], s = o, l !== 0 && (i[a++] = l);
  for (; c < e; )
    o = s + p, u = o - s, l = s - (o - u) + (p - u), p = n[++c], s = o, l !== 0 && (i[a++] = l);
  return (s !== 0 || a === 0) && (i[a++] = s), a;
}
function pe(r, t) {
  let e = t[0];
  for (let n = 1; n < r; n++) e += t[n];
  return e;
}
function U(r) {
  return new Float64Array(r);
}
const de = (3 + 16 * $) * $, ge = (2 + 12 * $) * $, ye = (9 + 64 * $) * $ * $, j = U(4), pt = U(8), dt = U(12), gt = U(16), k = U(4);
function xe(r, t, e, n, i, s, o) {
  let l, u, f, p, h, c, a, g, d, x, y, m, _, b, E, w, I, S;
  const R = r - i, P = e - i, L = t - s, O = n - s;
  b = R * O, c = v * R, a = c - (c - R), g = R - a, c = v * O, d = c - (c - O), x = O - d, E = g * x - (b - a * d - g * d - a * x), w = L * P, c = v * L, a = c - (c - L), g = L - a, c = v * P, d = c - (c - P), x = P - d, I = g * x - (w - a * d - g * d - a * x), y = E - I, h = E - y, j[0] = E - (y + h) + (h - I), m = b + y, h = m - b, _ = b - (m - h) + (y - h), y = _ - w, h = _ - y, j[1] = _ - (y + h) + (h - w), S = m + y, h = S - m, j[2] = m - (S - h) + (y - h), j[3] = S;
  let N = pe(4, j), Y = ge * o;
  if (N >= Y || -N >= Y || (h = r - R, l = r - (R + h) + (h - i), h = e - P, f = e - (P + h) + (h - i), h = t - L, u = t - (L + h) + (h - s), h = n - O, p = n - (O + h) + (h - s), l === 0 && u === 0 && f === 0 && p === 0) || (Y = ye * o + ae * Math.abs(N), N += R * p + O * l - (L * f + P * u), N >= Y || -N >= Y)) return N;
  b = l * O, c = v * l, a = c - (c - l), g = l - a, c = v * O, d = c - (c - O), x = O - d, E = g * x - (b - a * d - g * d - a * x), w = u * P, c = v * u, a = c - (c - u), g = u - a, c = v * P, d = c - (c - P), x = P - d, I = g * x - (w - a * d - g * d - a * x), y = E - I, h = E - y, k[0] = E - (y + h) + (h - I), m = b + y, h = m - b, _ = b - (m - h) + (y - h), y = _ - w, h = _ - y, k[1] = _ - (y + h) + (h - w), S = m + y, h = S - m, k[2] = m - (S - h) + (y - h), k[3] = S;
  const Bt = et(4, j, 4, k, pt);
  b = R * p, c = v * R, a = c - (c - R), g = R - a, c = v * p, d = c - (c - p), x = p - d, E = g * x - (b - a * d - g * d - a * x), w = L * f, c = v * L, a = c - (c - L), g = L - a, c = v * f, d = c - (c - f), x = f - d, I = g * x - (w - a * d - g * d - a * x), y = E - I, h = E - y, k[0] = E - (y + h) + (h - I), m = b + y, h = m - b, _ = b - (m - h) + (y - h), y = _ - w, h = _ - y, k[1] = _ - (y + h) + (h - w), S = m + y, h = S - m, k[2] = m - (S - h) + (y - h), k[3] = S;
  const zt = et(Bt, pt, 4, k, dt);
  b = l * p, c = v * l, a = c - (c - l), g = l - a, c = v * p, d = c - (c - p), x = p - d, E = g * x - (b - a * d - g * d - a * x), w = u * f, c = v * u, a = c - (c - u), g = u - a, c = v * f, d = c - (c - f), x = f - d, I = g * x - (w - a * d - g * d - a * x), y = E - I, h = E - y, k[0] = E - (y + h) + (h - I), m = b + y, h = m - b, _ = b - (m - h) + (y - h), y = _ - w, h = _ - y, k[1] = _ - (y + h) + (h - w), S = m + y, h = S - m, k[2] = m - (S - h) + (y - h), k[3] = S;
  const Tt = et(zt, dt, 4, k, gt);
  return gt[Tt - 1];
}
function me(r, t, e, n, i, s) {
  const o = (t - s) * (e - i), l = (r - i) * (n - s), u = o - l, f = Math.abs(o + l);
  return Math.abs(u) >= de * f ? u : -xe(r, t, e, n, i, s, f);
}
const F = (r, t) => r.ll.x <= t.x && t.x <= r.ur.x && r.ll.y <= t.y && t.y <= r.ur.y, ot = (r, t) => {
  if (t.ur.x < r.ll.x || r.ur.x < t.ll.x || t.ur.y < r.ll.y || r.ur.y < t.ll.y) return null;
  const e = r.ll.x < t.ll.x ? t.ll.x : r.ll.x, n = r.ur.x < t.ur.x ? r.ur.x : t.ur.x, i = r.ll.y < t.ll.y ? t.ll.y : r.ll.y, s = r.ur.y < t.ur.y ? r.ur.y : t.ur.y;
  return {
    ll: {
      x: e,
      y: i
    },
    ur: {
      x: n,
      y: s
    }
  };
};
let B = Number.EPSILON;
B === void 0 && (B = Math.pow(2, -52));
const be = B * B, yt = (r, t) => {
  if (-B < r && r < B && -B < t && t < B)
    return 0;
  const e = r - t;
  return e * e < be * r * t ? 0 : r < t ? -1 : 1;
};
class _e {
  constructor() {
    this.reset();
  }
  reset() {
    this.xRounder = new xt(), this.yRounder = new xt();
  }
  round(t, e) {
    return {
      x: this.xRounder.round(t),
      y: this.yRounder.round(e)
    };
  }
}
class xt {
  constructor() {
    this.tree = new ut(), this.round(0);
  }
  // Note: this can rounds input values backwards or forwards.
  //       You might ask, why not restrict this to just rounding
  //       forwards? Wouldn't that allow left endpoints to always
  //       remain left endpoints during splitting (never change to
  //       right). No - it wouldn't, because we snap intersections
  //       to endpoints (to establish independence from the segment
  //       angle for t-intersections).
  round(t) {
    const e = this.tree.add(t), n = this.tree.prev(e);
    if (n !== null && yt(e.key, n.key) === 0)
      return this.tree.remove(t), n.key;
    const i = this.tree.next(e);
    return i !== null && yt(e.key, i.key) === 0 ? (this.tree.remove(t), i.key) : t;
  }
}
const q = new _e(), H = (r, t) => r.x * t.y - r.y * t.x, Ct = (r, t) => r.x * t.x + r.y * t.y, mt = (r, t, e) => {
  const n = me(r.x, r.y, t.x, t.y, e.x, e.y);
  return n > 0 ? -1 : n < 0 ? 1 : 0;
}, W = (r) => Math.sqrt(Ct(r, r)), Ee = (r, t, e) => {
  const n = {
    x: t.x - r.x,
    y: t.y - r.y
  }, i = {
    x: e.x - r.x,
    y: e.y - r.y
  };
  return H(i, n) / W(i) / W(n);
}, we = (r, t, e) => {
  const n = {
    x: t.x - r.x,
    y: t.y - r.y
  }, i = {
    x: e.x - r.x,
    y: e.y - r.y
  };
  return Ct(i, n) / W(i) / W(n);
}, bt = (r, t, e) => t.y === 0 ? null : {
  x: r.x + t.x / t.y * (e - r.y),
  y: e
}, _t = (r, t, e) => t.x === 0 ? null : {
  x: e,
  y: r.y + t.y / t.x * (e - r.x)
}, Se = (r, t, e, n) => {
  if (t.x === 0) return _t(e, n, r.x);
  if (n.x === 0) return _t(r, t, e.x);
  if (t.y === 0) return bt(e, n, r.y);
  if (n.y === 0) return bt(r, t, e.y);
  const i = H(t, n);
  if (i == 0) return null;
  const s = {
    x: e.x - r.x,
    y: e.y - r.y
  }, o = H(s, t) / i, l = H(s, n) / i, u = r.x + l * t.x, f = e.x + o * n.x, p = r.y + l * t.y, h = e.y + o * n.y, c = (u + f) / 2, a = (p + h) / 2;
  return {
    x: c,
    y: a
  };
};
class M {
  // for ordering sweep events in the sweep event queue
  static compare(t, e) {
    const n = M.comparePoints(t.point, e.point);
    return n !== 0 ? n : (t.point !== e.point && t.link(e), t.isLeft !== e.isLeft ? t.isLeft ? 1 : -1 : z.compare(t.segment, e.segment));
  }
  // for ordering points in sweep line order
  static comparePoints(t, e) {
    return t.x < e.x ? -1 : t.x > e.x ? 1 : t.y < e.y ? -1 : t.y > e.y ? 1 : 0;
  }
  // Warning: 'point' input will be modified and re-used (for performance)
  constructor(t, e) {
    t.events === void 0 ? t.events = [this] : t.events.push(this), this.point = t, this.isLeft = e;
  }
  link(t) {
    if (t.point === this.point)
      throw new Error("Tried to link already linked events");
    const e = t.point.events;
    for (let n = 0, i = e.length; n < i; n++) {
      const s = e[n];
      this.point.events.push(s), s.point = this.point;
    }
    this.checkForConsuming();
  }
  /* Do a pass over our linked events and check to see if any pair
   * of segments match, and should be consumed. */
  checkForConsuming() {
    const t = this.point.events.length;
    for (let e = 0; e < t; e++) {
      const n = this.point.events[e];
      if (n.segment.consumedBy === void 0)
        for (let i = e + 1; i < t; i++) {
          const s = this.point.events[i];
          s.consumedBy === void 0 && n.otherSE.point.events === s.otherSE.point.events && n.segment.consume(s.segment);
        }
    }
  }
  getAvailableLinkedEvents() {
    const t = [];
    for (let e = 0, n = this.point.events.length; e < n; e++) {
      const i = this.point.events[e];
      i !== this && !i.segment.ringOut && i.segment.isInResult() && t.push(i);
    }
    return t;
  }
  /**
   * Returns a comparator function for sorting linked events that will
   * favor the event that will give us the smallest left-side angle.
   * All ring construction starts as low as possible heading to the right,
   * so by always turning left as sharp as possible we'll get polygons
   * without uncessary loops & holes.
   *
   * The comparator function has a compute cache such that it avoids
   * re-computing already-computed values.
   */
  getLeftmostComparator(t) {
    const e = /* @__PURE__ */ new Map(), n = (i) => {
      const s = i.otherSE;
      e.set(i, {
        sine: Ee(this.point, t.point, s.point),
        cosine: we(this.point, t.point, s.point)
      });
    };
    return (i, s) => {
      e.has(i) || n(i), e.has(s) || n(s);
      const {
        sine: o,
        cosine: l
      } = e.get(i), {
        sine: u,
        cosine: f
      } = e.get(s);
      return o >= 0 && u >= 0 ? l < f ? 1 : l > f ? -1 : 0 : o < 0 && u < 0 ? l < f ? -1 : l > f ? 1 : 0 : u < o ? -1 : u > o ? 1 : 0;
    };
  }
}
let ve = 0;
class z {
  /* This compare() function is for ordering segments in the sweep
   * line tree, and does so according to the following criteria:
   *
   * Consider the vertical line that lies an infinestimal step to the
   * right of the right-more of the two left endpoints of the input
   * segments. Imagine slowly moving a point up from negative infinity
   * in the increasing y direction. Which of the two segments will that
   * point intersect first? That segment comes 'before' the other one.
   *
   * If neither segment would be intersected by such a line, (if one
   * or more of the segments are vertical) then the line to be considered
   * is directly on the right-more of the two left inputs.
   */
  static compare(t, e) {
    const n = t.leftSE.point.x, i = e.leftSE.point.x, s = t.rightSE.point.x, o = e.rightSE.point.x;
    if (o < n) return 1;
    if (s < i) return -1;
    const l = t.leftSE.point.y, u = e.leftSE.point.y, f = t.rightSE.point.y, p = e.rightSE.point.y;
    if (n < i) {
      if (u < l && u < f) return 1;
      if (u > l && u > f) return -1;
      const h = t.comparePoint(e.leftSE.point);
      if (h < 0) return 1;
      if (h > 0) return -1;
      const c = e.comparePoint(t.rightSE.point);
      return c !== 0 ? c : -1;
    }
    if (n > i) {
      if (l < u && l < p) return -1;
      if (l > u && l > p) return 1;
      const h = e.comparePoint(t.leftSE.point);
      if (h !== 0) return h;
      const c = t.comparePoint(e.rightSE.point);
      return c < 0 ? 1 : c > 0 ? -1 : 1;
    }
    if (l < u) return -1;
    if (l > u) return 1;
    if (s < o) {
      const h = e.comparePoint(t.rightSE.point);
      if (h !== 0) return h;
    }
    if (s > o) {
      const h = t.comparePoint(e.rightSE.point);
      if (h < 0) return 1;
      if (h > 0) return -1;
    }
    if (s !== o) {
      const h = f - l, c = s - n, a = p - u, g = o - i;
      if (h > c && a < g) return 1;
      if (h < c && a > g) return -1;
    }
    return s > o ? 1 : s < o || f < p ? -1 : f > p ? 1 : t.id < e.id ? -1 : t.id > e.id ? 1 : 0;
  }
  /* Warning: a reference to ringWindings input will be stored,
   *  and possibly will be later modified */
  constructor(t, e, n, i) {
    this.id = ++ve, this.leftSE = t, t.segment = this, t.otherSE = e, this.rightSE = e, e.segment = this, e.otherSE = t, this.rings = n, this.windings = i;
  }
  static fromRing(t, e, n) {
    let i, s, o;
    const l = M.comparePoints(t, e);
    if (l < 0)
      i = t, s = e, o = 1;
    else if (l > 0)
      i = e, s = t, o = -1;
    else throw new Error(`Tried to create degenerate segment at [${t.x}, ${t.y}]`);
    const u = new M(i, !0), f = new M(s, !1);
    return new z(u, f, [n], [o]);
  }
  /* When a segment is split, the rightSE is replaced with a new sweep event */
  replaceRightSE(t) {
    this.rightSE = t, this.rightSE.segment = this, this.rightSE.otherSE = this.leftSE, this.leftSE.otherSE = this.rightSE;
  }
  bbox() {
    const t = this.leftSE.point.y, e = this.rightSE.point.y;
    return {
      ll: {
        x: this.leftSE.point.x,
        y: t < e ? t : e
      },
      ur: {
        x: this.rightSE.point.x,
        y: t > e ? t : e
      }
    };
  }
  /* A vector from the left point to the right */
  vector() {
    return {
      x: this.rightSE.point.x - this.leftSE.point.x,
      y: this.rightSE.point.y - this.leftSE.point.y
    };
  }
  isAnEndpoint(t) {
    return t.x === this.leftSE.point.x && t.y === this.leftSE.point.y || t.x === this.rightSE.point.x && t.y === this.rightSE.point.y;
  }
  /* Compare this segment with a point.
   *
   * A point P is considered to be colinear to a segment if there
   * exists a distance D such that if we travel along the segment
   * from one * endpoint towards the other a distance D, we find
   * ourselves at point P.
   *
   * Return value indicates:
   *
   *   1: point lies above the segment (to the left of vertical)
   *   0: point is colinear to segment
   *  -1: point lies below the segment (to the right of vertical)
   */
  comparePoint(t) {
    if (this.isAnEndpoint(t)) return 0;
    const e = this.leftSE.point, n = this.rightSE.point, i = this.vector();
    if (e.x === n.x)
      return t.x === e.x ? 0 : t.x < e.x ? 1 : -1;
    const s = (t.y - e.y) / i.y, o = e.x + s * i.x;
    if (t.x === o) return 0;
    const l = (t.x - e.x) / i.x, u = e.y + l * i.y;
    return t.y === u ? 0 : t.y < u ? -1 : 1;
  }
  /**
   * Given another segment, returns the first non-trivial intersection
   * between the two segments (in terms of sweep line ordering), if it exists.
   *
   * A 'non-trivial' intersection is one that will cause one or both of the
   * segments to be split(). As such, 'trivial' vs. 'non-trivial' intersection:
   *
   *   * endpoint of segA with endpoint of segB --> trivial
   *   * endpoint of segA with point along segB --> non-trivial
   *   * endpoint of segB with point along segA --> non-trivial
   *   * point along segA with point along segB --> non-trivial
   *
   * If no non-trivial intersection exists, return null
   * Else, return null.
   */
  getIntersection(t) {
    const e = this.bbox(), n = t.bbox(), i = ot(e, n);
    if (i === null) return null;
    const s = this.leftSE.point, o = this.rightSE.point, l = t.leftSE.point, u = t.rightSE.point, f = F(e, l) && this.comparePoint(l) === 0, p = F(n, s) && t.comparePoint(s) === 0, h = F(e, u) && this.comparePoint(u) === 0, c = F(n, o) && t.comparePoint(o) === 0;
    if (p && f)
      return c && !h ? o : !c && h ? u : null;
    if (p)
      return h && s.x === u.x && s.y === u.y ? null : s;
    if (f)
      return c && o.x === l.x && o.y === l.y ? null : l;
    if (c && h) return null;
    if (c) return o;
    if (h) return u;
    const a = Se(s, this.vector(), l, t.vector());
    return a === null || !F(i, a) ? null : q.round(a.x, a.y);
  }
  /**
   * Split the given segment into multiple segments on the given points.
   *  * Each existing segment will retain its leftSE and a new rightSE will be
   *    generated for it.
   *  * A new segment will be generated which will adopt the original segment's
   *    rightSE, and a new leftSE will be generated for it.
   *  * If there are more than two points given to split on, new segments
   *    in the middle will be generated with new leftSE and rightSE's.
   *  * An array of the newly generated SweepEvents will be returned.
   *
   * Warning: input array of points is modified
   */
  split(t) {
    const e = [], n = t.events !== void 0, i = new M(t, !0), s = new M(t, !1), o = this.rightSE;
    this.replaceRightSE(s), e.push(s), e.push(i);
    const l = new z(i, o, this.rings.slice(), this.windings.slice());
    return M.comparePoints(l.leftSE.point, l.rightSE.point) > 0 && l.swapEvents(), M.comparePoints(this.leftSE.point, this.rightSE.point) > 0 && this.swapEvents(), n && (i.checkForConsuming(), s.checkForConsuming()), e;
  }
  /* Swap which event is left and right */
  swapEvents() {
    const t = this.rightSE;
    this.rightSE = this.leftSE, this.leftSE = t, this.leftSE.isLeft = !0, this.rightSE.isLeft = !1;
    for (let e = 0, n = this.windings.length; e < n; e++)
      this.windings[e] *= -1;
  }
  /* Consume another segment. We take their rings under our wing
   * and mark them as consumed. Use for perfectly overlapping segments */
  consume(t) {
    let e = this, n = t;
    for (; e.consumedBy; ) e = e.consumedBy;
    for (; n.consumedBy; ) n = n.consumedBy;
    const i = z.compare(e, n);
    if (i !== 0) {
      if (i > 0) {
        const s = e;
        e = n, n = s;
      }
      if (e.prev === n) {
        const s = e;
        e = n, n = s;
      }
      for (let s = 0, o = n.rings.length; s < o; s++) {
        const l = n.rings[s], u = n.windings[s], f = e.rings.indexOf(l);
        f === -1 ? (e.rings.push(l), e.windings.push(u)) : e.windings[f] += u;
      }
      n.rings = null, n.windings = null, n.consumedBy = e, n.leftSE.consumedBy = e.leftSE, n.rightSE.consumedBy = e.rightSE;
    }
  }
  /* The first segment previous segment chain that is in the result */
  prevInResult() {
    return this._prevInResult !== void 0 ? this._prevInResult : (this.prev ? this.prev.isInResult() ? this._prevInResult = this.prev : this._prevInResult = this.prev.prevInResult() : this._prevInResult = null, this._prevInResult);
  }
  beforeState() {
    if (this._beforeState !== void 0) return this._beforeState;
    if (!this.prev) this._beforeState = {
      rings: [],
      windings: [],
      multiPolys: []
    };
    else {
      const t = this.prev.consumedBy || this.prev;
      this._beforeState = t.afterState();
    }
    return this._beforeState;
  }
  afterState() {
    if (this._afterState !== void 0) return this._afterState;
    const t = this.beforeState();
    this._afterState = {
      rings: t.rings.slice(0),
      windings: t.windings.slice(0),
      multiPolys: []
    };
    const e = this._afterState.rings, n = this._afterState.windings, i = this._afterState.multiPolys;
    for (let l = 0, u = this.rings.length; l < u; l++) {
      const f = this.rings[l], p = this.windings[l], h = e.indexOf(f);
      h === -1 ? (e.push(f), n.push(p)) : n[h] += p;
    }
    const s = [], o = [];
    for (let l = 0, u = e.length; l < u; l++) {
      if (n[l] === 0) continue;
      const f = e[l], p = f.poly;
      if (o.indexOf(p) === -1)
        if (f.isExterior) s.push(p);
        else {
          o.indexOf(p) === -1 && o.push(p);
          const h = s.indexOf(f.poly);
          h !== -1 && s.splice(h, 1);
        }
    }
    for (let l = 0, u = s.length; l < u; l++) {
      const f = s[l].multiPoly;
      i.indexOf(f) === -1 && i.push(f);
    }
    return this._afterState;
  }
  /* Is this segment part of the final result? */
  isInResult() {
    if (this.consumedBy) return !1;
    if (this._isInResult !== void 0) return this._isInResult;
    const t = this.beforeState().multiPolys, e = this.afterState().multiPolys;
    switch (A.type) {
      case "union": {
        const n = t.length === 0, i = e.length === 0;
        this._isInResult = n !== i;
        break;
      }
      case "intersection": {
        let n, i;
        t.length < e.length ? (n = t.length, i = e.length) : (n = e.length, i = t.length), this._isInResult = i === A.numMultiPolys && n < i;
        break;
      }
      case "xor": {
        const n = Math.abs(t.length - e.length);
        this._isInResult = n % 2 === 1;
        break;
      }
      case "difference": {
        const n = (i) => i.length === 1 && i[0].isSubject;
        this._isInResult = n(t) !== n(e);
        break;
      }
      default:
        throw new Error(`Unrecognized operation type found ${A.type}`);
    }
    return this._isInResult;
  }
}
class Et {
  constructor(t, e, n) {
    if (!Array.isArray(t) || t.length === 0)
      throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
    if (this.poly = e, this.isExterior = n, this.segments = [], typeof t[0][0] != "number" || typeof t[0][1] != "number")
      throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
    const i = q.round(t[0][0], t[0][1]);
    this.bbox = {
      ll: {
        x: i.x,
        y: i.y
      },
      ur: {
        x: i.x,
        y: i.y
      }
    };
    let s = i;
    for (let o = 1, l = t.length; o < l; o++) {
      if (typeof t[o][0] != "number" || typeof t[o][1] != "number")
        throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
      let u = q.round(t[o][0], t[o][1]);
      u.x === s.x && u.y === s.y || (this.segments.push(z.fromRing(s, u, this)), u.x < this.bbox.ll.x && (this.bbox.ll.x = u.x), u.y < this.bbox.ll.y && (this.bbox.ll.y = u.y), u.x > this.bbox.ur.x && (this.bbox.ur.x = u.x), u.y > this.bbox.ur.y && (this.bbox.ur.y = u.y), s = u);
    }
    (i.x !== s.x || i.y !== s.y) && this.segments.push(z.fromRing(s, i, this));
  }
  getSweepEvents() {
    const t = [];
    for (let e = 0, n = this.segments.length; e < n; e++) {
      const i = this.segments[e];
      t.push(i.leftSE), t.push(i.rightSE);
    }
    return t;
  }
}
class ke {
  constructor(t, e) {
    if (!Array.isArray(t))
      throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
    this.exteriorRing = new Et(t[0], this, !0), this.bbox = {
      ll: {
        x: this.exteriorRing.bbox.ll.x,
        y: this.exteriorRing.bbox.ll.y
      },
      ur: {
        x: this.exteriorRing.bbox.ur.x,
        y: this.exteriorRing.bbox.ur.y
      }
    }, this.interiorRings = [];
    for (let n = 1, i = t.length; n < i; n++) {
      const s = new Et(t[n], this, !1);
      s.bbox.ll.x < this.bbox.ll.x && (this.bbox.ll.x = s.bbox.ll.x), s.bbox.ll.y < this.bbox.ll.y && (this.bbox.ll.y = s.bbox.ll.y), s.bbox.ur.x > this.bbox.ur.x && (this.bbox.ur.x = s.bbox.ur.x), s.bbox.ur.y > this.bbox.ur.y && (this.bbox.ur.y = s.bbox.ur.y), this.interiorRings.push(s);
    }
    this.multiPoly = e;
  }
  getSweepEvents() {
    const t = this.exteriorRing.getSweepEvents();
    for (let e = 0, n = this.interiorRings.length; e < n; e++) {
      const i = this.interiorRings[e].getSweepEvents();
      for (let s = 0, o = i.length; s < o; s++)
        t.push(i[s]);
    }
    return t;
  }
}
class wt {
  constructor(t, e) {
    if (!Array.isArray(t))
      throw new Error("Input geometry is not a valid Polygon or MultiPolygon");
    try {
      typeof t[0][0][0] == "number" && (t = [t]);
    } catch {
    }
    this.polys = [], this.bbox = {
      ll: {
        x: Number.POSITIVE_INFINITY,
        y: Number.POSITIVE_INFINITY
      },
      ur: {
        x: Number.NEGATIVE_INFINITY,
        y: Number.NEGATIVE_INFINITY
      }
    };
    for (let n = 0, i = t.length; n < i; n++) {
      const s = new ke(t[n], this);
      s.bbox.ll.x < this.bbox.ll.x && (this.bbox.ll.x = s.bbox.ll.x), s.bbox.ll.y < this.bbox.ll.y && (this.bbox.ll.y = s.bbox.ll.y), s.bbox.ur.x > this.bbox.ur.x && (this.bbox.ur.x = s.bbox.ur.x), s.bbox.ur.y > this.bbox.ur.y && (this.bbox.ur.y = s.bbox.ur.y), this.polys.push(s);
    }
    this.isSubject = e;
  }
  getSweepEvents() {
    const t = [];
    for (let e = 0, n = this.polys.length; e < n; e++) {
      const i = this.polys[e].getSweepEvents();
      for (let s = 0, o = i.length; s < o; s++)
        t.push(i[s]);
    }
    return t;
  }
}
class J {
  /* Given the segments from the sweep line pass, compute & return a series
   * of closed rings from all the segments marked to be part of the result */
  static factory(t) {
    const e = [];
    for (let n = 0, i = t.length; n < i; n++) {
      const s = t[n];
      if (!s.isInResult() || s.ringOut) continue;
      let o = null, l = s.leftSE, u = s.rightSE;
      const f = [l], p = l.point, h = [];
      for (; o = l, l = u, f.push(l), l.point !== p; )
        for (; ; ) {
          const c = l.getAvailableLinkedEvents();
          if (c.length === 0) {
            const d = f[0].point, x = f[f.length - 1].point;
            throw new Error(`Unable to complete output ring starting at [${d.x}, ${d.y}]. Last matching segment found ends at [${x.x}, ${x.y}].`);
          }
          if (c.length === 1) {
            u = c[0].otherSE;
            break;
          }
          let a = null;
          for (let d = 0, x = h.length; d < x; d++)
            if (h[d].point === l.point) {
              a = d;
              break;
            }
          if (a !== null) {
            const d = h.splice(a)[0], x = f.splice(d.index);
            x.unshift(x[0].otherSE), e.push(new J(x.reverse()));
            continue;
          }
          h.push({
            index: f.length,
            point: l.point
          });
          const g = l.getLeftmostComparator(o);
          u = c.sort(g)[0].otherSE;
          break;
        }
      e.push(new J(f));
    }
    return e;
  }
  constructor(t) {
    this.events = t;
    for (let e = 0, n = t.length; e < n; e++)
      t[e].segment.ringOut = this;
    this.poly = null;
  }
  getGeom() {
    let t = this.events[0].point;
    const e = [t];
    for (let f = 1, p = this.events.length - 1; f < p; f++) {
      const h = this.events[f].point, c = this.events[f + 1].point;
      mt(h, t, c) !== 0 && (e.push(h), t = h);
    }
    if (e.length === 1) return null;
    const n = e[0], i = e[1];
    mt(n, t, i) === 0 && e.shift(), e.push(e[0]);
    const s = this.isExteriorRing() ? 1 : -1, o = this.isExteriorRing() ? 0 : e.length - 1, l = this.isExteriorRing() ? e.length : -1, u = [];
    for (let f = o; f != l; f += s) u.push([e[f].x, e[f].y]);
    return u;
  }
  isExteriorRing() {
    if (this._isExteriorRing === void 0) {
      const t = this.enclosingRing();
      this._isExteriorRing = t ? !t.isExteriorRing() : !0;
    }
    return this._isExteriorRing;
  }
  enclosingRing() {
    return this._enclosingRing === void 0 && (this._enclosingRing = this._calcEnclosingRing()), this._enclosingRing;
  }
  /* Returns the ring that encloses this one, if any */
  _calcEnclosingRing() {
    let t = this.events[0];
    for (let i = 1, s = this.events.length; i < s; i++) {
      const o = this.events[i];
      M.compare(t, o) > 0 && (t = o);
    }
    let e = t.segment.prevInResult(), n = e ? e.prevInResult() : null;
    for (; ; ) {
      if (!e) return null;
      if (!n) return e.ringOut;
      if (n.ringOut !== e.ringOut)
        return n.ringOut.enclosingRing() !== e.ringOut ? e.ringOut : e.ringOut.enclosingRing();
      e = n.prevInResult(), n = e ? e.prevInResult() : null;
    }
  }
}
class St {
  constructor(t) {
    this.exteriorRing = t, t.poly = this, this.interiorRings = [];
  }
  addInterior(t) {
    this.interiorRings.push(t), t.poly = this;
  }
  getGeom() {
    const t = [this.exteriorRing.getGeom()];
    if (t[0] === null) return null;
    for (let e = 0, n = this.interiorRings.length; e < n; e++) {
      const i = this.interiorRings[e].getGeom();
      i !== null && t.push(i);
    }
    return t;
  }
}
class Ie {
  constructor(t) {
    this.rings = t, this.polys = this._composePolys(t);
  }
  getGeom() {
    const t = [];
    for (let e = 0, n = this.polys.length; e < n; e++) {
      const i = this.polys[e].getGeom();
      i !== null && t.push(i);
    }
    return t;
  }
  _composePolys(t) {
    const e = [];
    for (let n = 0, i = t.length; n < i; n++) {
      const s = t[n];
      if (!s.poly)
        if (s.isExteriorRing()) e.push(new St(s));
        else {
          const o = s.enclosingRing();
          o.poly || e.push(new St(o)), o.poly.addInterior(s);
        }
    }
    return e;
  }
}
class Me {
  constructor(t) {
    let e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : z.compare;
    this.queue = t, this.tree = new ut(e), this.segments = [];
  }
  process(t) {
    const e = t.segment, n = [];
    if (t.consumedBy)
      return t.isLeft ? this.queue.remove(t.otherSE) : this.tree.remove(e), n;
    const i = t.isLeft ? this.tree.add(e) : this.tree.find(e);
    if (!i) throw new Error(`Unable to find segment #${e.id} [${e.leftSE.point.x}, ${e.leftSE.point.y}] -> [${e.rightSE.point.x}, ${e.rightSE.point.y}] in SweepLine tree.`);
    let s = i, o = i, l, u;
    for (; l === void 0; )
      s = this.tree.prev(s), s === null ? l = null : s.key.consumedBy === void 0 && (l = s.key);
    for (; u === void 0; )
      o = this.tree.next(o), o === null ? u = null : o.key.consumedBy === void 0 && (u = o.key);
    if (t.isLeft) {
      let f = null;
      if (l) {
        const h = l.getIntersection(e);
        if (h !== null && (e.isAnEndpoint(h) || (f = h), !l.isAnEndpoint(h))) {
          const c = this._splitSafely(l, h);
          for (let a = 0, g = c.length; a < g; a++)
            n.push(c[a]);
        }
      }
      let p = null;
      if (u) {
        const h = u.getIntersection(e);
        if (h !== null && (e.isAnEndpoint(h) || (p = h), !u.isAnEndpoint(h))) {
          const c = this._splitSafely(u, h);
          for (let a = 0, g = c.length; a < g; a++)
            n.push(c[a]);
        }
      }
      if (f !== null || p !== null) {
        let h = null;
        f === null ? h = p : p === null ? h = f : h = M.comparePoints(f, p) <= 0 ? f : p, this.queue.remove(e.rightSE), n.push(e.rightSE);
        const c = e.split(h);
        for (let a = 0, g = c.length; a < g; a++)
          n.push(c[a]);
      }
      n.length > 0 ? (this.tree.remove(e), n.push(t)) : (this.segments.push(e), e.prev = l);
    } else {
      if (l && u) {
        const f = l.getIntersection(u);
        if (f !== null) {
          if (!l.isAnEndpoint(f)) {
            const p = this._splitSafely(l, f);
            for (let h = 0, c = p.length; h < c; h++)
              n.push(p[h]);
          }
          if (!u.isAnEndpoint(f)) {
            const p = this._splitSafely(u, f);
            for (let h = 0, c = p.length; h < c; h++)
              n.push(p[h]);
          }
        }
      }
      this.tree.remove(e);
    }
    return n;
  }
  /* Safely split a segment that is currently in the datastructures
   * IE - a segment other than the one that is currently being processed. */
  _splitSafely(t, e) {
    this.tree.remove(t);
    const n = t.rightSE;
    this.queue.remove(n);
    const i = t.split(e);
    return i.push(n), t.consumedBy === void 0 && this.tree.add(t), i;
  }
}
const vt = typeof process < "u" && process.env.POLYGON_CLIPPING_MAX_QUEUE_SIZE || 1e6, Re = typeof process < "u" && process.env.POLYGON_CLIPPING_MAX_SWEEPLINE_SEGMENTS || 1e6;
class Pe {
  run(t, e, n) {
    A.type = t, q.reset();
    const i = [new wt(e, !0)];
    for (let h = 0, c = n.length; h < c; h++)
      i.push(new wt(n[h], !1));
    if (A.numMultiPolys = i.length, A.type === "difference") {
      const h = i[0];
      let c = 1;
      for (; c < i.length; )
        ot(i[c].bbox, h.bbox) !== null ? c++ : i.splice(c, 1);
    }
    if (A.type === "intersection")
      for (let h = 0, c = i.length; h < c; h++) {
        const a = i[h];
        for (let g = h + 1, d = i.length; g < d; g++)
          if (ot(a.bbox, i[g].bbox) === null) return [];
      }
    const s = new ut(M.compare);
    for (let h = 0, c = i.length; h < c; h++) {
      const a = i[h].getSweepEvents();
      for (let g = 0, d = a.length; g < d; g++)
        if (s.insert(a[g]), s.size > vt)
          throw new Error("Infinite loop when putting segment endpoints in a priority queue (queue size too big).");
    }
    const o = new Me(s);
    let l = s.size, u = s.pop();
    for (; u; ) {
      const h = u.key;
      if (s.size === l) {
        const a = h.segment;
        throw new Error(`Unable to pop() ${h.isLeft ? "left" : "right"} SweepEvent [${h.point.x}, ${h.point.y}] from segment #${a.id} [${a.leftSE.point.x}, ${a.leftSE.point.y}] -> [${a.rightSE.point.x}, ${a.rightSE.point.y}] from queue.`);
      }
      if (s.size > vt)
        throw new Error("Infinite loop when passing sweep line over endpoints (queue size too big).");
      if (o.segments.length > Re)
        throw new Error("Infinite loop when passing sweep line over endpoints (too many sweep line segments).");
      const c = o.process(h);
      for (let a = 0, g = c.length; a < g; a++) {
        const d = c[a];
        d.consumedBy === void 0 && s.insert(d);
      }
      l = s.size, u = s.pop();
    }
    q.reset();
    const f = J.factory(o.segments);
    return new Ie(f).getGeom();
  }
}
const A = new Pe(), Le = function(r) {
  for (var t = arguments.length, e = new Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++)
    e[n - 1] = arguments[n];
  return A.run("union", r, e);
}, Oe = function(r) {
  for (var t = arguments.length, e = new Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++)
    e[n - 1] = arguments[n];
  return A.run("intersection", r, e);
}, Ae = function(r) {
  for (var t = arguments.length, e = new Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++)
    e[n - 1] = arguments[n];
  return A.run("xor", r, e);
}, Ne = function(r) {
  for (var t = arguments.length, e = new Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++)
    e[n - 1] = arguments[n];
  return A.run("difference", r, e);
};
var kt = {
  union: Le,
  intersection: Oe,
  xor: Ae,
  difference: Ne
};
const It = 3, $e = 10, Ce = 1, Be = '<path d="M3.704 14.467a10 8 0 1 1 3.115 2.375"/><path d="M7 22a5 5 0 0 1-2-3.994"/><circle cx="5" cy="16" r="2"/>', ze = '<path d="M22 26h8M26 22v8"/>', Te = '<path d="M22 26h8"/>';
function lt(r = "") {
  const t = Be + r, e = r ? 24 : 16, n = e * 1.5, i = `<svg xmlns="http://www.w3.org/2000/svg" width="${e}" height="${e}" viewBox="0 0 ${n} ${n}" fill="none" stroke-linecap="round" stroke-linejoin="round"><g stroke="white" stroke-width="4">${t}</g><g stroke="black" stroke-width="2">${t}</g></svg>`;
  return `url("data:image/svg+xml,${encodeURIComponent(i)}") 5 15, crosshair`;
}
const je = lt(), Ge = {
  add: lt(ze),
  subtract: lt(Te)
}, Ye = `
	:host {
		position: absolute;
		display: none;
		z-index: 1;
		cursor: ${je};
		touch-action: none;
		user-select: none;
	}

	:host([hidden]) {
		display: none !important;
	}

	:host([disabled]) {
		pointer-events: none;
	}

	svg {
		position: absolute;
		inset: 0;
		width: 100%;
		height: 100%;
		overflow: visible;
		pointer-events: none;
	}

	polyline,
	polygon {
		display: none;
		fill: none;
		stroke-width: 1px;
	}

	#draft {
		stroke: var(--lasso-tool-color, var(--color-accent, #f97316));
	}

	/* Marching ants: black dashes over a white line. */
	#lasso {
		stroke: white;
	}

	#ants {
		stroke: black;
		stroke-dasharray: 4 4;
		animation: march 0.6s linear infinite;
	}

	:host([static]) #ants {
		animation: none;
	}

	@keyframes march {
		to {
			stroke-dashoffset: -8;
		}
	}
`;
class Fe extends HTMLElement {
  #t = null;
  /** As drawn, kept intact while browsing images. */
  #e = null;
  /** Resolution of the image lasso was drawn over. */
  #i = null;
  #S;
  #v;
  #k;
  /** Last emitted value, as JSON, to emit only changes. */
  #x = "null";
  /**
   * Element lasso is drawn within, e.g. the gallery: a drawing leaving it
   * is in fact a drag of image to another element.
   */
  area = null;
  /** Neighbors each vertex is averaged with on each side, to smooth the hand's jitter. */
  smoothing = 1;
  #m = ["", ""];
  #n = null;
  /** What lasso being drawn does to the current one, if not replace it. */
  #h = null;
  /** Operation of the shortcut held while pointer is over overlay, if any. */
  #p = null;
  /** Where user pressed, in client pixels, to tell a click from a move. */
  #b = null;
  /** Lasso as it was when user pressed, back if user cancels. */
  #d = null;
  /** Lasso being drawn, applied to the current one on release. */
  #r = null;
  /** Element outside overlay that pointer is over, while user drags image. */
  #s = null;
  /** Whether drop target accepts displayed image. */
  #g = !1;
  #u = null;
  #I = new ResizeObserver(() => this.#_());
  #M = () => this.#_();
  /** Escape cancels the lasso being drawn, and only that. */
  #R = (t) => {
    t.key === "Escape" && (t.preventDefault(), t.stopPropagation(), this.#A());
  };
  /** Tell what a drag would do, as user presses or releases a shortcut. */
  #y = (t) => {
    if (!this.matches(":hover")) {
      this.#L();
      return;
    }
    t.key === "Alt" && t.preventDefault(), this.#w(t);
  };
  constructor() {
    super();
    const t = this.attachShadow({ mode: "open" }), e = document.createElement("style");
    e.textContent = Ye;
    const n = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    n.innerHTML = '<polygon id="lasso"></polygon><polygon id="ants"></polygon><polyline id="draft"></polyline>', this.#S = n.querySelector("#draft"), this.#v = n.querySelector("#lasso"), this.#k = n.querySelector("#ants"), t.append(e, n), this.addEventListener("pointerenter", (i) => this.#$(i)), this.addEventListener("pointerleave", () => this.#L()), this.addEventListener("pointerdown", (i) => this.#C(i)), this.addEventListener("pointermove", (i) => this.#B(i)), this.addEventListener("pointerup", () => this.#z()), this.addEventListener("pointercancel", () => this.#T()), this.addEventListener("click", (i) => i.stopPropagation());
  }
  /**
   * Image to draw the lasso over. Lasso persists when another image is
   * displayed, scaled to its resolution, so user finds it back while
   * browsing images.
   */
  get target() {
    return this.#t;
  }
  set target(t) {
    this.#t !== t && (this.#t && (this.#I.unobserve(this.#t), this.#t.removeEventListener("load", this.#M)), this.#t = t, this.#l(), t && (this.#I.observe(t), t.addEventListener("load", this.#M))), this.#_();
  }
  /**
   * Tooltips shown over the image: while no lasso is drawn, e.g. to tell
   * how to draw one, then once drawn, e.g. to tell how to clear it.
   */
  get tooltips() {
    return this.#m;
  }
  set tooltips(t) {
    this.#m = t, this.#o();
  }
  /**
   * Lasso in pixels of the displayed image, scaled to it.
   * Setting it emits no event.
   */
  get value() {
    return this.#c();
  }
  set value(t) {
    this.#e = t && t.map(([e, n]) => [e, n]), this.#i = D(this.#t) ?? this.#i, this.#x = JSON.stringify(Lt(this.#c())), this.#l(), this.#o();
  }
  clear() {
    this.#e = null, this.#l(), this.#o(), this.#E();
  }
  /** Cover image content, letterbox bands excluded. */
  sync() {
    const t = this.#t, e = this.parentElement;
    if (!t?.isConnected || !e || !t.naturalWidth || !t.naturalHeight) {
      this.style.display = "none";
      return;
    }
    const n = t.getBoundingClientRect(), i = e.getBoundingClientRect(), s = Math.min(
      n.width / t.naturalWidth,
      n.height / t.naturalHeight
    ), o = t.naturalWidth * s, l = t.naturalHeight * s;
    if (o <= 0 || l <= 0) {
      this.style.display = "none";
      return;
    }
    const u = n.left - i.left - e.clientLeft + (n.width - o) / 2, f = n.top - i.top - e.clientTop + (n.height - l) / 2;
    this.style.display = "block", this.style.left = `${u}px`, this.style.top = `${f}px`, this.style.width = `${o}px`, this.style.height = `${l}px`;
  }
  /** Follow displayed image, which may be another one or resized. */
  #_() {
    this.#i ??= D(this.#t), this.sync(), this.#o(), this.#E();
  }
  /**
   * Lasso scaled to displayed image, whose resolution may differ from the
   * drawn one, so it surrounds the same region.
   */
  #c() {
    const t = this.#e, e = D(this.#t);
    if (!t || !e || !this.#i) return t;
    const n = e.width / this.#i.width, i = e.height / this.#i.height;
    return t.map(([s, o]) => [s * n, o * i]);
  }
  #P(t) {
    const e = this.#t, n = this.getBoundingClientRect(), i = Ot(t.clientX - n.left, 0, n.width), s = Ot(t.clientY - n.top, 0, n.height);
    return [
      i / n.width * e.naturalWidth,
      s / n.height * e.naturalHeight
    ];
  }
  #o() {
    const t = this.#t, e = !!D(t), n = e ? this.#c() : null, i = e && this.#n === "draw" && this.#r ? Mt(this.#r, this.#O()) : null;
    this.title = this.#m[n ? 1 : 0];
    for (const [s, o] of [
      [this.#S, i],
      [this.#v, n],
      [this.#k, n]
    ])
      s.style.display = o ? "inline" : "none", o && s.setAttribute("points", this.#N(o, t));
  }
  /** SVG points of vertices, in overlay pixels. */
  #N(t, e) {
    const n = this.clientWidth / e.naturalWidth, i = this.clientHeight / e.naturalHeight;
    return t.map(([s, o]) => `${s * n},${o * i}`).join(" ");
  }
  /** Emit value, if changed. */
  #E() {
    const t = Lt(this.#c()), e = JSON.stringify(t);
    e !== this.#x && (this.#x = e, this.dispatchEvent(new CustomEvent("lasso-change", { detail: t })));
  }
  #$(t) {
    window.addEventListener("keydown", this.#y, !0), window.addEventListener("keyup", this.#y, !0), this.#w(t);
  }
  #L() {
    window.removeEventListener("keydown", this.#y, !0), window.removeEventListener("keyup", this.#y, !0), this.#p = null, this.#f();
  }
  #w(t) {
    const e = Rt(t);
    e !== this.#p && (this.#p = e, this.#f());
  }
  /**
   * A click clears the lasso, and a drag draws a new one, which replaces
   * the current one at once and closes on release, or adds to it with Shift
   * held, or subtracts from it with Alt held. User may as well drag displayed
   * image to another element, e.g. a prompt left of the gallery: leaving the
   * area (gallery) turns the drawing into a drop.
   */
  #C(t) {
    !this.#t || t.button !== 0 || (t.preventDefault(), t.stopPropagation(), this.#l(), this.#e = this.#c(), this.#i = D(this.#t), this.#d = this.#e, this.#n = "press", this.#h = Rt(t), this.#b = [t.clientX, t.clientY], this.#r = [this.#P(t)], this.#f(), this.setPointerCapture(t.pointerId), window.addEventListener("keydown", this.#R, !0));
  }
  #B(t) {
    if (this.#w(t), !this.#t || !this.#n) return;
    if (this.#n === "press") {
      const [o, l] = this.#b;
      if (Math.hypot(t.clientX - o, t.clientY - l) <= $e)
        return;
      this.#n = "draw", this.#h || (this.#e = null);
    }
    if (this.#n === "draw" && this.#G(t) && (this.#n = "drop", this.#e = this.#d, this.#r = null, this.#o()), this.#n === "drop") {
      this.#Y(t);
      return;
    }
    const e = this.#P(t), n = this.#r, [i, s] = n[n.length - 1];
    Math.hypot(e[0] - i, e[1] - s) < Ce || (n.push(e), this.#o());
  }
  #z() {
    const t = this.#n;
    t === "press" ? this.#h ? this.#l() : this.clear() : t === "drop" ? (this.#g && (this.#a(this.#s, "drop"), this.#s = null), this.#l()) : t === "draw" && this.#j();
  }
  #T() {
    this.#n && this.#A();
  }
  /** Close lasso as drawn, unless it encloses nothing, and apply it. */
  #j() {
    const t = this.#r && Mt(this.#r, this.#O()), e = this.#h, n = this.#e;
    if (this.#l(), e)
      t && t.length >= It && (n ? this.#e = De(n, t, e) ?? n : this.#e = e === "add" ? t : null);
    else {
      if (!t || t.length < It) {
        this.clear();
        return;
      }
      this.#e = t;
    }
    this.#o(), this.#E();
  }
  #O() {
    return Math.max(0, Math.floor(this.smoothing)) || 0;
  }
  /** Back to lasso as it was before user pressed. */
  #A() {
    this.#e = this.#d, this.#l(), this.#o();
  }
  /** Forget ongoing gesture, if any. */
  #l() {
    this.#s && this.#a(this.#s, "dragleave"), window.removeEventListener("keydown", this.#R, !0), this.#n = null, this.#h = null, this.#b = null, this.#d = null, this.#r = null, this.#s = null, this.#g = !1, this.#u = null, this.#f();
  }
  /** Cursor of ongoing drop, if any, else of what a drag would do. */
  #f() {
    let t = "";
    if (this.#n === "drop")
      t = this.#g ? "copy" : "grabbing";
    else {
      const e = this.#n ? this.#h : this.#p;
      e && (t = Ge[e]);
    }
    this.style.cursor = t;
  }
  /** Whether pointer left the area lasso is drawn within. */
  #G(t) {
    const e = (this.area ?? this).getBoundingClientRect();
    return t.clientX < e.left || t.clientX > e.right || t.clientY < e.top || t.clientY > e.bottom;
  }
  /**
   * Drag displayed image over the element pointer is over, outside overlay,
   * as browser would do. Overlay can't let browser drag the image itself:
   * it would take any drag over it, those drawing the lasso included.
   */
  #Y(t) {
    const e = document.elementFromPoint(t.clientX, t.clientY), n = e === this ? null : e;
    n !== this.#s && (n && this.#a(n, "dragenter"), this.#s && this.#a(this.#s, "dragleave"), this.#s = n), this.#g = !!n && !this.#a(n, "dragover"), this.#f();
  }
  /** Returns false if canceled. */
  #a(t, e) {
    return this.#u || (this.#u = new DataTransfer(), this.#u.setData("text/uri-list", this.#t.currentSrc)), t.dispatchEvent(
      new DragEvent(e, {
        bubbles: !0,
        cancelable: !0,
        composed: !0,
        dataTransfer: this.#u
      })
    );
  }
}
function Mt(r, t) {
  const e = r.length;
  return t === 0 ? r : r.map((n, i) => {
    const s = Math.min(t, i, e - 1 - i);
    let [o, l] = [0, 0];
    for (let f = i - s; f <= i + s; f++)
      o += r[f][0], l += r[f][1];
    const u = 2 * s + 1;
    return [o / u, l / u];
  });
}
function Rt(r) {
  return r.shiftKey ? "add" : r.altKey ? "subtract" : null;
}
function De(r, t, e) {
  let n;
  try {
    n = e === "add" ? kt.union([r], [t]) : kt.difference([r], [t]);
  } catch (o) {
    return console.warn("Lasso tool couldn't combine lassos:", o), null;
  }
  const i = n.map((o) => o[0]);
  return i.length ? i.reduce((o, l) => Pt(l) > Pt(o) ? l : o).slice(0, -1).map(([o, l]) => [o, l]) : null;
}
function Pt(r) {
  let t = 0;
  for (let e = 0; e < r.length; e++) {
    const [n, i] = r[e], [s, o] = r[(e + 1) % r.length];
    t += n * o - s * i;
  }
  return Math.abs(t) / 2;
}
function D(r) {
  return r?.naturalWidth && r.naturalHeight ? { width: r.naturalWidth, height: r.naturalHeight } : null;
}
function Lt(r) {
  return r && r.map(([t, e]) => [Math.round(t), Math.round(e)]);
}
function Ot(r, t, e) {
  return Math.max(t, Math.min(e, r));
}
const ht = "lasso-tool-overlay";
customElements.get(ht) || customElements.define(ht, Fe);
function Ue(r, t) {
  Xt(t, !0);
  const e = /* @__PURE__ */ Kt(t, ["$$slots", "$$events", "$$legacy"]), n = new oe(e), i = document.createElement(ht);
  let s = n.props.value ?? null;
  i.value = s;
  let o = null;
  function l(h, c) {
    return JSON.stringify(h ?? null) === JSON.stringify(c ?? null);
  }
  function u(h, c) {
    !h && c ? n.dispatch("drawn") : h && !c && n.dispatch("cleared");
  }
  function f(h) {
    const c = h.querySelector('.media-button img[data-testid="detailed-image"]');
    if (!c) {
      i.target = null, i.remove();
      return;
    }
    const a = c.parentElement;
    i.parentElement !== a && a.append(i), i.area = h, i.target = c;
  }
  function p() {
    const h = n.props.gallery_elem_id, c = h ? document.getElementById(h) : null;
    if (o?.disconnect(), !c) {
      if (!h) return;
      o = new MutationObserver(p), o.observe(document.body, { childList: !0, subtree: !0 });
      return;
    }
    o = new MutationObserver(() => f(c)), o.observe(c, {
      childList: !0,
      subtree: !0,
      attributes: !0,
      attributeFilter: ["src"]
    }), f(c);
  }
  $t(() => {
    i.addEventListener("lasso-change", (h) => {
      const c = h.detail;
      u(s, c), s = c, n.props.value = c, n.dispatch("input"), n.dispatch("change");
    }), p();
  }), te(() => {
    o?.disconnect(), i.target = null, i.remove();
  }), G(() => {
    const h = n.props.value ?? null;
    l(h, s) || (u(s, h), s = h, i.value = h, n.dispatch("change"));
  }), G(() => {
    i.toggleAttribute("disabled", n.shared.interactive === !1), i.toggleAttribute("hidden", n.shared.visible === !1), i.toggleAttribute("static", n.props.marching_ants === !1), i.smoothing = n.props.smoothing ?? 1, i.tooltips = [
      n.props.draw_tooltip ?? "",
      n.props.clear_tooltip ?? ""
    ];
  }), Ut();
}
export {
  Ue as default
};
